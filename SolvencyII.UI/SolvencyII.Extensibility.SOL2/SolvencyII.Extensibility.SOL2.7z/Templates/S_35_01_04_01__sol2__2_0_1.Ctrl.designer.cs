using SolvencyII.Domain.ENumerators; 
using SolvencyII.UI.Shared.Controls; 

namespace SolvencyII.UI.UserControls 
{ 
   partial class S_35_01_04_01__sol2__2_0_1_ctrl 
   { 
      private void InitializeComponent() 
      { 
this.solvencyLabel0 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel1 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel2 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel3 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel4 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel5 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel6 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel7 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel8 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel9 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel10 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel11 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel12 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel13 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel14 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel15 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel16 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel17 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel18 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel19 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel20 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel21 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel22 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel23 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel24 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel25 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel26 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel27 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel28 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel29 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel30 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel31 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel32 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel33 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel34 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel35 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel36 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel37 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel38 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel39 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel40 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel41 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel42 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel43 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel44 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel45 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel46 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel47 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel48 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel49 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel50 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel51 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel52 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel53 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel54 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel55 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel56 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel57 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel58 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel59 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel60 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel62 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyTextBox63 = new SolvencyII.UI.Shared.Controls.SolvencyTextBox();
this.solvencyTextBox64 = new SolvencyII.UI.Shared.Controls.SolvencyTextBox();
this.SolvencyDataComboBox65 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox66 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox67 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox68 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox69 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox70 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox71 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox72 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox73 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox74 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox75 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox76 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox77 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox78 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox79 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox80 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox81 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox82 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox83 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox84 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox85 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox86 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox87 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.splitContainerColTitles = new SolvencyII.UI.Shared.Controls.SolvencySplitContainer();
this.splitContainerRowTitles = new SolvencyII.UI.Shared.Controls.SolvencySplitContainer();
this.spltMain = new SolvencyII.UI.Shared.Controls.SolvencySplitContainer();
            this.SuspendLayout(); 

//
// solvencyLabel0
//
this.solvencyLabel0.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel0.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel0.Location = new System.Drawing.Point(2678,85);
this.solvencyLabel0.Name = "solvencyLabel0";
this.solvencyLabel0.OrdinateID_Label = 8731;
this.solvencyLabel0.Size = new System.Drawing.Size(108, 30);
this.solvencyLabel0.TabIndex = 0;
this.solvencyLabel0.Text = "Amount of TP gross of IGT" ;
this.solvencyLabel0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel0.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel1
//
this.solvencyLabel1.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel1.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel1.Location = new System.Drawing.Point(2678,115);
this.solvencyLabel1.Name = "solvencyLabel1";
this.solvencyLabel1.OrdinateID_Label = 0;
this.solvencyLabel1.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel1.TabIndex = 1;
this.solvencyLabel1.Text = "C0260" ;
this.solvencyLabel1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel2
//
this.solvencyLabel2.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel2.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel2.Location = new System.Drawing.Point(2678,10);
this.solvencyLabel2.Name = "solvencyLabel2";
this.solvencyLabel2.OrdinateID_Label = 8730;
this.solvencyLabel2.Size = new System.Drawing.Size(108, 105);
this.solvencyLabel2.TabIndex = 2;
this.solvencyLabel2.Text = "LTG measures and transitionals - Technical Provisions subject to Matching Adjustment" ;
this.solvencyLabel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel3
//
this.solvencyLabel3.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel3.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel3.Location = new System.Drawing.Point(2571,85);
this.solvencyLabel3.Name = "solvencyLabel3";
this.solvencyLabel3.OrdinateID_Label = 8729;
this.solvencyLabel3.Size = new System.Drawing.Size(108, 30);
this.solvencyLabel3.TabIndex = 3;
this.solvencyLabel3.Text = "Amount of TP gross of IGT" ;
this.solvencyLabel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel4
//
this.solvencyLabel4.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel4.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel4.Location = new System.Drawing.Point(2571,115);
this.solvencyLabel4.Name = "solvencyLabel4";
this.solvencyLabel4.OrdinateID_Label = 0;
this.solvencyLabel4.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel4.TabIndex = 4;
this.solvencyLabel4.Text = "C0250" ;
this.solvencyLabel4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel5
//
this.solvencyLabel5.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel5.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel5.Location = new System.Drawing.Point(2571,10);
this.solvencyLabel5.Name = "solvencyLabel5";
this.solvencyLabel5.OrdinateID_Label = 8728;
this.solvencyLabel5.Size = new System.Drawing.Size(108, 105);
this.solvencyLabel5.TabIndex = 5;
this.solvencyLabel5.Text = "LTG measures and transitionals - Technical Provisions subject to Volatility Adjustment" ;
this.solvencyLabel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel6
//
this.solvencyLabel6.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel6.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel6.Location = new System.Drawing.Point(2464,85);
this.solvencyLabel6.Name = "solvencyLabel6";
this.solvencyLabel6.OrdinateID_Label = 8727;
this.solvencyLabel6.Size = new System.Drawing.Size(108, 30);
this.solvencyLabel6.TabIndex = 6;
this.solvencyLabel6.Text = "Amount of TP gross of IGT" ;
this.solvencyLabel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel6.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel7
//
this.solvencyLabel7.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel7.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel7.Location = new System.Drawing.Point(2464,115);
this.solvencyLabel7.Name = "solvencyLabel7";
this.solvencyLabel7.OrdinateID_Label = 0;
this.solvencyLabel7.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel7.TabIndex = 7;
this.solvencyLabel7.Text = "C0240" ;
this.solvencyLabel7.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel8
//
this.solvencyLabel8.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel8.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel8.Location = new System.Drawing.Point(2464,10);
this.solvencyLabel8.Name = "solvencyLabel8";
this.solvencyLabel8.OrdinateID_Label = 8726;
this.solvencyLabel8.Size = new System.Drawing.Size(108, 105);
this.solvencyLabel8.TabIndex = 8;
this.solvencyLabel8.Text = "LTG measures and transitionals - Technical Provisions subject to Transitional on Risk Free Rate" ;
this.solvencyLabel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel8.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel9
//
this.solvencyLabel9.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel9.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel9.Location = new System.Drawing.Point(2357,85);
this.solvencyLabel9.Name = "solvencyLabel9";
this.solvencyLabel9.OrdinateID_Label = 8725;
this.solvencyLabel9.Size = new System.Drawing.Size(108, 30);
this.solvencyLabel9.TabIndex = 9;
this.solvencyLabel9.Text = "Amount of TP net of IGT" ;
this.solvencyLabel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel9.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel10
//
this.solvencyLabel10.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel10.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel10.Location = new System.Drawing.Point(2357,115);
this.solvencyLabel10.Name = "solvencyLabel10";
this.solvencyLabel10.OrdinateID_Label = 0;
this.solvencyLabel10.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel10.TabIndex = 10;
this.solvencyLabel10.Text = "C0230" ;
this.solvencyLabel10.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel11
//
this.solvencyLabel11.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel11.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel11.Location = new System.Drawing.Point(2250,85);
this.solvencyLabel11.Name = "solvencyLabel11";
this.solvencyLabel11.OrdinateID_Label = 8724;
this.solvencyLabel11.Size = new System.Drawing.Size(108, 30);
this.solvencyLabel11.TabIndex = 11;
this.solvencyLabel11.Text = "Amount of TP gross of IGT" ;
this.solvencyLabel11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel11.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel12
//
this.solvencyLabel12.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel12.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel12.Location = new System.Drawing.Point(2250,115);
this.solvencyLabel12.Name = "solvencyLabel12";
this.solvencyLabel12.OrdinateID_Label = 0;
this.solvencyLabel12.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel12.TabIndex = 12;
this.solvencyLabel12.Text = "C0220" ;
this.solvencyLabel12.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel13
//
this.solvencyLabel13.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel13.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel13.Location = new System.Drawing.Point(2250,10);
this.solvencyLabel13.Name = "solvencyLabel13";
this.solvencyLabel13.OrdinateID_Label = 8723;
this.solvencyLabel13.Size = new System.Drawing.Size(215, 105);
this.solvencyLabel13.TabIndex = 13;
this.solvencyLabel13.Text = "Transitional on Technical Provisions" ;
this.solvencyLabel13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel13.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel14
//
this.solvencyLabel14.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel14.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel14.Location = new System.Drawing.Point(2143,85);
this.solvencyLabel14.Name = "solvencyLabel14";
this.solvencyLabel14.OrdinateID_Label = 8722;
this.solvencyLabel14.Size = new System.Drawing.Size(108, 30);
this.solvencyLabel14.TabIndex = 14;
this.solvencyLabel14.Text = "Net contribution to Group TP (%)" ;
this.solvencyLabel14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel14.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel15
//
this.solvencyLabel15.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel15.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel15.Location = new System.Drawing.Point(2143,115);
this.solvencyLabel15.Name = "solvencyLabel15";
this.solvencyLabel15.OrdinateID_Label = 0;
this.solvencyLabel15.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel15.TabIndex = 15;
this.solvencyLabel15.Text = "C0210" ;
this.solvencyLabel15.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel16
//
this.solvencyLabel16.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel16.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel16.Location = new System.Drawing.Point(2036,85);
this.solvencyLabel16.Name = "solvencyLabel16";
this.solvencyLabel16.OrdinateID_Label = 8721;
this.solvencyLabel16.Size = new System.Drawing.Size(108, 30);
this.solvencyLabel16.TabIndex = 16;
this.solvencyLabel16.Text = "Amount of TP net of IGT" ;
this.solvencyLabel16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel16.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel17
//
this.solvencyLabel17.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel17.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel17.Location = new System.Drawing.Point(2036,115);
this.solvencyLabel17.Name = "solvencyLabel17";
this.solvencyLabel17.OrdinateID_Label = 0;
this.solvencyLabel17.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel17.TabIndex = 17;
this.solvencyLabel17.Text = "C0200" ;
this.solvencyLabel17.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel18
//
this.solvencyLabel18.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel18.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel18.Location = new System.Drawing.Point(1929,85);
this.solvencyLabel18.Name = "solvencyLabel18";
this.solvencyLabel18.OrdinateID_Label = 8720;
this.solvencyLabel18.Size = new System.Drawing.Size(108, 30);
this.solvencyLabel18.TabIndex = 18;
this.solvencyLabel18.Text = "Amount of TP gross of IGT" ;
this.solvencyLabel18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel18.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel19
//
this.solvencyLabel19.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel19.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel19.Location = new System.Drawing.Point(1929,115);
this.solvencyLabel19.Name = "solvencyLabel19";
this.solvencyLabel19.OrdinateID_Label = 0;
this.solvencyLabel19.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel19.TabIndex = 19;
this.solvencyLabel19.Text = "C0190" ;
this.solvencyLabel19.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel20
//
this.solvencyLabel20.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel20.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel20.Location = new System.Drawing.Point(1929,10);
this.solvencyLabel20.Name = "solvencyLabel20";
this.solvencyLabel20.OrdinateID_Label = 8719;
this.solvencyLabel20.Size = new System.Drawing.Size(322, 105);
this.solvencyLabel20.TabIndex = 20;
this.solvencyLabel20.Text = "Technical Provisions - Index-linked and unit-linked insurance" ;
this.solvencyLabel20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel20.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel21
//
this.solvencyLabel21.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel21.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel21.Location = new System.Drawing.Point(1822,85);
this.solvencyLabel21.Name = "solvencyLabel21";
this.solvencyLabel21.OrdinateID_Label = 8718;
this.solvencyLabel21.Size = new System.Drawing.Size(108, 30);
this.solvencyLabel21.TabIndex = 21;
this.solvencyLabel21.Text = "Net contribution to Group TP (%)" ;
this.solvencyLabel21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel21.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel22
//
this.solvencyLabel22.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel22.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel22.Location = new System.Drawing.Point(1822,115);
this.solvencyLabel22.Name = "solvencyLabel22";
this.solvencyLabel22.OrdinateID_Label = 0;
this.solvencyLabel22.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel22.TabIndex = 22;
this.solvencyLabel22.Text = "C0180" ;
this.solvencyLabel22.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel23
//
this.solvencyLabel23.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel23.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel23.Location = new System.Drawing.Point(1715,85);
this.solvencyLabel23.Name = "solvencyLabel23";
this.solvencyLabel23.OrdinateID_Label = 8717;
this.solvencyLabel23.Size = new System.Drawing.Size(108, 30);
this.solvencyLabel23.TabIndex = 23;
this.solvencyLabel23.Text = "Amount of TP net of IGT" ;
this.solvencyLabel23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel23.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel24
//
this.solvencyLabel24.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel24.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel24.Location = new System.Drawing.Point(1715,115);
this.solvencyLabel24.Name = "solvencyLabel24";
this.solvencyLabel24.OrdinateID_Label = 0;
this.solvencyLabel24.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel24.TabIndex = 24;
this.solvencyLabel24.Text = "C0170" ;
this.solvencyLabel24.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel25
//
this.solvencyLabel25.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel25.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel25.Location = new System.Drawing.Point(1608,85);
this.solvencyLabel25.Name = "solvencyLabel25";
this.solvencyLabel25.OrdinateID_Label = 8716;
this.solvencyLabel25.Size = new System.Drawing.Size(108, 30);
this.solvencyLabel25.TabIndex = 25;
this.solvencyLabel25.Text = "Amount of TP gross of IGT" ;
this.solvencyLabel25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel25.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel26
//
this.solvencyLabel26.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel26.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel26.Location = new System.Drawing.Point(1608,115);
this.solvencyLabel26.Name = "solvencyLabel26";
this.solvencyLabel26.OrdinateID_Label = 0;
this.solvencyLabel26.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel26.TabIndex = 26;
this.solvencyLabel26.Text = "C0160" ;
this.solvencyLabel26.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel27
//
this.solvencyLabel27.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel27.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel27.Location = new System.Drawing.Point(1608,10);
this.solvencyLabel27.Name = "solvencyLabel27";
this.solvencyLabel27.OrdinateID_Label = 8715;
this.solvencyLabel27.Size = new System.Drawing.Size(322, 105);
this.solvencyLabel27.TabIndex = 27;
this.solvencyLabel27.Text = "Technical Provisions - Life (excluding health and index-linked and unit-linked)" ;
this.solvencyLabel27.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel27.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel28
//
this.solvencyLabel28.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel28.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel28.Location = new System.Drawing.Point(1501,85);
this.solvencyLabel28.Name = "solvencyLabel28";
this.solvencyLabel28.OrdinateID_Label = 8714;
this.solvencyLabel28.Size = new System.Drawing.Size(108, 30);
this.solvencyLabel28.TabIndex = 28;
this.solvencyLabel28.Text = "Net contribution to Group TP (%)" ;
this.solvencyLabel28.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel28.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel29
//
this.solvencyLabel29.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel29.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel29.Location = new System.Drawing.Point(1501,115);
this.solvencyLabel29.Name = "solvencyLabel29";
this.solvencyLabel29.OrdinateID_Label = 0;
this.solvencyLabel29.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel29.TabIndex = 29;
this.solvencyLabel29.Text = "C0150" ;
this.solvencyLabel29.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel30
//
this.solvencyLabel30.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel30.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel30.Location = new System.Drawing.Point(1394,85);
this.solvencyLabel30.Name = "solvencyLabel30";
this.solvencyLabel30.OrdinateID_Label = 8713;
this.solvencyLabel30.Size = new System.Drawing.Size(108, 30);
this.solvencyLabel30.TabIndex = 30;
this.solvencyLabel30.Text = "Amount of TP net of IGT" ;
this.solvencyLabel30.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel30.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel31
//
this.solvencyLabel31.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel31.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel31.Location = new System.Drawing.Point(1394,115);
this.solvencyLabel31.Name = "solvencyLabel31";
this.solvencyLabel31.OrdinateID_Label = 0;
this.solvencyLabel31.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel31.TabIndex = 31;
this.solvencyLabel31.Text = "C0140" ;
this.solvencyLabel31.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel32
//
this.solvencyLabel32.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel32.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel32.Location = new System.Drawing.Point(1287,85);
this.solvencyLabel32.Name = "solvencyLabel32";
this.solvencyLabel32.OrdinateID_Label = 8712;
this.solvencyLabel32.Size = new System.Drawing.Size(108, 30);
this.solvencyLabel32.TabIndex = 32;
this.solvencyLabel32.Text = "Amount of TP gross of IGT" ;
this.solvencyLabel32.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel32.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel33
//
this.solvencyLabel33.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel33.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel33.Location = new System.Drawing.Point(1287,115);
this.solvencyLabel33.Name = "solvencyLabel33";
this.solvencyLabel33.OrdinateID_Label = 0;
this.solvencyLabel33.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel33.TabIndex = 33;
this.solvencyLabel33.Text = "C0130" ;
this.solvencyLabel33.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel34
//
this.solvencyLabel34.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel34.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel34.Location = new System.Drawing.Point(1287,10);
this.solvencyLabel34.Name = "solvencyLabel34";
this.solvencyLabel34.OrdinateID_Label = 8711;
this.solvencyLabel34.Size = new System.Drawing.Size(322, 105);
this.solvencyLabel34.TabIndex = 34;
this.solvencyLabel34.Text = "Technical Provisions - Health (similar to life)" ;
this.solvencyLabel34.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel34.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel35
//
this.solvencyLabel35.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel35.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel35.Location = new System.Drawing.Point(1180,85);
this.solvencyLabel35.Name = "solvencyLabel35";
this.solvencyLabel35.OrdinateID_Label = 8710;
this.solvencyLabel35.Size = new System.Drawing.Size(108, 30);
this.solvencyLabel35.TabIndex = 35;
this.solvencyLabel35.Text = "Net contribution to Group TP (%)" ;
this.solvencyLabel35.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel35.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel36
//
this.solvencyLabel36.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel36.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel36.Location = new System.Drawing.Point(1180,115);
this.solvencyLabel36.Name = "solvencyLabel36";
this.solvencyLabel36.OrdinateID_Label = 0;
this.solvencyLabel36.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel36.TabIndex = 36;
this.solvencyLabel36.Text = "C0120" ;
this.solvencyLabel36.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel37
//
this.solvencyLabel37.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel37.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel37.Location = new System.Drawing.Point(1073,85);
this.solvencyLabel37.Name = "solvencyLabel37";
this.solvencyLabel37.OrdinateID_Label = 8709;
this.solvencyLabel37.Size = new System.Drawing.Size(108, 30);
this.solvencyLabel37.TabIndex = 37;
this.solvencyLabel37.Text = "Amount of TP net of IGT" ;
this.solvencyLabel37.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel37.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel38
//
this.solvencyLabel38.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel38.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel38.Location = new System.Drawing.Point(1073,115);
this.solvencyLabel38.Name = "solvencyLabel38";
this.solvencyLabel38.OrdinateID_Label = 0;
this.solvencyLabel38.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel38.TabIndex = 38;
this.solvencyLabel38.Text = "C0110" ;
this.solvencyLabel38.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel39
//
this.solvencyLabel39.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel39.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel39.Location = new System.Drawing.Point(966,85);
this.solvencyLabel39.Name = "solvencyLabel39";
this.solvencyLabel39.OrdinateID_Label = 8708;
this.solvencyLabel39.Size = new System.Drawing.Size(108, 30);
this.solvencyLabel39.TabIndex = 39;
this.solvencyLabel39.Text = "Amount of TP gross of IGT" ;
this.solvencyLabel39.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel39.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel40
//
this.solvencyLabel40.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel40.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel40.Location = new System.Drawing.Point(966,115);
this.solvencyLabel40.Name = "solvencyLabel40";
this.solvencyLabel40.OrdinateID_Label = 0;
this.solvencyLabel40.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel40.TabIndex = 40;
this.solvencyLabel40.Text = "C0100" ;
this.solvencyLabel40.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel41
//
this.solvencyLabel41.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel41.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel41.Location = new System.Drawing.Point(966,10);
this.solvencyLabel41.Name = "solvencyLabel41";
this.solvencyLabel41.OrdinateID_Label = 8707;
this.solvencyLabel41.Size = new System.Drawing.Size(322, 105);
this.solvencyLabel41.TabIndex = 41;
this.solvencyLabel41.Text = "Technical Provisions - Health (similar to non-life)" ;
this.solvencyLabel41.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel41.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel42
//
this.solvencyLabel42.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel42.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel42.Location = new System.Drawing.Point(859,85);
this.solvencyLabel42.Name = "solvencyLabel42";
this.solvencyLabel42.OrdinateID_Label = 8706;
this.solvencyLabel42.Size = new System.Drawing.Size(108, 30);
this.solvencyLabel42.TabIndex = 42;
this.solvencyLabel42.Text = "Net contribution to Group TP (%)" ;
this.solvencyLabel42.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel42.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel43
//
this.solvencyLabel43.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel43.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel43.Location = new System.Drawing.Point(859,115);
this.solvencyLabel43.Name = "solvencyLabel43";
this.solvencyLabel43.OrdinateID_Label = 0;
this.solvencyLabel43.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel43.TabIndex = 43;
this.solvencyLabel43.Text = "C0090" ;
this.solvencyLabel43.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel44
//
this.solvencyLabel44.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel44.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel44.Location = new System.Drawing.Point(752,85);
this.solvencyLabel44.Name = "solvencyLabel44";
this.solvencyLabel44.OrdinateID_Label = 8705;
this.solvencyLabel44.Size = new System.Drawing.Size(108, 30);
this.solvencyLabel44.TabIndex = 44;
this.solvencyLabel44.Text = "Amount of TP net of IGT" ;
this.solvencyLabel44.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel44.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel45
//
this.solvencyLabel45.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel45.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel45.Location = new System.Drawing.Point(752,115);
this.solvencyLabel45.Name = "solvencyLabel45";
this.solvencyLabel45.OrdinateID_Label = 0;
this.solvencyLabel45.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel45.TabIndex = 45;
this.solvencyLabel45.Text = "C0080" ;
this.solvencyLabel45.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel46
//
this.solvencyLabel46.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel46.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel46.Location = new System.Drawing.Point(645,85);
this.solvencyLabel46.Name = "solvencyLabel46";
this.solvencyLabel46.OrdinateID_Label = 8704;
this.solvencyLabel46.Size = new System.Drawing.Size(108, 30);
this.solvencyLabel46.TabIndex = 46;
this.solvencyLabel46.Text = "Amount of TP gross of IGT" ;
this.solvencyLabel46.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel46.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel47
//
this.solvencyLabel47.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel47.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel47.Location = new System.Drawing.Point(645,115);
this.solvencyLabel47.Name = "solvencyLabel47";
this.solvencyLabel47.OrdinateID_Label = 0;
this.solvencyLabel47.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel47.TabIndex = 47;
this.solvencyLabel47.Text = "C0070" ;
this.solvencyLabel47.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel48
//
this.solvencyLabel48.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel48.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel48.Location = new System.Drawing.Point(645,10);
this.solvencyLabel48.Name = "solvencyLabel48";
this.solvencyLabel48.OrdinateID_Label = 8703;
this.solvencyLabel48.Size = new System.Drawing.Size(322, 105);
this.solvencyLabel48.TabIndex = 48;
this.solvencyLabel48.Text = "Technical Provisions - Non-Life (excluding Health)" ;
this.solvencyLabel48.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel48.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel49
//
this.solvencyLabel49.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel49.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel49.Location = new System.Drawing.Point(538,85);
this.solvencyLabel49.Name = "solvencyLabel49";
this.solvencyLabel49.OrdinateID_Label = 8702;
this.solvencyLabel49.Size = new System.Drawing.Size(108, 30);
this.solvencyLabel49.TabIndex = 49;
this.solvencyLabel49.Text = "Amount of TP net of IGT" ;
this.solvencyLabel49.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel49.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel50
//
this.solvencyLabel50.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel50.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel50.Location = new System.Drawing.Point(538,115);
this.solvencyLabel50.Name = "solvencyLabel50";
this.solvencyLabel50.OrdinateID_Label = 0;
this.solvencyLabel50.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel50.TabIndex = 50;
this.solvencyLabel50.Text = "C0060" ;
this.solvencyLabel50.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel51
//
this.solvencyLabel51.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel51.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel51.Location = new System.Drawing.Point(431,85);
this.solvencyLabel51.Name = "solvencyLabel51";
this.solvencyLabel51.OrdinateID_Label = 8701;
this.solvencyLabel51.Size = new System.Drawing.Size(108, 30);
this.solvencyLabel51.TabIndex = 51;
this.solvencyLabel51.Text = "Amount of TP gross of IGT" ;
this.solvencyLabel51.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel51.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel52
//
this.solvencyLabel52.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel52.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel52.Location = new System.Drawing.Point(431,115);
this.solvencyLabel52.Name = "solvencyLabel52";
this.solvencyLabel52.OrdinateID_Label = 0;
this.solvencyLabel52.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel52.TabIndex = 52;
this.solvencyLabel52.Text = "C0050" ;
this.solvencyLabel52.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel53
//
this.solvencyLabel53.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel53.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel53.Location = new System.Drawing.Point(431,10);
this.solvencyLabel53.Name = "solvencyLabel53";
this.solvencyLabel53.OrdinateID_Label = 8700;
this.solvencyLabel53.Size = new System.Drawing.Size(215, 105);
this.solvencyLabel53.TabIndex = 53;
this.solvencyLabel53.Text = "Total amount of TP" ;
this.solvencyLabel53.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel53.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel54
//
this.solvencyLabel54.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel54.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel54.Location = new System.Drawing.Point(224,10);
this.solvencyLabel54.Name = "solvencyLabel54";
this.solvencyLabel54.OrdinateID_Label = 8699;
this.solvencyLabel54.Size = new System.Drawing.Size(208, 105);
this.solvencyLabel54.TabIndex = 54;
this.solvencyLabel54.Text = "Method of group solvency calculation used" ;
this.solvencyLabel54.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel54.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel55
//
this.solvencyLabel55.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel55.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel55.Location = new System.Drawing.Point(224,115);
this.solvencyLabel55.Name = "solvencyLabel55";
this.solvencyLabel55.OrdinateID_Label = 0;
this.solvencyLabel55.Size = new System.Drawing.Size(208, 13);
this.solvencyLabel55.TabIndex = 55;
this.solvencyLabel55.Text = "C0040" ;
this.solvencyLabel55.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel56
//
this.solvencyLabel56.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel56.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel56.Location = new System.Drawing.Point(117,10);
this.solvencyLabel56.Name = "solvencyLabel56";
this.solvencyLabel56.OrdinateID_Label = 8698;
this.solvencyLabel56.Size = new System.Drawing.Size(108, 105);
this.solvencyLabel56.TabIndex = 56;
this.solvencyLabel56.Text = "Legal name of each undertaking" ;
this.solvencyLabel56.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel56.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel57
//
this.solvencyLabel57.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel57.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel57.Location = new System.Drawing.Point(117,115);
this.solvencyLabel57.Name = "solvencyLabel57";
this.solvencyLabel57.OrdinateID_Label = 0;
this.solvencyLabel57.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel57.TabIndex = 57;
this.solvencyLabel57.Text = "C0010" ;
this.solvencyLabel57.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel58
//
this.solvencyLabel58.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel58.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel58.Location = new System.Drawing.Point(10,10);
this.solvencyLabel58.Name = "solvencyLabel58";
this.solvencyLabel58.OrdinateID_Label = 8732;
this.solvencyLabel58.Size = new System.Drawing.Size(108, 105);
this.solvencyLabel58.TabIndex = 58;
this.solvencyLabel58.Text = "Identification code of the undertaking" ;
this.solvencyLabel58.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel58.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel59
//
this.solvencyLabel59.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel59.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel59.Location = new System.Drawing.Point(10,115);
this.solvencyLabel59.Name = "solvencyLabel59";
this.solvencyLabel59.OrdinateID_Label = 0;
this.solvencyLabel59.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel59.TabIndex = 59;
this.solvencyLabel59.Text = "C0020" ;
this.solvencyLabel59.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel60
//
this.solvencyLabel60.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel60.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel60.Location = new System.Drawing.Point(3,3);
this.solvencyLabel60.Name = "solvencyLabel60";
this.solvencyLabel60.OrdinateID_Label = 0;
this.solvencyLabel60.Size = new System.Drawing.Size(21, 0);
this.solvencyLabel60.TabIndex = 60;
this.solvencyLabel60.Text = "" ;
this.solvencyLabel60.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel62
//
this.solvencyLabel62.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel62.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel62.Location = new System.Drawing.Point(38,23);
this.solvencyLabel62.Name = "solvencyLabel62";
this.solvencyLabel62.OrdinateID_Label = 0;
this.solvencyLabel62.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel62.TabIndex = 62;
this.solvencyLabel62.Text = "." ;
this.solvencyLabel62.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyTextBox63
//
this.solvencyTextBox63.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyTextBox63.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyTextBox63.Location = new System.Drawing.Point(10,3);
this.solvencyTextBox63.Name = "solvencyTextBox63";
this.solvencyTextBox63.Size = new System.Drawing.Size(100, 13);
this.solvencyTextBox63.TabIndex = 63;
this.solvencyTextBox63.ColName = "C0020";
this.solvencyTextBox63.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
//
// solvencyTextBox64
//
this.solvencyTextBox64.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyTextBox64.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyTextBox64.Location = new System.Drawing.Point(117,3);
this.solvencyTextBox64.Name = "solvencyTextBox64";
this.solvencyTextBox64.Size = new System.Drawing.Size(100, 13);
this.solvencyTextBox64.TabIndex = 64;
this.solvencyTextBox64.ColName = "C0010";
this.solvencyTextBox64.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
//
// SolvencyDataComboBox65
//
this.SolvencyDataComboBox65.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox65.Location = new System.Drawing.Point(224,3);
this.SolvencyDataComboBox65.Name = "SolvencyDataComboBox65";
this.SolvencyDataComboBox65.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox65.TabIndex = 65;
this.SolvencyDataComboBox65.ColName = "C0040";
this.SolvencyDataComboBox65.AxisID = 1712;
this.SolvencyDataComboBox65.OrdinateID = 8699;
this.SolvencyDataComboBox65.StartOrder = 0;
this.SolvencyDataComboBox65.NextOrder = 0;
//
// solvencyCurrencyTextBox66
//
this.solvencyCurrencyTextBox66.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox66.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox66.Location = new System.Drawing.Point(431,3);
this.solvencyCurrencyTextBox66.Name = "solvencyCurrencyTextBox66";
this.solvencyCurrencyTextBox66.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox66.TabIndex = 66;
this.solvencyCurrencyTextBox66.ColName = "C0050";
this.solvencyCurrencyTextBox66.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox67
//
this.solvencyCurrencyTextBox67.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox67.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox67.Location = new System.Drawing.Point(538,3);
this.solvencyCurrencyTextBox67.Name = "solvencyCurrencyTextBox67";
this.solvencyCurrencyTextBox67.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox67.TabIndex = 67;
this.solvencyCurrencyTextBox67.ColName = "C0060";
this.solvencyCurrencyTextBox67.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox68
//
this.solvencyCurrencyTextBox68.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox68.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox68.Location = new System.Drawing.Point(645,3);
this.solvencyCurrencyTextBox68.Name = "solvencyCurrencyTextBox68";
this.solvencyCurrencyTextBox68.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox68.TabIndex = 68;
this.solvencyCurrencyTextBox68.ColName = "C0070";
this.solvencyCurrencyTextBox68.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox69
//
this.solvencyCurrencyTextBox69.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox69.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox69.Location = new System.Drawing.Point(752,3);
this.solvencyCurrencyTextBox69.Name = "solvencyCurrencyTextBox69";
this.solvencyCurrencyTextBox69.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox69.TabIndex = 69;
this.solvencyCurrencyTextBox69.ColName = "C0080";
this.solvencyCurrencyTextBox69.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox70
//
this.solvencyCurrencyTextBox70.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox70.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox70.Location = new System.Drawing.Point(859,3);
this.solvencyCurrencyTextBox70.Name = "solvencyCurrencyTextBox70";
this.solvencyCurrencyTextBox70.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox70.TabIndex = 70;
this.solvencyCurrencyTextBox70.ColName = "C0090";
this.solvencyCurrencyTextBox70.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox71
//
this.solvencyCurrencyTextBox71.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox71.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox71.Location = new System.Drawing.Point(966,3);
this.solvencyCurrencyTextBox71.Name = "solvencyCurrencyTextBox71";
this.solvencyCurrencyTextBox71.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox71.TabIndex = 71;
this.solvencyCurrencyTextBox71.ColName = "C0100";
this.solvencyCurrencyTextBox71.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox72
//
this.solvencyCurrencyTextBox72.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox72.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox72.Location = new System.Drawing.Point(1073,3);
this.solvencyCurrencyTextBox72.Name = "solvencyCurrencyTextBox72";
this.solvencyCurrencyTextBox72.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox72.TabIndex = 72;
this.solvencyCurrencyTextBox72.ColName = "C0110";
this.solvencyCurrencyTextBox72.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox73
//
this.solvencyCurrencyTextBox73.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox73.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox73.Location = new System.Drawing.Point(1180,3);
this.solvencyCurrencyTextBox73.Name = "solvencyCurrencyTextBox73";
this.solvencyCurrencyTextBox73.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox73.TabIndex = 73;
this.solvencyCurrencyTextBox73.ColName = "C0120";
this.solvencyCurrencyTextBox73.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox74
//
this.solvencyCurrencyTextBox74.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox74.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox74.Location = new System.Drawing.Point(1287,3);
this.solvencyCurrencyTextBox74.Name = "solvencyCurrencyTextBox74";
this.solvencyCurrencyTextBox74.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox74.TabIndex = 74;
this.solvencyCurrencyTextBox74.ColName = "C0130";
this.solvencyCurrencyTextBox74.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox75
//
this.solvencyCurrencyTextBox75.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox75.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox75.Location = new System.Drawing.Point(1394,3);
this.solvencyCurrencyTextBox75.Name = "solvencyCurrencyTextBox75";
this.solvencyCurrencyTextBox75.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox75.TabIndex = 75;
this.solvencyCurrencyTextBox75.ColName = "C0140";
this.solvencyCurrencyTextBox75.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox76
//
this.solvencyCurrencyTextBox76.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox76.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox76.Location = new System.Drawing.Point(1501,3);
this.solvencyCurrencyTextBox76.Name = "solvencyCurrencyTextBox76";
this.solvencyCurrencyTextBox76.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox76.TabIndex = 76;
this.solvencyCurrencyTextBox76.ColName = "C0150";
this.solvencyCurrencyTextBox76.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox77
//
this.solvencyCurrencyTextBox77.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox77.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox77.Location = new System.Drawing.Point(1608,3);
this.solvencyCurrencyTextBox77.Name = "solvencyCurrencyTextBox77";
this.solvencyCurrencyTextBox77.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox77.TabIndex = 77;
this.solvencyCurrencyTextBox77.ColName = "C0160";
this.solvencyCurrencyTextBox77.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox78
//
this.solvencyCurrencyTextBox78.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox78.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox78.Location = new System.Drawing.Point(1715,3);
this.solvencyCurrencyTextBox78.Name = "solvencyCurrencyTextBox78";
this.solvencyCurrencyTextBox78.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox78.TabIndex = 78;
this.solvencyCurrencyTextBox78.ColName = "C0170";
this.solvencyCurrencyTextBox78.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox79
//
this.solvencyCurrencyTextBox79.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox79.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox79.Location = new System.Drawing.Point(1822,3);
this.solvencyCurrencyTextBox79.Name = "solvencyCurrencyTextBox79";
this.solvencyCurrencyTextBox79.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox79.TabIndex = 79;
this.solvencyCurrencyTextBox79.ColName = "C0180";
this.solvencyCurrencyTextBox79.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox80
//
this.solvencyCurrencyTextBox80.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox80.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox80.Location = new System.Drawing.Point(1929,3);
this.solvencyCurrencyTextBox80.Name = "solvencyCurrencyTextBox80";
this.solvencyCurrencyTextBox80.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox80.TabIndex = 80;
this.solvencyCurrencyTextBox80.ColName = "C0190";
this.solvencyCurrencyTextBox80.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox81
//
this.solvencyCurrencyTextBox81.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox81.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox81.Location = new System.Drawing.Point(2036,3);
this.solvencyCurrencyTextBox81.Name = "solvencyCurrencyTextBox81";
this.solvencyCurrencyTextBox81.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox81.TabIndex = 81;
this.solvencyCurrencyTextBox81.ColName = "C0200";
this.solvencyCurrencyTextBox81.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox82
//
this.solvencyCurrencyTextBox82.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox82.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox82.Location = new System.Drawing.Point(2143,3);
this.solvencyCurrencyTextBox82.Name = "solvencyCurrencyTextBox82";
this.solvencyCurrencyTextBox82.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox82.TabIndex = 82;
this.solvencyCurrencyTextBox82.ColName = "C0210";
this.solvencyCurrencyTextBox82.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox83
//
this.solvencyCurrencyTextBox83.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox83.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox83.Location = new System.Drawing.Point(2250,3);
this.solvencyCurrencyTextBox83.Name = "solvencyCurrencyTextBox83";
this.solvencyCurrencyTextBox83.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox83.TabIndex = 83;
this.solvencyCurrencyTextBox83.ColName = "C0220";
this.solvencyCurrencyTextBox83.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox84
//
this.solvencyCurrencyTextBox84.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox84.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox84.Location = new System.Drawing.Point(2357,3);
this.solvencyCurrencyTextBox84.Name = "solvencyCurrencyTextBox84";
this.solvencyCurrencyTextBox84.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox84.TabIndex = 84;
this.solvencyCurrencyTextBox84.ColName = "C0230";
this.solvencyCurrencyTextBox84.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox85
//
this.solvencyCurrencyTextBox85.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox85.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox85.Location = new System.Drawing.Point(2464,3);
this.solvencyCurrencyTextBox85.Name = "solvencyCurrencyTextBox85";
this.solvencyCurrencyTextBox85.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox85.TabIndex = 85;
this.solvencyCurrencyTextBox85.ColName = "C0240";
this.solvencyCurrencyTextBox85.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox86
//
this.solvencyCurrencyTextBox86.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox86.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox86.Location = new System.Drawing.Point(2571,3);
this.solvencyCurrencyTextBox86.Name = "solvencyCurrencyTextBox86";
this.solvencyCurrencyTextBox86.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox86.TabIndex = 86;
this.solvencyCurrencyTextBox86.ColName = "C0250";
this.solvencyCurrencyTextBox86.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox87
//
this.solvencyCurrencyTextBox87.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox87.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox87.Location = new System.Drawing.Point(2678,3);
this.solvencyCurrencyTextBox87.Name = "solvencyCurrencyTextBox87";
this.solvencyCurrencyTextBox87.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox87.TabIndex = 87;
this.solvencyCurrencyTextBox87.ColName = "C0260";
this.solvencyCurrencyTextBox87.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// splitContainerColTitles
//
this.splitContainerColTitles.Dock = System.Windows.Forms.DockStyle.Fill;
this.splitContainerColTitles.Location = new System.Drawing.Point(0,0);
this.splitContainerColTitles.Name = "splitContainerColTitles";
this.splitContainerColTitles.Orientation = System.Windows.Forms.Orientation.Vertical;
this.splitContainerColTitles.Panel1MinSize = 0;
//
// splitContainerColTitles.Panel1
//
//
// splitContainerColTitles.Panel2
//
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel0);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel1);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel2);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel3);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel4);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel5);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel6);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel7);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel8);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel9);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel10);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel11);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel12);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel13);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel14);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel15);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel16);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel17);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel18);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel19);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel20);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel21);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel22);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel23);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel24);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel25);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel26);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel27);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel28);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel29);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel30);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel31);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel32);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel33);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel34);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel35);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel36);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel37);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel38);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel39);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel40);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel41);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel42);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel43);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel44);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel45);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel46);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel47);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel48);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel49);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel50);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel51);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel52);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel53);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel54);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel55);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel56);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel57);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel58);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel59);
this.splitContainerColTitles.Size = new System.Drawing.Size(2977, 220);
this.splitContainerColTitles.SplitterDistance = 85;
//
// splitContainerRowTitles
//
this.splitContainerRowTitles.Dock = System.Windows.Forms.DockStyle.Fill;
this.splitContainerRowTitles.Location = new System.Drawing.Point(0,0);
this.splitContainerRowTitles.Name = "splitContainerRowTitles";
this.splitContainerRowTitles.Orientation = System.Windows.Forms.Orientation.Vertical;
this.splitContainerRowTitles.Panel1MinSize = 0;
//
// splitContainerRowTitles.Panel1
//
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel60);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel62);
//
// splitContainerRowTitles.Panel2
//
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyTextBox63);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyTextBox64);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox65);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox66);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox67);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox68);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox69);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox70);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox71);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox72);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox73);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox74);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox75);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox76);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox77);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox78);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox79);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox80);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox81);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox82);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox83);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox84);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox85);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox86);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox87);
this.splitContainerRowTitles.Panel2.AutoScroll = true;
this.splitContainerRowTitles.Size = new System.Drawing.Size(2977, 220);
this.splitContainerRowTitles.SplitterDistance = 85;
//
// spltMain
//
this.spltMain.Dock = System.Windows.Forms.DockStyle.Fill;
this.spltMain.Location = new System.Drawing.Point(0,0);
this.spltMain.Name = "spltMain";
this.spltMain.Orientation = System.Windows.Forms.Orientation.Horizontal;
this.spltMain.Panel1MinSize = 0;
//
// spltMain.Panel1
//
this.spltMain.Panel1.Controls.Add(this.splitContainerColTitles);
//
// spltMain.Panel2
//
this.spltMain.Panel2.Controls.Add(this.splitContainerRowTitles);
this.spltMain.Panel2.AutoScroll = true;
this.spltMain.Size = new System.Drawing.Size(2977, 296);
this.spltMain.SplitterDistance = 135;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F); 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font; 
this.Controls.Add(this.spltMain);
            this.Name = "S_35_01_04_01__sol2__2_0_1_ctrl"; 
            this.Size = new System.Drawing.Size(2977, 161); 
            this.Load += new System.EventHandler(this.BoundControl_Load);
            this.ResumeLayout(false); 
            this.PerformLayout(); 

      } 
private SolvencyLabel solvencyLabel0;
private SolvencyLabel solvencyLabel1;
private SolvencyLabel solvencyLabel2;
private SolvencyLabel solvencyLabel3;
private SolvencyLabel solvencyLabel4;
private SolvencyLabel solvencyLabel5;
private SolvencyLabel solvencyLabel6;
private SolvencyLabel solvencyLabel7;
private SolvencyLabel solvencyLabel8;
private SolvencyLabel solvencyLabel9;
private SolvencyLabel solvencyLabel10;
private SolvencyLabel solvencyLabel11;
private SolvencyLabel solvencyLabel12;
private SolvencyLabel solvencyLabel13;
private SolvencyLabel solvencyLabel14;
private SolvencyLabel solvencyLabel15;
private SolvencyLabel solvencyLabel16;
private SolvencyLabel solvencyLabel17;
private SolvencyLabel solvencyLabel18;
private SolvencyLabel solvencyLabel19;
private SolvencyLabel solvencyLabel20;
private SolvencyLabel solvencyLabel21;
private SolvencyLabel solvencyLabel22;
private SolvencyLabel solvencyLabel23;
private SolvencyLabel solvencyLabel24;
private SolvencyLabel solvencyLabel25;
private SolvencyLabel solvencyLabel26;
private SolvencyLabel solvencyLabel27;
private SolvencyLabel solvencyLabel28;
private SolvencyLabel solvencyLabel29;
private SolvencyLabel solvencyLabel30;
private SolvencyLabel solvencyLabel31;
private SolvencyLabel solvencyLabel32;
private SolvencyLabel solvencyLabel33;
private SolvencyLabel solvencyLabel34;
private SolvencyLabel solvencyLabel35;
private SolvencyLabel solvencyLabel36;
private SolvencyLabel solvencyLabel37;
private SolvencyLabel solvencyLabel38;
private SolvencyLabel solvencyLabel39;
private SolvencyLabel solvencyLabel40;
private SolvencyLabel solvencyLabel41;
private SolvencyLabel solvencyLabel42;
private SolvencyLabel solvencyLabel43;
private SolvencyLabel solvencyLabel44;
private SolvencyLabel solvencyLabel45;
private SolvencyLabel solvencyLabel46;
private SolvencyLabel solvencyLabel47;
private SolvencyLabel solvencyLabel48;
private SolvencyLabel solvencyLabel49;
private SolvencyLabel solvencyLabel50;
private SolvencyLabel solvencyLabel51;
private SolvencyLabel solvencyLabel52;
private SolvencyLabel solvencyLabel53;
private SolvencyLabel solvencyLabel54;
private SolvencyLabel solvencyLabel55;
private SolvencyLabel solvencyLabel56;
private SolvencyLabel solvencyLabel57;
private SolvencyLabel solvencyLabel58;
private SolvencyLabel solvencyLabel59;
private SolvencyLabel solvencyLabel60;
private SolvencyLabel solvencyLabel62;
private SolvencyTextBox solvencyTextBox63;
private SolvencyTextBox solvencyTextBox64;
private SolvencyDataComboBox SolvencyDataComboBox65;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox66;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox67;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox68;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox69;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox70;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox71;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox72;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox73;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox74;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox75;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox76;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox77;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox78;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox79;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox80;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox81;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox82;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox83;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox84;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox85;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox86;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox87;
private SolvencySplitContainer splitContainerColTitles;
private SolvencySplitContainer splitContainerRowTitles;
private SolvencySplitContainer spltMain;

   }
}

