using SolvencyII.Domain.ENumerators; 
using SolvencyII.UI.Shared.Controls; 

namespace SolvencyII.UI.UserControls 
{ 
   partial class SE_02_01_16_01__sol2__2_0_1_ctrl 
   { 
      private void InitializeComponent() 
      { 
this.solvencyLabel0 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel1 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel2 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel3 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel4 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel5 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel6 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel7 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel8 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel9 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel10 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel11 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel12 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel13 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel14 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel15 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel16 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel17 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel18 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel19 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel20 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel21 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel22 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel23 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel24 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel25 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel26 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel27 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel28 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel29 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel30 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel31 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel32 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel33 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel34 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel35 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel36 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel37 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel38 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel39 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel40 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel41 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel42 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel43 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel44 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel45 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel46 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel47 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel48 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel49 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel50 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel51 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel52 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel53 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel54 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel55 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel56 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel57 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel58 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel59 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel60 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel61 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel62 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel63 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel64 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel65 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel66 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel67 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel68 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel69 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel70 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel71 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel72 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel73 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel74 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel75 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel76 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel77 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel78 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel79 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel80 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel81 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel82 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel83 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel84 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel85 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel86 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel87 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel88 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel89 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel90 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel91 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel92 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel93 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel94 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel95 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel96 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel97 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel98 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel99 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel100 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel101 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel102 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel103 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel104 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel105 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel106 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel107 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel108 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel109 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel110 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel111 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel112 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel113 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel114 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel115 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel116 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel117 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel118 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel119 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel120 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel121 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel122 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel123 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel124 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel125 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel126 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel127 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel128 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel129 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel130 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel131 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel132 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel133 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel134 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel135 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel136 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel137 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel138 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel139 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel140 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel141 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel142 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel143 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel144 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel145 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel146 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel147 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel148 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel149 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel150 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel151 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel152 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel153 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel154 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel155 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel156 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel157 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel158 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel159 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel160 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel161 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel162 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel163 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel164 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel165 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel166 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel167 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel168 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel169 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel170 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel171 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel172 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel173 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel174 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel175 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel176 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel177 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel178 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel179 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel180 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel181 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel182 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel183 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel184 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel185 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel186 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel187 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel188 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel189 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel190 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel191 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel192 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyCurrencyTextBox193 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox194 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox195 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox196 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox197 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox198 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox199 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox200 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox201 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox202 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox203 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox204 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox205 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox206 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox207 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox208 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox209 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox210 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox211 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox212 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox213 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox214 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox215 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox216 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox217 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox218 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox219 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox220 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox221 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox222 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox223 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox224 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox225 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox226 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox227 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox228 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox229 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox230 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox231 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox232 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox233 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox234 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox235 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox236 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox237 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox238 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox239 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox240 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox241 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox242 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox243 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox244 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox245 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox246 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox247 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox248 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox249 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox250 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox251 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox252 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox253 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox254 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox255 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox256 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox257 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox258 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox259 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox260 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox261 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox262 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox263 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox264 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox265 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox266 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox267 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox268 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox269 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox270 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox271 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox272 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox273 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox274 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox275 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox276 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox277 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox278 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox279 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox280 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox281 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox282 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox283 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox284 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox285 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox286 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox287 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox288 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox289 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox290 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox291 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox292 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox293 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox294 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox295 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox296 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox297 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox298 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox299 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox300 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox301 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox302 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox303 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox304 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox305 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox306 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox307 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox308 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox309 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox310 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox311 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox312 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox313 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox314 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox315 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox316 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox317 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox318 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox319 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox320 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox321 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox322 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox323 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox324 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox325 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox326 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox327 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox328 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox329 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox330 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox331 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox332 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox333 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox334 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox335 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox336 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox337 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox338 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox339 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox340 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox341 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox342 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox343 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox344 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox345 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox346 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox347 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox348 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox349 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox350 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox351 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox352 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox353 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox354 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox355 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox356 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox357 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox358 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox359 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox360 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox361 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox362 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox363 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox364 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox365 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox366 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox367 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox368 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox369 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox370 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox371 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox372 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox373 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox374 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox375 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox376 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox377 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox378 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox379 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox380 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox381 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox382 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox383 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox384 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox385 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox386 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox387 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox388 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox389 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox390 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox391 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox392 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox393 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox394 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox395 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox396 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox397 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox398 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox399 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox400 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox401 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox402 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox403 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox404 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox405 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox406 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox407 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox408 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox409 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox410 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox411 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox412 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox413 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox414 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox415 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox416 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox417 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox418 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox419 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox420 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox421 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox422 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox423 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox424 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox425 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox426 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox427 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox428 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox429 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox430 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox431 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox432 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox433 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox434 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox435 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox436 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox437 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox438 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox439 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox440 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox441 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox442 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox443 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox444 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox445 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox446 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox447 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox448 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox449 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox450 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox451 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox452 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox453 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox454 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox455 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox456 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox457 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox458 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox459 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox460 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox461 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox462 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox463 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox464 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox465 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.splitContainerColTitles = new SolvencyII.UI.Shared.Controls.SolvencySplitContainer();
this.splitContainerRowTitles = new SolvencyII.UI.Shared.Controls.SolvencySplitContainer();
this.spltMain = new SolvencyII.UI.Shared.Controls.SolvencySplitContainer();
            this.SuspendLayout(); 

//
// solvencyLabel0
//
this.solvencyLabel0.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel0.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel0.Location = new System.Drawing.Point(224,10);
this.solvencyLabel0.Name = "solvencyLabel0";
this.solvencyLabel0.OrdinateID_Label = 1130;
this.solvencyLabel0.Size = new System.Drawing.Size(108, 30);
this.solvencyLabel0.TabIndex = 0;
this.solvencyLabel0.Text = "Reclassification adjustments" ;
this.solvencyLabel0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel0.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel1
//
this.solvencyLabel1.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel1.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel1.Location = new System.Drawing.Point(224,40);
this.solvencyLabel1.Name = "solvencyLabel1";
this.solvencyLabel1.OrdinateID_Label = 0;
this.solvencyLabel1.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel1.TabIndex = 1;
this.solvencyLabel1.Text = "EC0021" ;
this.solvencyLabel1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel2
//
this.solvencyLabel2.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel2.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel2.Location = new System.Drawing.Point(117,10);
this.solvencyLabel2.Name = "solvencyLabel2";
this.solvencyLabel2.OrdinateID_Label = 1129;
this.solvencyLabel2.Size = new System.Drawing.Size(108, 30);
this.solvencyLabel2.TabIndex = 2;
this.solvencyLabel2.Text = "Statutory accounts value" ;
this.solvencyLabel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel3
//
this.solvencyLabel3.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel3.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel3.Location = new System.Drawing.Point(117,40);
this.solvencyLabel3.Name = "solvencyLabel3";
this.solvencyLabel3.OrdinateID_Label = 0;
this.solvencyLabel3.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel3.TabIndex = 3;
this.solvencyLabel3.Text = "C0020" ;
this.solvencyLabel3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel4
//
this.solvencyLabel4.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel4.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel4.Location = new System.Drawing.Point(10,10);
this.solvencyLabel4.Name = "solvencyLabel4";
this.solvencyLabel4.OrdinateID_Label = 1128;
this.solvencyLabel4.Size = new System.Drawing.Size(108, 30);
this.solvencyLabel4.TabIndex = 4;
this.solvencyLabel4.Text = "Solvency II value" ;
this.solvencyLabel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel5
//
this.solvencyLabel5.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel5.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel5.Location = new System.Drawing.Point(10,40);
this.solvencyLabel5.Name = "solvencyLabel5";
this.solvencyLabel5.OrdinateID_Label = 0;
this.solvencyLabel5.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel5.TabIndex = 5;
this.solvencyLabel5.Text = "C0010" ;
this.solvencyLabel5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel6
//
this.solvencyLabel6.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel6.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel6.Location = new System.Drawing.Point(10,3);
this.solvencyLabel6.Name = "solvencyLabel6";
this.solvencyLabel6.OrdinateID_Label = 1131;
this.solvencyLabel6.Size = new System.Drawing.Size(261, 15);
this.solvencyLabel6.TabIndex = 6;
this.solvencyLabel6.Text = "Assets" ;
this.solvencyLabel6.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel7
//
this.solvencyLabel7.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel7.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel7.Location = new System.Drawing.Point(285,3);
this.solvencyLabel7.Name = "solvencyLabel7";
this.solvencyLabel7.OrdinateID_Label = 0;
this.solvencyLabel7.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel7.TabIndex = 7;
this.solvencyLabel7.Text = "" ;
this.solvencyLabel7.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel8
//
this.solvencyLabel8.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel8.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel8.Location = new System.Drawing.Point(17,23);
this.solvencyLabel8.Name = "solvencyLabel8";
this.solvencyLabel8.OrdinateID_Label = 1132;
this.solvencyLabel8.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel8.TabIndex = 8;
this.solvencyLabel8.Text = "Goodwill" ;
this.solvencyLabel8.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel9
//
this.solvencyLabel9.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel9.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel9.Location = new System.Drawing.Point(285,23);
this.solvencyLabel9.Name = "solvencyLabel9";
this.solvencyLabel9.OrdinateID_Label = 0;
this.solvencyLabel9.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel9.TabIndex = 9;
this.solvencyLabel9.Text = "R0010" ;
this.solvencyLabel9.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel10
//
this.solvencyLabel10.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel10.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel10.Location = new System.Drawing.Point(17,43);
this.solvencyLabel10.Name = "solvencyLabel10";
this.solvencyLabel10.OrdinateID_Label = 1133;
this.solvencyLabel10.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel10.TabIndex = 10;
this.solvencyLabel10.Text = "Deferred acquisition costs" ;
this.solvencyLabel10.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel11
//
this.solvencyLabel11.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel11.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel11.Location = new System.Drawing.Point(285,43);
this.solvencyLabel11.Name = "solvencyLabel11";
this.solvencyLabel11.OrdinateID_Label = 0;
this.solvencyLabel11.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel11.TabIndex = 11;
this.solvencyLabel11.Text = "R0020" ;
this.solvencyLabel11.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel12
//
this.solvencyLabel12.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel12.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel12.Location = new System.Drawing.Point(17,63);
this.solvencyLabel12.Name = "solvencyLabel12";
this.solvencyLabel12.OrdinateID_Label = 1134;
this.solvencyLabel12.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel12.TabIndex = 12;
this.solvencyLabel12.Text = "Intangible assets" ;
this.solvencyLabel12.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel13
//
this.solvencyLabel13.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel13.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel13.Location = new System.Drawing.Point(285,63);
this.solvencyLabel13.Name = "solvencyLabel13";
this.solvencyLabel13.OrdinateID_Label = 0;
this.solvencyLabel13.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel13.TabIndex = 13;
this.solvencyLabel13.Text = "R0030" ;
this.solvencyLabel13.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel14
//
this.solvencyLabel14.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel14.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel14.Location = new System.Drawing.Point(17,83);
this.solvencyLabel14.Name = "solvencyLabel14";
this.solvencyLabel14.OrdinateID_Label = 1135;
this.solvencyLabel14.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel14.TabIndex = 14;
this.solvencyLabel14.Text = "Deferred tax assets" ;
this.solvencyLabel14.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel15
//
this.solvencyLabel15.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel15.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel15.Location = new System.Drawing.Point(285,83);
this.solvencyLabel15.Name = "solvencyLabel15";
this.solvencyLabel15.OrdinateID_Label = 0;
this.solvencyLabel15.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel15.TabIndex = 15;
this.solvencyLabel15.Text = "R0040" ;
this.solvencyLabel15.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel16
//
this.solvencyLabel16.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel16.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel16.Location = new System.Drawing.Point(17,103);
this.solvencyLabel16.Name = "solvencyLabel16";
this.solvencyLabel16.OrdinateID_Label = 1136;
this.solvencyLabel16.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel16.TabIndex = 16;
this.solvencyLabel16.Text = "Pension benefit surplus" ;
this.solvencyLabel16.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel17
//
this.solvencyLabel17.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel17.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel17.Location = new System.Drawing.Point(285,103);
this.solvencyLabel17.Name = "solvencyLabel17";
this.solvencyLabel17.OrdinateID_Label = 0;
this.solvencyLabel17.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel17.TabIndex = 17;
this.solvencyLabel17.Text = "R0050" ;
this.solvencyLabel17.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel18
//
this.solvencyLabel18.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel18.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel18.Location = new System.Drawing.Point(17,123);
this.solvencyLabel18.Name = "solvencyLabel18";
this.solvencyLabel18.OrdinateID_Label = 1137;
this.solvencyLabel18.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel18.TabIndex = 18;
this.solvencyLabel18.Text = "Property, plant & equipment held for own use" ;
this.solvencyLabel18.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel19
//
this.solvencyLabel19.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel19.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel19.Location = new System.Drawing.Point(285,123);
this.solvencyLabel19.Name = "solvencyLabel19";
this.solvencyLabel19.OrdinateID_Label = 0;
this.solvencyLabel19.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel19.TabIndex = 19;
this.solvencyLabel19.Text = "R0060" ;
this.solvencyLabel19.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel20
//
this.solvencyLabel20.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel20.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel20.Location = new System.Drawing.Point(17,143);
this.solvencyLabel20.Name = "solvencyLabel20";
this.solvencyLabel20.OrdinateID_Label = 1138;
this.solvencyLabel20.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel20.TabIndex = 20;
this.solvencyLabel20.Text = "Investments (other than assets held for index-linked and unit-linked contracts)" ;
this.solvencyLabel20.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel21
//
this.solvencyLabel21.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel21.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel21.Location = new System.Drawing.Point(285,143);
this.solvencyLabel21.Name = "solvencyLabel21";
this.solvencyLabel21.OrdinateID_Label = 0;
this.solvencyLabel21.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel21.TabIndex = 21;
this.solvencyLabel21.Text = "R0070" ;
this.solvencyLabel21.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel22
//
this.solvencyLabel22.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel22.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel22.Location = new System.Drawing.Point(24,176);
this.solvencyLabel22.Name = "solvencyLabel22";
this.solvencyLabel22.OrdinateID_Label = 1139;
this.solvencyLabel22.Size = new System.Drawing.Size(247, 15);
this.solvencyLabel22.TabIndex = 22;
this.solvencyLabel22.Text = "Property (other than for own use)" ;
this.solvencyLabel22.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel23
//
this.solvencyLabel23.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel23.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel23.Location = new System.Drawing.Point(285,176);
this.solvencyLabel23.Name = "solvencyLabel23";
this.solvencyLabel23.OrdinateID_Label = 0;
this.solvencyLabel23.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel23.TabIndex = 23;
this.solvencyLabel23.Text = "R0080" ;
this.solvencyLabel23.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel24
//
this.solvencyLabel24.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel24.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel24.Location = new System.Drawing.Point(24,196);
this.solvencyLabel24.Name = "solvencyLabel24";
this.solvencyLabel24.OrdinateID_Label = 1140;
this.solvencyLabel24.Size = new System.Drawing.Size(247, 30);
this.solvencyLabel24.TabIndex = 24;
this.solvencyLabel24.Text = "Holdings in related undertakings, including participations" ;
this.solvencyLabel24.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel25
//
this.solvencyLabel25.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel25.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel25.Location = new System.Drawing.Point(285,196);
this.solvencyLabel25.Name = "solvencyLabel25";
this.solvencyLabel25.OrdinateID_Label = 0;
this.solvencyLabel25.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel25.TabIndex = 25;
this.solvencyLabel25.Text = "R0090" ;
this.solvencyLabel25.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel26
//
this.solvencyLabel26.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel26.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel26.Location = new System.Drawing.Point(24,229);
this.solvencyLabel26.Name = "solvencyLabel26";
this.solvencyLabel26.OrdinateID_Label = 1141;
this.solvencyLabel26.Size = new System.Drawing.Size(247, 15);
this.solvencyLabel26.TabIndex = 26;
this.solvencyLabel26.Text = "Equities" ;
this.solvencyLabel26.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel27
//
this.solvencyLabel27.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel27.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel27.Location = new System.Drawing.Point(285,229);
this.solvencyLabel27.Name = "solvencyLabel27";
this.solvencyLabel27.OrdinateID_Label = 0;
this.solvencyLabel27.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel27.TabIndex = 27;
this.solvencyLabel27.Text = "R0100" ;
this.solvencyLabel27.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel28
//
this.solvencyLabel28.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel28.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel28.Location = new System.Drawing.Point(31,249);
this.solvencyLabel28.Name = "solvencyLabel28";
this.solvencyLabel28.OrdinateID_Label = 1142;
this.solvencyLabel28.Size = new System.Drawing.Size(240, 15);
this.solvencyLabel28.TabIndex = 28;
this.solvencyLabel28.Text = "Equities - listed" ;
this.solvencyLabel28.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel29
//
this.solvencyLabel29.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel29.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel29.Location = new System.Drawing.Point(285,249);
this.solvencyLabel29.Name = "solvencyLabel29";
this.solvencyLabel29.OrdinateID_Label = 0;
this.solvencyLabel29.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel29.TabIndex = 29;
this.solvencyLabel29.Text = "R0110" ;
this.solvencyLabel29.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel30
//
this.solvencyLabel30.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel30.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel30.Location = new System.Drawing.Point(31,269);
this.solvencyLabel30.Name = "solvencyLabel30";
this.solvencyLabel30.OrdinateID_Label = 1143;
this.solvencyLabel30.Size = new System.Drawing.Size(240, 15);
this.solvencyLabel30.TabIndex = 30;
this.solvencyLabel30.Text = "Equities - unlisted" ;
this.solvencyLabel30.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel31
//
this.solvencyLabel31.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel31.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel31.Location = new System.Drawing.Point(285,269);
this.solvencyLabel31.Name = "solvencyLabel31";
this.solvencyLabel31.OrdinateID_Label = 0;
this.solvencyLabel31.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel31.TabIndex = 31;
this.solvencyLabel31.Text = "R0120" ;
this.solvencyLabel31.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel32
//
this.solvencyLabel32.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel32.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel32.Location = new System.Drawing.Point(24,289);
this.solvencyLabel32.Name = "solvencyLabel32";
this.solvencyLabel32.OrdinateID_Label = 1144;
this.solvencyLabel32.Size = new System.Drawing.Size(247, 15);
this.solvencyLabel32.TabIndex = 32;
this.solvencyLabel32.Text = "Bonds" ;
this.solvencyLabel32.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel33
//
this.solvencyLabel33.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel33.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel33.Location = new System.Drawing.Point(285,289);
this.solvencyLabel33.Name = "solvencyLabel33";
this.solvencyLabel33.OrdinateID_Label = 0;
this.solvencyLabel33.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel33.TabIndex = 33;
this.solvencyLabel33.Text = "R0130" ;
this.solvencyLabel33.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel34
//
this.solvencyLabel34.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel34.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel34.Location = new System.Drawing.Point(31,309);
this.solvencyLabel34.Name = "solvencyLabel34";
this.solvencyLabel34.OrdinateID_Label = 1145;
this.solvencyLabel34.Size = new System.Drawing.Size(240, 15);
this.solvencyLabel34.TabIndex = 34;
this.solvencyLabel34.Text = "Government Bonds" ;
this.solvencyLabel34.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel35
//
this.solvencyLabel35.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel35.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel35.Location = new System.Drawing.Point(285,309);
this.solvencyLabel35.Name = "solvencyLabel35";
this.solvencyLabel35.OrdinateID_Label = 0;
this.solvencyLabel35.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel35.TabIndex = 35;
this.solvencyLabel35.Text = "R0140" ;
this.solvencyLabel35.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel36
//
this.solvencyLabel36.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel36.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel36.Location = new System.Drawing.Point(31,329);
this.solvencyLabel36.Name = "solvencyLabel36";
this.solvencyLabel36.OrdinateID_Label = 1146;
this.solvencyLabel36.Size = new System.Drawing.Size(240, 15);
this.solvencyLabel36.TabIndex = 36;
this.solvencyLabel36.Text = "Corporate Bonds" ;
this.solvencyLabel36.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel37
//
this.solvencyLabel37.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel37.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel37.Location = new System.Drawing.Point(285,329);
this.solvencyLabel37.Name = "solvencyLabel37";
this.solvencyLabel37.OrdinateID_Label = 0;
this.solvencyLabel37.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel37.TabIndex = 37;
this.solvencyLabel37.Text = "R0150" ;
this.solvencyLabel37.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel38
//
this.solvencyLabel38.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel38.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel38.Location = new System.Drawing.Point(31,349);
this.solvencyLabel38.Name = "solvencyLabel38";
this.solvencyLabel38.OrdinateID_Label = 1147;
this.solvencyLabel38.Size = new System.Drawing.Size(240, 15);
this.solvencyLabel38.TabIndex = 38;
this.solvencyLabel38.Text = "Structured notes" ;
this.solvencyLabel38.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel39
//
this.solvencyLabel39.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel39.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel39.Location = new System.Drawing.Point(285,349);
this.solvencyLabel39.Name = "solvencyLabel39";
this.solvencyLabel39.OrdinateID_Label = 0;
this.solvencyLabel39.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel39.TabIndex = 39;
this.solvencyLabel39.Text = "R0160" ;
this.solvencyLabel39.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel40
//
this.solvencyLabel40.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel40.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel40.Location = new System.Drawing.Point(31,369);
this.solvencyLabel40.Name = "solvencyLabel40";
this.solvencyLabel40.OrdinateID_Label = 1148;
this.solvencyLabel40.Size = new System.Drawing.Size(240, 15);
this.solvencyLabel40.TabIndex = 40;
this.solvencyLabel40.Text = "Collateralised securities" ;
this.solvencyLabel40.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel41
//
this.solvencyLabel41.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel41.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel41.Location = new System.Drawing.Point(285,369);
this.solvencyLabel41.Name = "solvencyLabel41";
this.solvencyLabel41.OrdinateID_Label = 0;
this.solvencyLabel41.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel41.TabIndex = 41;
this.solvencyLabel41.Text = "R0170" ;
this.solvencyLabel41.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel42
//
this.solvencyLabel42.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel42.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel42.Location = new System.Drawing.Point(24,389);
this.solvencyLabel42.Name = "solvencyLabel42";
this.solvencyLabel42.OrdinateID_Label = 1149;
this.solvencyLabel42.Size = new System.Drawing.Size(247, 15);
this.solvencyLabel42.TabIndex = 42;
this.solvencyLabel42.Text = "Collective Investments Undertakings" ;
this.solvencyLabel42.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel43
//
this.solvencyLabel43.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel43.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel43.Location = new System.Drawing.Point(285,389);
this.solvencyLabel43.Name = "solvencyLabel43";
this.solvencyLabel43.OrdinateID_Label = 0;
this.solvencyLabel43.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel43.TabIndex = 43;
this.solvencyLabel43.Text = "R0180" ;
this.solvencyLabel43.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel44
//
this.solvencyLabel44.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel44.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel44.Location = new System.Drawing.Point(24,409);
this.solvencyLabel44.Name = "solvencyLabel44";
this.solvencyLabel44.OrdinateID_Label = 1150;
this.solvencyLabel44.Size = new System.Drawing.Size(247, 15);
this.solvencyLabel44.TabIndex = 44;
this.solvencyLabel44.Text = "Derivatives" ;
this.solvencyLabel44.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel45
//
this.solvencyLabel45.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel45.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel45.Location = new System.Drawing.Point(285,409);
this.solvencyLabel45.Name = "solvencyLabel45";
this.solvencyLabel45.OrdinateID_Label = 0;
this.solvencyLabel45.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel45.TabIndex = 45;
this.solvencyLabel45.Text = "R0190" ;
this.solvencyLabel45.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel46
//
this.solvencyLabel46.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel46.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel46.Location = new System.Drawing.Point(24,429);
this.solvencyLabel46.Name = "solvencyLabel46";
this.solvencyLabel46.OrdinateID_Label = 1151;
this.solvencyLabel46.Size = new System.Drawing.Size(247, 15);
this.solvencyLabel46.TabIndex = 46;
this.solvencyLabel46.Text = "Deposits other than cash equivalents" ;
this.solvencyLabel46.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel47
//
this.solvencyLabel47.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel47.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel47.Location = new System.Drawing.Point(285,429);
this.solvencyLabel47.Name = "solvencyLabel47";
this.solvencyLabel47.OrdinateID_Label = 0;
this.solvencyLabel47.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel47.TabIndex = 47;
this.solvencyLabel47.Text = "R0200" ;
this.solvencyLabel47.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel48
//
this.solvencyLabel48.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel48.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel48.Location = new System.Drawing.Point(24,449);
this.solvencyLabel48.Name = "solvencyLabel48";
this.solvencyLabel48.OrdinateID_Label = 1152;
this.solvencyLabel48.Size = new System.Drawing.Size(247, 15);
this.solvencyLabel48.TabIndex = 48;
this.solvencyLabel48.Text = "Other investments" ;
this.solvencyLabel48.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel49
//
this.solvencyLabel49.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel49.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel49.Location = new System.Drawing.Point(285,449);
this.solvencyLabel49.Name = "solvencyLabel49";
this.solvencyLabel49.OrdinateID_Label = 0;
this.solvencyLabel49.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel49.TabIndex = 49;
this.solvencyLabel49.Text = "R0210" ;
this.solvencyLabel49.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel50
//
this.solvencyLabel50.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel50.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel50.Location = new System.Drawing.Point(17,469);
this.solvencyLabel50.Name = "solvencyLabel50";
this.solvencyLabel50.OrdinateID_Label = 1153;
this.solvencyLabel50.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel50.TabIndex = 50;
this.solvencyLabel50.Text = "Assets held for index-linked and unit-linked contracts" ;
this.solvencyLabel50.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel51
//
this.solvencyLabel51.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel51.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel51.Location = new System.Drawing.Point(285,469);
this.solvencyLabel51.Name = "solvencyLabel51";
this.solvencyLabel51.OrdinateID_Label = 0;
this.solvencyLabel51.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel51.TabIndex = 51;
this.solvencyLabel51.Text = "R0220" ;
this.solvencyLabel51.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel52
//
this.solvencyLabel52.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel52.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel52.Location = new System.Drawing.Point(17,489);
this.solvencyLabel52.Name = "solvencyLabel52";
this.solvencyLabel52.OrdinateID_Label = 1154;
this.solvencyLabel52.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel52.TabIndex = 52;
this.solvencyLabel52.Text = "Loans and mortgages" ;
this.solvencyLabel52.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel53
//
this.solvencyLabel53.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel53.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel53.Location = new System.Drawing.Point(285,489);
this.solvencyLabel53.Name = "solvencyLabel53";
this.solvencyLabel53.OrdinateID_Label = 0;
this.solvencyLabel53.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel53.TabIndex = 53;
this.solvencyLabel53.Text = "R0230" ;
this.solvencyLabel53.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel54
//
this.solvencyLabel54.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel54.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel54.Location = new System.Drawing.Point(24,509);
this.solvencyLabel54.Name = "solvencyLabel54";
this.solvencyLabel54.OrdinateID_Label = 1155;
this.solvencyLabel54.Size = new System.Drawing.Size(247, 15);
this.solvencyLabel54.TabIndex = 54;
this.solvencyLabel54.Text = "Loans on policies" ;
this.solvencyLabel54.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel55
//
this.solvencyLabel55.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel55.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel55.Location = new System.Drawing.Point(285,509);
this.solvencyLabel55.Name = "solvencyLabel55";
this.solvencyLabel55.OrdinateID_Label = 0;
this.solvencyLabel55.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel55.TabIndex = 55;
this.solvencyLabel55.Text = "R0240" ;
this.solvencyLabel55.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel56
//
this.solvencyLabel56.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel56.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel56.Location = new System.Drawing.Point(24,529);
this.solvencyLabel56.Name = "solvencyLabel56";
this.solvencyLabel56.OrdinateID_Label = 1156;
this.solvencyLabel56.Size = new System.Drawing.Size(247, 15);
this.solvencyLabel56.TabIndex = 56;
this.solvencyLabel56.Text = "Loans and mortgages to individuals" ;
this.solvencyLabel56.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel57
//
this.solvencyLabel57.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel57.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel57.Location = new System.Drawing.Point(285,529);
this.solvencyLabel57.Name = "solvencyLabel57";
this.solvencyLabel57.OrdinateID_Label = 0;
this.solvencyLabel57.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel57.TabIndex = 57;
this.solvencyLabel57.Text = "R0250" ;
this.solvencyLabel57.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel58
//
this.solvencyLabel58.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel58.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel58.Location = new System.Drawing.Point(24,549);
this.solvencyLabel58.Name = "solvencyLabel58";
this.solvencyLabel58.OrdinateID_Label = 1157;
this.solvencyLabel58.Size = new System.Drawing.Size(247, 15);
this.solvencyLabel58.TabIndex = 58;
this.solvencyLabel58.Text = "Other loans and mortgages" ;
this.solvencyLabel58.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel59
//
this.solvencyLabel59.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel59.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel59.Location = new System.Drawing.Point(285,549);
this.solvencyLabel59.Name = "solvencyLabel59";
this.solvencyLabel59.OrdinateID_Label = 0;
this.solvencyLabel59.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel59.TabIndex = 59;
this.solvencyLabel59.Text = "R0260" ;
this.solvencyLabel59.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel60
//
this.solvencyLabel60.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel60.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel60.Location = new System.Drawing.Point(17,569);
this.solvencyLabel60.Name = "solvencyLabel60";
this.solvencyLabel60.OrdinateID_Label = 1158;
this.solvencyLabel60.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel60.TabIndex = 60;
this.solvencyLabel60.Text = "Reinsurance recoverables from:" ;
this.solvencyLabel60.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel61
//
this.solvencyLabel61.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel61.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel61.Location = new System.Drawing.Point(285,569);
this.solvencyLabel61.Name = "solvencyLabel61";
this.solvencyLabel61.OrdinateID_Label = 0;
this.solvencyLabel61.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel61.TabIndex = 61;
this.solvencyLabel61.Text = "R0270" ;
this.solvencyLabel61.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel62
//
this.solvencyLabel62.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel62.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel62.Location = new System.Drawing.Point(24,589);
this.solvencyLabel62.Name = "solvencyLabel62";
this.solvencyLabel62.OrdinateID_Label = 1159;
this.solvencyLabel62.Size = new System.Drawing.Size(247, 15);
this.solvencyLabel62.TabIndex = 62;
this.solvencyLabel62.Text = "Non-life and health similar to non-life" ;
this.solvencyLabel62.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel63
//
this.solvencyLabel63.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel63.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel63.Location = new System.Drawing.Point(285,589);
this.solvencyLabel63.Name = "solvencyLabel63";
this.solvencyLabel63.OrdinateID_Label = 0;
this.solvencyLabel63.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel63.TabIndex = 63;
this.solvencyLabel63.Text = "R0280" ;
this.solvencyLabel63.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel64
//
this.solvencyLabel64.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel64.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel64.Location = new System.Drawing.Point(31,609);
this.solvencyLabel64.Name = "solvencyLabel64";
this.solvencyLabel64.OrdinateID_Label = 1160;
this.solvencyLabel64.Size = new System.Drawing.Size(240, 15);
this.solvencyLabel64.TabIndex = 64;
this.solvencyLabel64.Text = "Non-life excluding health" ;
this.solvencyLabel64.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel65
//
this.solvencyLabel65.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel65.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel65.Location = new System.Drawing.Point(285,609);
this.solvencyLabel65.Name = "solvencyLabel65";
this.solvencyLabel65.OrdinateID_Label = 0;
this.solvencyLabel65.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel65.TabIndex = 65;
this.solvencyLabel65.Text = "R0290" ;
this.solvencyLabel65.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel66
//
this.solvencyLabel66.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel66.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel66.Location = new System.Drawing.Point(31,629);
this.solvencyLabel66.Name = "solvencyLabel66";
this.solvencyLabel66.OrdinateID_Label = 1161;
this.solvencyLabel66.Size = new System.Drawing.Size(240, 15);
this.solvencyLabel66.TabIndex = 66;
this.solvencyLabel66.Text = "Health similar to non-life" ;
this.solvencyLabel66.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel67
//
this.solvencyLabel67.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel67.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel67.Location = new System.Drawing.Point(285,629);
this.solvencyLabel67.Name = "solvencyLabel67";
this.solvencyLabel67.OrdinateID_Label = 0;
this.solvencyLabel67.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel67.TabIndex = 67;
this.solvencyLabel67.Text = "R0300" ;
this.solvencyLabel67.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel68
//
this.solvencyLabel68.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel68.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel68.Location = new System.Drawing.Point(24,649);
this.solvencyLabel68.Name = "solvencyLabel68";
this.solvencyLabel68.OrdinateID_Label = 1162;
this.solvencyLabel68.Size = new System.Drawing.Size(247, 30);
this.solvencyLabel68.TabIndex = 68;
this.solvencyLabel68.Text = "Life and health similar to life, excluding health and index-linked and unit-linked" ;
this.solvencyLabel68.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel69
//
this.solvencyLabel69.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel69.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel69.Location = new System.Drawing.Point(285,649);
this.solvencyLabel69.Name = "solvencyLabel69";
this.solvencyLabel69.OrdinateID_Label = 0;
this.solvencyLabel69.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel69.TabIndex = 69;
this.solvencyLabel69.Text = "R0310" ;
this.solvencyLabel69.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel70
//
this.solvencyLabel70.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel70.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel70.Location = new System.Drawing.Point(31,682);
this.solvencyLabel70.Name = "solvencyLabel70";
this.solvencyLabel70.OrdinateID_Label = 1163;
this.solvencyLabel70.Size = new System.Drawing.Size(240, 15);
this.solvencyLabel70.TabIndex = 70;
this.solvencyLabel70.Text = "Health similar to life" ;
this.solvencyLabel70.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel71
//
this.solvencyLabel71.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel71.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel71.Location = new System.Drawing.Point(285,682);
this.solvencyLabel71.Name = "solvencyLabel71";
this.solvencyLabel71.OrdinateID_Label = 0;
this.solvencyLabel71.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel71.TabIndex = 71;
this.solvencyLabel71.Text = "R0320" ;
this.solvencyLabel71.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel72
//
this.solvencyLabel72.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel72.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel72.Location = new System.Drawing.Point(31,702);
this.solvencyLabel72.Name = "solvencyLabel72";
this.solvencyLabel72.OrdinateID_Label = 1164;
this.solvencyLabel72.Size = new System.Drawing.Size(240, 30);
this.solvencyLabel72.TabIndex = 72;
this.solvencyLabel72.Text = "Life excluding health and index-linked and unit-linked" ;
this.solvencyLabel72.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel73
//
this.solvencyLabel73.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel73.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel73.Location = new System.Drawing.Point(285,702);
this.solvencyLabel73.Name = "solvencyLabel73";
this.solvencyLabel73.OrdinateID_Label = 0;
this.solvencyLabel73.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel73.TabIndex = 73;
this.solvencyLabel73.Text = "R0330" ;
this.solvencyLabel73.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel74
//
this.solvencyLabel74.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel74.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel74.Location = new System.Drawing.Point(24,735);
this.solvencyLabel74.Name = "solvencyLabel74";
this.solvencyLabel74.OrdinateID_Label = 1165;
this.solvencyLabel74.Size = new System.Drawing.Size(247, 15);
this.solvencyLabel74.TabIndex = 74;
this.solvencyLabel74.Text = "Life index-linked and unit-linked" ;
this.solvencyLabel74.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel75
//
this.solvencyLabel75.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel75.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel75.Location = new System.Drawing.Point(285,735);
this.solvencyLabel75.Name = "solvencyLabel75";
this.solvencyLabel75.OrdinateID_Label = 0;
this.solvencyLabel75.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel75.TabIndex = 75;
this.solvencyLabel75.Text = "R0340" ;
this.solvencyLabel75.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel76
//
this.solvencyLabel76.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel76.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel76.Location = new System.Drawing.Point(17,755);
this.solvencyLabel76.Name = "solvencyLabel76";
this.solvencyLabel76.OrdinateID_Label = 1166;
this.solvencyLabel76.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel76.TabIndex = 76;
this.solvencyLabel76.Text = "Deposits to cedants" ;
this.solvencyLabel76.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel77
//
this.solvencyLabel77.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel77.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel77.Location = new System.Drawing.Point(285,755);
this.solvencyLabel77.Name = "solvencyLabel77";
this.solvencyLabel77.OrdinateID_Label = 0;
this.solvencyLabel77.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel77.TabIndex = 77;
this.solvencyLabel77.Text = "R0350" ;
this.solvencyLabel77.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel78
//
this.solvencyLabel78.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel78.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel78.Location = new System.Drawing.Point(17,775);
this.solvencyLabel78.Name = "solvencyLabel78";
this.solvencyLabel78.OrdinateID_Label = 1167;
this.solvencyLabel78.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel78.TabIndex = 78;
this.solvencyLabel78.Text = "Insurance and intermediaries receivables" ;
this.solvencyLabel78.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel79
//
this.solvencyLabel79.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel79.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel79.Location = new System.Drawing.Point(285,775);
this.solvencyLabel79.Name = "solvencyLabel79";
this.solvencyLabel79.OrdinateID_Label = 0;
this.solvencyLabel79.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel79.TabIndex = 79;
this.solvencyLabel79.Text = "R0360" ;
this.solvencyLabel79.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel80
//
this.solvencyLabel80.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel80.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel80.Location = new System.Drawing.Point(17,795);
this.solvencyLabel80.Name = "solvencyLabel80";
this.solvencyLabel80.OrdinateID_Label = 1168;
this.solvencyLabel80.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel80.TabIndex = 80;
this.solvencyLabel80.Text = "Reinsurance receivables" ;
this.solvencyLabel80.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel81
//
this.solvencyLabel81.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel81.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel81.Location = new System.Drawing.Point(285,795);
this.solvencyLabel81.Name = "solvencyLabel81";
this.solvencyLabel81.OrdinateID_Label = 0;
this.solvencyLabel81.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel81.TabIndex = 81;
this.solvencyLabel81.Text = "R0370" ;
this.solvencyLabel81.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel82
//
this.solvencyLabel82.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel82.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel82.Location = new System.Drawing.Point(17,815);
this.solvencyLabel82.Name = "solvencyLabel82";
this.solvencyLabel82.OrdinateID_Label = 1169;
this.solvencyLabel82.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel82.TabIndex = 82;
this.solvencyLabel82.Text = "Receivables (trade, not insurance)" ;
this.solvencyLabel82.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel83
//
this.solvencyLabel83.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel83.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel83.Location = new System.Drawing.Point(285,815);
this.solvencyLabel83.Name = "solvencyLabel83";
this.solvencyLabel83.OrdinateID_Label = 0;
this.solvencyLabel83.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel83.TabIndex = 83;
this.solvencyLabel83.Text = "R0380" ;
this.solvencyLabel83.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel84
//
this.solvencyLabel84.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel84.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel84.Location = new System.Drawing.Point(17,835);
this.solvencyLabel84.Name = "solvencyLabel84";
this.solvencyLabel84.OrdinateID_Label = 1170;
this.solvencyLabel84.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel84.TabIndex = 84;
this.solvencyLabel84.Text = "Own shares (held directly)" ;
this.solvencyLabel84.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel85
//
this.solvencyLabel85.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel85.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel85.Location = new System.Drawing.Point(285,835);
this.solvencyLabel85.Name = "solvencyLabel85";
this.solvencyLabel85.OrdinateID_Label = 0;
this.solvencyLabel85.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel85.TabIndex = 85;
this.solvencyLabel85.Text = "R0390" ;
this.solvencyLabel85.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel86
//
this.solvencyLabel86.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel86.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel86.Location = new System.Drawing.Point(17,855);
this.solvencyLabel86.Name = "solvencyLabel86";
this.solvencyLabel86.OrdinateID_Label = 1171;
this.solvencyLabel86.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel86.TabIndex = 86;
this.solvencyLabel86.Text = "Amounts due in respect of own fund items or initial fund called up but not yet paid in" ;
this.solvencyLabel86.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel87
//
this.solvencyLabel87.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel87.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel87.Location = new System.Drawing.Point(285,855);
this.solvencyLabel87.Name = "solvencyLabel87";
this.solvencyLabel87.OrdinateID_Label = 0;
this.solvencyLabel87.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel87.TabIndex = 87;
this.solvencyLabel87.Text = "R0400" ;
this.solvencyLabel87.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel88
//
this.solvencyLabel88.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel88.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel88.Location = new System.Drawing.Point(17,888);
this.solvencyLabel88.Name = "solvencyLabel88";
this.solvencyLabel88.OrdinateID_Label = 1172;
this.solvencyLabel88.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel88.TabIndex = 88;
this.solvencyLabel88.Text = "Cash and cash equivalents" ;
this.solvencyLabel88.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel89
//
this.solvencyLabel89.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel89.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel89.Location = new System.Drawing.Point(285,888);
this.solvencyLabel89.Name = "solvencyLabel89";
this.solvencyLabel89.OrdinateID_Label = 0;
this.solvencyLabel89.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel89.TabIndex = 89;
this.solvencyLabel89.Text = "R0410" ;
this.solvencyLabel89.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel90
//
this.solvencyLabel90.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel90.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel90.Location = new System.Drawing.Point(17,908);
this.solvencyLabel90.Name = "solvencyLabel90";
this.solvencyLabel90.OrdinateID_Label = 1173;
this.solvencyLabel90.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel90.TabIndex = 90;
this.solvencyLabel90.Text = "Any other assets, not elsewhere shown" ;
this.solvencyLabel90.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel91
//
this.solvencyLabel91.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel91.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel91.Location = new System.Drawing.Point(285,908);
this.solvencyLabel91.Name = "solvencyLabel91";
this.solvencyLabel91.OrdinateID_Label = 0;
this.solvencyLabel91.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel91.TabIndex = 91;
this.solvencyLabel91.Text = "R0420" ;
this.solvencyLabel91.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel92
//
this.solvencyLabel92.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel92.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel92.Location = new System.Drawing.Point(17,928);
this.solvencyLabel92.Name = "solvencyLabel92";
this.solvencyLabel92.OrdinateID_Label = 1174;
this.solvencyLabel92.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel92.TabIndex = 92;
this.solvencyLabel92.Text = "Total assets" ;
this.solvencyLabel92.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel93
//
this.solvencyLabel93.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel93.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel93.Location = new System.Drawing.Point(285,928);
this.solvencyLabel93.Name = "solvencyLabel93";
this.solvencyLabel93.OrdinateID_Label = 0;
this.solvencyLabel93.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel93.TabIndex = 93;
this.solvencyLabel93.Text = "R0500" ;
this.solvencyLabel93.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel94
//
this.solvencyLabel94.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel94.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel94.Location = new System.Drawing.Point(10,948);
this.solvencyLabel94.Name = "solvencyLabel94";
this.solvencyLabel94.OrdinateID_Label = 1175;
this.solvencyLabel94.Size = new System.Drawing.Size(261, 15);
this.solvencyLabel94.TabIndex = 94;
this.solvencyLabel94.Text = "Liabilities" ;
this.solvencyLabel94.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel95
//
this.solvencyLabel95.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel95.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel95.Location = new System.Drawing.Point(285,948);
this.solvencyLabel95.Name = "solvencyLabel95";
this.solvencyLabel95.OrdinateID_Label = 0;
this.solvencyLabel95.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel95.TabIndex = 95;
this.solvencyLabel95.Text = "" ;
this.solvencyLabel95.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel96
//
this.solvencyLabel96.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel96.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel96.Location = new System.Drawing.Point(17,968);
this.solvencyLabel96.Name = "solvencyLabel96";
this.solvencyLabel96.OrdinateID_Label = 1176;
this.solvencyLabel96.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel96.TabIndex = 96;
this.solvencyLabel96.Text = "Technical provisions – non-life" ;
this.solvencyLabel96.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel97
//
this.solvencyLabel97.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel97.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel97.Location = new System.Drawing.Point(285,968);
this.solvencyLabel97.Name = "solvencyLabel97";
this.solvencyLabel97.OrdinateID_Label = 0;
this.solvencyLabel97.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel97.TabIndex = 97;
this.solvencyLabel97.Text = "R0510" ;
this.solvencyLabel97.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel98
//
this.solvencyLabel98.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel98.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel98.Location = new System.Drawing.Point(24,988);
this.solvencyLabel98.Name = "solvencyLabel98";
this.solvencyLabel98.OrdinateID_Label = 1177;
this.solvencyLabel98.Size = new System.Drawing.Size(247, 15);
this.solvencyLabel98.TabIndex = 98;
this.solvencyLabel98.Text = "Technical provisions – non-life (excluding health)" ;
this.solvencyLabel98.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel99
//
this.solvencyLabel99.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel99.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel99.Location = new System.Drawing.Point(285,988);
this.solvencyLabel99.Name = "solvencyLabel99";
this.solvencyLabel99.OrdinateID_Label = 0;
this.solvencyLabel99.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel99.TabIndex = 99;
this.solvencyLabel99.Text = "R0520" ;
this.solvencyLabel99.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel100
//
this.solvencyLabel100.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel100.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel100.Location = new System.Drawing.Point(31,1008);
this.solvencyLabel100.Name = "solvencyLabel100";
this.solvencyLabel100.OrdinateID_Label = 1178;
this.solvencyLabel100.Size = new System.Drawing.Size(240, 15);
this.solvencyLabel100.TabIndex = 100;
this.solvencyLabel100.Text = "Technical provisions calculated as a whole" ;
this.solvencyLabel100.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel101
//
this.solvencyLabel101.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel101.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel101.Location = new System.Drawing.Point(285,1008);
this.solvencyLabel101.Name = "solvencyLabel101";
this.solvencyLabel101.OrdinateID_Label = 0;
this.solvencyLabel101.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel101.TabIndex = 101;
this.solvencyLabel101.Text = "R0530" ;
this.solvencyLabel101.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel102
//
this.solvencyLabel102.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel102.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel102.Location = new System.Drawing.Point(31,1028);
this.solvencyLabel102.Name = "solvencyLabel102";
this.solvencyLabel102.OrdinateID_Label = 1179;
this.solvencyLabel102.Size = new System.Drawing.Size(240, 15);
this.solvencyLabel102.TabIndex = 102;
this.solvencyLabel102.Text = "Best Estimate" ;
this.solvencyLabel102.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel103
//
this.solvencyLabel103.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel103.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel103.Location = new System.Drawing.Point(285,1028);
this.solvencyLabel103.Name = "solvencyLabel103";
this.solvencyLabel103.OrdinateID_Label = 0;
this.solvencyLabel103.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel103.TabIndex = 103;
this.solvencyLabel103.Text = "R0540" ;
this.solvencyLabel103.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel104
//
this.solvencyLabel104.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel104.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel104.Location = new System.Drawing.Point(31,1048);
this.solvencyLabel104.Name = "solvencyLabel104";
this.solvencyLabel104.OrdinateID_Label = 1180;
this.solvencyLabel104.Size = new System.Drawing.Size(240, 15);
this.solvencyLabel104.TabIndex = 104;
this.solvencyLabel104.Text = "Risk margin" ;
this.solvencyLabel104.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel105
//
this.solvencyLabel105.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel105.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel105.Location = new System.Drawing.Point(285,1048);
this.solvencyLabel105.Name = "solvencyLabel105";
this.solvencyLabel105.OrdinateID_Label = 0;
this.solvencyLabel105.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel105.TabIndex = 105;
this.solvencyLabel105.Text = "R0550" ;
this.solvencyLabel105.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel106
//
this.solvencyLabel106.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel106.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel106.Location = new System.Drawing.Point(24,1068);
this.solvencyLabel106.Name = "solvencyLabel106";
this.solvencyLabel106.OrdinateID_Label = 1181;
this.solvencyLabel106.Size = new System.Drawing.Size(247, 15);
this.solvencyLabel106.TabIndex = 106;
this.solvencyLabel106.Text = "Technical provisions - health (similar to non-life)" ;
this.solvencyLabel106.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel107
//
this.solvencyLabel107.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel107.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel107.Location = new System.Drawing.Point(285,1068);
this.solvencyLabel107.Name = "solvencyLabel107";
this.solvencyLabel107.OrdinateID_Label = 0;
this.solvencyLabel107.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel107.TabIndex = 107;
this.solvencyLabel107.Text = "R0560" ;
this.solvencyLabel107.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel108
//
this.solvencyLabel108.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel108.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel108.Location = new System.Drawing.Point(31,1088);
this.solvencyLabel108.Name = "solvencyLabel108";
this.solvencyLabel108.OrdinateID_Label = 1182;
this.solvencyLabel108.Size = new System.Drawing.Size(240, 15);
this.solvencyLabel108.TabIndex = 108;
this.solvencyLabel108.Text = "Technical provisions calculated as a whole" ;
this.solvencyLabel108.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel109
//
this.solvencyLabel109.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel109.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel109.Location = new System.Drawing.Point(285,1088);
this.solvencyLabel109.Name = "solvencyLabel109";
this.solvencyLabel109.OrdinateID_Label = 0;
this.solvencyLabel109.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel109.TabIndex = 109;
this.solvencyLabel109.Text = "R0570" ;
this.solvencyLabel109.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel110
//
this.solvencyLabel110.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel110.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel110.Location = new System.Drawing.Point(31,1108);
this.solvencyLabel110.Name = "solvencyLabel110";
this.solvencyLabel110.OrdinateID_Label = 1183;
this.solvencyLabel110.Size = new System.Drawing.Size(240, 15);
this.solvencyLabel110.TabIndex = 110;
this.solvencyLabel110.Text = "Best Estimate" ;
this.solvencyLabel110.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel111
//
this.solvencyLabel111.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel111.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel111.Location = new System.Drawing.Point(285,1108);
this.solvencyLabel111.Name = "solvencyLabel111";
this.solvencyLabel111.OrdinateID_Label = 0;
this.solvencyLabel111.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel111.TabIndex = 111;
this.solvencyLabel111.Text = "R0580" ;
this.solvencyLabel111.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel112
//
this.solvencyLabel112.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel112.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel112.Location = new System.Drawing.Point(31,1128);
this.solvencyLabel112.Name = "solvencyLabel112";
this.solvencyLabel112.OrdinateID_Label = 1184;
this.solvencyLabel112.Size = new System.Drawing.Size(240, 15);
this.solvencyLabel112.TabIndex = 112;
this.solvencyLabel112.Text = "Risk margin" ;
this.solvencyLabel112.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel113
//
this.solvencyLabel113.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel113.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel113.Location = new System.Drawing.Point(285,1128);
this.solvencyLabel113.Name = "solvencyLabel113";
this.solvencyLabel113.OrdinateID_Label = 0;
this.solvencyLabel113.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel113.TabIndex = 113;
this.solvencyLabel113.Text = "R0590" ;
this.solvencyLabel113.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel114
//
this.solvencyLabel114.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel114.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel114.Location = new System.Drawing.Point(17,1148);
this.solvencyLabel114.Name = "solvencyLabel114";
this.solvencyLabel114.OrdinateID_Label = 1185;
this.solvencyLabel114.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel114.TabIndex = 114;
this.solvencyLabel114.Text = "Technical provisions - life (excluding index-linked and unit-linked)" ;
this.solvencyLabel114.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel115
//
this.solvencyLabel115.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel115.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel115.Location = new System.Drawing.Point(285,1148);
this.solvencyLabel115.Name = "solvencyLabel115";
this.solvencyLabel115.OrdinateID_Label = 0;
this.solvencyLabel115.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel115.TabIndex = 115;
this.solvencyLabel115.Text = "R0600" ;
this.solvencyLabel115.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel116
//
this.solvencyLabel116.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel116.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel116.Location = new System.Drawing.Point(24,1181);
this.solvencyLabel116.Name = "solvencyLabel116";
this.solvencyLabel116.OrdinateID_Label = 1186;
this.solvencyLabel116.Size = new System.Drawing.Size(247, 15);
this.solvencyLabel116.TabIndex = 116;
this.solvencyLabel116.Text = "Technical provisions - health (similar to life)" ;
this.solvencyLabel116.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel117
//
this.solvencyLabel117.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel117.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel117.Location = new System.Drawing.Point(285,1181);
this.solvencyLabel117.Name = "solvencyLabel117";
this.solvencyLabel117.OrdinateID_Label = 0;
this.solvencyLabel117.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel117.TabIndex = 117;
this.solvencyLabel117.Text = "R0610" ;
this.solvencyLabel117.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel118
//
this.solvencyLabel118.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel118.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel118.Location = new System.Drawing.Point(31,1201);
this.solvencyLabel118.Name = "solvencyLabel118";
this.solvencyLabel118.OrdinateID_Label = 1187;
this.solvencyLabel118.Size = new System.Drawing.Size(240, 15);
this.solvencyLabel118.TabIndex = 118;
this.solvencyLabel118.Text = "Technical provisions calculated as a whole" ;
this.solvencyLabel118.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel119
//
this.solvencyLabel119.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel119.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel119.Location = new System.Drawing.Point(285,1201);
this.solvencyLabel119.Name = "solvencyLabel119";
this.solvencyLabel119.OrdinateID_Label = 0;
this.solvencyLabel119.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel119.TabIndex = 119;
this.solvencyLabel119.Text = "R0620" ;
this.solvencyLabel119.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel120
//
this.solvencyLabel120.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel120.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel120.Location = new System.Drawing.Point(31,1221);
this.solvencyLabel120.Name = "solvencyLabel120";
this.solvencyLabel120.OrdinateID_Label = 1188;
this.solvencyLabel120.Size = new System.Drawing.Size(240, 15);
this.solvencyLabel120.TabIndex = 120;
this.solvencyLabel120.Text = "Best Estimate" ;
this.solvencyLabel120.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel121
//
this.solvencyLabel121.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel121.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel121.Location = new System.Drawing.Point(285,1221);
this.solvencyLabel121.Name = "solvencyLabel121";
this.solvencyLabel121.OrdinateID_Label = 0;
this.solvencyLabel121.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel121.TabIndex = 121;
this.solvencyLabel121.Text = "R0630" ;
this.solvencyLabel121.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel122
//
this.solvencyLabel122.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel122.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel122.Location = new System.Drawing.Point(31,1241);
this.solvencyLabel122.Name = "solvencyLabel122";
this.solvencyLabel122.OrdinateID_Label = 1189;
this.solvencyLabel122.Size = new System.Drawing.Size(240, 15);
this.solvencyLabel122.TabIndex = 122;
this.solvencyLabel122.Text = "Risk margin" ;
this.solvencyLabel122.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel123
//
this.solvencyLabel123.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel123.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel123.Location = new System.Drawing.Point(285,1241);
this.solvencyLabel123.Name = "solvencyLabel123";
this.solvencyLabel123.OrdinateID_Label = 0;
this.solvencyLabel123.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel123.TabIndex = 123;
this.solvencyLabel123.Text = "R0640" ;
this.solvencyLabel123.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel124
//
this.solvencyLabel124.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel124.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel124.Location = new System.Drawing.Point(24,1261);
this.solvencyLabel124.Name = "solvencyLabel124";
this.solvencyLabel124.OrdinateID_Label = 1190;
this.solvencyLabel124.Size = new System.Drawing.Size(247, 30);
this.solvencyLabel124.TabIndex = 124;
this.solvencyLabel124.Text = "Technical provisions – life (excluding health and index-linked and unit-linked)" ;
this.solvencyLabel124.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel125
//
this.solvencyLabel125.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel125.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel125.Location = new System.Drawing.Point(285,1261);
this.solvencyLabel125.Name = "solvencyLabel125";
this.solvencyLabel125.OrdinateID_Label = 0;
this.solvencyLabel125.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel125.TabIndex = 125;
this.solvencyLabel125.Text = "R0650" ;
this.solvencyLabel125.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel126
//
this.solvencyLabel126.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel126.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel126.Location = new System.Drawing.Point(31,1294);
this.solvencyLabel126.Name = "solvencyLabel126";
this.solvencyLabel126.OrdinateID_Label = 1191;
this.solvencyLabel126.Size = new System.Drawing.Size(240, 15);
this.solvencyLabel126.TabIndex = 126;
this.solvencyLabel126.Text = "Technical provisions calculated as a whole" ;
this.solvencyLabel126.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel127
//
this.solvencyLabel127.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel127.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel127.Location = new System.Drawing.Point(285,1294);
this.solvencyLabel127.Name = "solvencyLabel127";
this.solvencyLabel127.OrdinateID_Label = 0;
this.solvencyLabel127.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel127.TabIndex = 127;
this.solvencyLabel127.Text = "R0660" ;
this.solvencyLabel127.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel128
//
this.solvencyLabel128.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel128.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel128.Location = new System.Drawing.Point(31,1314);
this.solvencyLabel128.Name = "solvencyLabel128";
this.solvencyLabel128.OrdinateID_Label = 1192;
this.solvencyLabel128.Size = new System.Drawing.Size(240, 15);
this.solvencyLabel128.TabIndex = 128;
this.solvencyLabel128.Text = "Best Estimate" ;
this.solvencyLabel128.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel129
//
this.solvencyLabel129.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel129.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel129.Location = new System.Drawing.Point(285,1314);
this.solvencyLabel129.Name = "solvencyLabel129";
this.solvencyLabel129.OrdinateID_Label = 0;
this.solvencyLabel129.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel129.TabIndex = 129;
this.solvencyLabel129.Text = "R0670" ;
this.solvencyLabel129.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel130
//
this.solvencyLabel130.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel130.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel130.Location = new System.Drawing.Point(31,1334);
this.solvencyLabel130.Name = "solvencyLabel130";
this.solvencyLabel130.OrdinateID_Label = 1193;
this.solvencyLabel130.Size = new System.Drawing.Size(240, 15);
this.solvencyLabel130.TabIndex = 130;
this.solvencyLabel130.Text = "Risk margin" ;
this.solvencyLabel130.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel131
//
this.solvencyLabel131.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel131.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel131.Location = new System.Drawing.Point(285,1334);
this.solvencyLabel131.Name = "solvencyLabel131";
this.solvencyLabel131.OrdinateID_Label = 0;
this.solvencyLabel131.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel131.TabIndex = 131;
this.solvencyLabel131.Text = "R0680" ;
this.solvencyLabel131.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel132
//
this.solvencyLabel132.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel132.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel132.Location = new System.Drawing.Point(17,1354);
this.solvencyLabel132.Name = "solvencyLabel132";
this.solvencyLabel132.OrdinateID_Label = 1194;
this.solvencyLabel132.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel132.TabIndex = 132;
this.solvencyLabel132.Text = "Technical provisions – index-linked and unit-linked" ;
this.solvencyLabel132.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel133
//
this.solvencyLabel133.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel133.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel133.Location = new System.Drawing.Point(285,1354);
this.solvencyLabel133.Name = "solvencyLabel133";
this.solvencyLabel133.OrdinateID_Label = 0;
this.solvencyLabel133.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel133.TabIndex = 133;
this.solvencyLabel133.Text = "R0690" ;
this.solvencyLabel133.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel134
//
this.solvencyLabel134.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel134.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel134.Location = new System.Drawing.Point(24,1374);
this.solvencyLabel134.Name = "solvencyLabel134";
this.solvencyLabel134.OrdinateID_Label = 1195;
this.solvencyLabel134.Size = new System.Drawing.Size(247, 15);
this.solvencyLabel134.TabIndex = 134;
this.solvencyLabel134.Text = "Technical provisions calculated as a whole" ;
this.solvencyLabel134.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel135
//
this.solvencyLabel135.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel135.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel135.Location = new System.Drawing.Point(285,1374);
this.solvencyLabel135.Name = "solvencyLabel135";
this.solvencyLabel135.OrdinateID_Label = 0;
this.solvencyLabel135.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel135.TabIndex = 135;
this.solvencyLabel135.Text = "R0700" ;
this.solvencyLabel135.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel136
//
this.solvencyLabel136.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel136.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel136.Location = new System.Drawing.Point(24,1394);
this.solvencyLabel136.Name = "solvencyLabel136";
this.solvencyLabel136.OrdinateID_Label = 1196;
this.solvencyLabel136.Size = new System.Drawing.Size(247, 15);
this.solvencyLabel136.TabIndex = 136;
this.solvencyLabel136.Text = "Best Estimate" ;
this.solvencyLabel136.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel137
//
this.solvencyLabel137.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel137.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel137.Location = new System.Drawing.Point(285,1394);
this.solvencyLabel137.Name = "solvencyLabel137";
this.solvencyLabel137.OrdinateID_Label = 0;
this.solvencyLabel137.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel137.TabIndex = 137;
this.solvencyLabel137.Text = "R0710" ;
this.solvencyLabel137.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel138
//
this.solvencyLabel138.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel138.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel138.Location = new System.Drawing.Point(24,1414);
this.solvencyLabel138.Name = "solvencyLabel138";
this.solvencyLabel138.OrdinateID_Label = 1197;
this.solvencyLabel138.Size = new System.Drawing.Size(247, 15);
this.solvencyLabel138.TabIndex = 138;
this.solvencyLabel138.Text = "Risk margin" ;
this.solvencyLabel138.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel139
//
this.solvencyLabel139.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel139.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel139.Location = new System.Drawing.Point(285,1414);
this.solvencyLabel139.Name = "solvencyLabel139";
this.solvencyLabel139.OrdinateID_Label = 0;
this.solvencyLabel139.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel139.TabIndex = 139;
this.solvencyLabel139.Text = "R0720" ;
this.solvencyLabel139.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel140
//
this.solvencyLabel140.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel140.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel140.Location = new System.Drawing.Point(17,1434);
this.solvencyLabel140.Name = "solvencyLabel140";
this.solvencyLabel140.OrdinateID_Label = 1198;
this.solvencyLabel140.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel140.TabIndex = 140;
this.solvencyLabel140.Text = "Other technical provisions" ;
this.solvencyLabel140.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel141
//
this.solvencyLabel141.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel141.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel141.Location = new System.Drawing.Point(285,1434);
this.solvencyLabel141.Name = "solvencyLabel141";
this.solvencyLabel141.OrdinateID_Label = 0;
this.solvencyLabel141.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel141.TabIndex = 141;
this.solvencyLabel141.Text = "R0730" ;
this.solvencyLabel141.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel142
//
this.solvencyLabel142.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel142.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel142.Location = new System.Drawing.Point(17,1454);
this.solvencyLabel142.Name = "solvencyLabel142";
this.solvencyLabel142.OrdinateID_Label = 1199;
this.solvencyLabel142.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel142.TabIndex = 142;
this.solvencyLabel142.Text = "Contingent liabilities" ;
this.solvencyLabel142.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel143
//
this.solvencyLabel143.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel143.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel143.Location = new System.Drawing.Point(285,1454);
this.solvencyLabel143.Name = "solvencyLabel143";
this.solvencyLabel143.OrdinateID_Label = 0;
this.solvencyLabel143.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel143.TabIndex = 143;
this.solvencyLabel143.Text = "R0740" ;
this.solvencyLabel143.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel144
//
this.solvencyLabel144.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel144.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel144.Location = new System.Drawing.Point(17,1474);
this.solvencyLabel144.Name = "solvencyLabel144";
this.solvencyLabel144.OrdinateID_Label = 1200;
this.solvencyLabel144.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel144.TabIndex = 144;
this.solvencyLabel144.Text = "Provisions other than technical provisions" ;
this.solvencyLabel144.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel145
//
this.solvencyLabel145.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel145.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel145.Location = new System.Drawing.Point(285,1474);
this.solvencyLabel145.Name = "solvencyLabel145";
this.solvencyLabel145.OrdinateID_Label = 0;
this.solvencyLabel145.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel145.TabIndex = 145;
this.solvencyLabel145.Text = "R0750" ;
this.solvencyLabel145.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel146
//
this.solvencyLabel146.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel146.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel146.Location = new System.Drawing.Point(17,1494);
this.solvencyLabel146.Name = "solvencyLabel146";
this.solvencyLabel146.OrdinateID_Label = 1201;
this.solvencyLabel146.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel146.TabIndex = 146;
this.solvencyLabel146.Text = "Pension benefit obligations" ;
this.solvencyLabel146.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel147
//
this.solvencyLabel147.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel147.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel147.Location = new System.Drawing.Point(285,1494);
this.solvencyLabel147.Name = "solvencyLabel147";
this.solvencyLabel147.OrdinateID_Label = 0;
this.solvencyLabel147.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel147.TabIndex = 147;
this.solvencyLabel147.Text = "R0760" ;
this.solvencyLabel147.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel148
//
this.solvencyLabel148.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel148.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel148.Location = new System.Drawing.Point(17,1514);
this.solvencyLabel148.Name = "solvencyLabel148";
this.solvencyLabel148.OrdinateID_Label = 1202;
this.solvencyLabel148.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel148.TabIndex = 148;
this.solvencyLabel148.Text = "Deposits from reinsurers" ;
this.solvencyLabel148.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel149
//
this.solvencyLabel149.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel149.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel149.Location = new System.Drawing.Point(285,1514);
this.solvencyLabel149.Name = "solvencyLabel149";
this.solvencyLabel149.OrdinateID_Label = 0;
this.solvencyLabel149.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel149.TabIndex = 149;
this.solvencyLabel149.Text = "R0770" ;
this.solvencyLabel149.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel150
//
this.solvencyLabel150.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel150.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel150.Location = new System.Drawing.Point(17,1534);
this.solvencyLabel150.Name = "solvencyLabel150";
this.solvencyLabel150.OrdinateID_Label = 1203;
this.solvencyLabel150.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel150.TabIndex = 150;
this.solvencyLabel150.Text = "Deferred tax liabilities" ;
this.solvencyLabel150.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel151
//
this.solvencyLabel151.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel151.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel151.Location = new System.Drawing.Point(285,1534);
this.solvencyLabel151.Name = "solvencyLabel151";
this.solvencyLabel151.OrdinateID_Label = 0;
this.solvencyLabel151.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel151.TabIndex = 151;
this.solvencyLabel151.Text = "R0780" ;
this.solvencyLabel151.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel152
//
this.solvencyLabel152.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel152.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel152.Location = new System.Drawing.Point(17,1554);
this.solvencyLabel152.Name = "solvencyLabel152";
this.solvencyLabel152.OrdinateID_Label = 1204;
this.solvencyLabel152.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel152.TabIndex = 152;
this.solvencyLabel152.Text = "Derivatives" ;
this.solvencyLabel152.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel153
//
this.solvencyLabel153.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel153.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel153.Location = new System.Drawing.Point(285,1554);
this.solvencyLabel153.Name = "solvencyLabel153";
this.solvencyLabel153.OrdinateID_Label = 0;
this.solvencyLabel153.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel153.TabIndex = 153;
this.solvencyLabel153.Text = "R0790" ;
this.solvencyLabel153.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel154
//
this.solvencyLabel154.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel154.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel154.Location = new System.Drawing.Point(17,1574);
this.solvencyLabel154.Name = "solvencyLabel154";
this.solvencyLabel154.OrdinateID_Label = 1205;
this.solvencyLabel154.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel154.TabIndex = 154;
this.solvencyLabel154.Text = "Debts owed to credit institutions" ;
this.solvencyLabel154.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel155
//
this.solvencyLabel155.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel155.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel155.Location = new System.Drawing.Point(285,1574);
this.solvencyLabel155.Name = "solvencyLabel155";
this.solvencyLabel155.OrdinateID_Label = 0;
this.solvencyLabel155.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel155.TabIndex = 155;
this.solvencyLabel155.Text = "R0800" ;
this.solvencyLabel155.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel156
//
this.solvencyLabel156.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel156.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel156.Location = new System.Drawing.Point(24,1594);
this.solvencyLabel156.Name = "solvencyLabel156";
this.solvencyLabel156.OrdinateID_Label = 1206;
this.solvencyLabel156.Size = new System.Drawing.Size(247, 30);
this.solvencyLabel156.TabIndex = 156;
this.solvencyLabel156.Text = "Debts owed to credit institutions resident domestically" ;
this.solvencyLabel156.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel157
//
this.solvencyLabel157.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel157.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel157.Location = new System.Drawing.Point(285,1594);
this.solvencyLabel157.Name = "solvencyLabel157";
this.solvencyLabel157.OrdinateID_Label = 0;
this.solvencyLabel157.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel157.TabIndex = 157;
this.solvencyLabel157.Text = "ER0801" ;
this.solvencyLabel157.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel158
//
this.solvencyLabel158.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel158.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel158.Location = new System.Drawing.Point(24,1627);
this.solvencyLabel158.Name = "solvencyLabel158";
this.solvencyLabel158.OrdinateID_Label = 1207;
this.solvencyLabel158.Size = new System.Drawing.Size(247, 30);
this.solvencyLabel158.TabIndex = 158;
this.solvencyLabel158.Text = "Debts owed to credit institutions resident in the euro area other than domestic" ;
this.solvencyLabel158.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel159
//
this.solvencyLabel159.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel159.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel159.Location = new System.Drawing.Point(285,1627);
this.solvencyLabel159.Name = "solvencyLabel159";
this.solvencyLabel159.OrdinateID_Label = 0;
this.solvencyLabel159.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel159.TabIndex = 159;
this.solvencyLabel159.Text = "ER0802" ;
this.solvencyLabel159.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel160
//
this.solvencyLabel160.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel160.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel160.Location = new System.Drawing.Point(24,1660);
this.solvencyLabel160.Name = "solvencyLabel160";
this.solvencyLabel160.OrdinateID_Label = 1208;
this.solvencyLabel160.Size = new System.Drawing.Size(247, 30);
this.solvencyLabel160.TabIndex = 160;
this.solvencyLabel160.Text = "Debts owed to credit institutions resident in rest of the world" ;
this.solvencyLabel160.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel161
//
this.solvencyLabel161.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel161.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel161.Location = new System.Drawing.Point(285,1660);
this.solvencyLabel161.Name = "solvencyLabel161";
this.solvencyLabel161.OrdinateID_Label = 0;
this.solvencyLabel161.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel161.TabIndex = 161;
this.solvencyLabel161.Text = "ER0803" ;
this.solvencyLabel161.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel162
//
this.solvencyLabel162.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel162.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel162.Location = new System.Drawing.Point(17,1693);
this.solvencyLabel162.Name = "solvencyLabel162";
this.solvencyLabel162.OrdinateID_Label = 1209;
this.solvencyLabel162.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel162.TabIndex = 162;
this.solvencyLabel162.Text = "Financial liabilities other than debts owed to credit institutions" ;
this.solvencyLabel162.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel163
//
this.solvencyLabel163.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel163.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel163.Location = new System.Drawing.Point(285,1693);
this.solvencyLabel163.Name = "solvencyLabel163";
this.solvencyLabel163.OrdinateID_Label = 0;
this.solvencyLabel163.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel163.TabIndex = 163;
this.solvencyLabel163.Text = "R0810" ;
this.solvencyLabel163.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel164
//
this.solvencyLabel164.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel164.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel164.Location = new System.Drawing.Point(24,1726);
this.solvencyLabel164.Name = "solvencyLabel164";
this.solvencyLabel164.OrdinateID_Label = 1210;
this.solvencyLabel164.Size = new System.Drawing.Size(247, 15);
this.solvencyLabel164.TabIndex = 164;
this.solvencyLabel164.Text = "Debts owed to non-credit institutions" ;
this.solvencyLabel164.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel165
//
this.solvencyLabel165.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel165.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel165.Location = new System.Drawing.Point(285,1726);
this.solvencyLabel165.Name = "solvencyLabel165";
this.solvencyLabel165.OrdinateID_Label = 0;
this.solvencyLabel165.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel165.TabIndex = 165;
this.solvencyLabel165.Text = "ER0811" ;
this.solvencyLabel165.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel166
//
this.solvencyLabel166.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel166.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel166.Location = new System.Drawing.Point(31,1746);
this.solvencyLabel166.Name = "solvencyLabel166";
this.solvencyLabel166.OrdinateID_Label = 1211;
this.solvencyLabel166.Size = new System.Drawing.Size(240, 30);
this.solvencyLabel166.TabIndex = 166;
this.solvencyLabel166.Text = "Debts owed to non-credit institutions resident domestically" ;
this.solvencyLabel166.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel167
//
this.solvencyLabel167.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel167.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel167.Location = new System.Drawing.Point(285,1746);
this.solvencyLabel167.Name = "solvencyLabel167";
this.solvencyLabel167.OrdinateID_Label = 0;
this.solvencyLabel167.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel167.TabIndex = 167;
this.solvencyLabel167.Text = "ER0812" ;
this.solvencyLabel167.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel168
//
this.solvencyLabel168.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel168.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel168.Location = new System.Drawing.Point(31,1779);
this.solvencyLabel168.Name = "solvencyLabel168";
this.solvencyLabel168.OrdinateID_Label = 1212;
this.solvencyLabel168.Size = new System.Drawing.Size(240, 30);
this.solvencyLabel168.TabIndex = 168;
this.solvencyLabel168.Text = "Debts owed to non-credit institutions resident in the euro area other than domestic" ;
this.solvencyLabel168.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel169
//
this.solvencyLabel169.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel169.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel169.Location = new System.Drawing.Point(285,1779);
this.solvencyLabel169.Name = "solvencyLabel169";
this.solvencyLabel169.OrdinateID_Label = 0;
this.solvencyLabel169.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel169.TabIndex = 169;
this.solvencyLabel169.Text = "ER0813" ;
this.solvencyLabel169.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel170
//
this.solvencyLabel170.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel170.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel170.Location = new System.Drawing.Point(31,1812);
this.solvencyLabel170.Name = "solvencyLabel170";
this.solvencyLabel170.OrdinateID_Label = 1213;
this.solvencyLabel170.Size = new System.Drawing.Size(240, 30);
this.solvencyLabel170.TabIndex = 170;
this.solvencyLabel170.Text = "Debts owed to non-credit institutions resident in rest of the world" ;
this.solvencyLabel170.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel171
//
this.solvencyLabel171.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel171.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel171.Location = new System.Drawing.Point(285,1812);
this.solvencyLabel171.Name = "solvencyLabel171";
this.solvencyLabel171.OrdinateID_Label = 0;
this.solvencyLabel171.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel171.TabIndex = 171;
this.solvencyLabel171.Text = "ER0814" ;
this.solvencyLabel171.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel172
//
this.solvencyLabel172.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel172.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel172.Location = new System.Drawing.Point(24,1845);
this.solvencyLabel172.Name = "solvencyLabel172";
this.solvencyLabel172.OrdinateID_Label = 1214;
this.solvencyLabel172.Size = new System.Drawing.Size(247, 15);
this.solvencyLabel172.TabIndex = 172;
this.solvencyLabel172.Text = "Other financial liabilities (debt securities issued)" ;
this.solvencyLabel172.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel173
//
this.solvencyLabel173.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel173.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel173.Location = new System.Drawing.Point(285,1845);
this.solvencyLabel173.Name = "solvencyLabel173";
this.solvencyLabel173.OrdinateID_Label = 0;
this.solvencyLabel173.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel173.TabIndex = 173;
this.solvencyLabel173.Text = "ER0815" ;
this.solvencyLabel173.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel174
//
this.solvencyLabel174.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel174.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel174.Location = new System.Drawing.Point(17,1865);
this.solvencyLabel174.Name = "solvencyLabel174";
this.solvencyLabel174.OrdinateID_Label = 1215;
this.solvencyLabel174.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel174.TabIndex = 174;
this.solvencyLabel174.Text = "Insurance & intermediaries payables" ;
this.solvencyLabel174.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel175
//
this.solvencyLabel175.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel175.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel175.Location = new System.Drawing.Point(285,1865);
this.solvencyLabel175.Name = "solvencyLabel175";
this.solvencyLabel175.OrdinateID_Label = 0;
this.solvencyLabel175.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel175.TabIndex = 175;
this.solvencyLabel175.Text = "R0820" ;
this.solvencyLabel175.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel176
//
this.solvencyLabel176.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel176.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel176.Location = new System.Drawing.Point(17,1885);
this.solvencyLabel176.Name = "solvencyLabel176";
this.solvencyLabel176.OrdinateID_Label = 1216;
this.solvencyLabel176.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel176.TabIndex = 176;
this.solvencyLabel176.Text = "Reinsurance payables" ;
this.solvencyLabel176.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel177
//
this.solvencyLabel177.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel177.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel177.Location = new System.Drawing.Point(285,1885);
this.solvencyLabel177.Name = "solvencyLabel177";
this.solvencyLabel177.OrdinateID_Label = 0;
this.solvencyLabel177.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel177.TabIndex = 177;
this.solvencyLabel177.Text = "R0830" ;
this.solvencyLabel177.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel178
//
this.solvencyLabel178.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel178.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel178.Location = new System.Drawing.Point(17,1905);
this.solvencyLabel178.Name = "solvencyLabel178";
this.solvencyLabel178.OrdinateID_Label = 1217;
this.solvencyLabel178.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel178.TabIndex = 178;
this.solvencyLabel178.Text = "Payables (trade, not insurance)" ;
this.solvencyLabel178.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel179
//
this.solvencyLabel179.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel179.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel179.Location = new System.Drawing.Point(285,1905);
this.solvencyLabel179.Name = "solvencyLabel179";
this.solvencyLabel179.OrdinateID_Label = 0;
this.solvencyLabel179.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel179.TabIndex = 179;
this.solvencyLabel179.Text = "R0840" ;
this.solvencyLabel179.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel180
//
this.solvencyLabel180.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel180.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel180.Location = new System.Drawing.Point(17,1925);
this.solvencyLabel180.Name = "solvencyLabel180";
this.solvencyLabel180.OrdinateID_Label = 1218;
this.solvencyLabel180.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel180.TabIndex = 180;
this.solvencyLabel180.Text = "Subordinated liabilities" ;
this.solvencyLabel180.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel181
//
this.solvencyLabel181.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel181.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel181.Location = new System.Drawing.Point(285,1925);
this.solvencyLabel181.Name = "solvencyLabel181";
this.solvencyLabel181.OrdinateID_Label = 0;
this.solvencyLabel181.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel181.TabIndex = 181;
this.solvencyLabel181.Text = "R0850" ;
this.solvencyLabel181.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel182
//
this.solvencyLabel182.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel182.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel182.Location = new System.Drawing.Point(24,1945);
this.solvencyLabel182.Name = "solvencyLabel182";
this.solvencyLabel182.OrdinateID_Label = 1219;
this.solvencyLabel182.Size = new System.Drawing.Size(247, 15);
this.solvencyLabel182.TabIndex = 182;
this.solvencyLabel182.Text = "Subordinated liabilities not in Basic Own Funds" ;
this.solvencyLabel182.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel183
//
this.solvencyLabel183.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel183.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel183.Location = new System.Drawing.Point(285,1945);
this.solvencyLabel183.Name = "solvencyLabel183";
this.solvencyLabel183.OrdinateID_Label = 0;
this.solvencyLabel183.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel183.TabIndex = 183;
this.solvencyLabel183.Text = "R0860" ;
this.solvencyLabel183.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel184
//
this.solvencyLabel184.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel184.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel184.Location = new System.Drawing.Point(24,1965);
this.solvencyLabel184.Name = "solvencyLabel184";
this.solvencyLabel184.OrdinateID_Label = 1220;
this.solvencyLabel184.Size = new System.Drawing.Size(247, 15);
this.solvencyLabel184.TabIndex = 184;
this.solvencyLabel184.Text = "Subordinated liabilities in Basic Own Funds" ;
this.solvencyLabel184.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel185
//
this.solvencyLabel185.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel185.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel185.Location = new System.Drawing.Point(285,1965);
this.solvencyLabel185.Name = "solvencyLabel185";
this.solvencyLabel185.OrdinateID_Label = 0;
this.solvencyLabel185.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel185.TabIndex = 185;
this.solvencyLabel185.Text = "R0870" ;
this.solvencyLabel185.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel186
//
this.solvencyLabel186.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel186.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel186.Location = new System.Drawing.Point(17,1985);
this.solvencyLabel186.Name = "solvencyLabel186";
this.solvencyLabel186.OrdinateID_Label = 1221;
this.solvencyLabel186.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel186.TabIndex = 186;
this.solvencyLabel186.Text = "Any other liabilities, not elsewhere shown" ;
this.solvencyLabel186.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel187
//
this.solvencyLabel187.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel187.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel187.Location = new System.Drawing.Point(285,1985);
this.solvencyLabel187.Name = "solvencyLabel187";
this.solvencyLabel187.OrdinateID_Label = 0;
this.solvencyLabel187.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel187.TabIndex = 187;
this.solvencyLabel187.Text = "R0880" ;
this.solvencyLabel187.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel188
//
this.solvencyLabel188.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel188.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel188.Location = new System.Drawing.Point(17,2005);
this.solvencyLabel188.Name = "solvencyLabel188";
this.solvencyLabel188.OrdinateID_Label = 1222;
this.solvencyLabel188.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel188.TabIndex = 188;
this.solvencyLabel188.Text = "Total liabilities" ;
this.solvencyLabel188.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel189
//
this.solvencyLabel189.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel189.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel189.Location = new System.Drawing.Point(285,2005);
this.solvencyLabel189.Name = "solvencyLabel189";
this.solvencyLabel189.OrdinateID_Label = 0;
this.solvencyLabel189.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel189.TabIndex = 189;
this.solvencyLabel189.Text = "R0900" ;
this.solvencyLabel189.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel190
//
this.solvencyLabel190.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel190.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel190.Location = new System.Drawing.Point(10,2025);
this.solvencyLabel190.Name = "solvencyLabel190";
this.solvencyLabel190.OrdinateID_Label = 1223;
this.solvencyLabel190.Size = new System.Drawing.Size(261, 15);
this.solvencyLabel190.TabIndex = 190;
this.solvencyLabel190.Text = "Excess of assets over liabilities" ;
this.solvencyLabel190.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel191
//
this.solvencyLabel191.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel191.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel191.Location = new System.Drawing.Point(285,2025);
this.solvencyLabel191.Name = "solvencyLabel191";
this.solvencyLabel191.OrdinateID_Label = 0;
this.solvencyLabel191.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel191.TabIndex = 191;
this.solvencyLabel191.Text = "R1000" ;
this.solvencyLabel191.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel192
//
this.solvencyLabel192.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel192.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel192.Location = new System.Drawing.Point(285,2045);
this.solvencyLabel192.Name = "solvencyLabel192";
this.solvencyLabel192.OrdinateID_Label = 0;
this.solvencyLabel192.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel192.TabIndex = 192;
this.solvencyLabel192.Text = "." ;
this.solvencyLabel192.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyCurrencyTextBox193
//
this.solvencyCurrencyTextBox193.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox193.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox193.Location = new System.Drawing.Point(10,23);
this.solvencyCurrencyTextBox193.Name = "solvencyCurrencyTextBox193";
this.solvencyCurrencyTextBox193.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox193.TabIndex = 193;
this.solvencyCurrencyTextBox193.ColName = "R0010C0010";
this.solvencyCurrencyTextBox193.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox193.Enabled = false;
this.solvencyCurrencyTextBox193.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox194
//
this.solvencyCurrencyTextBox194.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox194.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox194.Location = new System.Drawing.Point(117,23);
this.solvencyCurrencyTextBox194.Name = "solvencyCurrencyTextBox194";
this.solvencyCurrencyTextBox194.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox194.TabIndex = 194;
this.solvencyCurrencyTextBox194.ColName = "R0010C0020";
this.solvencyCurrencyTextBox194.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox195
//
this.solvencyCurrencyTextBox195.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox195.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox195.Location = new System.Drawing.Point(224,23);
this.solvencyCurrencyTextBox195.Name = "solvencyCurrencyTextBox195";
this.solvencyCurrencyTextBox195.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox195.TabIndex = 195;
this.solvencyCurrencyTextBox195.ColName = "R0010EC0021";
this.solvencyCurrencyTextBox195.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox195.Enabled = false;
this.solvencyCurrencyTextBox195.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox196
//
this.solvencyCurrencyTextBox196.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox196.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox196.Location = new System.Drawing.Point(10,43);
this.solvencyCurrencyTextBox196.Name = "solvencyCurrencyTextBox196";
this.solvencyCurrencyTextBox196.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox196.TabIndex = 196;
this.solvencyCurrencyTextBox196.ColName = "R0020C0010";
this.solvencyCurrencyTextBox196.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox196.Enabled = false;
this.solvencyCurrencyTextBox196.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox197
//
this.solvencyCurrencyTextBox197.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox197.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox197.Location = new System.Drawing.Point(117,43);
this.solvencyCurrencyTextBox197.Name = "solvencyCurrencyTextBox197";
this.solvencyCurrencyTextBox197.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox197.TabIndex = 197;
this.solvencyCurrencyTextBox197.ColName = "R0020C0020";
this.solvencyCurrencyTextBox197.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox198
//
this.solvencyCurrencyTextBox198.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox198.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox198.Location = new System.Drawing.Point(224,43);
this.solvencyCurrencyTextBox198.Name = "solvencyCurrencyTextBox198";
this.solvencyCurrencyTextBox198.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox198.TabIndex = 198;
this.solvencyCurrencyTextBox198.ColName = "R0020EC0021";
this.solvencyCurrencyTextBox198.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox198.Enabled = false;
this.solvencyCurrencyTextBox198.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox199
//
this.solvencyCurrencyTextBox199.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox199.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox199.Location = new System.Drawing.Point(10,63);
this.solvencyCurrencyTextBox199.Name = "solvencyCurrencyTextBox199";
this.solvencyCurrencyTextBox199.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox199.TabIndex = 199;
this.solvencyCurrencyTextBox199.ColName = "R0030C0010";
this.solvencyCurrencyTextBox199.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox200
//
this.solvencyCurrencyTextBox200.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox200.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox200.Location = new System.Drawing.Point(117,63);
this.solvencyCurrencyTextBox200.Name = "solvencyCurrencyTextBox200";
this.solvencyCurrencyTextBox200.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox200.TabIndex = 200;
this.solvencyCurrencyTextBox200.ColName = "R0030C0020";
this.solvencyCurrencyTextBox200.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox201
//
this.solvencyCurrencyTextBox201.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox201.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox201.Location = new System.Drawing.Point(224,63);
this.solvencyCurrencyTextBox201.Name = "solvencyCurrencyTextBox201";
this.solvencyCurrencyTextBox201.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox201.TabIndex = 201;
this.solvencyCurrencyTextBox201.ColName = "R0030EC0021";
this.solvencyCurrencyTextBox201.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox202
//
this.solvencyCurrencyTextBox202.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox202.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox202.Location = new System.Drawing.Point(10,83);
this.solvencyCurrencyTextBox202.Name = "solvencyCurrencyTextBox202";
this.solvencyCurrencyTextBox202.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox202.TabIndex = 202;
this.solvencyCurrencyTextBox202.ColName = "R0040C0010";
this.solvencyCurrencyTextBox202.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox203
//
this.solvencyCurrencyTextBox203.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox203.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox203.Location = new System.Drawing.Point(117,83);
this.solvencyCurrencyTextBox203.Name = "solvencyCurrencyTextBox203";
this.solvencyCurrencyTextBox203.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox203.TabIndex = 203;
this.solvencyCurrencyTextBox203.ColName = "R0040C0020";
this.solvencyCurrencyTextBox203.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox204
//
this.solvencyCurrencyTextBox204.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox204.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox204.Location = new System.Drawing.Point(224,83);
this.solvencyCurrencyTextBox204.Name = "solvencyCurrencyTextBox204";
this.solvencyCurrencyTextBox204.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox204.TabIndex = 204;
this.solvencyCurrencyTextBox204.ColName = "R0040EC0021";
this.solvencyCurrencyTextBox204.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox205
//
this.solvencyCurrencyTextBox205.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox205.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox205.Location = new System.Drawing.Point(10,103);
this.solvencyCurrencyTextBox205.Name = "solvencyCurrencyTextBox205";
this.solvencyCurrencyTextBox205.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox205.TabIndex = 205;
this.solvencyCurrencyTextBox205.ColName = "R0050C0010";
this.solvencyCurrencyTextBox205.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox206
//
this.solvencyCurrencyTextBox206.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox206.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox206.Location = new System.Drawing.Point(117,103);
this.solvencyCurrencyTextBox206.Name = "solvencyCurrencyTextBox206";
this.solvencyCurrencyTextBox206.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox206.TabIndex = 206;
this.solvencyCurrencyTextBox206.ColName = "R0050C0020";
this.solvencyCurrencyTextBox206.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox207
//
this.solvencyCurrencyTextBox207.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox207.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox207.Location = new System.Drawing.Point(224,103);
this.solvencyCurrencyTextBox207.Name = "solvencyCurrencyTextBox207";
this.solvencyCurrencyTextBox207.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox207.TabIndex = 207;
this.solvencyCurrencyTextBox207.ColName = "R0050EC0021";
this.solvencyCurrencyTextBox207.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox208
//
this.solvencyCurrencyTextBox208.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox208.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox208.Location = new System.Drawing.Point(10,123);
this.solvencyCurrencyTextBox208.Name = "solvencyCurrencyTextBox208";
this.solvencyCurrencyTextBox208.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox208.TabIndex = 208;
this.solvencyCurrencyTextBox208.ColName = "R0060C0010";
this.solvencyCurrencyTextBox208.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox209
//
this.solvencyCurrencyTextBox209.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox209.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox209.Location = new System.Drawing.Point(117,123);
this.solvencyCurrencyTextBox209.Name = "solvencyCurrencyTextBox209";
this.solvencyCurrencyTextBox209.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox209.TabIndex = 209;
this.solvencyCurrencyTextBox209.ColName = "R0060C0020";
this.solvencyCurrencyTextBox209.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox210
//
this.solvencyCurrencyTextBox210.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox210.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox210.Location = new System.Drawing.Point(224,123);
this.solvencyCurrencyTextBox210.Name = "solvencyCurrencyTextBox210";
this.solvencyCurrencyTextBox210.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox210.TabIndex = 210;
this.solvencyCurrencyTextBox210.ColName = "R0060EC0021";
this.solvencyCurrencyTextBox210.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox211
//
this.solvencyCurrencyTextBox211.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox211.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox211.Location = new System.Drawing.Point(10,143);
this.solvencyCurrencyTextBox211.Name = "solvencyCurrencyTextBox211";
this.solvencyCurrencyTextBox211.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox211.TabIndex = 211;
this.solvencyCurrencyTextBox211.ColName = "R0070C0010";
this.solvencyCurrencyTextBox211.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox212
//
this.solvencyCurrencyTextBox212.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox212.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox212.Location = new System.Drawing.Point(117,143);
this.solvencyCurrencyTextBox212.Name = "solvencyCurrencyTextBox212";
this.solvencyCurrencyTextBox212.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox212.TabIndex = 212;
this.solvencyCurrencyTextBox212.ColName = "R0070C0020";
this.solvencyCurrencyTextBox212.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox213
//
this.solvencyCurrencyTextBox213.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox213.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox213.Location = new System.Drawing.Point(224,143);
this.solvencyCurrencyTextBox213.Name = "solvencyCurrencyTextBox213";
this.solvencyCurrencyTextBox213.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox213.TabIndex = 213;
this.solvencyCurrencyTextBox213.ColName = "R0070EC0021";
this.solvencyCurrencyTextBox213.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox214
//
this.solvencyCurrencyTextBox214.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox214.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox214.Location = new System.Drawing.Point(10,176);
this.solvencyCurrencyTextBox214.Name = "solvencyCurrencyTextBox214";
this.solvencyCurrencyTextBox214.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox214.TabIndex = 214;
this.solvencyCurrencyTextBox214.ColName = "R0080C0010";
this.solvencyCurrencyTextBox214.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox215
//
this.solvencyCurrencyTextBox215.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox215.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox215.Location = new System.Drawing.Point(117,176);
this.solvencyCurrencyTextBox215.Name = "solvencyCurrencyTextBox215";
this.solvencyCurrencyTextBox215.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox215.TabIndex = 215;
this.solvencyCurrencyTextBox215.ColName = "R0080C0020";
this.solvencyCurrencyTextBox215.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox216
//
this.solvencyCurrencyTextBox216.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox216.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox216.Location = new System.Drawing.Point(224,176);
this.solvencyCurrencyTextBox216.Name = "solvencyCurrencyTextBox216";
this.solvencyCurrencyTextBox216.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox216.TabIndex = 216;
this.solvencyCurrencyTextBox216.ColName = "R0080EC0021";
this.solvencyCurrencyTextBox216.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox217
//
this.solvencyCurrencyTextBox217.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox217.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox217.Location = new System.Drawing.Point(10,196);
this.solvencyCurrencyTextBox217.Name = "solvencyCurrencyTextBox217";
this.solvencyCurrencyTextBox217.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox217.TabIndex = 217;
this.solvencyCurrencyTextBox217.ColName = "R0090C0010";
this.solvencyCurrencyTextBox217.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox218
//
this.solvencyCurrencyTextBox218.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox218.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox218.Location = new System.Drawing.Point(117,196);
this.solvencyCurrencyTextBox218.Name = "solvencyCurrencyTextBox218";
this.solvencyCurrencyTextBox218.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox218.TabIndex = 218;
this.solvencyCurrencyTextBox218.ColName = "R0090C0020";
this.solvencyCurrencyTextBox218.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox219
//
this.solvencyCurrencyTextBox219.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox219.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox219.Location = new System.Drawing.Point(224,196);
this.solvencyCurrencyTextBox219.Name = "solvencyCurrencyTextBox219";
this.solvencyCurrencyTextBox219.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox219.TabIndex = 219;
this.solvencyCurrencyTextBox219.ColName = "R0090EC0021";
this.solvencyCurrencyTextBox219.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox220
//
this.solvencyCurrencyTextBox220.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox220.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox220.Location = new System.Drawing.Point(10,229);
this.solvencyCurrencyTextBox220.Name = "solvencyCurrencyTextBox220";
this.solvencyCurrencyTextBox220.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox220.TabIndex = 220;
this.solvencyCurrencyTextBox220.ColName = "R0100C0010";
this.solvencyCurrencyTextBox220.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox221
//
this.solvencyCurrencyTextBox221.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox221.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox221.Location = new System.Drawing.Point(117,229);
this.solvencyCurrencyTextBox221.Name = "solvencyCurrencyTextBox221";
this.solvencyCurrencyTextBox221.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox221.TabIndex = 221;
this.solvencyCurrencyTextBox221.ColName = "R0100C0020";
this.solvencyCurrencyTextBox221.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox222
//
this.solvencyCurrencyTextBox222.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox222.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox222.Location = new System.Drawing.Point(224,229);
this.solvencyCurrencyTextBox222.Name = "solvencyCurrencyTextBox222";
this.solvencyCurrencyTextBox222.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox222.TabIndex = 222;
this.solvencyCurrencyTextBox222.ColName = "R0100EC0021";
this.solvencyCurrencyTextBox222.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox223
//
this.solvencyCurrencyTextBox223.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox223.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox223.Location = new System.Drawing.Point(10,249);
this.solvencyCurrencyTextBox223.Name = "solvencyCurrencyTextBox223";
this.solvencyCurrencyTextBox223.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox223.TabIndex = 223;
this.solvencyCurrencyTextBox223.ColName = "R0110C0010";
this.solvencyCurrencyTextBox223.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox224
//
this.solvencyCurrencyTextBox224.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox224.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox224.Location = new System.Drawing.Point(117,249);
this.solvencyCurrencyTextBox224.Name = "solvencyCurrencyTextBox224";
this.solvencyCurrencyTextBox224.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox224.TabIndex = 224;
this.solvencyCurrencyTextBox224.ColName = "R0110C0020";
this.solvencyCurrencyTextBox224.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox225
//
this.solvencyCurrencyTextBox225.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox225.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox225.Location = new System.Drawing.Point(224,249);
this.solvencyCurrencyTextBox225.Name = "solvencyCurrencyTextBox225";
this.solvencyCurrencyTextBox225.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox225.TabIndex = 225;
this.solvencyCurrencyTextBox225.ColName = "R0110EC0021";
this.solvencyCurrencyTextBox225.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox226
//
this.solvencyCurrencyTextBox226.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox226.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox226.Location = new System.Drawing.Point(10,269);
this.solvencyCurrencyTextBox226.Name = "solvencyCurrencyTextBox226";
this.solvencyCurrencyTextBox226.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox226.TabIndex = 226;
this.solvencyCurrencyTextBox226.ColName = "R0120C0010";
this.solvencyCurrencyTextBox226.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox227
//
this.solvencyCurrencyTextBox227.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox227.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox227.Location = new System.Drawing.Point(117,269);
this.solvencyCurrencyTextBox227.Name = "solvencyCurrencyTextBox227";
this.solvencyCurrencyTextBox227.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox227.TabIndex = 227;
this.solvencyCurrencyTextBox227.ColName = "R0120C0020";
this.solvencyCurrencyTextBox227.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox228
//
this.solvencyCurrencyTextBox228.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox228.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox228.Location = new System.Drawing.Point(224,269);
this.solvencyCurrencyTextBox228.Name = "solvencyCurrencyTextBox228";
this.solvencyCurrencyTextBox228.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox228.TabIndex = 228;
this.solvencyCurrencyTextBox228.ColName = "R0120EC0021";
this.solvencyCurrencyTextBox228.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox229
//
this.solvencyCurrencyTextBox229.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox229.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox229.Location = new System.Drawing.Point(10,289);
this.solvencyCurrencyTextBox229.Name = "solvencyCurrencyTextBox229";
this.solvencyCurrencyTextBox229.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox229.TabIndex = 229;
this.solvencyCurrencyTextBox229.ColName = "R0130C0010";
this.solvencyCurrencyTextBox229.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox230
//
this.solvencyCurrencyTextBox230.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox230.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox230.Location = new System.Drawing.Point(117,289);
this.solvencyCurrencyTextBox230.Name = "solvencyCurrencyTextBox230";
this.solvencyCurrencyTextBox230.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox230.TabIndex = 230;
this.solvencyCurrencyTextBox230.ColName = "R0130C0020";
this.solvencyCurrencyTextBox230.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox231
//
this.solvencyCurrencyTextBox231.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox231.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox231.Location = new System.Drawing.Point(224,289);
this.solvencyCurrencyTextBox231.Name = "solvencyCurrencyTextBox231";
this.solvencyCurrencyTextBox231.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox231.TabIndex = 231;
this.solvencyCurrencyTextBox231.ColName = "R0130EC0021";
this.solvencyCurrencyTextBox231.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox232
//
this.solvencyCurrencyTextBox232.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox232.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox232.Location = new System.Drawing.Point(10,309);
this.solvencyCurrencyTextBox232.Name = "solvencyCurrencyTextBox232";
this.solvencyCurrencyTextBox232.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox232.TabIndex = 232;
this.solvencyCurrencyTextBox232.ColName = "R0140C0010";
this.solvencyCurrencyTextBox232.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox233
//
this.solvencyCurrencyTextBox233.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox233.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox233.Location = new System.Drawing.Point(117,309);
this.solvencyCurrencyTextBox233.Name = "solvencyCurrencyTextBox233";
this.solvencyCurrencyTextBox233.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox233.TabIndex = 233;
this.solvencyCurrencyTextBox233.ColName = "R0140C0020";
this.solvencyCurrencyTextBox233.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox234
//
this.solvencyCurrencyTextBox234.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox234.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox234.Location = new System.Drawing.Point(224,309);
this.solvencyCurrencyTextBox234.Name = "solvencyCurrencyTextBox234";
this.solvencyCurrencyTextBox234.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox234.TabIndex = 234;
this.solvencyCurrencyTextBox234.ColName = "R0140EC0021";
this.solvencyCurrencyTextBox234.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox235
//
this.solvencyCurrencyTextBox235.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox235.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox235.Location = new System.Drawing.Point(10,329);
this.solvencyCurrencyTextBox235.Name = "solvencyCurrencyTextBox235";
this.solvencyCurrencyTextBox235.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox235.TabIndex = 235;
this.solvencyCurrencyTextBox235.ColName = "R0150C0010";
this.solvencyCurrencyTextBox235.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox236
//
this.solvencyCurrencyTextBox236.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox236.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox236.Location = new System.Drawing.Point(117,329);
this.solvencyCurrencyTextBox236.Name = "solvencyCurrencyTextBox236";
this.solvencyCurrencyTextBox236.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox236.TabIndex = 236;
this.solvencyCurrencyTextBox236.ColName = "R0150C0020";
this.solvencyCurrencyTextBox236.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox237
//
this.solvencyCurrencyTextBox237.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox237.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox237.Location = new System.Drawing.Point(224,329);
this.solvencyCurrencyTextBox237.Name = "solvencyCurrencyTextBox237";
this.solvencyCurrencyTextBox237.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox237.TabIndex = 237;
this.solvencyCurrencyTextBox237.ColName = "R0150EC0021";
this.solvencyCurrencyTextBox237.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox238
//
this.solvencyCurrencyTextBox238.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox238.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox238.Location = new System.Drawing.Point(10,349);
this.solvencyCurrencyTextBox238.Name = "solvencyCurrencyTextBox238";
this.solvencyCurrencyTextBox238.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox238.TabIndex = 238;
this.solvencyCurrencyTextBox238.ColName = "R0160C0010";
this.solvencyCurrencyTextBox238.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox239
//
this.solvencyCurrencyTextBox239.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox239.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox239.Location = new System.Drawing.Point(117,349);
this.solvencyCurrencyTextBox239.Name = "solvencyCurrencyTextBox239";
this.solvencyCurrencyTextBox239.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox239.TabIndex = 239;
this.solvencyCurrencyTextBox239.ColName = "R0160C0020";
this.solvencyCurrencyTextBox239.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox240
//
this.solvencyCurrencyTextBox240.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox240.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox240.Location = new System.Drawing.Point(224,349);
this.solvencyCurrencyTextBox240.Name = "solvencyCurrencyTextBox240";
this.solvencyCurrencyTextBox240.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox240.TabIndex = 240;
this.solvencyCurrencyTextBox240.ColName = "R0160EC0021";
this.solvencyCurrencyTextBox240.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox241
//
this.solvencyCurrencyTextBox241.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox241.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox241.Location = new System.Drawing.Point(10,369);
this.solvencyCurrencyTextBox241.Name = "solvencyCurrencyTextBox241";
this.solvencyCurrencyTextBox241.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox241.TabIndex = 241;
this.solvencyCurrencyTextBox241.ColName = "R0170C0010";
this.solvencyCurrencyTextBox241.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox242
//
this.solvencyCurrencyTextBox242.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox242.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox242.Location = new System.Drawing.Point(117,369);
this.solvencyCurrencyTextBox242.Name = "solvencyCurrencyTextBox242";
this.solvencyCurrencyTextBox242.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox242.TabIndex = 242;
this.solvencyCurrencyTextBox242.ColName = "R0170C0020";
this.solvencyCurrencyTextBox242.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox243
//
this.solvencyCurrencyTextBox243.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox243.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox243.Location = new System.Drawing.Point(224,369);
this.solvencyCurrencyTextBox243.Name = "solvencyCurrencyTextBox243";
this.solvencyCurrencyTextBox243.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox243.TabIndex = 243;
this.solvencyCurrencyTextBox243.ColName = "R0170EC0021";
this.solvencyCurrencyTextBox243.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox244
//
this.solvencyCurrencyTextBox244.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox244.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox244.Location = new System.Drawing.Point(10,389);
this.solvencyCurrencyTextBox244.Name = "solvencyCurrencyTextBox244";
this.solvencyCurrencyTextBox244.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox244.TabIndex = 244;
this.solvencyCurrencyTextBox244.ColName = "R0180C0010";
this.solvencyCurrencyTextBox244.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox245
//
this.solvencyCurrencyTextBox245.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox245.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox245.Location = new System.Drawing.Point(117,389);
this.solvencyCurrencyTextBox245.Name = "solvencyCurrencyTextBox245";
this.solvencyCurrencyTextBox245.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox245.TabIndex = 245;
this.solvencyCurrencyTextBox245.ColName = "R0180C0020";
this.solvencyCurrencyTextBox245.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox246
//
this.solvencyCurrencyTextBox246.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox246.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox246.Location = new System.Drawing.Point(224,389);
this.solvencyCurrencyTextBox246.Name = "solvencyCurrencyTextBox246";
this.solvencyCurrencyTextBox246.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox246.TabIndex = 246;
this.solvencyCurrencyTextBox246.ColName = "R0180EC0021";
this.solvencyCurrencyTextBox246.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox247
//
this.solvencyCurrencyTextBox247.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox247.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox247.Location = new System.Drawing.Point(10,409);
this.solvencyCurrencyTextBox247.Name = "solvencyCurrencyTextBox247";
this.solvencyCurrencyTextBox247.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox247.TabIndex = 247;
this.solvencyCurrencyTextBox247.ColName = "R0190C0010";
this.solvencyCurrencyTextBox247.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox248
//
this.solvencyCurrencyTextBox248.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox248.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox248.Location = new System.Drawing.Point(117,409);
this.solvencyCurrencyTextBox248.Name = "solvencyCurrencyTextBox248";
this.solvencyCurrencyTextBox248.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox248.TabIndex = 248;
this.solvencyCurrencyTextBox248.ColName = "R0190C0020";
this.solvencyCurrencyTextBox248.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox249
//
this.solvencyCurrencyTextBox249.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox249.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox249.Location = new System.Drawing.Point(224,409);
this.solvencyCurrencyTextBox249.Name = "solvencyCurrencyTextBox249";
this.solvencyCurrencyTextBox249.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox249.TabIndex = 249;
this.solvencyCurrencyTextBox249.ColName = "R0190EC0021";
this.solvencyCurrencyTextBox249.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox250
//
this.solvencyCurrencyTextBox250.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox250.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox250.Location = new System.Drawing.Point(10,429);
this.solvencyCurrencyTextBox250.Name = "solvencyCurrencyTextBox250";
this.solvencyCurrencyTextBox250.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox250.TabIndex = 250;
this.solvencyCurrencyTextBox250.ColName = "R0200C0010";
this.solvencyCurrencyTextBox250.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox251
//
this.solvencyCurrencyTextBox251.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox251.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox251.Location = new System.Drawing.Point(117,429);
this.solvencyCurrencyTextBox251.Name = "solvencyCurrencyTextBox251";
this.solvencyCurrencyTextBox251.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox251.TabIndex = 251;
this.solvencyCurrencyTextBox251.ColName = "R0200C0020";
this.solvencyCurrencyTextBox251.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox252
//
this.solvencyCurrencyTextBox252.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox252.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox252.Location = new System.Drawing.Point(224,429);
this.solvencyCurrencyTextBox252.Name = "solvencyCurrencyTextBox252";
this.solvencyCurrencyTextBox252.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox252.TabIndex = 252;
this.solvencyCurrencyTextBox252.ColName = "R0200EC0021";
this.solvencyCurrencyTextBox252.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox253
//
this.solvencyCurrencyTextBox253.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox253.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox253.Location = new System.Drawing.Point(10,449);
this.solvencyCurrencyTextBox253.Name = "solvencyCurrencyTextBox253";
this.solvencyCurrencyTextBox253.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox253.TabIndex = 253;
this.solvencyCurrencyTextBox253.ColName = "R0210C0010";
this.solvencyCurrencyTextBox253.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox254
//
this.solvencyCurrencyTextBox254.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox254.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox254.Location = new System.Drawing.Point(117,449);
this.solvencyCurrencyTextBox254.Name = "solvencyCurrencyTextBox254";
this.solvencyCurrencyTextBox254.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox254.TabIndex = 254;
this.solvencyCurrencyTextBox254.ColName = "R0210C0020";
this.solvencyCurrencyTextBox254.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox255
//
this.solvencyCurrencyTextBox255.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox255.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox255.Location = new System.Drawing.Point(224,449);
this.solvencyCurrencyTextBox255.Name = "solvencyCurrencyTextBox255";
this.solvencyCurrencyTextBox255.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox255.TabIndex = 255;
this.solvencyCurrencyTextBox255.ColName = "R0210EC0021";
this.solvencyCurrencyTextBox255.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox256
//
this.solvencyCurrencyTextBox256.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox256.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox256.Location = new System.Drawing.Point(10,469);
this.solvencyCurrencyTextBox256.Name = "solvencyCurrencyTextBox256";
this.solvencyCurrencyTextBox256.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox256.TabIndex = 256;
this.solvencyCurrencyTextBox256.ColName = "R0220C0010";
this.solvencyCurrencyTextBox256.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox257
//
this.solvencyCurrencyTextBox257.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox257.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox257.Location = new System.Drawing.Point(117,469);
this.solvencyCurrencyTextBox257.Name = "solvencyCurrencyTextBox257";
this.solvencyCurrencyTextBox257.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox257.TabIndex = 257;
this.solvencyCurrencyTextBox257.ColName = "R0220C0020";
this.solvencyCurrencyTextBox257.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox258
//
this.solvencyCurrencyTextBox258.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox258.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox258.Location = new System.Drawing.Point(224,469);
this.solvencyCurrencyTextBox258.Name = "solvencyCurrencyTextBox258";
this.solvencyCurrencyTextBox258.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox258.TabIndex = 258;
this.solvencyCurrencyTextBox258.ColName = "R0220EC0021";
this.solvencyCurrencyTextBox258.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox259
//
this.solvencyCurrencyTextBox259.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox259.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox259.Location = new System.Drawing.Point(10,489);
this.solvencyCurrencyTextBox259.Name = "solvencyCurrencyTextBox259";
this.solvencyCurrencyTextBox259.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox259.TabIndex = 259;
this.solvencyCurrencyTextBox259.ColName = "R0230C0010";
this.solvencyCurrencyTextBox259.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox260
//
this.solvencyCurrencyTextBox260.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox260.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox260.Location = new System.Drawing.Point(117,489);
this.solvencyCurrencyTextBox260.Name = "solvencyCurrencyTextBox260";
this.solvencyCurrencyTextBox260.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox260.TabIndex = 260;
this.solvencyCurrencyTextBox260.ColName = "R0230C0020";
this.solvencyCurrencyTextBox260.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox261
//
this.solvencyCurrencyTextBox261.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox261.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox261.Location = new System.Drawing.Point(224,489);
this.solvencyCurrencyTextBox261.Name = "solvencyCurrencyTextBox261";
this.solvencyCurrencyTextBox261.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox261.TabIndex = 261;
this.solvencyCurrencyTextBox261.ColName = "R0230EC0021";
this.solvencyCurrencyTextBox261.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox262
//
this.solvencyCurrencyTextBox262.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox262.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox262.Location = new System.Drawing.Point(10,509);
this.solvencyCurrencyTextBox262.Name = "solvencyCurrencyTextBox262";
this.solvencyCurrencyTextBox262.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox262.TabIndex = 262;
this.solvencyCurrencyTextBox262.ColName = "R0240C0010";
this.solvencyCurrencyTextBox262.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox263
//
this.solvencyCurrencyTextBox263.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox263.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox263.Location = new System.Drawing.Point(117,509);
this.solvencyCurrencyTextBox263.Name = "solvencyCurrencyTextBox263";
this.solvencyCurrencyTextBox263.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox263.TabIndex = 263;
this.solvencyCurrencyTextBox263.ColName = "R0240C0020";
this.solvencyCurrencyTextBox263.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox264
//
this.solvencyCurrencyTextBox264.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox264.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox264.Location = new System.Drawing.Point(224,509);
this.solvencyCurrencyTextBox264.Name = "solvencyCurrencyTextBox264";
this.solvencyCurrencyTextBox264.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox264.TabIndex = 264;
this.solvencyCurrencyTextBox264.ColName = "R0240EC0021";
this.solvencyCurrencyTextBox264.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox265
//
this.solvencyCurrencyTextBox265.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox265.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox265.Location = new System.Drawing.Point(10,529);
this.solvencyCurrencyTextBox265.Name = "solvencyCurrencyTextBox265";
this.solvencyCurrencyTextBox265.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox265.TabIndex = 265;
this.solvencyCurrencyTextBox265.ColName = "R0250C0010";
this.solvencyCurrencyTextBox265.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox266
//
this.solvencyCurrencyTextBox266.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox266.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox266.Location = new System.Drawing.Point(117,529);
this.solvencyCurrencyTextBox266.Name = "solvencyCurrencyTextBox266";
this.solvencyCurrencyTextBox266.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox266.TabIndex = 266;
this.solvencyCurrencyTextBox266.ColName = "R0250C0020";
this.solvencyCurrencyTextBox266.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox267
//
this.solvencyCurrencyTextBox267.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox267.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox267.Location = new System.Drawing.Point(224,529);
this.solvencyCurrencyTextBox267.Name = "solvencyCurrencyTextBox267";
this.solvencyCurrencyTextBox267.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox267.TabIndex = 267;
this.solvencyCurrencyTextBox267.ColName = "R0250EC0021";
this.solvencyCurrencyTextBox267.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox268
//
this.solvencyCurrencyTextBox268.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox268.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox268.Location = new System.Drawing.Point(10,549);
this.solvencyCurrencyTextBox268.Name = "solvencyCurrencyTextBox268";
this.solvencyCurrencyTextBox268.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox268.TabIndex = 268;
this.solvencyCurrencyTextBox268.ColName = "R0260C0010";
this.solvencyCurrencyTextBox268.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox269
//
this.solvencyCurrencyTextBox269.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox269.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox269.Location = new System.Drawing.Point(117,549);
this.solvencyCurrencyTextBox269.Name = "solvencyCurrencyTextBox269";
this.solvencyCurrencyTextBox269.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox269.TabIndex = 269;
this.solvencyCurrencyTextBox269.ColName = "R0260C0020";
this.solvencyCurrencyTextBox269.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox270
//
this.solvencyCurrencyTextBox270.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox270.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox270.Location = new System.Drawing.Point(224,549);
this.solvencyCurrencyTextBox270.Name = "solvencyCurrencyTextBox270";
this.solvencyCurrencyTextBox270.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox270.TabIndex = 270;
this.solvencyCurrencyTextBox270.ColName = "R0260EC0021";
this.solvencyCurrencyTextBox270.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox271
//
this.solvencyCurrencyTextBox271.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox271.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox271.Location = new System.Drawing.Point(10,569);
this.solvencyCurrencyTextBox271.Name = "solvencyCurrencyTextBox271";
this.solvencyCurrencyTextBox271.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox271.TabIndex = 271;
this.solvencyCurrencyTextBox271.ColName = "R0270C0010";
this.solvencyCurrencyTextBox271.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox272
//
this.solvencyCurrencyTextBox272.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox272.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox272.Location = new System.Drawing.Point(117,569);
this.solvencyCurrencyTextBox272.Name = "solvencyCurrencyTextBox272";
this.solvencyCurrencyTextBox272.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox272.TabIndex = 272;
this.solvencyCurrencyTextBox272.ColName = "R0270C0020";
this.solvencyCurrencyTextBox272.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox273
//
this.solvencyCurrencyTextBox273.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox273.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox273.Location = new System.Drawing.Point(224,569);
this.solvencyCurrencyTextBox273.Name = "solvencyCurrencyTextBox273";
this.solvencyCurrencyTextBox273.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox273.TabIndex = 273;
this.solvencyCurrencyTextBox273.ColName = "R0270EC0021";
this.solvencyCurrencyTextBox273.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox274
//
this.solvencyCurrencyTextBox274.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox274.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox274.Location = new System.Drawing.Point(10,589);
this.solvencyCurrencyTextBox274.Name = "solvencyCurrencyTextBox274";
this.solvencyCurrencyTextBox274.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox274.TabIndex = 274;
this.solvencyCurrencyTextBox274.ColName = "R0280C0010";
this.solvencyCurrencyTextBox274.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox275
//
this.solvencyCurrencyTextBox275.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox275.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox275.Location = new System.Drawing.Point(117,589);
this.solvencyCurrencyTextBox275.Name = "solvencyCurrencyTextBox275";
this.solvencyCurrencyTextBox275.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox275.TabIndex = 275;
this.solvencyCurrencyTextBox275.ColName = "R0280C0020";
this.solvencyCurrencyTextBox275.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox276
//
this.solvencyCurrencyTextBox276.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox276.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox276.Location = new System.Drawing.Point(224,589);
this.solvencyCurrencyTextBox276.Name = "solvencyCurrencyTextBox276";
this.solvencyCurrencyTextBox276.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox276.TabIndex = 276;
this.solvencyCurrencyTextBox276.ColName = "R0280EC0021";
this.solvencyCurrencyTextBox276.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox276.Enabled = false;
this.solvencyCurrencyTextBox276.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox277
//
this.solvencyCurrencyTextBox277.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox277.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox277.Location = new System.Drawing.Point(10,609);
this.solvencyCurrencyTextBox277.Name = "solvencyCurrencyTextBox277";
this.solvencyCurrencyTextBox277.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox277.TabIndex = 277;
this.solvencyCurrencyTextBox277.ColName = "R0290C0010";
this.solvencyCurrencyTextBox277.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox278
//
this.solvencyCurrencyTextBox278.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox278.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox278.Location = new System.Drawing.Point(117,609);
this.solvencyCurrencyTextBox278.Name = "solvencyCurrencyTextBox278";
this.solvencyCurrencyTextBox278.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox278.TabIndex = 278;
this.solvencyCurrencyTextBox278.ColName = "R0290C0020";
this.solvencyCurrencyTextBox278.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox279
//
this.solvencyCurrencyTextBox279.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox279.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox279.Location = new System.Drawing.Point(224,609);
this.solvencyCurrencyTextBox279.Name = "solvencyCurrencyTextBox279";
this.solvencyCurrencyTextBox279.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox279.TabIndex = 279;
this.solvencyCurrencyTextBox279.ColName = "R0290EC0021";
this.solvencyCurrencyTextBox279.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox279.Enabled = false;
this.solvencyCurrencyTextBox279.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox280
//
this.solvencyCurrencyTextBox280.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox280.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox280.Location = new System.Drawing.Point(10,629);
this.solvencyCurrencyTextBox280.Name = "solvencyCurrencyTextBox280";
this.solvencyCurrencyTextBox280.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox280.TabIndex = 280;
this.solvencyCurrencyTextBox280.ColName = "R0300C0010";
this.solvencyCurrencyTextBox280.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox281
//
this.solvencyCurrencyTextBox281.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox281.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox281.Location = new System.Drawing.Point(117,629);
this.solvencyCurrencyTextBox281.Name = "solvencyCurrencyTextBox281";
this.solvencyCurrencyTextBox281.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox281.TabIndex = 281;
this.solvencyCurrencyTextBox281.ColName = "R0300C0020";
this.solvencyCurrencyTextBox281.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox282
//
this.solvencyCurrencyTextBox282.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox282.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox282.Location = new System.Drawing.Point(224,629);
this.solvencyCurrencyTextBox282.Name = "solvencyCurrencyTextBox282";
this.solvencyCurrencyTextBox282.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox282.TabIndex = 282;
this.solvencyCurrencyTextBox282.ColName = "R0300EC0021";
this.solvencyCurrencyTextBox282.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox282.Enabled = false;
this.solvencyCurrencyTextBox282.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox283
//
this.solvencyCurrencyTextBox283.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox283.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox283.Location = new System.Drawing.Point(10,649);
this.solvencyCurrencyTextBox283.Name = "solvencyCurrencyTextBox283";
this.solvencyCurrencyTextBox283.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox283.TabIndex = 283;
this.solvencyCurrencyTextBox283.ColName = "R0310C0010";
this.solvencyCurrencyTextBox283.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox284
//
this.solvencyCurrencyTextBox284.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox284.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox284.Location = new System.Drawing.Point(117,649);
this.solvencyCurrencyTextBox284.Name = "solvencyCurrencyTextBox284";
this.solvencyCurrencyTextBox284.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox284.TabIndex = 284;
this.solvencyCurrencyTextBox284.ColName = "R0310C0020";
this.solvencyCurrencyTextBox284.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox285
//
this.solvencyCurrencyTextBox285.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox285.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox285.Location = new System.Drawing.Point(224,649);
this.solvencyCurrencyTextBox285.Name = "solvencyCurrencyTextBox285";
this.solvencyCurrencyTextBox285.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox285.TabIndex = 285;
this.solvencyCurrencyTextBox285.ColName = "R0310EC0021";
this.solvencyCurrencyTextBox285.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox285.Enabled = false;
this.solvencyCurrencyTextBox285.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox286
//
this.solvencyCurrencyTextBox286.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox286.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox286.Location = new System.Drawing.Point(10,682);
this.solvencyCurrencyTextBox286.Name = "solvencyCurrencyTextBox286";
this.solvencyCurrencyTextBox286.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox286.TabIndex = 286;
this.solvencyCurrencyTextBox286.ColName = "R0320C0010";
this.solvencyCurrencyTextBox286.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox287
//
this.solvencyCurrencyTextBox287.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox287.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox287.Location = new System.Drawing.Point(117,682);
this.solvencyCurrencyTextBox287.Name = "solvencyCurrencyTextBox287";
this.solvencyCurrencyTextBox287.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox287.TabIndex = 287;
this.solvencyCurrencyTextBox287.ColName = "R0320C0020";
this.solvencyCurrencyTextBox287.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox288
//
this.solvencyCurrencyTextBox288.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox288.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox288.Location = new System.Drawing.Point(224,682);
this.solvencyCurrencyTextBox288.Name = "solvencyCurrencyTextBox288";
this.solvencyCurrencyTextBox288.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox288.TabIndex = 288;
this.solvencyCurrencyTextBox288.ColName = "R0320EC0021";
this.solvencyCurrencyTextBox288.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox288.Enabled = false;
this.solvencyCurrencyTextBox288.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox289
//
this.solvencyCurrencyTextBox289.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox289.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox289.Location = new System.Drawing.Point(10,702);
this.solvencyCurrencyTextBox289.Name = "solvencyCurrencyTextBox289";
this.solvencyCurrencyTextBox289.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox289.TabIndex = 289;
this.solvencyCurrencyTextBox289.ColName = "R0330C0010";
this.solvencyCurrencyTextBox289.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox290
//
this.solvencyCurrencyTextBox290.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox290.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox290.Location = new System.Drawing.Point(117,702);
this.solvencyCurrencyTextBox290.Name = "solvencyCurrencyTextBox290";
this.solvencyCurrencyTextBox290.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox290.TabIndex = 290;
this.solvencyCurrencyTextBox290.ColName = "R0330C0020";
this.solvencyCurrencyTextBox290.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox291
//
this.solvencyCurrencyTextBox291.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox291.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox291.Location = new System.Drawing.Point(224,702);
this.solvencyCurrencyTextBox291.Name = "solvencyCurrencyTextBox291";
this.solvencyCurrencyTextBox291.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox291.TabIndex = 291;
this.solvencyCurrencyTextBox291.ColName = "R0330EC0021";
this.solvencyCurrencyTextBox291.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox291.Enabled = false;
this.solvencyCurrencyTextBox291.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox292
//
this.solvencyCurrencyTextBox292.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox292.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox292.Location = new System.Drawing.Point(10,735);
this.solvencyCurrencyTextBox292.Name = "solvencyCurrencyTextBox292";
this.solvencyCurrencyTextBox292.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox292.TabIndex = 292;
this.solvencyCurrencyTextBox292.ColName = "R0340C0010";
this.solvencyCurrencyTextBox292.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox293
//
this.solvencyCurrencyTextBox293.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox293.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox293.Location = new System.Drawing.Point(117,735);
this.solvencyCurrencyTextBox293.Name = "solvencyCurrencyTextBox293";
this.solvencyCurrencyTextBox293.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox293.TabIndex = 293;
this.solvencyCurrencyTextBox293.ColName = "R0340C0020";
this.solvencyCurrencyTextBox293.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox294
//
this.solvencyCurrencyTextBox294.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox294.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox294.Location = new System.Drawing.Point(224,735);
this.solvencyCurrencyTextBox294.Name = "solvencyCurrencyTextBox294";
this.solvencyCurrencyTextBox294.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox294.TabIndex = 294;
this.solvencyCurrencyTextBox294.ColName = "R0340EC0021";
this.solvencyCurrencyTextBox294.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox294.Enabled = false;
this.solvencyCurrencyTextBox294.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox295
//
this.solvencyCurrencyTextBox295.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox295.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox295.Location = new System.Drawing.Point(10,755);
this.solvencyCurrencyTextBox295.Name = "solvencyCurrencyTextBox295";
this.solvencyCurrencyTextBox295.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox295.TabIndex = 295;
this.solvencyCurrencyTextBox295.ColName = "R0350C0010";
this.solvencyCurrencyTextBox295.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox296
//
this.solvencyCurrencyTextBox296.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox296.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox296.Location = new System.Drawing.Point(117,755);
this.solvencyCurrencyTextBox296.Name = "solvencyCurrencyTextBox296";
this.solvencyCurrencyTextBox296.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox296.TabIndex = 296;
this.solvencyCurrencyTextBox296.ColName = "R0350C0020";
this.solvencyCurrencyTextBox296.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox297
//
this.solvencyCurrencyTextBox297.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox297.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox297.Location = new System.Drawing.Point(224,755);
this.solvencyCurrencyTextBox297.Name = "solvencyCurrencyTextBox297";
this.solvencyCurrencyTextBox297.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox297.TabIndex = 297;
this.solvencyCurrencyTextBox297.ColName = "R0350EC0021";
this.solvencyCurrencyTextBox297.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox298
//
this.solvencyCurrencyTextBox298.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox298.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox298.Location = new System.Drawing.Point(10,775);
this.solvencyCurrencyTextBox298.Name = "solvencyCurrencyTextBox298";
this.solvencyCurrencyTextBox298.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox298.TabIndex = 298;
this.solvencyCurrencyTextBox298.ColName = "R0360C0010";
this.solvencyCurrencyTextBox298.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox299
//
this.solvencyCurrencyTextBox299.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox299.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox299.Location = new System.Drawing.Point(117,775);
this.solvencyCurrencyTextBox299.Name = "solvencyCurrencyTextBox299";
this.solvencyCurrencyTextBox299.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox299.TabIndex = 299;
this.solvencyCurrencyTextBox299.ColName = "R0360C0020";
this.solvencyCurrencyTextBox299.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox300
//
this.solvencyCurrencyTextBox300.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox300.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox300.Location = new System.Drawing.Point(224,775);
this.solvencyCurrencyTextBox300.Name = "solvencyCurrencyTextBox300";
this.solvencyCurrencyTextBox300.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox300.TabIndex = 300;
this.solvencyCurrencyTextBox300.ColName = "R0360EC0021";
this.solvencyCurrencyTextBox300.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox301
//
this.solvencyCurrencyTextBox301.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox301.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox301.Location = new System.Drawing.Point(10,795);
this.solvencyCurrencyTextBox301.Name = "solvencyCurrencyTextBox301";
this.solvencyCurrencyTextBox301.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox301.TabIndex = 301;
this.solvencyCurrencyTextBox301.ColName = "R0370C0010";
this.solvencyCurrencyTextBox301.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox302
//
this.solvencyCurrencyTextBox302.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox302.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox302.Location = new System.Drawing.Point(117,795);
this.solvencyCurrencyTextBox302.Name = "solvencyCurrencyTextBox302";
this.solvencyCurrencyTextBox302.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox302.TabIndex = 302;
this.solvencyCurrencyTextBox302.ColName = "R0370C0020";
this.solvencyCurrencyTextBox302.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox303
//
this.solvencyCurrencyTextBox303.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox303.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox303.Location = new System.Drawing.Point(224,795);
this.solvencyCurrencyTextBox303.Name = "solvencyCurrencyTextBox303";
this.solvencyCurrencyTextBox303.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox303.TabIndex = 303;
this.solvencyCurrencyTextBox303.ColName = "R0370EC0021";
this.solvencyCurrencyTextBox303.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox304
//
this.solvencyCurrencyTextBox304.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox304.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox304.Location = new System.Drawing.Point(10,815);
this.solvencyCurrencyTextBox304.Name = "solvencyCurrencyTextBox304";
this.solvencyCurrencyTextBox304.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox304.TabIndex = 304;
this.solvencyCurrencyTextBox304.ColName = "R0380C0010";
this.solvencyCurrencyTextBox304.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox305
//
this.solvencyCurrencyTextBox305.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox305.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox305.Location = new System.Drawing.Point(117,815);
this.solvencyCurrencyTextBox305.Name = "solvencyCurrencyTextBox305";
this.solvencyCurrencyTextBox305.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox305.TabIndex = 305;
this.solvencyCurrencyTextBox305.ColName = "R0380C0020";
this.solvencyCurrencyTextBox305.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox306
//
this.solvencyCurrencyTextBox306.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox306.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox306.Location = new System.Drawing.Point(224,815);
this.solvencyCurrencyTextBox306.Name = "solvencyCurrencyTextBox306";
this.solvencyCurrencyTextBox306.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox306.TabIndex = 306;
this.solvencyCurrencyTextBox306.ColName = "R0380EC0021";
this.solvencyCurrencyTextBox306.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox307
//
this.solvencyCurrencyTextBox307.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox307.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox307.Location = new System.Drawing.Point(10,835);
this.solvencyCurrencyTextBox307.Name = "solvencyCurrencyTextBox307";
this.solvencyCurrencyTextBox307.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox307.TabIndex = 307;
this.solvencyCurrencyTextBox307.ColName = "R0390C0010";
this.solvencyCurrencyTextBox307.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox308
//
this.solvencyCurrencyTextBox308.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox308.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox308.Location = new System.Drawing.Point(117,835);
this.solvencyCurrencyTextBox308.Name = "solvencyCurrencyTextBox308";
this.solvencyCurrencyTextBox308.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox308.TabIndex = 308;
this.solvencyCurrencyTextBox308.ColName = "R0390C0020";
this.solvencyCurrencyTextBox308.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox309
//
this.solvencyCurrencyTextBox309.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox309.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox309.Location = new System.Drawing.Point(224,835);
this.solvencyCurrencyTextBox309.Name = "solvencyCurrencyTextBox309";
this.solvencyCurrencyTextBox309.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox309.TabIndex = 309;
this.solvencyCurrencyTextBox309.ColName = "R0390EC0021";
this.solvencyCurrencyTextBox309.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox310
//
this.solvencyCurrencyTextBox310.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox310.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox310.Location = new System.Drawing.Point(10,855);
this.solvencyCurrencyTextBox310.Name = "solvencyCurrencyTextBox310";
this.solvencyCurrencyTextBox310.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox310.TabIndex = 310;
this.solvencyCurrencyTextBox310.ColName = "R0400C0010";
this.solvencyCurrencyTextBox310.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox311
//
this.solvencyCurrencyTextBox311.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox311.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox311.Location = new System.Drawing.Point(117,855);
this.solvencyCurrencyTextBox311.Name = "solvencyCurrencyTextBox311";
this.solvencyCurrencyTextBox311.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox311.TabIndex = 311;
this.solvencyCurrencyTextBox311.ColName = "R0400C0020";
this.solvencyCurrencyTextBox311.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox312
//
this.solvencyCurrencyTextBox312.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox312.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox312.Location = new System.Drawing.Point(224,855);
this.solvencyCurrencyTextBox312.Name = "solvencyCurrencyTextBox312";
this.solvencyCurrencyTextBox312.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox312.TabIndex = 312;
this.solvencyCurrencyTextBox312.ColName = "R0400EC0021";
this.solvencyCurrencyTextBox312.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox313
//
this.solvencyCurrencyTextBox313.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox313.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox313.Location = new System.Drawing.Point(10,888);
this.solvencyCurrencyTextBox313.Name = "solvencyCurrencyTextBox313";
this.solvencyCurrencyTextBox313.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox313.TabIndex = 313;
this.solvencyCurrencyTextBox313.ColName = "R0410C0010";
this.solvencyCurrencyTextBox313.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox314
//
this.solvencyCurrencyTextBox314.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox314.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox314.Location = new System.Drawing.Point(117,888);
this.solvencyCurrencyTextBox314.Name = "solvencyCurrencyTextBox314";
this.solvencyCurrencyTextBox314.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox314.TabIndex = 314;
this.solvencyCurrencyTextBox314.ColName = "R0410C0020";
this.solvencyCurrencyTextBox314.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox315
//
this.solvencyCurrencyTextBox315.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox315.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox315.Location = new System.Drawing.Point(224,888);
this.solvencyCurrencyTextBox315.Name = "solvencyCurrencyTextBox315";
this.solvencyCurrencyTextBox315.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox315.TabIndex = 315;
this.solvencyCurrencyTextBox315.ColName = "R0410EC0021";
this.solvencyCurrencyTextBox315.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox316
//
this.solvencyCurrencyTextBox316.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox316.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox316.Location = new System.Drawing.Point(10,908);
this.solvencyCurrencyTextBox316.Name = "solvencyCurrencyTextBox316";
this.solvencyCurrencyTextBox316.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox316.TabIndex = 316;
this.solvencyCurrencyTextBox316.ColName = "R0420C0010";
this.solvencyCurrencyTextBox316.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox317
//
this.solvencyCurrencyTextBox317.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox317.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox317.Location = new System.Drawing.Point(117,908);
this.solvencyCurrencyTextBox317.Name = "solvencyCurrencyTextBox317";
this.solvencyCurrencyTextBox317.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox317.TabIndex = 317;
this.solvencyCurrencyTextBox317.ColName = "R0420C0020";
this.solvencyCurrencyTextBox317.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox318
//
this.solvencyCurrencyTextBox318.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox318.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox318.Location = new System.Drawing.Point(224,908);
this.solvencyCurrencyTextBox318.Name = "solvencyCurrencyTextBox318";
this.solvencyCurrencyTextBox318.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox318.TabIndex = 318;
this.solvencyCurrencyTextBox318.ColName = "R0420EC0021";
this.solvencyCurrencyTextBox318.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox319
//
this.solvencyCurrencyTextBox319.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox319.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox319.Location = new System.Drawing.Point(10,928);
this.solvencyCurrencyTextBox319.Name = "solvencyCurrencyTextBox319";
this.solvencyCurrencyTextBox319.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox319.TabIndex = 319;
this.solvencyCurrencyTextBox319.ColName = "R0500C0010";
this.solvencyCurrencyTextBox319.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox320
//
this.solvencyCurrencyTextBox320.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox320.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox320.Location = new System.Drawing.Point(117,928);
this.solvencyCurrencyTextBox320.Name = "solvencyCurrencyTextBox320";
this.solvencyCurrencyTextBox320.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox320.TabIndex = 320;
this.solvencyCurrencyTextBox320.ColName = "R0500C0020";
this.solvencyCurrencyTextBox320.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox321
//
this.solvencyCurrencyTextBox321.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox321.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox321.Location = new System.Drawing.Point(224,928);
this.solvencyCurrencyTextBox321.Name = "solvencyCurrencyTextBox321";
this.solvencyCurrencyTextBox321.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox321.TabIndex = 321;
this.solvencyCurrencyTextBox321.ColName = "R0500EC0021";
this.solvencyCurrencyTextBox321.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox322
//
this.solvencyCurrencyTextBox322.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox322.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox322.Location = new System.Drawing.Point(10,968);
this.solvencyCurrencyTextBox322.Name = "solvencyCurrencyTextBox322";
this.solvencyCurrencyTextBox322.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox322.TabIndex = 322;
this.solvencyCurrencyTextBox322.ColName = "R0510C0010";
this.solvencyCurrencyTextBox322.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox323
//
this.solvencyCurrencyTextBox323.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox323.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox323.Location = new System.Drawing.Point(117,968);
this.solvencyCurrencyTextBox323.Name = "solvencyCurrencyTextBox323";
this.solvencyCurrencyTextBox323.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox323.TabIndex = 323;
this.solvencyCurrencyTextBox323.ColName = "R0510C0020";
this.solvencyCurrencyTextBox323.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox324
//
this.solvencyCurrencyTextBox324.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox324.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox324.Location = new System.Drawing.Point(224,968);
this.solvencyCurrencyTextBox324.Name = "solvencyCurrencyTextBox324";
this.solvencyCurrencyTextBox324.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox324.TabIndex = 324;
this.solvencyCurrencyTextBox324.ColName = "R0510EC0021";
this.solvencyCurrencyTextBox324.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox325
//
this.solvencyCurrencyTextBox325.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox325.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox325.Location = new System.Drawing.Point(10,988);
this.solvencyCurrencyTextBox325.Name = "solvencyCurrencyTextBox325";
this.solvencyCurrencyTextBox325.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox325.TabIndex = 325;
this.solvencyCurrencyTextBox325.ColName = "R0520C0010";
this.solvencyCurrencyTextBox325.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox326
//
this.solvencyCurrencyTextBox326.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox326.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox326.Location = new System.Drawing.Point(117,988);
this.solvencyCurrencyTextBox326.Name = "solvencyCurrencyTextBox326";
this.solvencyCurrencyTextBox326.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox326.TabIndex = 326;
this.solvencyCurrencyTextBox326.ColName = "R0520C0020";
this.solvencyCurrencyTextBox326.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox327
//
this.solvencyCurrencyTextBox327.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox327.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox327.Location = new System.Drawing.Point(224,988);
this.solvencyCurrencyTextBox327.Name = "solvencyCurrencyTextBox327";
this.solvencyCurrencyTextBox327.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox327.TabIndex = 327;
this.solvencyCurrencyTextBox327.ColName = "R0520EC0021";
this.solvencyCurrencyTextBox327.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox327.Enabled = false;
this.solvencyCurrencyTextBox327.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox328
//
this.solvencyCurrencyTextBox328.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox328.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox328.Location = new System.Drawing.Point(10,1008);
this.solvencyCurrencyTextBox328.Name = "solvencyCurrencyTextBox328";
this.solvencyCurrencyTextBox328.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox328.TabIndex = 328;
this.solvencyCurrencyTextBox328.ColName = "R0530C0010";
this.solvencyCurrencyTextBox328.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox329
//
this.solvencyCurrencyTextBox329.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox329.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox329.Location = new System.Drawing.Point(117,1008);
this.solvencyCurrencyTextBox329.Name = "solvencyCurrencyTextBox329";
this.solvencyCurrencyTextBox329.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox329.TabIndex = 329;
this.solvencyCurrencyTextBox329.ColName = "R0530C0020";
this.solvencyCurrencyTextBox329.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox329.Enabled = false;
this.solvencyCurrencyTextBox329.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox330
//
this.solvencyCurrencyTextBox330.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox330.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox330.Location = new System.Drawing.Point(224,1008);
this.solvencyCurrencyTextBox330.Name = "solvencyCurrencyTextBox330";
this.solvencyCurrencyTextBox330.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox330.TabIndex = 330;
this.solvencyCurrencyTextBox330.ColName = "R0530EC0021";
this.solvencyCurrencyTextBox330.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox330.Enabled = false;
this.solvencyCurrencyTextBox330.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox331
//
this.solvencyCurrencyTextBox331.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox331.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox331.Location = new System.Drawing.Point(10,1028);
this.solvencyCurrencyTextBox331.Name = "solvencyCurrencyTextBox331";
this.solvencyCurrencyTextBox331.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox331.TabIndex = 331;
this.solvencyCurrencyTextBox331.ColName = "R0540C0010";
this.solvencyCurrencyTextBox331.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox332
//
this.solvencyCurrencyTextBox332.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox332.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox332.Location = new System.Drawing.Point(117,1028);
this.solvencyCurrencyTextBox332.Name = "solvencyCurrencyTextBox332";
this.solvencyCurrencyTextBox332.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox332.TabIndex = 332;
this.solvencyCurrencyTextBox332.ColName = "R0540C0020";
this.solvencyCurrencyTextBox332.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox332.Enabled = false;
this.solvencyCurrencyTextBox332.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox333
//
this.solvencyCurrencyTextBox333.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox333.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox333.Location = new System.Drawing.Point(224,1028);
this.solvencyCurrencyTextBox333.Name = "solvencyCurrencyTextBox333";
this.solvencyCurrencyTextBox333.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox333.TabIndex = 333;
this.solvencyCurrencyTextBox333.ColName = "R0540EC0021";
this.solvencyCurrencyTextBox333.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox333.Enabled = false;
this.solvencyCurrencyTextBox333.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox334
//
this.solvencyCurrencyTextBox334.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox334.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox334.Location = new System.Drawing.Point(10,1048);
this.solvencyCurrencyTextBox334.Name = "solvencyCurrencyTextBox334";
this.solvencyCurrencyTextBox334.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox334.TabIndex = 334;
this.solvencyCurrencyTextBox334.ColName = "R0550C0010";
this.solvencyCurrencyTextBox334.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox335
//
this.solvencyCurrencyTextBox335.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox335.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox335.Location = new System.Drawing.Point(117,1048);
this.solvencyCurrencyTextBox335.Name = "solvencyCurrencyTextBox335";
this.solvencyCurrencyTextBox335.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox335.TabIndex = 335;
this.solvencyCurrencyTextBox335.ColName = "R0550C0020";
this.solvencyCurrencyTextBox335.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox335.Enabled = false;
this.solvencyCurrencyTextBox335.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox336
//
this.solvencyCurrencyTextBox336.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox336.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox336.Location = new System.Drawing.Point(224,1048);
this.solvencyCurrencyTextBox336.Name = "solvencyCurrencyTextBox336";
this.solvencyCurrencyTextBox336.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox336.TabIndex = 336;
this.solvencyCurrencyTextBox336.ColName = "R0550EC0021";
this.solvencyCurrencyTextBox336.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox336.Enabled = false;
this.solvencyCurrencyTextBox336.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox337
//
this.solvencyCurrencyTextBox337.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox337.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox337.Location = new System.Drawing.Point(10,1068);
this.solvencyCurrencyTextBox337.Name = "solvencyCurrencyTextBox337";
this.solvencyCurrencyTextBox337.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox337.TabIndex = 337;
this.solvencyCurrencyTextBox337.ColName = "R0560C0010";
this.solvencyCurrencyTextBox337.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox338
//
this.solvencyCurrencyTextBox338.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox338.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox338.Location = new System.Drawing.Point(117,1068);
this.solvencyCurrencyTextBox338.Name = "solvencyCurrencyTextBox338";
this.solvencyCurrencyTextBox338.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox338.TabIndex = 338;
this.solvencyCurrencyTextBox338.ColName = "R0560C0020";
this.solvencyCurrencyTextBox338.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox339
//
this.solvencyCurrencyTextBox339.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox339.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox339.Location = new System.Drawing.Point(224,1068);
this.solvencyCurrencyTextBox339.Name = "solvencyCurrencyTextBox339";
this.solvencyCurrencyTextBox339.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox339.TabIndex = 339;
this.solvencyCurrencyTextBox339.ColName = "R0560EC0021";
this.solvencyCurrencyTextBox339.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox339.Enabled = false;
this.solvencyCurrencyTextBox339.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox340
//
this.solvencyCurrencyTextBox340.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox340.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox340.Location = new System.Drawing.Point(10,1088);
this.solvencyCurrencyTextBox340.Name = "solvencyCurrencyTextBox340";
this.solvencyCurrencyTextBox340.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox340.TabIndex = 340;
this.solvencyCurrencyTextBox340.ColName = "R0570C0010";
this.solvencyCurrencyTextBox340.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox341
//
this.solvencyCurrencyTextBox341.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox341.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox341.Location = new System.Drawing.Point(117,1088);
this.solvencyCurrencyTextBox341.Name = "solvencyCurrencyTextBox341";
this.solvencyCurrencyTextBox341.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox341.TabIndex = 341;
this.solvencyCurrencyTextBox341.ColName = "R0570C0020";
this.solvencyCurrencyTextBox341.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox341.Enabled = false;
this.solvencyCurrencyTextBox341.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox342
//
this.solvencyCurrencyTextBox342.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox342.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox342.Location = new System.Drawing.Point(224,1088);
this.solvencyCurrencyTextBox342.Name = "solvencyCurrencyTextBox342";
this.solvencyCurrencyTextBox342.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox342.TabIndex = 342;
this.solvencyCurrencyTextBox342.ColName = "R0570EC0021";
this.solvencyCurrencyTextBox342.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox342.Enabled = false;
this.solvencyCurrencyTextBox342.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox343
//
this.solvencyCurrencyTextBox343.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox343.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox343.Location = new System.Drawing.Point(10,1108);
this.solvencyCurrencyTextBox343.Name = "solvencyCurrencyTextBox343";
this.solvencyCurrencyTextBox343.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox343.TabIndex = 343;
this.solvencyCurrencyTextBox343.ColName = "R0580C0010";
this.solvencyCurrencyTextBox343.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox344
//
this.solvencyCurrencyTextBox344.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox344.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox344.Location = new System.Drawing.Point(117,1108);
this.solvencyCurrencyTextBox344.Name = "solvencyCurrencyTextBox344";
this.solvencyCurrencyTextBox344.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox344.TabIndex = 344;
this.solvencyCurrencyTextBox344.ColName = "R0580C0020";
this.solvencyCurrencyTextBox344.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox344.Enabled = false;
this.solvencyCurrencyTextBox344.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox345
//
this.solvencyCurrencyTextBox345.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox345.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox345.Location = new System.Drawing.Point(224,1108);
this.solvencyCurrencyTextBox345.Name = "solvencyCurrencyTextBox345";
this.solvencyCurrencyTextBox345.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox345.TabIndex = 345;
this.solvencyCurrencyTextBox345.ColName = "R0580EC0021";
this.solvencyCurrencyTextBox345.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox345.Enabled = false;
this.solvencyCurrencyTextBox345.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox346
//
this.solvencyCurrencyTextBox346.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox346.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox346.Location = new System.Drawing.Point(10,1128);
this.solvencyCurrencyTextBox346.Name = "solvencyCurrencyTextBox346";
this.solvencyCurrencyTextBox346.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox346.TabIndex = 346;
this.solvencyCurrencyTextBox346.ColName = "R0590C0010";
this.solvencyCurrencyTextBox346.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox347
//
this.solvencyCurrencyTextBox347.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox347.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox347.Location = new System.Drawing.Point(117,1128);
this.solvencyCurrencyTextBox347.Name = "solvencyCurrencyTextBox347";
this.solvencyCurrencyTextBox347.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox347.TabIndex = 347;
this.solvencyCurrencyTextBox347.ColName = "R0590C0020";
this.solvencyCurrencyTextBox347.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox347.Enabled = false;
this.solvencyCurrencyTextBox347.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox348
//
this.solvencyCurrencyTextBox348.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox348.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox348.Location = new System.Drawing.Point(224,1128);
this.solvencyCurrencyTextBox348.Name = "solvencyCurrencyTextBox348";
this.solvencyCurrencyTextBox348.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox348.TabIndex = 348;
this.solvencyCurrencyTextBox348.ColName = "R0590EC0021";
this.solvencyCurrencyTextBox348.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox348.Enabled = false;
this.solvencyCurrencyTextBox348.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox349
//
this.solvencyCurrencyTextBox349.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox349.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox349.Location = new System.Drawing.Point(10,1148);
this.solvencyCurrencyTextBox349.Name = "solvencyCurrencyTextBox349";
this.solvencyCurrencyTextBox349.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox349.TabIndex = 349;
this.solvencyCurrencyTextBox349.ColName = "R0600C0010";
this.solvencyCurrencyTextBox349.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox350
//
this.solvencyCurrencyTextBox350.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox350.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox350.Location = new System.Drawing.Point(117,1148);
this.solvencyCurrencyTextBox350.Name = "solvencyCurrencyTextBox350";
this.solvencyCurrencyTextBox350.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox350.TabIndex = 350;
this.solvencyCurrencyTextBox350.ColName = "R0600C0020";
this.solvencyCurrencyTextBox350.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox351
//
this.solvencyCurrencyTextBox351.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox351.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox351.Location = new System.Drawing.Point(224,1148);
this.solvencyCurrencyTextBox351.Name = "solvencyCurrencyTextBox351";
this.solvencyCurrencyTextBox351.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox351.TabIndex = 351;
this.solvencyCurrencyTextBox351.ColName = "R0600EC0021";
this.solvencyCurrencyTextBox351.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox352
//
this.solvencyCurrencyTextBox352.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox352.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox352.Location = new System.Drawing.Point(10,1181);
this.solvencyCurrencyTextBox352.Name = "solvencyCurrencyTextBox352";
this.solvencyCurrencyTextBox352.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox352.TabIndex = 352;
this.solvencyCurrencyTextBox352.ColName = "R0610C0010";
this.solvencyCurrencyTextBox352.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox353
//
this.solvencyCurrencyTextBox353.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox353.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox353.Location = new System.Drawing.Point(117,1181);
this.solvencyCurrencyTextBox353.Name = "solvencyCurrencyTextBox353";
this.solvencyCurrencyTextBox353.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox353.TabIndex = 353;
this.solvencyCurrencyTextBox353.ColName = "R0610C0020";
this.solvencyCurrencyTextBox353.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox354
//
this.solvencyCurrencyTextBox354.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox354.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox354.Location = new System.Drawing.Point(224,1181);
this.solvencyCurrencyTextBox354.Name = "solvencyCurrencyTextBox354";
this.solvencyCurrencyTextBox354.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox354.TabIndex = 354;
this.solvencyCurrencyTextBox354.ColName = "R0610EC0021";
this.solvencyCurrencyTextBox354.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox354.Enabled = false;
this.solvencyCurrencyTextBox354.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox355
//
this.solvencyCurrencyTextBox355.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox355.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox355.Location = new System.Drawing.Point(10,1201);
this.solvencyCurrencyTextBox355.Name = "solvencyCurrencyTextBox355";
this.solvencyCurrencyTextBox355.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox355.TabIndex = 355;
this.solvencyCurrencyTextBox355.ColName = "R0620C0010";
this.solvencyCurrencyTextBox355.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox356
//
this.solvencyCurrencyTextBox356.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox356.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox356.Location = new System.Drawing.Point(117,1201);
this.solvencyCurrencyTextBox356.Name = "solvencyCurrencyTextBox356";
this.solvencyCurrencyTextBox356.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox356.TabIndex = 356;
this.solvencyCurrencyTextBox356.ColName = "R0620C0020";
this.solvencyCurrencyTextBox356.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox356.Enabled = false;
this.solvencyCurrencyTextBox356.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox357
//
this.solvencyCurrencyTextBox357.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox357.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox357.Location = new System.Drawing.Point(224,1201);
this.solvencyCurrencyTextBox357.Name = "solvencyCurrencyTextBox357";
this.solvencyCurrencyTextBox357.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox357.TabIndex = 357;
this.solvencyCurrencyTextBox357.ColName = "R0620EC0021";
this.solvencyCurrencyTextBox357.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox357.Enabled = false;
this.solvencyCurrencyTextBox357.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox358
//
this.solvencyCurrencyTextBox358.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox358.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox358.Location = new System.Drawing.Point(10,1221);
this.solvencyCurrencyTextBox358.Name = "solvencyCurrencyTextBox358";
this.solvencyCurrencyTextBox358.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox358.TabIndex = 358;
this.solvencyCurrencyTextBox358.ColName = "R0630C0010";
this.solvencyCurrencyTextBox358.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox359
//
this.solvencyCurrencyTextBox359.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox359.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox359.Location = new System.Drawing.Point(117,1221);
this.solvencyCurrencyTextBox359.Name = "solvencyCurrencyTextBox359";
this.solvencyCurrencyTextBox359.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox359.TabIndex = 359;
this.solvencyCurrencyTextBox359.ColName = "R0630C0020";
this.solvencyCurrencyTextBox359.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox359.Enabled = false;
this.solvencyCurrencyTextBox359.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox360
//
this.solvencyCurrencyTextBox360.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox360.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox360.Location = new System.Drawing.Point(224,1221);
this.solvencyCurrencyTextBox360.Name = "solvencyCurrencyTextBox360";
this.solvencyCurrencyTextBox360.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox360.TabIndex = 360;
this.solvencyCurrencyTextBox360.ColName = "R0630EC0021";
this.solvencyCurrencyTextBox360.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox360.Enabled = false;
this.solvencyCurrencyTextBox360.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox361
//
this.solvencyCurrencyTextBox361.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox361.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox361.Location = new System.Drawing.Point(10,1241);
this.solvencyCurrencyTextBox361.Name = "solvencyCurrencyTextBox361";
this.solvencyCurrencyTextBox361.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox361.TabIndex = 361;
this.solvencyCurrencyTextBox361.ColName = "R0640C0010";
this.solvencyCurrencyTextBox361.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox362
//
this.solvencyCurrencyTextBox362.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox362.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox362.Location = new System.Drawing.Point(117,1241);
this.solvencyCurrencyTextBox362.Name = "solvencyCurrencyTextBox362";
this.solvencyCurrencyTextBox362.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox362.TabIndex = 362;
this.solvencyCurrencyTextBox362.ColName = "R0640C0020";
this.solvencyCurrencyTextBox362.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox362.Enabled = false;
this.solvencyCurrencyTextBox362.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox363
//
this.solvencyCurrencyTextBox363.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox363.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox363.Location = new System.Drawing.Point(224,1241);
this.solvencyCurrencyTextBox363.Name = "solvencyCurrencyTextBox363";
this.solvencyCurrencyTextBox363.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox363.TabIndex = 363;
this.solvencyCurrencyTextBox363.ColName = "R0640EC0021";
this.solvencyCurrencyTextBox363.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox363.Enabled = false;
this.solvencyCurrencyTextBox363.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox364
//
this.solvencyCurrencyTextBox364.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox364.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox364.Location = new System.Drawing.Point(10,1261);
this.solvencyCurrencyTextBox364.Name = "solvencyCurrencyTextBox364";
this.solvencyCurrencyTextBox364.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox364.TabIndex = 364;
this.solvencyCurrencyTextBox364.ColName = "R0650C0010";
this.solvencyCurrencyTextBox364.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox365
//
this.solvencyCurrencyTextBox365.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox365.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox365.Location = new System.Drawing.Point(117,1261);
this.solvencyCurrencyTextBox365.Name = "solvencyCurrencyTextBox365";
this.solvencyCurrencyTextBox365.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox365.TabIndex = 365;
this.solvencyCurrencyTextBox365.ColName = "R0650C0020";
this.solvencyCurrencyTextBox365.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox366
//
this.solvencyCurrencyTextBox366.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox366.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox366.Location = new System.Drawing.Point(224,1261);
this.solvencyCurrencyTextBox366.Name = "solvencyCurrencyTextBox366";
this.solvencyCurrencyTextBox366.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox366.TabIndex = 366;
this.solvencyCurrencyTextBox366.ColName = "R0650EC0021";
this.solvencyCurrencyTextBox366.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox366.Enabled = false;
this.solvencyCurrencyTextBox366.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox367
//
this.solvencyCurrencyTextBox367.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox367.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox367.Location = new System.Drawing.Point(10,1294);
this.solvencyCurrencyTextBox367.Name = "solvencyCurrencyTextBox367";
this.solvencyCurrencyTextBox367.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox367.TabIndex = 367;
this.solvencyCurrencyTextBox367.ColName = "R0660C0010";
this.solvencyCurrencyTextBox367.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox368
//
this.solvencyCurrencyTextBox368.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox368.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox368.Location = new System.Drawing.Point(117,1294);
this.solvencyCurrencyTextBox368.Name = "solvencyCurrencyTextBox368";
this.solvencyCurrencyTextBox368.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox368.TabIndex = 368;
this.solvencyCurrencyTextBox368.ColName = "R0660C0020";
this.solvencyCurrencyTextBox368.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox368.Enabled = false;
this.solvencyCurrencyTextBox368.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox369
//
this.solvencyCurrencyTextBox369.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox369.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox369.Location = new System.Drawing.Point(224,1294);
this.solvencyCurrencyTextBox369.Name = "solvencyCurrencyTextBox369";
this.solvencyCurrencyTextBox369.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox369.TabIndex = 369;
this.solvencyCurrencyTextBox369.ColName = "R0660EC0021";
this.solvencyCurrencyTextBox369.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox369.Enabled = false;
this.solvencyCurrencyTextBox369.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox370
//
this.solvencyCurrencyTextBox370.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox370.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox370.Location = new System.Drawing.Point(10,1314);
this.solvencyCurrencyTextBox370.Name = "solvencyCurrencyTextBox370";
this.solvencyCurrencyTextBox370.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox370.TabIndex = 370;
this.solvencyCurrencyTextBox370.ColName = "R0670C0010";
this.solvencyCurrencyTextBox370.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox371
//
this.solvencyCurrencyTextBox371.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox371.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox371.Location = new System.Drawing.Point(117,1314);
this.solvencyCurrencyTextBox371.Name = "solvencyCurrencyTextBox371";
this.solvencyCurrencyTextBox371.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox371.TabIndex = 371;
this.solvencyCurrencyTextBox371.ColName = "R0670C0020";
this.solvencyCurrencyTextBox371.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox371.Enabled = false;
this.solvencyCurrencyTextBox371.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox372
//
this.solvencyCurrencyTextBox372.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox372.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox372.Location = new System.Drawing.Point(224,1314);
this.solvencyCurrencyTextBox372.Name = "solvencyCurrencyTextBox372";
this.solvencyCurrencyTextBox372.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox372.TabIndex = 372;
this.solvencyCurrencyTextBox372.ColName = "R0670EC0021";
this.solvencyCurrencyTextBox372.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox372.Enabled = false;
this.solvencyCurrencyTextBox372.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox373
//
this.solvencyCurrencyTextBox373.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox373.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox373.Location = new System.Drawing.Point(10,1334);
this.solvencyCurrencyTextBox373.Name = "solvencyCurrencyTextBox373";
this.solvencyCurrencyTextBox373.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox373.TabIndex = 373;
this.solvencyCurrencyTextBox373.ColName = "R0680C0010";
this.solvencyCurrencyTextBox373.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox374
//
this.solvencyCurrencyTextBox374.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox374.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox374.Location = new System.Drawing.Point(117,1334);
this.solvencyCurrencyTextBox374.Name = "solvencyCurrencyTextBox374";
this.solvencyCurrencyTextBox374.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox374.TabIndex = 374;
this.solvencyCurrencyTextBox374.ColName = "R0680C0020";
this.solvencyCurrencyTextBox374.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox374.Enabled = false;
this.solvencyCurrencyTextBox374.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox375
//
this.solvencyCurrencyTextBox375.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox375.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox375.Location = new System.Drawing.Point(224,1334);
this.solvencyCurrencyTextBox375.Name = "solvencyCurrencyTextBox375";
this.solvencyCurrencyTextBox375.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox375.TabIndex = 375;
this.solvencyCurrencyTextBox375.ColName = "R0680EC0021";
this.solvencyCurrencyTextBox375.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox375.Enabled = false;
this.solvencyCurrencyTextBox375.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox376
//
this.solvencyCurrencyTextBox376.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox376.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox376.Location = new System.Drawing.Point(10,1354);
this.solvencyCurrencyTextBox376.Name = "solvencyCurrencyTextBox376";
this.solvencyCurrencyTextBox376.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox376.TabIndex = 376;
this.solvencyCurrencyTextBox376.ColName = "R0690C0010";
this.solvencyCurrencyTextBox376.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox377
//
this.solvencyCurrencyTextBox377.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox377.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox377.Location = new System.Drawing.Point(117,1354);
this.solvencyCurrencyTextBox377.Name = "solvencyCurrencyTextBox377";
this.solvencyCurrencyTextBox377.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox377.TabIndex = 377;
this.solvencyCurrencyTextBox377.ColName = "R0690C0020";
this.solvencyCurrencyTextBox377.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox378
//
this.solvencyCurrencyTextBox378.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox378.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox378.Location = new System.Drawing.Point(224,1354);
this.solvencyCurrencyTextBox378.Name = "solvencyCurrencyTextBox378";
this.solvencyCurrencyTextBox378.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox378.TabIndex = 378;
this.solvencyCurrencyTextBox378.ColName = "R0690EC0021";
this.solvencyCurrencyTextBox378.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox379
//
this.solvencyCurrencyTextBox379.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox379.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox379.Location = new System.Drawing.Point(10,1374);
this.solvencyCurrencyTextBox379.Name = "solvencyCurrencyTextBox379";
this.solvencyCurrencyTextBox379.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox379.TabIndex = 379;
this.solvencyCurrencyTextBox379.ColName = "R0700C0010";
this.solvencyCurrencyTextBox379.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox380
//
this.solvencyCurrencyTextBox380.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox380.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox380.Location = new System.Drawing.Point(117,1374);
this.solvencyCurrencyTextBox380.Name = "solvencyCurrencyTextBox380";
this.solvencyCurrencyTextBox380.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox380.TabIndex = 380;
this.solvencyCurrencyTextBox380.ColName = "R0700C0020";
this.solvencyCurrencyTextBox380.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox380.Enabled = false;
this.solvencyCurrencyTextBox380.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox381
//
this.solvencyCurrencyTextBox381.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox381.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox381.Location = new System.Drawing.Point(224,1374);
this.solvencyCurrencyTextBox381.Name = "solvencyCurrencyTextBox381";
this.solvencyCurrencyTextBox381.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox381.TabIndex = 381;
this.solvencyCurrencyTextBox381.ColName = "R0700EC0021";
this.solvencyCurrencyTextBox381.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox381.Enabled = false;
this.solvencyCurrencyTextBox381.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox382
//
this.solvencyCurrencyTextBox382.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox382.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox382.Location = new System.Drawing.Point(10,1394);
this.solvencyCurrencyTextBox382.Name = "solvencyCurrencyTextBox382";
this.solvencyCurrencyTextBox382.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox382.TabIndex = 382;
this.solvencyCurrencyTextBox382.ColName = "R0710C0010";
this.solvencyCurrencyTextBox382.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox383
//
this.solvencyCurrencyTextBox383.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox383.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox383.Location = new System.Drawing.Point(117,1394);
this.solvencyCurrencyTextBox383.Name = "solvencyCurrencyTextBox383";
this.solvencyCurrencyTextBox383.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox383.TabIndex = 383;
this.solvencyCurrencyTextBox383.ColName = "R0710C0020";
this.solvencyCurrencyTextBox383.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox383.Enabled = false;
this.solvencyCurrencyTextBox383.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox384
//
this.solvencyCurrencyTextBox384.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox384.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox384.Location = new System.Drawing.Point(224,1394);
this.solvencyCurrencyTextBox384.Name = "solvencyCurrencyTextBox384";
this.solvencyCurrencyTextBox384.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox384.TabIndex = 384;
this.solvencyCurrencyTextBox384.ColName = "R0710EC0021";
this.solvencyCurrencyTextBox384.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox384.Enabled = false;
this.solvencyCurrencyTextBox384.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox385
//
this.solvencyCurrencyTextBox385.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox385.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox385.Location = new System.Drawing.Point(10,1414);
this.solvencyCurrencyTextBox385.Name = "solvencyCurrencyTextBox385";
this.solvencyCurrencyTextBox385.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox385.TabIndex = 385;
this.solvencyCurrencyTextBox385.ColName = "R0720C0010";
this.solvencyCurrencyTextBox385.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox386
//
this.solvencyCurrencyTextBox386.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox386.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox386.Location = new System.Drawing.Point(117,1414);
this.solvencyCurrencyTextBox386.Name = "solvencyCurrencyTextBox386";
this.solvencyCurrencyTextBox386.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox386.TabIndex = 386;
this.solvencyCurrencyTextBox386.ColName = "R0720C0020";
this.solvencyCurrencyTextBox386.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox386.Enabled = false;
this.solvencyCurrencyTextBox386.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox387
//
this.solvencyCurrencyTextBox387.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox387.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox387.Location = new System.Drawing.Point(224,1414);
this.solvencyCurrencyTextBox387.Name = "solvencyCurrencyTextBox387";
this.solvencyCurrencyTextBox387.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox387.TabIndex = 387;
this.solvencyCurrencyTextBox387.ColName = "R0720EC0021";
this.solvencyCurrencyTextBox387.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox387.Enabled = false;
this.solvencyCurrencyTextBox387.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox388
//
this.solvencyCurrencyTextBox388.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox388.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox388.Location = new System.Drawing.Point(10,1434);
this.solvencyCurrencyTextBox388.Name = "solvencyCurrencyTextBox388";
this.solvencyCurrencyTextBox388.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox388.TabIndex = 388;
this.solvencyCurrencyTextBox388.ColName = "R0730C0010";
this.solvencyCurrencyTextBox388.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox388.Enabled = false;
this.solvencyCurrencyTextBox388.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox389
//
this.solvencyCurrencyTextBox389.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox389.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox389.Location = new System.Drawing.Point(117,1434);
this.solvencyCurrencyTextBox389.Name = "solvencyCurrencyTextBox389";
this.solvencyCurrencyTextBox389.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox389.TabIndex = 389;
this.solvencyCurrencyTextBox389.ColName = "R0730C0020";
this.solvencyCurrencyTextBox389.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox390
//
this.solvencyCurrencyTextBox390.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox390.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox390.Location = new System.Drawing.Point(224,1434);
this.solvencyCurrencyTextBox390.Name = "solvencyCurrencyTextBox390";
this.solvencyCurrencyTextBox390.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox390.TabIndex = 390;
this.solvencyCurrencyTextBox390.ColName = "R0730EC0021";
this.solvencyCurrencyTextBox390.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox390.Enabled = false;
this.solvencyCurrencyTextBox390.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox391
//
this.solvencyCurrencyTextBox391.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox391.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox391.Location = new System.Drawing.Point(10,1454);
this.solvencyCurrencyTextBox391.Name = "solvencyCurrencyTextBox391";
this.solvencyCurrencyTextBox391.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox391.TabIndex = 391;
this.solvencyCurrencyTextBox391.ColName = "R0740C0010";
this.solvencyCurrencyTextBox391.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox392
//
this.solvencyCurrencyTextBox392.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox392.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox392.Location = new System.Drawing.Point(117,1454);
this.solvencyCurrencyTextBox392.Name = "solvencyCurrencyTextBox392";
this.solvencyCurrencyTextBox392.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox392.TabIndex = 392;
this.solvencyCurrencyTextBox392.ColName = "R0740C0020";
this.solvencyCurrencyTextBox392.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox393
//
this.solvencyCurrencyTextBox393.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox393.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox393.Location = new System.Drawing.Point(224,1454);
this.solvencyCurrencyTextBox393.Name = "solvencyCurrencyTextBox393";
this.solvencyCurrencyTextBox393.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox393.TabIndex = 393;
this.solvencyCurrencyTextBox393.ColName = "R0740EC0021";
this.solvencyCurrencyTextBox393.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox394
//
this.solvencyCurrencyTextBox394.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox394.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox394.Location = new System.Drawing.Point(10,1474);
this.solvencyCurrencyTextBox394.Name = "solvencyCurrencyTextBox394";
this.solvencyCurrencyTextBox394.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox394.TabIndex = 394;
this.solvencyCurrencyTextBox394.ColName = "R0750C0010";
this.solvencyCurrencyTextBox394.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox395
//
this.solvencyCurrencyTextBox395.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox395.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox395.Location = new System.Drawing.Point(117,1474);
this.solvencyCurrencyTextBox395.Name = "solvencyCurrencyTextBox395";
this.solvencyCurrencyTextBox395.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox395.TabIndex = 395;
this.solvencyCurrencyTextBox395.ColName = "R0750C0020";
this.solvencyCurrencyTextBox395.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox396
//
this.solvencyCurrencyTextBox396.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox396.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox396.Location = new System.Drawing.Point(224,1474);
this.solvencyCurrencyTextBox396.Name = "solvencyCurrencyTextBox396";
this.solvencyCurrencyTextBox396.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox396.TabIndex = 396;
this.solvencyCurrencyTextBox396.ColName = "R0750EC0021";
this.solvencyCurrencyTextBox396.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox397
//
this.solvencyCurrencyTextBox397.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox397.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox397.Location = new System.Drawing.Point(10,1494);
this.solvencyCurrencyTextBox397.Name = "solvencyCurrencyTextBox397";
this.solvencyCurrencyTextBox397.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox397.TabIndex = 397;
this.solvencyCurrencyTextBox397.ColName = "R0760C0010";
this.solvencyCurrencyTextBox397.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox398
//
this.solvencyCurrencyTextBox398.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox398.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox398.Location = new System.Drawing.Point(117,1494);
this.solvencyCurrencyTextBox398.Name = "solvencyCurrencyTextBox398";
this.solvencyCurrencyTextBox398.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox398.TabIndex = 398;
this.solvencyCurrencyTextBox398.ColName = "R0760C0020";
this.solvencyCurrencyTextBox398.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox399
//
this.solvencyCurrencyTextBox399.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox399.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox399.Location = new System.Drawing.Point(224,1494);
this.solvencyCurrencyTextBox399.Name = "solvencyCurrencyTextBox399";
this.solvencyCurrencyTextBox399.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox399.TabIndex = 399;
this.solvencyCurrencyTextBox399.ColName = "R0760EC0021";
this.solvencyCurrencyTextBox399.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox400
//
this.solvencyCurrencyTextBox400.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox400.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox400.Location = new System.Drawing.Point(10,1514);
this.solvencyCurrencyTextBox400.Name = "solvencyCurrencyTextBox400";
this.solvencyCurrencyTextBox400.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox400.TabIndex = 400;
this.solvencyCurrencyTextBox400.ColName = "R0770C0010";
this.solvencyCurrencyTextBox400.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox401
//
this.solvencyCurrencyTextBox401.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox401.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox401.Location = new System.Drawing.Point(117,1514);
this.solvencyCurrencyTextBox401.Name = "solvencyCurrencyTextBox401";
this.solvencyCurrencyTextBox401.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox401.TabIndex = 401;
this.solvencyCurrencyTextBox401.ColName = "R0770C0020";
this.solvencyCurrencyTextBox401.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox402
//
this.solvencyCurrencyTextBox402.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox402.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox402.Location = new System.Drawing.Point(224,1514);
this.solvencyCurrencyTextBox402.Name = "solvencyCurrencyTextBox402";
this.solvencyCurrencyTextBox402.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox402.TabIndex = 402;
this.solvencyCurrencyTextBox402.ColName = "R0770EC0021";
this.solvencyCurrencyTextBox402.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox403
//
this.solvencyCurrencyTextBox403.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox403.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox403.Location = new System.Drawing.Point(10,1534);
this.solvencyCurrencyTextBox403.Name = "solvencyCurrencyTextBox403";
this.solvencyCurrencyTextBox403.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox403.TabIndex = 403;
this.solvencyCurrencyTextBox403.ColName = "R0780C0010";
this.solvencyCurrencyTextBox403.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox404
//
this.solvencyCurrencyTextBox404.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox404.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox404.Location = new System.Drawing.Point(117,1534);
this.solvencyCurrencyTextBox404.Name = "solvencyCurrencyTextBox404";
this.solvencyCurrencyTextBox404.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox404.TabIndex = 404;
this.solvencyCurrencyTextBox404.ColName = "R0780C0020";
this.solvencyCurrencyTextBox404.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox405
//
this.solvencyCurrencyTextBox405.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox405.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox405.Location = new System.Drawing.Point(224,1534);
this.solvencyCurrencyTextBox405.Name = "solvencyCurrencyTextBox405";
this.solvencyCurrencyTextBox405.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox405.TabIndex = 405;
this.solvencyCurrencyTextBox405.ColName = "R0780EC0021";
this.solvencyCurrencyTextBox405.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox406
//
this.solvencyCurrencyTextBox406.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox406.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox406.Location = new System.Drawing.Point(10,1554);
this.solvencyCurrencyTextBox406.Name = "solvencyCurrencyTextBox406";
this.solvencyCurrencyTextBox406.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox406.TabIndex = 406;
this.solvencyCurrencyTextBox406.ColName = "R0790C0010";
this.solvencyCurrencyTextBox406.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox407
//
this.solvencyCurrencyTextBox407.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox407.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox407.Location = new System.Drawing.Point(117,1554);
this.solvencyCurrencyTextBox407.Name = "solvencyCurrencyTextBox407";
this.solvencyCurrencyTextBox407.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox407.TabIndex = 407;
this.solvencyCurrencyTextBox407.ColName = "R0790C0020";
this.solvencyCurrencyTextBox407.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox408
//
this.solvencyCurrencyTextBox408.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox408.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox408.Location = new System.Drawing.Point(224,1554);
this.solvencyCurrencyTextBox408.Name = "solvencyCurrencyTextBox408";
this.solvencyCurrencyTextBox408.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox408.TabIndex = 408;
this.solvencyCurrencyTextBox408.ColName = "R0790EC0021";
this.solvencyCurrencyTextBox408.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox409
//
this.solvencyCurrencyTextBox409.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox409.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox409.Location = new System.Drawing.Point(10,1574);
this.solvencyCurrencyTextBox409.Name = "solvencyCurrencyTextBox409";
this.solvencyCurrencyTextBox409.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox409.TabIndex = 409;
this.solvencyCurrencyTextBox409.ColName = "R0800C0010";
this.solvencyCurrencyTextBox409.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox410
//
this.solvencyCurrencyTextBox410.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox410.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox410.Location = new System.Drawing.Point(117,1574);
this.solvencyCurrencyTextBox410.Name = "solvencyCurrencyTextBox410";
this.solvencyCurrencyTextBox410.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox410.TabIndex = 410;
this.solvencyCurrencyTextBox410.ColName = "R0800C0020";
this.solvencyCurrencyTextBox410.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox411
//
this.solvencyCurrencyTextBox411.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox411.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox411.Location = new System.Drawing.Point(224,1574);
this.solvencyCurrencyTextBox411.Name = "solvencyCurrencyTextBox411";
this.solvencyCurrencyTextBox411.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox411.TabIndex = 411;
this.solvencyCurrencyTextBox411.ColName = "R0800EC0021";
this.solvencyCurrencyTextBox411.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox412
//
this.solvencyCurrencyTextBox412.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox412.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox412.Location = new System.Drawing.Point(10,1594);
this.solvencyCurrencyTextBox412.Name = "solvencyCurrencyTextBox412";
this.solvencyCurrencyTextBox412.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox412.TabIndex = 412;
this.solvencyCurrencyTextBox412.ColName = "ER0801C0010";
this.solvencyCurrencyTextBox412.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox413
//
this.solvencyCurrencyTextBox413.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox413.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox413.Location = new System.Drawing.Point(117,1594);
this.solvencyCurrencyTextBox413.Name = "solvencyCurrencyTextBox413";
this.solvencyCurrencyTextBox413.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox413.TabIndex = 413;
this.solvencyCurrencyTextBox413.ColName = "ER0801C0020";
this.solvencyCurrencyTextBox413.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox413.Enabled = false;
this.solvencyCurrencyTextBox413.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox414
//
this.solvencyCurrencyTextBox414.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox414.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox414.Location = new System.Drawing.Point(224,1594);
this.solvencyCurrencyTextBox414.Name = "solvencyCurrencyTextBox414";
this.solvencyCurrencyTextBox414.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox414.TabIndex = 414;
this.solvencyCurrencyTextBox414.ColName = "ER0801EC0021";
this.solvencyCurrencyTextBox414.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox415
//
this.solvencyCurrencyTextBox415.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox415.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox415.Location = new System.Drawing.Point(10,1627);
this.solvencyCurrencyTextBox415.Name = "solvencyCurrencyTextBox415";
this.solvencyCurrencyTextBox415.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox415.TabIndex = 415;
this.solvencyCurrencyTextBox415.ColName = "ER0802C0010";
this.solvencyCurrencyTextBox415.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox416
//
this.solvencyCurrencyTextBox416.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox416.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox416.Location = new System.Drawing.Point(117,1627);
this.solvencyCurrencyTextBox416.Name = "solvencyCurrencyTextBox416";
this.solvencyCurrencyTextBox416.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox416.TabIndex = 416;
this.solvencyCurrencyTextBox416.ColName = "ER0802C0020";
this.solvencyCurrencyTextBox416.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox416.Enabled = false;
this.solvencyCurrencyTextBox416.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox417
//
this.solvencyCurrencyTextBox417.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox417.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox417.Location = new System.Drawing.Point(224,1627);
this.solvencyCurrencyTextBox417.Name = "solvencyCurrencyTextBox417";
this.solvencyCurrencyTextBox417.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox417.TabIndex = 417;
this.solvencyCurrencyTextBox417.ColName = "ER0802EC0021";
this.solvencyCurrencyTextBox417.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox418
//
this.solvencyCurrencyTextBox418.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox418.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox418.Location = new System.Drawing.Point(10,1660);
this.solvencyCurrencyTextBox418.Name = "solvencyCurrencyTextBox418";
this.solvencyCurrencyTextBox418.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox418.TabIndex = 418;
this.solvencyCurrencyTextBox418.ColName = "ER0803C0010";
this.solvencyCurrencyTextBox418.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox419
//
this.solvencyCurrencyTextBox419.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox419.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox419.Location = new System.Drawing.Point(117,1660);
this.solvencyCurrencyTextBox419.Name = "solvencyCurrencyTextBox419";
this.solvencyCurrencyTextBox419.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox419.TabIndex = 419;
this.solvencyCurrencyTextBox419.ColName = "ER0803C0020";
this.solvencyCurrencyTextBox419.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox419.Enabled = false;
this.solvencyCurrencyTextBox419.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox420
//
this.solvencyCurrencyTextBox420.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox420.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox420.Location = new System.Drawing.Point(224,1660);
this.solvencyCurrencyTextBox420.Name = "solvencyCurrencyTextBox420";
this.solvencyCurrencyTextBox420.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox420.TabIndex = 420;
this.solvencyCurrencyTextBox420.ColName = "ER0803EC0021";
this.solvencyCurrencyTextBox420.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox421
//
this.solvencyCurrencyTextBox421.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox421.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox421.Location = new System.Drawing.Point(10,1693);
this.solvencyCurrencyTextBox421.Name = "solvencyCurrencyTextBox421";
this.solvencyCurrencyTextBox421.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox421.TabIndex = 421;
this.solvencyCurrencyTextBox421.ColName = "R0810C0010";
this.solvencyCurrencyTextBox421.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox422
//
this.solvencyCurrencyTextBox422.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox422.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox422.Location = new System.Drawing.Point(117,1693);
this.solvencyCurrencyTextBox422.Name = "solvencyCurrencyTextBox422";
this.solvencyCurrencyTextBox422.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox422.TabIndex = 422;
this.solvencyCurrencyTextBox422.ColName = "R0810C0020";
this.solvencyCurrencyTextBox422.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox423
//
this.solvencyCurrencyTextBox423.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox423.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox423.Location = new System.Drawing.Point(224,1693);
this.solvencyCurrencyTextBox423.Name = "solvencyCurrencyTextBox423";
this.solvencyCurrencyTextBox423.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox423.TabIndex = 423;
this.solvencyCurrencyTextBox423.ColName = "R0810EC0021";
this.solvencyCurrencyTextBox423.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox424
//
this.solvencyCurrencyTextBox424.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox424.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox424.Location = new System.Drawing.Point(10,1726);
this.solvencyCurrencyTextBox424.Name = "solvencyCurrencyTextBox424";
this.solvencyCurrencyTextBox424.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox424.TabIndex = 424;
this.solvencyCurrencyTextBox424.ColName = "ER0811C0010";
this.solvencyCurrencyTextBox424.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox425
//
this.solvencyCurrencyTextBox425.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox425.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox425.Location = new System.Drawing.Point(117,1726);
this.solvencyCurrencyTextBox425.Name = "solvencyCurrencyTextBox425";
this.solvencyCurrencyTextBox425.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox425.TabIndex = 425;
this.solvencyCurrencyTextBox425.ColName = "ER0811C0020";
this.solvencyCurrencyTextBox425.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox425.Enabled = false;
this.solvencyCurrencyTextBox425.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox426
//
this.solvencyCurrencyTextBox426.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox426.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox426.Location = new System.Drawing.Point(224,1726);
this.solvencyCurrencyTextBox426.Name = "solvencyCurrencyTextBox426";
this.solvencyCurrencyTextBox426.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox426.TabIndex = 426;
this.solvencyCurrencyTextBox426.ColName = "ER0811EC0021";
this.solvencyCurrencyTextBox426.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox427
//
this.solvencyCurrencyTextBox427.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox427.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox427.Location = new System.Drawing.Point(10,1746);
this.solvencyCurrencyTextBox427.Name = "solvencyCurrencyTextBox427";
this.solvencyCurrencyTextBox427.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox427.TabIndex = 427;
this.solvencyCurrencyTextBox427.ColName = "ER0812C0010";
this.solvencyCurrencyTextBox427.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox428
//
this.solvencyCurrencyTextBox428.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox428.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox428.Location = new System.Drawing.Point(117,1746);
this.solvencyCurrencyTextBox428.Name = "solvencyCurrencyTextBox428";
this.solvencyCurrencyTextBox428.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox428.TabIndex = 428;
this.solvencyCurrencyTextBox428.ColName = "ER0812C0020";
this.solvencyCurrencyTextBox428.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox428.Enabled = false;
this.solvencyCurrencyTextBox428.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox429
//
this.solvencyCurrencyTextBox429.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox429.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox429.Location = new System.Drawing.Point(224,1746);
this.solvencyCurrencyTextBox429.Name = "solvencyCurrencyTextBox429";
this.solvencyCurrencyTextBox429.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox429.TabIndex = 429;
this.solvencyCurrencyTextBox429.ColName = "ER0812EC0021";
this.solvencyCurrencyTextBox429.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox430
//
this.solvencyCurrencyTextBox430.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox430.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox430.Location = new System.Drawing.Point(10,1779);
this.solvencyCurrencyTextBox430.Name = "solvencyCurrencyTextBox430";
this.solvencyCurrencyTextBox430.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox430.TabIndex = 430;
this.solvencyCurrencyTextBox430.ColName = "ER0813C0010";
this.solvencyCurrencyTextBox430.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox431
//
this.solvencyCurrencyTextBox431.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox431.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox431.Location = new System.Drawing.Point(117,1779);
this.solvencyCurrencyTextBox431.Name = "solvencyCurrencyTextBox431";
this.solvencyCurrencyTextBox431.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox431.TabIndex = 431;
this.solvencyCurrencyTextBox431.ColName = "ER0813C0020";
this.solvencyCurrencyTextBox431.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox431.Enabled = false;
this.solvencyCurrencyTextBox431.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox432
//
this.solvencyCurrencyTextBox432.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox432.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox432.Location = new System.Drawing.Point(224,1779);
this.solvencyCurrencyTextBox432.Name = "solvencyCurrencyTextBox432";
this.solvencyCurrencyTextBox432.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox432.TabIndex = 432;
this.solvencyCurrencyTextBox432.ColName = "ER0813EC0021";
this.solvencyCurrencyTextBox432.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox433
//
this.solvencyCurrencyTextBox433.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox433.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox433.Location = new System.Drawing.Point(10,1812);
this.solvencyCurrencyTextBox433.Name = "solvencyCurrencyTextBox433";
this.solvencyCurrencyTextBox433.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox433.TabIndex = 433;
this.solvencyCurrencyTextBox433.ColName = "ER0814C0010";
this.solvencyCurrencyTextBox433.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox434
//
this.solvencyCurrencyTextBox434.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox434.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox434.Location = new System.Drawing.Point(117,1812);
this.solvencyCurrencyTextBox434.Name = "solvencyCurrencyTextBox434";
this.solvencyCurrencyTextBox434.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox434.TabIndex = 434;
this.solvencyCurrencyTextBox434.ColName = "ER0814C0020";
this.solvencyCurrencyTextBox434.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox434.Enabled = false;
this.solvencyCurrencyTextBox434.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox435
//
this.solvencyCurrencyTextBox435.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox435.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox435.Location = new System.Drawing.Point(224,1812);
this.solvencyCurrencyTextBox435.Name = "solvencyCurrencyTextBox435";
this.solvencyCurrencyTextBox435.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox435.TabIndex = 435;
this.solvencyCurrencyTextBox435.ColName = "ER0814EC0021";
this.solvencyCurrencyTextBox435.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox436
//
this.solvencyCurrencyTextBox436.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox436.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox436.Location = new System.Drawing.Point(10,1845);
this.solvencyCurrencyTextBox436.Name = "solvencyCurrencyTextBox436";
this.solvencyCurrencyTextBox436.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox436.TabIndex = 436;
this.solvencyCurrencyTextBox436.ColName = "ER0815C0010";
this.solvencyCurrencyTextBox436.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox437
//
this.solvencyCurrencyTextBox437.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox437.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox437.Location = new System.Drawing.Point(117,1845);
this.solvencyCurrencyTextBox437.Name = "solvencyCurrencyTextBox437";
this.solvencyCurrencyTextBox437.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox437.TabIndex = 437;
this.solvencyCurrencyTextBox437.ColName = "ER0815C0020";
this.solvencyCurrencyTextBox437.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox437.Enabled = false;
this.solvencyCurrencyTextBox437.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox438
//
this.solvencyCurrencyTextBox438.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox438.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox438.Location = new System.Drawing.Point(224,1845);
this.solvencyCurrencyTextBox438.Name = "solvencyCurrencyTextBox438";
this.solvencyCurrencyTextBox438.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox438.TabIndex = 438;
this.solvencyCurrencyTextBox438.ColName = "ER0815EC0021";
this.solvencyCurrencyTextBox438.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox439
//
this.solvencyCurrencyTextBox439.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox439.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox439.Location = new System.Drawing.Point(10,1865);
this.solvencyCurrencyTextBox439.Name = "solvencyCurrencyTextBox439";
this.solvencyCurrencyTextBox439.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox439.TabIndex = 439;
this.solvencyCurrencyTextBox439.ColName = "R0820C0010";
this.solvencyCurrencyTextBox439.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox440
//
this.solvencyCurrencyTextBox440.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox440.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox440.Location = new System.Drawing.Point(117,1865);
this.solvencyCurrencyTextBox440.Name = "solvencyCurrencyTextBox440";
this.solvencyCurrencyTextBox440.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox440.TabIndex = 440;
this.solvencyCurrencyTextBox440.ColName = "R0820C0020";
this.solvencyCurrencyTextBox440.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox441
//
this.solvencyCurrencyTextBox441.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox441.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox441.Location = new System.Drawing.Point(224,1865);
this.solvencyCurrencyTextBox441.Name = "solvencyCurrencyTextBox441";
this.solvencyCurrencyTextBox441.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox441.TabIndex = 441;
this.solvencyCurrencyTextBox441.ColName = "R0820EC0021";
this.solvencyCurrencyTextBox441.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox442
//
this.solvencyCurrencyTextBox442.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox442.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox442.Location = new System.Drawing.Point(10,1885);
this.solvencyCurrencyTextBox442.Name = "solvencyCurrencyTextBox442";
this.solvencyCurrencyTextBox442.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox442.TabIndex = 442;
this.solvencyCurrencyTextBox442.ColName = "R0830C0010";
this.solvencyCurrencyTextBox442.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox443
//
this.solvencyCurrencyTextBox443.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox443.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox443.Location = new System.Drawing.Point(117,1885);
this.solvencyCurrencyTextBox443.Name = "solvencyCurrencyTextBox443";
this.solvencyCurrencyTextBox443.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox443.TabIndex = 443;
this.solvencyCurrencyTextBox443.ColName = "R0830C0020";
this.solvencyCurrencyTextBox443.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox444
//
this.solvencyCurrencyTextBox444.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox444.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox444.Location = new System.Drawing.Point(224,1885);
this.solvencyCurrencyTextBox444.Name = "solvencyCurrencyTextBox444";
this.solvencyCurrencyTextBox444.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox444.TabIndex = 444;
this.solvencyCurrencyTextBox444.ColName = "R0830EC0021";
this.solvencyCurrencyTextBox444.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox445
//
this.solvencyCurrencyTextBox445.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox445.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox445.Location = new System.Drawing.Point(10,1905);
this.solvencyCurrencyTextBox445.Name = "solvencyCurrencyTextBox445";
this.solvencyCurrencyTextBox445.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox445.TabIndex = 445;
this.solvencyCurrencyTextBox445.ColName = "R0840C0010";
this.solvencyCurrencyTextBox445.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox446
//
this.solvencyCurrencyTextBox446.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox446.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox446.Location = new System.Drawing.Point(117,1905);
this.solvencyCurrencyTextBox446.Name = "solvencyCurrencyTextBox446";
this.solvencyCurrencyTextBox446.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox446.TabIndex = 446;
this.solvencyCurrencyTextBox446.ColName = "R0840C0020";
this.solvencyCurrencyTextBox446.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox447
//
this.solvencyCurrencyTextBox447.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox447.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox447.Location = new System.Drawing.Point(224,1905);
this.solvencyCurrencyTextBox447.Name = "solvencyCurrencyTextBox447";
this.solvencyCurrencyTextBox447.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox447.TabIndex = 447;
this.solvencyCurrencyTextBox447.ColName = "R0840EC0021";
this.solvencyCurrencyTextBox447.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox448
//
this.solvencyCurrencyTextBox448.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox448.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox448.Location = new System.Drawing.Point(10,1925);
this.solvencyCurrencyTextBox448.Name = "solvencyCurrencyTextBox448";
this.solvencyCurrencyTextBox448.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox448.TabIndex = 448;
this.solvencyCurrencyTextBox448.ColName = "R0850C0010";
this.solvencyCurrencyTextBox448.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox449
//
this.solvencyCurrencyTextBox449.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox449.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox449.Location = new System.Drawing.Point(117,1925);
this.solvencyCurrencyTextBox449.Name = "solvencyCurrencyTextBox449";
this.solvencyCurrencyTextBox449.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox449.TabIndex = 449;
this.solvencyCurrencyTextBox449.ColName = "R0850C0020";
this.solvencyCurrencyTextBox449.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox450
//
this.solvencyCurrencyTextBox450.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox450.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox450.Location = new System.Drawing.Point(224,1925);
this.solvencyCurrencyTextBox450.Name = "solvencyCurrencyTextBox450";
this.solvencyCurrencyTextBox450.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox450.TabIndex = 450;
this.solvencyCurrencyTextBox450.ColName = "R0850EC0021";
this.solvencyCurrencyTextBox450.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox451
//
this.solvencyCurrencyTextBox451.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox451.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox451.Location = new System.Drawing.Point(10,1945);
this.solvencyCurrencyTextBox451.Name = "solvencyCurrencyTextBox451";
this.solvencyCurrencyTextBox451.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox451.TabIndex = 451;
this.solvencyCurrencyTextBox451.ColName = "R0860C0010";
this.solvencyCurrencyTextBox451.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox452
//
this.solvencyCurrencyTextBox452.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox452.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox452.Location = new System.Drawing.Point(117,1945);
this.solvencyCurrencyTextBox452.Name = "solvencyCurrencyTextBox452";
this.solvencyCurrencyTextBox452.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox452.TabIndex = 452;
this.solvencyCurrencyTextBox452.ColName = "R0860C0020";
this.solvencyCurrencyTextBox452.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox453
//
this.solvencyCurrencyTextBox453.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox453.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox453.Location = new System.Drawing.Point(224,1945);
this.solvencyCurrencyTextBox453.Name = "solvencyCurrencyTextBox453";
this.solvencyCurrencyTextBox453.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox453.TabIndex = 453;
this.solvencyCurrencyTextBox453.ColName = "R0860EC0021";
this.solvencyCurrencyTextBox453.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox454
//
this.solvencyCurrencyTextBox454.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox454.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox454.Location = new System.Drawing.Point(10,1965);
this.solvencyCurrencyTextBox454.Name = "solvencyCurrencyTextBox454";
this.solvencyCurrencyTextBox454.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox454.TabIndex = 454;
this.solvencyCurrencyTextBox454.ColName = "R0870C0010";
this.solvencyCurrencyTextBox454.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox455
//
this.solvencyCurrencyTextBox455.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox455.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox455.Location = new System.Drawing.Point(117,1965);
this.solvencyCurrencyTextBox455.Name = "solvencyCurrencyTextBox455";
this.solvencyCurrencyTextBox455.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox455.TabIndex = 455;
this.solvencyCurrencyTextBox455.ColName = "R0870C0020";
this.solvencyCurrencyTextBox455.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox456
//
this.solvencyCurrencyTextBox456.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox456.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox456.Location = new System.Drawing.Point(224,1965);
this.solvencyCurrencyTextBox456.Name = "solvencyCurrencyTextBox456";
this.solvencyCurrencyTextBox456.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox456.TabIndex = 456;
this.solvencyCurrencyTextBox456.ColName = "R0870EC0021";
this.solvencyCurrencyTextBox456.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox457
//
this.solvencyCurrencyTextBox457.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox457.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox457.Location = new System.Drawing.Point(10,1985);
this.solvencyCurrencyTextBox457.Name = "solvencyCurrencyTextBox457";
this.solvencyCurrencyTextBox457.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox457.TabIndex = 457;
this.solvencyCurrencyTextBox457.ColName = "R0880C0010";
this.solvencyCurrencyTextBox457.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox458
//
this.solvencyCurrencyTextBox458.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox458.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox458.Location = new System.Drawing.Point(117,1985);
this.solvencyCurrencyTextBox458.Name = "solvencyCurrencyTextBox458";
this.solvencyCurrencyTextBox458.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox458.TabIndex = 458;
this.solvencyCurrencyTextBox458.ColName = "R0880C0020";
this.solvencyCurrencyTextBox458.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox459
//
this.solvencyCurrencyTextBox459.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox459.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox459.Location = new System.Drawing.Point(224,1985);
this.solvencyCurrencyTextBox459.Name = "solvencyCurrencyTextBox459";
this.solvencyCurrencyTextBox459.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox459.TabIndex = 459;
this.solvencyCurrencyTextBox459.ColName = "R0880EC0021";
this.solvencyCurrencyTextBox459.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox460
//
this.solvencyCurrencyTextBox460.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox460.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox460.Location = new System.Drawing.Point(10,2005);
this.solvencyCurrencyTextBox460.Name = "solvencyCurrencyTextBox460";
this.solvencyCurrencyTextBox460.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox460.TabIndex = 460;
this.solvencyCurrencyTextBox460.ColName = "R0900C0010";
this.solvencyCurrencyTextBox460.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox461
//
this.solvencyCurrencyTextBox461.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox461.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox461.Location = new System.Drawing.Point(117,2005);
this.solvencyCurrencyTextBox461.Name = "solvencyCurrencyTextBox461";
this.solvencyCurrencyTextBox461.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox461.TabIndex = 461;
this.solvencyCurrencyTextBox461.ColName = "R0900C0020";
this.solvencyCurrencyTextBox461.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox462
//
this.solvencyCurrencyTextBox462.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox462.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox462.Location = new System.Drawing.Point(224,2005);
this.solvencyCurrencyTextBox462.Name = "solvencyCurrencyTextBox462";
this.solvencyCurrencyTextBox462.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox462.TabIndex = 462;
this.solvencyCurrencyTextBox462.ColName = "R0900EC0021";
this.solvencyCurrencyTextBox462.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox463
//
this.solvencyCurrencyTextBox463.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox463.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox463.Location = new System.Drawing.Point(10,2025);
this.solvencyCurrencyTextBox463.Name = "solvencyCurrencyTextBox463";
this.solvencyCurrencyTextBox463.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox463.TabIndex = 463;
this.solvencyCurrencyTextBox463.ColName = "R1000C0010";
this.solvencyCurrencyTextBox463.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox464
//
this.solvencyCurrencyTextBox464.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox464.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox464.Location = new System.Drawing.Point(117,2025);
this.solvencyCurrencyTextBox464.Name = "solvencyCurrencyTextBox464";
this.solvencyCurrencyTextBox464.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox464.TabIndex = 464;
this.solvencyCurrencyTextBox464.ColName = "R1000C0020";
this.solvencyCurrencyTextBox464.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox465
//
this.solvencyCurrencyTextBox465.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox465.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox465.Location = new System.Drawing.Point(224,2025);
this.solvencyCurrencyTextBox465.Name = "solvencyCurrencyTextBox465";
this.solvencyCurrencyTextBox465.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox465.TabIndex = 465;
this.solvencyCurrencyTextBox465.ColName = "R1000EC0021";
this.solvencyCurrencyTextBox465.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox465.Enabled = false;
this.solvencyCurrencyTextBox465.BackColor = System.Drawing.Color.Gray;
//
// splitContainerColTitles
//
this.splitContainerColTitles.Dock = System.Windows.Forms.DockStyle.Fill;
this.splitContainerColTitles.Location = new System.Drawing.Point(0,0);
this.splitContainerColTitles.Name = "splitContainerColTitles";
this.splitContainerColTitles.Orientation = System.Windows.Forms.Orientation.Vertical;
this.splitContainerColTitles.Panel1MinSize = 0;
//
// splitContainerColTitles.Panel1
//
//
// splitContainerColTitles.Panel2
//
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel0);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel1);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel2);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel3);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel4);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel5);
this.splitContainerColTitles.Size = new System.Drawing.Size(770, 392);
this.splitContainerColTitles.SplitterDistance = 332;
//
// splitContainerRowTitles
//
this.splitContainerRowTitles.Dock = System.Windows.Forms.DockStyle.Fill;
this.splitContainerRowTitles.Location = new System.Drawing.Point(0,0);
this.splitContainerRowTitles.Name = "splitContainerRowTitles";
this.splitContainerRowTitles.Orientation = System.Windows.Forms.Orientation.Vertical;
this.splitContainerRowTitles.Panel1MinSize = 0;
//
// splitContainerRowTitles.Panel1
//
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel6);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel7);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel8);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel9);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel10);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel11);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel12);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel13);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel14);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel15);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel16);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel17);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel18);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel19);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel20);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel21);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel22);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel23);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel24);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel25);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel26);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel27);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel28);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel29);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel30);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel31);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel32);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel33);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel34);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel35);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel36);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel37);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel38);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel39);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel40);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel41);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel42);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel43);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel44);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel45);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel46);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel47);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel48);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel49);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel50);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel51);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel52);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel53);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel54);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel55);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel56);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel57);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel58);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel59);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel60);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel61);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel62);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel63);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel64);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel65);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel66);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel67);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel68);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel69);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel70);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel71);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel72);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel73);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel74);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel75);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel76);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel77);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel78);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel79);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel80);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel81);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel82);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel83);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel84);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel85);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel86);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel87);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel88);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel89);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel90);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel91);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel92);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel93);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel94);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel95);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel96);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel97);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel98);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel99);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel100);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel101);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel102);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel103);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel104);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel105);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel106);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel107);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel108);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel109);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel110);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel111);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel112);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel113);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel114);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel115);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel116);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel117);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel118);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel119);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel120);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel121);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel122);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel123);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel124);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel125);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel126);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel127);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel128);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel129);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel130);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel131);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel132);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel133);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel134);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel135);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel136);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel137);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel138);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel139);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel140);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel141);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel142);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel143);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel144);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel145);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel146);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel147);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel148);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel149);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel150);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel151);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel152);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel153);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel154);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel155);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel156);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel157);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel158);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel159);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel160);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel161);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel162);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel163);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel164);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel165);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel166);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel167);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel168);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel169);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel170);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel171);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel172);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel173);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel174);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel175);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel176);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel177);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel178);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel179);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel180);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel181);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel182);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel183);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel184);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel185);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel186);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel187);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel188);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel189);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel190);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel191);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel192);
//
// splitContainerRowTitles.Panel2
//
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox193);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox194);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox195);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox196);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox197);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox198);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox199);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox200);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox201);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox202);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox203);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox204);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox205);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox206);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox207);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox208);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox209);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox210);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox211);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox212);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox213);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox214);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox215);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox216);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox217);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox218);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox219);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox220);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox221);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox222);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox223);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox224);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox225);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox226);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox227);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox228);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox229);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox230);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox231);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox232);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox233);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox234);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox235);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox236);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox237);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox238);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox239);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox240);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox241);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox242);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox243);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox244);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox245);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox246);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox247);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox248);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox249);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox250);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox251);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox252);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox253);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox254);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox255);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox256);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox257);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox258);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox259);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox260);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox261);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox262);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox263);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox264);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox265);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox266);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox267);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox268);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox269);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox270);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox271);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox272);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox273);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox274);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox275);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox276);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox277);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox278);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox279);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox280);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox281);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox282);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox283);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox284);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox285);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox286);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox287);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox288);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox289);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox290);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox291);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox292);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox293);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox294);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox295);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox296);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox297);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox298);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox299);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox300);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox301);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox302);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox303);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox304);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox305);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox306);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox307);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox308);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox309);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox310);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox311);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox312);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox313);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox314);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox315);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox316);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox317);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox318);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox319);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox320);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox321);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox322);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox323);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox324);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox325);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox326);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox327);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox328);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox329);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox330);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox331);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox332);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox333);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox334);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox335);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox336);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox337);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox338);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox339);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox340);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox341);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox342);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox343);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox344);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox345);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox346);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox347);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox348);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox349);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox350);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox351);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox352);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox353);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox354);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox355);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox356);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox357);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox358);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox359);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox360);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox361);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox362);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox363);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox364);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox365);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox366);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox367);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox368);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox369);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox370);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox371);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox372);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox373);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox374);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox375);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox376);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox377);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox378);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox379);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox380);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox381);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox382);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox383);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox384);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox385);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox386);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox387);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox388);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox389);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox390);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox391);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox392);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox393);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox394);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox395);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox396);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox397);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox398);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox399);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox400);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox401);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox402);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox403);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox404);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox405);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox406);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox407);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox408);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox409);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox410);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox411);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox412);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox413);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox414);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox415);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox416);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox417);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox418);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox419);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox420);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox421);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox422);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox423);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox424);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox425);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox426);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox427);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox428);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox429);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox430);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox431);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox432);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox433);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox434);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox435);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox436);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox437);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox438);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox439);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox440);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox441);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox442);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox443);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox444);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox445);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox446);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox447);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox448);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox449);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox450);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox451);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox452);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox453);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox454);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox455);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox456);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox457);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox458);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox459);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox460);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox461);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox462);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox463);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox464);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox465);
this.splitContainerRowTitles.Panel2.AutoScroll = true;
this.splitContainerRowTitles.Size = new System.Drawing.Size(770, 392);
this.splitContainerRowTitles.SplitterDistance = 332;
//
// spltMain
//
this.spltMain.Dock = System.Windows.Forms.DockStyle.Fill;
this.spltMain.Location = new System.Drawing.Point(0,0);
this.spltMain.Name = "spltMain";
this.spltMain.Orientation = System.Windows.Forms.Orientation.Horizontal;
this.spltMain.Panel1MinSize = 0;
//
// spltMain.Panel1
//
this.spltMain.Panel1.Controls.Add(this.splitContainerColTitles);
//
// spltMain.Panel2
//
this.spltMain.Panel2.Controls.Add(this.splitContainerRowTitles);
this.spltMain.Panel2.AutoScroll = true;
this.spltMain.Size = new System.Drawing.Size(770, 2168);
this.spltMain.SplitterDistance = 60;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F); 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font; 
this.Controls.Add(this.spltMain);
            this.Name = "SE_02_01_16_01__sol2__2_0_1_ctrl"; 
            this.Size = new System.Drawing.Size(770, 2108); 
            this.Load += new System.EventHandler(this.BoundControl_Load);
            this.ResumeLayout(false); 
            this.PerformLayout(); 

      } 
private SolvencyLabel solvencyLabel0;
private SolvencyLabel solvencyLabel1;
private SolvencyLabel solvencyLabel2;
private SolvencyLabel solvencyLabel3;
private SolvencyLabel solvencyLabel4;
private SolvencyLabel solvencyLabel5;
private SolvencyLabel solvencyLabel6;
private SolvencyLabel solvencyLabel7;
private SolvencyLabel solvencyLabel8;
private SolvencyLabel solvencyLabel9;
private SolvencyLabel solvencyLabel10;
private SolvencyLabel solvencyLabel11;
private SolvencyLabel solvencyLabel12;
private SolvencyLabel solvencyLabel13;
private SolvencyLabel solvencyLabel14;
private SolvencyLabel solvencyLabel15;
private SolvencyLabel solvencyLabel16;
private SolvencyLabel solvencyLabel17;
private SolvencyLabel solvencyLabel18;
private SolvencyLabel solvencyLabel19;
private SolvencyLabel solvencyLabel20;
private SolvencyLabel solvencyLabel21;
private SolvencyLabel solvencyLabel22;
private SolvencyLabel solvencyLabel23;
private SolvencyLabel solvencyLabel24;
private SolvencyLabel solvencyLabel25;
private SolvencyLabel solvencyLabel26;
private SolvencyLabel solvencyLabel27;
private SolvencyLabel solvencyLabel28;
private SolvencyLabel solvencyLabel29;
private SolvencyLabel solvencyLabel30;
private SolvencyLabel solvencyLabel31;
private SolvencyLabel solvencyLabel32;
private SolvencyLabel solvencyLabel33;
private SolvencyLabel solvencyLabel34;
private SolvencyLabel solvencyLabel35;
private SolvencyLabel solvencyLabel36;
private SolvencyLabel solvencyLabel37;
private SolvencyLabel solvencyLabel38;
private SolvencyLabel solvencyLabel39;
private SolvencyLabel solvencyLabel40;
private SolvencyLabel solvencyLabel41;
private SolvencyLabel solvencyLabel42;
private SolvencyLabel solvencyLabel43;
private SolvencyLabel solvencyLabel44;
private SolvencyLabel solvencyLabel45;
private SolvencyLabel solvencyLabel46;
private SolvencyLabel solvencyLabel47;
private SolvencyLabel solvencyLabel48;
private SolvencyLabel solvencyLabel49;
private SolvencyLabel solvencyLabel50;
private SolvencyLabel solvencyLabel51;
private SolvencyLabel solvencyLabel52;
private SolvencyLabel solvencyLabel53;
private SolvencyLabel solvencyLabel54;
private SolvencyLabel solvencyLabel55;
private SolvencyLabel solvencyLabel56;
private SolvencyLabel solvencyLabel57;
private SolvencyLabel solvencyLabel58;
private SolvencyLabel solvencyLabel59;
private SolvencyLabel solvencyLabel60;
private SolvencyLabel solvencyLabel61;
private SolvencyLabel solvencyLabel62;
private SolvencyLabel solvencyLabel63;
private SolvencyLabel solvencyLabel64;
private SolvencyLabel solvencyLabel65;
private SolvencyLabel solvencyLabel66;
private SolvencyLabel solvencyLabel67;
private SolvencyLabel solvencyLabel68;
private SolvencyLabel solvencyLabel69;
private SolvencyLabel solvencyLabel70;
private SolvencyLabel solvencyLabel71;
private SolvencyLabel solvencyLabel72;
private SolvencyLabel solvencyLabel73;
private SolvencyLabel solvencyLabel74;
private SolvencyLabel solvencyLabel75;
private SolvencyLabel solvencyLabel76;
private SolvencyLabel solvencyLabel77;
private SolvencyLabel solvencyLabel78;
private SolvencyLabel solvencyLabel79;
private SolvencyLabel solvencyLabel80;
private SolvencyLabel solvencyLabel81;
private SolvencyLabel solvencyLabel82;
private SolvencyLabel solvencyLabel83;
private SolvencyLabel solvencyLabel84;
private SolvencyLabel solvencyLabel85;
private SolvencyLabel solvencyLabel86;
private SolvencyLabel solvencyLabel87;
private SolvencyLabel solvencyLabel88;
private SolvencyLabel solvencyLabel89;
private SolvencyLabel solvencyLabel90;
private SolvencyLabel solvencyLabel91;
private SolvencyLabel solvencyLabel92;
private SolvencyLabel solvencyLabel93;
private SolvencyLabel solvencyLabel94;
private SolvencyLabel solvencyLabel95;
private SolvencyLabel solvencyLabel96;
private SolvencyLabel solvencyLabel97;
private SolvencyLabel solvencyLabel98;
private SolvencyLabel solvencyLabel99;
private SolvencyLabel solvencyLabel100;
private SolvencyLabel solvencyLabel101;
private SolvencyLabel solvencyLabel102;
private SolvencyLabel solvencyLabel103;
private SolvencyLabel solvencyLabel104;
private SolvencyLabel solvencyLabel105;
private SolvencyLabel solvencyLabel106;
private SolvencyLabel solvencyLabel107;
private SolvencyLabel solvencyLabel108;
private SolvencyLabel solvencyLabel109;
private SolvencyLabel solvencyLabel110;
private SolvencyLabel solvencyLabel111;
private SolvencyLabel solvencyLabel112;
private SolvencyLabel solvencyLabel113;
private SolvencyLabel solvencyLabel114;
private SolvencyLabel solvencyLabel115;
private SolvencyLabel solvencyLabel116;
private SolvencyLabel solvencyLabel117;
private SolvencyLabel solvencyLabel118;
private SolvencyLabel solvencyLabel119;
private SolvencyLabel solvencyLabel120;
private SolvencyLabel solvencyLabel121;
private SolvencyLabel solvencyLabel122;
private SolvencyLabel solvencyLabel123;
private SolvencyLabel solvencyLabel124;
private SolvencyLabel solvencyLabel125;
private SolvencyLabel solvencyLabel126;
private SolvencyLabel solvencyLabel127;
private SolvencyLabel solvencyLabel128;
private SolvencyLabel solvencyLabel129;
private SolvencyLabel solvencyLabel130;
private SolvencyLabel solvencyLabel131;
private SolvencyLabel solvencyLabel132;
private SolvencyLabel solvencyLabel133;
private SolvencyLabel solvencyLabel134;
private SolvencyLabel solvencyLabel135;
private SolvencyLabel solvencyLabel136;
private SolvencyLabel solvencyLabel137;
private SolvencyLabel solvencyLabel138;
private SolvencyLabel solvencyLabel139;
private SolvencyLabel solvencyLabel140;
private SolvencyLabel solvencyLabel141;
private SolvencyLabel solvencyLabel142;
private SolvencyLabel solvencyLabel143;
private SolvencyLabel solvencyLabel144;
private SolvencyLabel solvencyLabel145;
private SolvencyLabel solvencyLabel146;
private SolvencyLabel solvencyLabel147;
private SolvencyLabel solvencyLabel148;
private SolvencyLabel solvencyLabel149;
private SolvencyLabel solvencyLabel150;
private SolvencyLabel solvencyLabel151;
private SolvencyLabel solvencyLabel152;
private SolvencyLabel solvencyLabel153;
private SolvencyLabel solvencyLabel154;
private SolvencyLabel solvencyLabel155;
private SolvencyLabel solvencyLabel156;
private SolvencyLabel solvencyLabel157;
private SolvencyLabel solvencyLabel158;
private SolvencyLabel solvencyLabel159;
private SolvencyLabel solvencyLabel160;
private SolvencyLabel solvencyLabel161;
private SolvencyLabel solvencyLabel162;
private SolvencyLabel solvencyLabel163;
private SolvencyLabel solvencyLabel164;
private SolvencyLabel solvencyLabel165;
private SolvencyLabel solvencyLabel166;
private SolvencyLabel solvencyLabel167;
private SolvencyLabel solvencyLabel168;
private SolvencyLabel solvencyLabel169;
private SolvencyLabel solvencyLabel170;
private SolvencyLabel solvencyLabel171;
private SolvencyLabel solvencyLabel172;
private SolvencyLabel solvencyLabel173;
private SolvencyLabel solvencyLabel174;
private SolvencyLabel solvencyLabel175;
private SolvencyLabel solvencyLabel176;
private SolvencyLabel solvencyLabel177;
private SolvencyLabel solvencyLabel178;
private SolvencyLabel solvencyLabel179;
private SolvencyLabel solvencyLabel180;
private SolvencyLabel solvencyLabel181;
private SolvencyLabel solvencyLabel182;
private SolvencyLabel solvencyLabel183;
private SolvencyLabel solvencyLabel184;
private SolvencyLabel solvencyLabel185;
private SolvencyLabel solvencyLabel186;
private SolvencyLabel solvencyLabel187;
private SolvencyLabel solvencyLabel188;
private SolvencyLabel solvencyLabel189;
private SolvencyLabel solvencyLabel190;
private SolvencyLabel solvencyLabel191;
private SolvencyLabel solvencyLabel192;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox193;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox194;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox195;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox196;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox197;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox198;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox199;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox200;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox201;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox202;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox203;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox204;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox205;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox206;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox207;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox208;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox209;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox210;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox211;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox212;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox213;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox214;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox215;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox216;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox217;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox218;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox219;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox220;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox221;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox222;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox223;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox224;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox225;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox226;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox227;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox228;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox229;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox230;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox231;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox232;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox233;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox234;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox235;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox236;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox237;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox238;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox239;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox240;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox241;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox242;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox243;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox244;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox245;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox246;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox247;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox248;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox249;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox250;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox251;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox252;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox253;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox254;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox255;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox256;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox257;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox258;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox259;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox260;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox261;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox262;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox263;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox264;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox265;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox266;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox267;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox268;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox269;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox270;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox271;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox272;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox273;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox274;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox275;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox276;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox277;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox278;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox279;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox280;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox281;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox282;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox283;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox284;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox285;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox286;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox287;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox288;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox289;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox290;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox291;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox292;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox293;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox294;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox295;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox296;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox297;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox298;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox299;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox300;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox301;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox302;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox303;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox304;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox305;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox306;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox307;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox308;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox309;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox310;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox311;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox312;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox313;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox314;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox315;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox316;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox317;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox318;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox319;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox320;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox321;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox322;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox323;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox324;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox325;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox326;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox327;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox328;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox329;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox330;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox331;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox332;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox333;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox334;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox335;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox336;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox337;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox338;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox339;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox340;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox341;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox342;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox343;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox344;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox345;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox346;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox347;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox348;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox349;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox350;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox351;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox352;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox353;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox354;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox355;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox356;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox357;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox358;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox359;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox360;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox361;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox362;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox363;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox364;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox365;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox366;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox367;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox368;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox369;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox370;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox371;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox372;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox373;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox374;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox375;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox376;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox377;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox378;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox379;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox380;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox381;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox382;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox383;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox384;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox385;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox386;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox387;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox388;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox389;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox390;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox391;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox392;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox393;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox394;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox395;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox396;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox397;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox398;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox399;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox400;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox401;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox402;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox403;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox404;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox405;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox406;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox407;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox408;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox409;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox410;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox411;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox412;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox413;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox414;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox415;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox416;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox417;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox418;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox419;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox420;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox421;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox422;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox423;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox424;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox425;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox426;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox427;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox428;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox429;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox430;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox431;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox432;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox433;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox434;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox435;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox436;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox437;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox438;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox439;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox440;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox441;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox442;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox443;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox444;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox445;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox446;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox447;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox448;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox449;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox450;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox451;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox452;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox453;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox454;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox455;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox456;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox457;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox458;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox459;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox460;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox461;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox462;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox463;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox464;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox465;
private SolvencySplitContainer splitContainerColTitles;
private SolvencySplitContainer splitContainerRowTitles;
private SolvencySplitContainer spltMain;

   }
}

