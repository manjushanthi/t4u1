using SolvencyII.Domain.ENumerators; 
using SolvencyII.UI.Shared.Controls; 

namespace SolvencyII.UI.UserControls 
{ 
   partial class S_26_02_01_01__sol2__2_0_1_ctrl 
   { 
      private void InitializeComponent() 
      { 
this.solvencyLabel0 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel1 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel2 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel3 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel4 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel5 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel6 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel7 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel8 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel9 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel10 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel11 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel12 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel13 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel14 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel15 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel16 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel17 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel18 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel19 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel20 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel21 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel22 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel23 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel24 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel25 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel26 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel27 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel28 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel29 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel30 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel31 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel32 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel33 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel34 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel35 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel36 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel37 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel38 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel39 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel40 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel41 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel42 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel43 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel44 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyTextBox45 = new SolvencyII.UI.Shared.Controls.SolvencyTextBox();
this.solvencyTextBox46 = new SolvencyII.UI.Shared.Controls.SolvencyTextBox();
this.solvencyCurrencyTextBox47 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox48 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox49 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox50 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyTextBox51 = new SolvencyII.UI.Shared.Controls.SolvencyTextBox();
this.solvencyTextBox52 = new SolvencyII.UI.Shared.Controls.SolvencyTextBox();
this.solvencyCurrencyTextBox53 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox54 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox55 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox56 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyTextBox57 = new SolvencyII.UI.Shared.Controls.SolvencyTextBox();
this.solvencyTextBox58 = new SolvencyII.UI.Shared.Controls.SolvencyTextBox();
this.solvencyCurrencyTextBox59 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox60 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox61 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox62 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyTextBox63 = new SolvencyII.UI.Shared.Controls.SolvencyTextBox();
this.solvencyTextBox64 = new SolvencyII.UI.Shared.Controls.SolvencyTextBox();
this.solvencyCurrencyTextBox65 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox66 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox67 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox68 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyTextBox69 = new SolvencyII.UI.Shared.Controls.SolvencyTextBox();
this.solvencyTextBox70 = new SolvencyII.UI.Shared.Controls.SolvencyTextBox();
this.solvencyCurrencyTextBox71 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox72 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox73 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox74 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyTextBox75 = new SolvencyII.UI.Shared.Controls.SolvencyTextBox();
this.solvencyTextBox76 = new SolvencyII.UI.Shared.Controls.SolvencyTextBox();
this.solvencyCurrencyTextBox77 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox78 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox79 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox80 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyTextBox81 = new SolvencyII.UI.Shared.Controls.SolvencyTextBox();
this.solvencyTextBox82 = new SolvencyII.UI.Shared.Controls.SolvencyTextBox();
this.solvencyCurrencyTextBox83 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox84 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox85 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox86 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyTextBox87 = new SolvencyII.UI.Shared.Controls.SolvencyTextBox();
this.solvencyTextBox88 = new SolvencyII.UI.Shared.Controls.SolvencyTextBox();
this.solvencyCurrencyTextBox89 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox90 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox91 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox92 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyTextBox93 = new SolvencyII.UI.Shared.Controls.SolvencyTextBox();
this.solvencyTextBox94 = new SolvencyII.UI.Shared.Controls.SolvencyTextBox();
this.solvencyCurrencyTextBox95 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox96 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox97 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox98 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyTextBox99 = new SolvencyII.UI.Shared.Controls.SolvencyTextBox();
this.solvencyTextBox100 = new SolvencyII.UI.Shared.Controls.SolvencyTextBox();
this.solvencyCurrencyTextBox101 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox102 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox103 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox104 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyTextBox105 = new SolvencyII.UI.Shared.Controls.SolvencyTextBox();
this.solvencyTextBox106 = new SolvencyII.UI.Shared.Controls.SolvencyTextBox();
this.solvencyCurrencyTextBox107 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox108 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox109 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox110 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyTextBox111 = new SolvencyII.UI.Shared.Controls.SolvencyTextBox();
this.solvencyTextBox112 = new SolvencyII.UI.Shared.Controls.SolvencyTextBox();
this.solvencyCurrencyTextBox113 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox114 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox115 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox116 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyTextBox117 = new SolvencyII.UI.Shared.Controls.SolvencyTextBox();
this.solvencyTextBox118 = new SolvencyII.UI.Shared.Controls.SolvencyTextBox();
this.solvencyCurrencyTextBox119 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox120 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox121 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox122 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyTextBox123 = new SolvencyII.UI.Shared.Controls.SolvencyTextBox();
this.solvencyTextBox124 = new SolvencyII.UI.Shared.Controls.SolvencyTextBox();
this.solvencyCurrencyTextBox125 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox126 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox127 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox128 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyTextBox129 = new SolvencyII.UI.Shared.Controls.SolvencyTextBox();
this.solvencyTextBox130 = new SolvencyII.UI.Shared.Controls.SolvencyTextBox();
this.solvencyCurrencyTextBox131 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox132 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox133 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox134 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyTextBox135 = new SolvencyII.UI.Shared.Controls.SolvencyTextBox();
this.solvencyTextBox136 = new SolvencyII.UI.Shared.Controls.SolvencyTextBox();
this.solvencyCurrencyTextBox137 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox138 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox139 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox140 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.splitContainerColTitles = new SolvencyII.UI.Shared.Controls.SolvencySplitContainer();
this.splitContainerRowTitles = new SolvencyII.UI.Shared.Controls.SolvencySplitContainer();
this.spltMain = new SolvencyII.UI.Shared.Controls.SolvencySplitContainer();
            this.SuspendLayout(); 

//
// solvencyLabel0
//
this.solvencyLabel0.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel0.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel0.Location = new System.Drawing.Point(545,10);
this.solvencyLabel0.Name = "solvencyLabel0";
this.solvencyLabel0.OrdinateID_Label = 5406;
this.solvencyLabel0.Size = new System.Drawing.Size(108, 30);
this.solvencyLabel0.TabIndex = 0;
this.solvencyLabel0.Text = "Gross solvency capital requirement" ;
this.solvencyLabel0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel0.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel1
//
this.solvencyLabel1.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel1.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel1.Location = new System.Drawing.Point(545,40);
this.solvencyLabel1.Name = "solvencyLabel1";
this.solvencyLabel1.OrdinateID_Label = 0;
this.solvencyLabel1.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel1.TabIndex = 1;
this.solvencyLabel1.Text = "C0080" ;
this.solvencyLabel1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel2
//
this.solvencyLabel2.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel2.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel2.Location = new System.Drawing.Point(438,10);
this.solvencyLabel2.Name = "solvencyLabel2";
this.solvencyLabel2.OrdinateID_Label = 5405;
this.solvencyLabel2.Size = new System.Drawing.Size(108, 30);
this.solvencyLabel2.TabIndex = 2;
this.solvencyLabel2.Text = "Net solvency capital requirement" ;
this.solvencyLabel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel3
//
this.solvencyLabel3.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel3.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel3.Location = new System.Drawing.Point(438,40);
this.solvencyLabel3.Name = "solvencyLabel3";
this.solvencyLabel3.OrdinateID_Label = 0;
this.solvencyLabel3.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel3.TabIndex = 3;
this.solvencyLabel3.Text = "C0070" ;
this.solvencyLabel3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel4
//
this.solvencyLabel4.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel4.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel4.Location = new System.Drawing.Point(331,10);
this.solvencyLabel4.Name = "solvencyLabel4";
this.solvencyLabel4.OrdinateID_Label = 5404;
this.solvencyLabel4.Size = new System.Drawing.Size(108, 30);
this.solvencyLabel4.TabIndex = 4;
this.solvencyLabel4.Text = "Probability of Default" ;
this.solvencyLabel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel5
//
this.solvencyLabel5.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel5.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel5.Location = new System.Drawing.Point(331,40);
this.solvencyLabel5.Name = "solvencyLabel5";
this.solvencyLabel5.OrdinateID_Label = 0;
this.solvencyLabel5.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel5.TabIndex = 5;
this.solvencyLabel5.Text = "C0060" ;
this.solvencyLabel5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel6
//
this.solvencyLabel6.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel6.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel6.Location = new System.Drawing.Point(224,10);
this.solvencyLabel6.Name = "solvencyLabel6";
this.solvencyLabel6.OrdinateID_Label = 5403;
this.solvencyLabel6.Size = new System.Drawing.Size(108, 30);
this.solvencyLabel6.TabIndex = 6;
this.solvencyLabel6.Text = "Loss Given Default" ;
this.solvencyLabel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel6.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel7
//
this.solvencyLabel7.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel7.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel7.Location = new System.Drawing.Point(224,40);
this.solvencyLabel7.Name = "solvencyLabel7";
this.solvencyLabel7.OrdinateID_Label = 0;
this.solvencyLabel7.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel7.TabIndex = 7;
this.solvencyLabel7.Text = "C0050" ;
this.solvencyLabel7.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel8
//
this.solvencyLabel8.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel8.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel8.Location = new System.Drawing.Point(117,10);
this.solvencyLabel8.Name = "solvencyLabel8";
this.solvencyLabel8.OrdinateID_Label = 5402;
this.solvencyLabel8.Size = new System.Drawing.Size(108, 30);
this.solvencyLabel8.TabIndex = 8;
this.solvencyLabel8.Text = "Code of single name exposure" ;
this.solvencyLabel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel8.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel9
//
this.solvencyLabel9.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel9.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel9.Location = new System.Drawing.Point(117,40);
this.solvencyLabel9.Name = "solvencyLabel9";
this.solvencyLabel9.OrdinateID_Label = 0;
this.solvencyLabel9.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel9.TabIndex = 9;
this.solvencyLabel9.Text = "C0030" ;
this.solvencyLabel9.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel10
//
this.solvencyLabel10.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel10.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel10.Location = new System.Drawing.Point(10,10);
this.solvencyLabel10.Name = "solvencyLabel10";
this.solvencyLabel10.OrdinateID_Label = 5401;
this.solvencyLabel10.Size = new System.Drawing.Size(108, 30);
this.solvencyLabel10.TabIndex = 10;
this.solvencyLabel10.Text = "Name of single name exposure" ;
this.solvencyLabel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel10.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel11
//
this.solvencyLabel11.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel11.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel11.Location = new System.Drawing.Point(10,40);
this.solvencyLabel11.Name = "solvencyLabel11";
this.solvencyLabel11.OrdinateID_Label = 0;
this.solvencyLabel11.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel11.TabIndex = 11;
this.solvencyLabel11.Text = "C0020" ;
this.solvencyLabel11.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel12
//
this.solvencyLabel12.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel12.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel12.Location = new System.Drawing.Point(10,3);
this.solvencyLabel12.Name = "solvencyLabel12";
this.solvencyLabel12.OrdinateID_Label = 5407;
this.solvencyLabel12.Size = new System.Drawing.Size(261, 15);
this.solvencyLabel12.TabIndex = 12;
this.solvencyLabel12.Text = "Type 1 exposures" ;
this.solvencyLabel12.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel13
//
this.solvencyLabel13.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel13.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel13.Location = new System.Drawing.Point(285,3);
this.solvencyLabel13.Name = "solvencyLabel13";
this.solvencyLabel13.OrdinateID_Label = 0;
this.solvencyLabel13.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel13.TabIndex = 13;
this.solvencyLabel13.Text = "R0100" ;
this.solvencyLabel13.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel14
//
this.solvencyLabel14.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel14.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel14.Location = new System.Drawing.Point(17,23);
this.solvencyLabel14.Name = "solvencyLabel14";
this.solvencyLabel14.OrdinateID_Label = 5408;
this.solvencyLabel14.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel14.TabIndex = 14;
this.solvencyLabel14.Text = "Single name exposure 1" ;
this.solvencyLabel14.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel15
//
this.solvencyLabel15.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel15.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel15.Location = new System.Drawing.Point(285,23);
this.solvencyLabel15.Name = "solvencyLabel15";
this.solvencyLabel15.OrdinateID_Label = 0;
this.solvencyLabel15.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel15.TabIndex = 15;
this.solvencyLabel15.Text = "R0110" ;
this.solvencyLabel15.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel16
//
this.solvencyLabel16.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel16.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel16.Location = new System.Drawing.Point(17,43);
this.solvencyLabel16.Name = "solvencyLabel16";
this.solvencyLabel16.OrdinateID_Label = 5409;
this.solvencyLabel16.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel16.TabIndex = 16;
this.solvencyLabel16.Text = "Single name exposure 2" ;
this.solvencyLabel16.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel17
//
this.solvencyLabel17.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel17.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel17.Location = new System.Drawing.Point(285,43);
this.solvencyLabel17.Name = "solvencyLabel17";
this.solvencyLabel17.OrdinateID_Label = 0;
this.solvencyLabel17.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel17.TabIndex = 17;
this.solvencyLabel17.Text = "R0120" ;
this.solvencyLabel17.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel18
//
this.solvencyLabel18.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel18.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel18.Location = new System.Drawing.Point(17,63);
this.solvencyLabel18.Name = "solvencyLabel18";
this.solvencyLabel18.OrdinateID_Label = 5410;
this.solvencyLabel18.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel18.TabIndex = 18;
this.solvencyLabel18.Text = "Single name exposure 3" ;
this.solvencyLabel18.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel19
//
this.solvencyLabel19.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel19.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel19.Location = new System.Drawing.Point(285,63);
this.solvencyLabel19.Name = "solvencyLabel19";
this.solvencyLabel19.OrdinateID_Label = 0;
this.solvencyLabel19.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel19.TabIndex = 19;
this.solvencyLabel19.Text = "R0130" ;
this.solvencyLabel19.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel20
//
this.solvencyLabel20.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel20.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel20.Location = new System.Drawing.Point(17,83);
this.solvencyLabel20.Name = "solvencyLabel20";
this.solvencyLabel20.OrdinateID_Label = 5411;
this.solvencyLabel20.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel20.TabIndex = 20;
this.solvencyLabel20.Text = "Single name exposure 4" ;
this.solvencyLabel20.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel21
//
this.solvencyLabel21.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel21.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel21.Location = new System.Drawing.Point(285,83);
this.solvencyLabel21.Name = "solvencyLabel21";
this.solvencyLabel21.OrdinateID_Label = 0;
this.solvencyLabel21.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel21.TabIndex = 21;
this.solvencyLabel21.Text = "R0140" ;
this.solvencyLabel21.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel22
//
this.solvencyLabel22.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel22.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel22.Location = new System.Drawing.Point(17,103);
this.solvencyLabel22.Name = "solvencyLabel22";
this.solvencyLabel22.OrdinateID_Label = 5412;
this.solvencyLabel22.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel22.TabIndex = 22;
this.solvencyLabel22.Text = "Single name exposure 5" ;
this.solvencyLabel22.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel23
//
this.solvencyLabel23.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel23.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel23.Location = new System.Drawing.Point(285,103);
this.solvencyLabel23.Name = "solvencyLabel23";
this.solvencyLabel23.OrdinateID_Label = 0;
this.solvencyLabel23.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel23.TabIndex = 23;
this.solvencyLabel23.Text = "R0150" ;
this.solvencyLabel23.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel24
//
this.solvencyLabel24.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel24.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel24.Location = new System.Drawing.Point(17,123);
this.solvencyLabel24.Name = "solvencyLabel24";
this.solvencyLabel24.OrdinateID_Label = 5413;
this.solvencyLabel24.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel24.TabIndex = 24;
this.solvencyLabel24.Text = "Single name exposure 6" ;
this.solvencyLabel24.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel25
//
this.solvencyLabel25.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel25.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel25.Location = new System.Drawing.Point(285,123);
this.solvencyLabel25.Name = "solvencyLabel25";
this.solvencyLabel25.OrdinateID_Label = 0;
this.solvencyLabel25.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel25.TabIndex = 25;
this.solvencyLabel25.Text = "R0160" ;
this.solvencyLabel25.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel26
//
this.solvencyLabel26.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel26.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel26.Location = new System.Drawing.Point(17,143);
this.solvencyLabel26.Name = "solvencyLabel26";
this.solvencyLabel26.OrdinateID_Label = 5414;
this.solvencyLabel26.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel26.TabIndex = 26;
this.solvencyLabel26.Text = "Single name exposure 7" ;
this.solvencyLabel26.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel27
//
this.solvencyLabel27.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel27.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel27.Location = new System.Drawing.Point(285,143);
this.solvencyLabel27.Name = "solvencyLabel27";
this.solvencyLabel27.OrdinateID_Label = 0;
this.solvencyLabel27.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel27.TabIndex = 27;
this.solvencyLabel27.Text = "R0170" ;
this.solvencyLabel27.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel28
//
this.solvencyLabel28.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel28.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel28.Location = new System.Drawing.Point(17,163);
this.solvencyLabel28.Name = "solvencyLabel28";
this.solvencyLabel28.OrdinateID_Label = 5415;
this.solvencyLabel28.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel28.TabIndex = 28;
this.solvencyLabel28.Text = "Single name exposure 8" ;
this.solvencyLabel28.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel29
//
this.solvencyLabel29.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel29.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel29.Location = new System.Drawing.Point(285,163);
this.solvencyLabel29.Name = "solvencyLabel29";
this.solvencyLabel29.OrdinateID_Label = 0;
this.solvencyLabel29.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel29.TabIndex = 29;
this.solvencyLabel29.Text = "R0180" ;
this.solvencyLabel29.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel30
//
this.solvencyLabel30.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel30.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel30.Location = new System.Drawing.Point(17,183);
this.solvencyLabel30.Name = "solvencyLabel30";
this.solvencyLabel30.OrdinateID_Label = 5416;
this.solvencyLabel30.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel30.TabIndex = 30;
this.solvencyLabel30.Text = "Single name exposure 9" ;
this.solvencyLabel30.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel31
//
this.solvencyLabel31.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel31.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel31.Location = new System.Drawing.Point(285,183);
this.solvencyLabel31.Name = "solvencyLabel31";
this.solvencyLabel31.OrdinateID_Label = 0;
this.solvencyLabel31.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel31.TabIndex = 31;
this.solvencyLabel31.Text = "R0190" ;
this.solvencyLabel31.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel32
//
this.solvencyLabel32.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel32.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel32.Location = new System.Drawing.Point(17,203);
this.solvencyLabel32.Name = "solvencyLabel32";
this.solvencyLabel32.OrdinateID_Label = 5417;
this.solvencyLabel32.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel32.TabIndex = 32;
this.solvencyLabel32.Text = "Single name exposure 10" ;
this.solvencyLabel32.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel33
//
this.solvencyLabel33.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel33.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel33.Location = new System.Drawing.Point(285,203);
this.solvencyLabel33.Name = "solvencyLabel33";
this.solvencyLabel33.OrdinateID_Label = 0;
this.solvencyLabel33.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel33.TabIndex = 33;
this.solvencyLabel33.Text = "R0200" ;
this.solvencyLabel33.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel34
//
this.solvencyLabel34.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel34.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel34.Location = new System.Drawing.Point(10,223);
this.solvencyLabel34.Name = "solvencyLabel34";
this.solvencyLabel34.OrdinateID_Label = 5418;
this.solvencyLabel34.Size = new System.Drawing.Size(261, 15);
this.solvencyLabel34.TabIndex = 34;
this.solvencyLabel34.Text = "Type 2 exposures" ;
this.solvencyLabel34.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel35
//
this.solvencyLabel35.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel35.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel35.Location = new System.Drawing.Point(285,223);
this.solvencyLabel35.Name = "solvencyLabel35";
this.solvencyLabel35.OrdinateID_Label = 0;
this.solvencyLabel35.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel35.TabIndex = 35;
this.solvencyLabel35.Text = "R0300" ;
this.solvencyLabel35.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel36
//
this.solvencyLabel36.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel36.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel36.Location = new System.Drawing.Point(17,243);
this.solvencyLabel36.Name = "solvencyLabel36";
this.solvencyLabel36.OrdinateID_Label = 5419;
this.solvencyLabel36.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel36.TabIndex = 36;
this.solvencyLabel36.Text = "Receivables from Intermediaries due for more than 3 months" ;
this.solvencyLabel36.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel37
//
this.solvencyLabel37.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel37.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel37.Location = new System.Drawing.Point(285,243);
this.solvencyLabel37.Name = "solvencyLabel37";
this.solvencyLabel37.OrdinateID_Label = 0;
this.solvencyLabel37.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel37.TabIndex = 37;
this.solvencyLabel37.Text = "R0310" ;
this.solvencyLabel37.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel38
//
this.solvencyLabel38.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel38.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel38.Location = new System.Drawing.Point(17,276);
this.solvencyLabel38.Name = "solvencyLabel38";
this.solvencyLabel38.OrdinateID_Label = 5420;
this.solvencyLabel38.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel38.TabIndex = 38;
this.solvencyLabel38.Text = "All type 2 exposures other than receivables from Intermediaries due for more than 3 months" ;
this.solvencyLabel38.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel39
//
this.solvencyLabel39.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel39.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel39.Location = new System.Drawing.Point(285,276);
this.solvencyLabel39.Name = "solvencyLabel39";
this.solvencyLabel39.OrdinateID_Label = 0;
this.solvencyLabel39.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel39.TabIndex = 39;
this.solvencyLabel39.Text = "R0320" ;
this.solvencyLabel39.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel40
//
this.solvencyLabel40.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel40.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel40.Location = new System.Drawing.Point(10,309);
this.solvencyLabel40.Name = "solvencyLabel40";
this.solvencyLabel40.OrdinateID_Label = 5421;
this.solvencyLabel40.Size = new System.Drawing.Size(261, 15);
this.solvencyLabel40.TabIndex = 40;
this.solvencyLabel40.Text = "Diversification within counterparty default risk module" ;
this.solvencyLabel40.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel41
//
this.solvencyLabel41.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel41.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel41.Location = new System.Drawing.Point(285,309);
this.solvencyLabel41.Name = "solvencyLabel41";
this.solvencyLabel41.OrdinateID_Label = 0;
this.solvencyLabel41.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel41.TabIndex = 41;
this.solvencyLabel41.Text = "R0330" ;
this.solvencyLabel41.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel42
//
this.solvencyLabel42.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel42.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel42.Location = new System.Drawing.Point(10,329);
this.solvencyLabel42.Name = "solvencyLabel42";
this.solvencyLabel42.OrdinateID_Label = 5422;
this.solvencyLabel42.Size = new System.Drawing.Size(261, 15);
this.solvencyLabel42.TabIndex = 42;
this.solvencyLabel42.Text = "Total counterparty default risk" ;
this.solvencyLabel42.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel43
//
this.solvencyLabel43.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel43.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel43.Location = new System.Drawing.Point(285,329);
this.solvencyLabel43.Name = "solvencyLabel43";
this.solvencyLabel43.OrdinateID_Label = 0;
this.solvencyLabel43.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel43.TabIndex = 43;
this.solvencyLabel43.Text = "R0400" ;
this.solvencyLabel43.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel44
//
this.solvencyLabel44.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel44.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel44.Location = new System.Drawing.Point(285,349);
this.solvencyLabel44.Name = "solvencyLabel44";
this.solvencyLabel44.OrdinateID_Label = 0;
this.solvencyLabel44.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel44.TabIndex = 44;
this.solvencyLabel44.Text = "." ;
this.solvencyLabel44.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyTextBox45
//
this.solvencyTextBox45.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyTextBox45.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyTextBox45.Location = new System.Drawing.Point(10,3);
this.solvencyTextBox45.Name = "solvencyTextBox45";
this.solvencyTextBox45.Size = new System.Drawing.Size(100, 13);
this.solvencyTextBox45.TabIndex = 45;
this.solvencyTextBox45.ColName = "R0100C0020";
this.solvencyTextBox45.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
this.solvencyTextBox45.Enabled = false;
this.solvencyTextBox45.BackColor = System.Drawing.Color.Gray;
//
// solvencyTextBox46
//
this.solvencyTextBox46.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyTextBox46.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyTextBox46.Location = new System.Drawing.Point(117,3);
this.solvencyTextBox46.Name = "solvencyTextBox46";
this.solvencyTextBox46.Size = new System.Drawing.Size(100, 13);
this.solvencyTextBox46.TabIndex = 46;
this.solvencyTextBox46.ColName = "R0100C0030";
this.solvencyTextBox46.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
this.solvencyTextBox46.Enabled = false;
this.solvencyTextBox46.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox47
//
this.solvencyCurrencyTextBox47.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox47.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox47.Location = new System.Drawing.Point(224,3);
this.solvencyCurrencyTextBox47.Name = "solvencyCurrencyTextBox47";
this.solvencyCurrencyTextBox47.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox47.TabIndex = 47;
this.solvencyCurrencyTextBox47.ColName = "R0100C0050";
this.solvencyCurrencyTextBox47.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox47.Enabled = false;
this.solvencyCurrencyTextBox47.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox48
//
this.solvencyCurrencyTextBox48.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox48.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox48.Location = new System.Drawing.Point(331,3);
this.solvencyCurrencyTextBox48.Name = "solvencyCurrencyTextBox48";
this.solvencyCurrencyTextBox48.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox48.TabIndex = 48;
this.solvencyCurrencyTextBox48.ColName = "R0100C0060";
this.solvencyCurrencyTextBox48.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox48.Enabled = false;
this.solvencyCurrencyTextBox48.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox49
//
this.solvencyCurrencyTextBox49.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox49.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox49.Location = new System.Drawing.Point(438,3);
this.solvencyCurrencyTextBox49.Name = "solvencyCurrencyTextBox49";
this.solvencyCurrencyTextBox49.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox49.TabIndex = 49;
this.solvencyCurrencyTextBox49.ColName = "R0100C0070";
this.solvencyCurrencyTextBox49.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox49.Enabled = false;
this.solvencyCurrencyTextBox49.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox50
//
this.solvencyCurrencyTextBox50.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox50.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox50.Location = new System.Drawing.Point(545,3);
this.solvencyCurrencyTextBox50.Name = "solvencyCurrencyTextBox50";
this.solvencyCurrencyTextBox50.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox50.TabIndex = 50;
this.solvencyCurrencyTextBox50.ColName = "R0100C0080";
this.solvencyCurrencyTextBox50.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyTextBox51
//
this.solvencyTextBox51.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyTextBox51.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyTextBox51.Location = new System.Drawing.Point(10,23);
this.solvencyTextBox51.Name = "solvencyTextBox51";
this.solvencyTextBox51.Size = new System.Drawing.Size(100, 13);
this.solvencyTextBox51.TabIndex = 51;
this.solvencyTextBox51.ColName = "R0110C0020";
this.solvencyTextBox51.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
//
// solvencyTextBox52
//
this.solvencyTextBox52.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyTextBox52.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyTextBox52.Location = new System.Drawing.Point(117,23);
this.solvencyTextBox52.Name = "solvencyTextBox52";
this.solvencyTextBox52.Size = new System.Drawing.Size(100, 13);
this.solvencyTextBox52.TabIndex = 52;
this.solvencyTextBox52.ColName = "R0110C0030";
this.solvencyTextBox52.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
//
// solvencyCurrencyTextBox53
//
this.solvencyCurrencyTextBox53.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox53.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox53.Location = new System.Drawing.Point(224,23);
this.solvencyCurrencyTextBox53.Name = "solvencyCurrencyTextBox53";
this.solvencyCurrencyTextBox53.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox53.TabIndex = 53;
this.solvencyCurrencyTextBox53.ColName = "R0110C0050";
this.solvencyCurrencyTextBox53.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox54
//
this.solvencyCurrencyTextBox54.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox54.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox54.Location = new System.Drawing.Point(331,23);
this.solvencyCurrencyTextBox54.Name = "solvencyCurrencyTextBox54";
this.solvencyCurrencyTextBox54.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox54.TabIndex = 54;
this.solvencyCurrencyTextBox54.ColName = "R0110C0060";
this.solvencyCurrencyTextBox54.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox55
//
this.solvencyCurrencyTextBox55.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox55.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox55.Location = new System.Drawing.Point(438,23);
this.solvencyCurrencyTextBox55.Name = "solvencyCurrencyTextBox55";
this.solvencyCurrencyTextBox55.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox55.TabIndex = 55;
this.solvencyCurrencyTextBox55.ColName = "R0110C0070";
this.solvencyCurrencyTextBox55.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox55.Enabled = false;
this.solvencyCurrencyTextBox55.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox56
//
this.solvencyCurrencyTextBox56.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox56.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox56.Location = new System.Drawing.Point(545,23);
this.solvencyCurrencyTextBox56.Name = "solvencyCurrencyTextBox56";
this.solvencyCurrencyTextBox56.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox56.TabIndex = 56;
this.solvencyCurrencyTextBox56.ColName = "R0110C0080";
this.solvencyCurrencyTextBox56.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox56.Enabled = false;
this.solvencyCurrencyTextBox56.BackColor = System.Drawing.Color.Gray;
//
// solvencyTextBox57
//
this.solvencyTextBox57.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyTextBox57.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyTextBox57.Location = new System.Drawing.Point(10,43);
this.solvencyTextBox57.Name = "solvencyTextBox57";
this.solvencyTextBox57.Size = new System.Drawing.Size(100, 13);
this.solvencyTextBox57.TabIndex = 57;
this.solvencyTextBox57.ColName = "R0120C0020";
this.solvencyTextBox57.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
//
// solvencyTextBox58
//
this.solvencyTextBox58.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyTextBox58.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyTextBox58.Location = new System.Drawing.Point(117,43);
this.solvencyTextBox58.Name = "solvencyTextBox58";
this.solvencyTextBox58.Size = new System.Drawing.Size(100, 13);
this.solvencyTextBox58.TabIndex = 58;
this.solvencyTextBox58.ColName = "R0120C0030";
this.solvencyTextBox58.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
//
// solvencyCurrencyTextBox59
//
this.solvencyCurrencyTextBox59.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox59.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox59.Location = new System.Drawing.Point(224,43);
this.solvencyCurrencyTextBox59.Name = "solvencyCurrencyTextBox59";
this.solvencyCurrencyTextBox59.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox59.TabIndex = 59;
this.solvencyCurrencyTextBox59.ColName = "R0120C0050";
this.solvencyCurrencyTextBox59.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox60
//
this.solvencyCurrencyTextBox60.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox60.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox60.Location = new System.Drawing.Point(331,43);
this.solvencyCurrencyTextBox60.Name = "solvencyCurrencyTextBox60";
this.solvencyCurrencyTextBox60.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox60.TabIndex = 60;
this.solvencyCurrencyTextBox60.ColName = "R0120C0060";
this.solvencyCurrencyTextBox60.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox61
//
this.solvencyCurrencyTextBox61.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox61.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox61.Location = new System.Drawing.Point(438,43);
this.solvencyCurrencyTextBox61.Name = "solvencyCurrencyTextBox61";
this.solvencyCurrencyTextBox61.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox61.TabIndex = 61;
this.solvencyCurrencyTextBox61.ColName = "R0120C0070";
this.solvencyCurrencyTextBox61.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox61.Enabled = false;
this.solvencyCurrencyTextBox61.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox62
//
this.solvencyCurrencyTextBox62.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox62.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox62.Location = new System.Drawing.Point(545,43);
this.solvencyCurrencyTextBox62.Name = "solvencyCurrencyTextBox62";
this.solvencyCurrencyTextBox62.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox62.TabIndex = 62;
this.solvencyCurrencyTextBox62.ColName = "R0120C0080";
this.solvencyCurrencyTextBox62.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox62.Enabled = false;
this.solvencyCurrencyTextBox62.BackColor = System.Drawing.Color.Gray;
//
// solvencyTextBox63
//
this.solvencyTextBox63.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyTextBox63.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyTextBox63.Location = new System.Drawing.Point(10,63);
this.solvencyTextBox63.Name = "solvencyTextBox63";
this.solvencyTextBox63.Size = new System.Drawing.Size(100, 13);
this.solvencyTextBox63.TabIndex = 63;
this.solvencyTextBox63.ColName = "R0130C0020";
this.solvencyTextBox63.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
//
// solvencyTextBox64
//
this.solvencyTextBox64.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyTextBox64.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyTextBox64.Location = new System.Drawing.Point(117,63);
this.solvencyTextBox64.Name = "solvencyTextBox64";
this.solvencyTextBox64.Size = new System.Drawing.Size(100, 13);
this.solvencyTextBox64.TabIndex = 64;
this.solvencyTextBox64.ColName = "R0130C0030";
this.solvencyTextBox64.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
//
// solvencyCurrencyTextBox65
//
this.solvencyCurrencyTextBox65.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox65.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox65.Location = new System.Drawing.Point(224,63);
this.solvencyCurrencyTextBox65.Name = "solvencyCurrencyTextBox65";
this.solvencyCurrencyTextBox65.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox65.TabIndex = 65;
this.solvencyCurrencyTextBox65.ColName = "R0130C0050";
this.solvencyCurrencyTextBox65.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox66
//
this.solvencyCurrencyTextBox66.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox66.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox66.Location = new System.Drawing.Point(331,63);
this.solvencyCurrencyTextBox66.Name = "solvencyCurrencyTextBox66";
this.solvencyCurrencyTextBox66.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox66.TabIndex = 66;
this.solvencyCurrencyTextBox66.ColName = "R0130C0060";
this.solvencyCurrencyTextBox66.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox67
//
this.solvencyCurrencyTextBox67.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox67.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox67.Location = new System.Drawing.Point(438,63);
this.solvencyCurrencyTextBox67.Name = "solvencyCurrencyTextBox67";
this.solvencyCurrencyTextBox67.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox67.TabIndex = 67;
this.solvencyCurrencyTextBox67.ColName = "R0130C0070";
this.solvencyCurrencyTextBox67.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox67.Enabled = false;
this.solvencyCurrencyTextBox67.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox68
//
this.solvencyCurrencyTextBox68.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox68.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox68.Location = new System.Drawing.Point(545,63);
this.solvencyCurrencyTextBox68.Name = "solvencyCurrencyTextBox68";
this.solvencyCurrencyTextBox68.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox68.TabIndex = 68;
this.solvencyCurrencyTextBox68.ColName = "R0130C0080";
this.solvencyCurrencyTextBox68.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox68.Enabled = false;
this.solvencyCurrencyTextBox68.BackColor = System.Drawing.Color.Gray;
//
// solvencyTextBox69
//
this.solvencyTextBox69.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyTextBox69.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyTextBox69.Location = new System.Drawing.Point(10,83);
this.solvencyTextBox69.Name = "solvencyTextBox69";
this.solvencyTextBox69.Size = new System.Drawing.Size(100, 13);
this.solvencyTextBox69.TabIndex = 69;
this.solvencyTextBox69.ColName = "R0140C0020";
this.solvencyTextBox69.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
//
// solvencyTextBox70
//
this.solvencyTextBox70.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyTextBox70.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyTextBox70.Location = new System.Drawing.Point(117,83);
this.solvencyTextBox70.Name = "solvencyTextBox70";
this.solvencyTextBox70.Size = new System.Drawing.Size(100, 13);
this.solvencyTextBox70.TabIndex = 70;
this.solvencyTextBox70.ColName = "R0140C0030";
this.solvencyTextBox70.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
//
// solvencyCurrencyTextBox71
//
this.solvencyCurrencyTextBox71.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox71.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox71.Location = new System.Drawing.Point(224,83);
this.solvencyCurrencyTextBox71.Name = "solvencyCurrencyTextBox71";
this.solvencyCurrencyTextBox71.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox71.TabIndex = 71;
this.solvencyCurrencyTextBox71.ColName = "R0140C0050";
this.solvencyCurrencyTextBox71.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox72
//
this.solvencyCurrencyTextBox72.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox72.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox72.Location = new System.Drawing.Point(331,83);
this.solvencyCurrencyTextBox72.Name = "solvencyCurrencyTextBox72";
this.solvencyCurrencyTextBox72.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox72.TabIndex = 72;
this.solvencyCurrencyTextBox72.ColName = "R0140C0060";
this.solvencyCurrencyTextBox72.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox73
//
this.solvencyCurrencyTextBox73.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox73.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox73.Location = new System.Drawing.Point(438,83);
this.solvencyCurrencyTextBox73.Name = "solvencyCurrencyTextBox73";
this.solvencyCurrencyTextBox73.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox73.TabIndex = 73;
this.solvencyCurrencyTextBox73.ColName = "R0140C0070";
this.solvencyCurrencyTextBox73.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox73.Enabled = false;
this.solvencyCurrencyTextBox73.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox74
//
this.solvencyCurrencyTextBox74.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox74.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox74.Location = new System.Drawing.Point(545,83);
this.solvencyCurrencyTextBox74.Name = "solvencyCurrencyTextBox74";
this.solvencyCurrencyTextBox74.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox74.TabIndex = 74;
this.solvencyCurrencyTextBox74.ColName = "R0140C0080";
this.solvencyCurrencyTextBox74.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox74.Enabled = false;
this.solvencyCurrencyTextBox74.BackColor = System.Drawing.Color.Gray;
//
// solvencyTextBox75
//
this.solvencyTextBox75.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyTextBox75.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyTextBox75.Location = new System.Drawing.Point(10,103);
this.solvencyTextBox75.Name = "solvencyTextBox75";
this.solvencyTextBox75.Size = new System.Drawing.Size(100, 13);
this.solvencyTextBox75.TabIndex = 75;
this.solvencyTextBox75.ColName = "R0150C0020";
this.solvencyTextBox75.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
//
// solvencyTextBox76
//
this.solvencyTextBox76.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyTextBox76.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyTextBox76.Location = new System.Drawing.Point(117,103);
this.solvencyTextBox76.Name = "solvencyTextBox76";
this.solvencyTextBox76.Size = new System.Drawing.Size(100, 13);
this.solvencyTextBox76.TabIndex = 76;
this.solvencyTextBox76.ColName = "R0150C0030";
this.solvencyTextBox76.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
//
// solvencyCurrencyTextBox77
//
this.solvencyCurrencyTextBox77.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox77.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox77.Location = new System.Drawing.Point(224,103);
this.solvencyCurrencyTextBox77.Name = "solvencyCurrencyTextBox77";
this.solvencyCurrencyTextBox77.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox77.TabIndex = 77;
this.solvencyCurrencyTextBox77.ColName = "R0150C0050";
this.solvencyCurrencyTextBox77.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox78
//
this.solvencyCurrencyTextBox78.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox78.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox78.Location = new System.Drawing.Point(331,103);
this.solvencyCurrencyTextBox78.Name = "solvencyCurrencyTextBox78";
this.solvencyCurrencyTextBox78.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox78.TabIndex = 78;
this.solvencyCurrencyTextBox78.ColName = "R0150C0060";
this.solvencyCurrencyTextBox78.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox79
//
this.solvencyCurrencyTextBox79.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox79.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox79.Location = new System.Drawing.Point(438,103);
this.solvencyCurrencyTextBox79.Name = "solvencyCurrencyTextBox79";
this.solvencyCurrencyTextBox79.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox79.TabIndex = 79;
this.solvencyCurrencyTextBox79.ColName = "R0150C0070";
this.solvencyCurrencyTextBox79.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox79.Enabled = false;
this.solvencyCurrencyTextBox79.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox80
//
this.solvencyCurrencyTextBox80.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox80.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox80.Location = new System.Drawing.Point(545,103);
this.solvencyCurrencyTextBox80.Name = "solvencyCurrencyTextBox80";
this.solvencyCurrencyTextBox80.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox80.TabIndex = 80;
this.solvencyCurrencyTextBox80.ColName = "R0150C0080";
this.solvencyCurrencyTextBox80.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox80.Enabled = false;
this.solvencyCurrencyTextBox80.BackColor = System.Drawing.Color.Gray;
//
// solvencyTextBox81
//
this.solvencyTextBox81.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyTextBox81.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyTextBox81.Location = new System.Drawing.Point(10,123);
this.solvencyTextBox81.Name = "solvencyTextBox81";
this.solvencyTextBox81.Size = new System.Drawing.Size(100, 13);
this.solvencyTextBox81.TabIndex = 81;
this.solvencyTextBox81.ColName = "R0160C0020";
this.solvencyTextBox81.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
//
// solvencyTextBox82
//
this.solvencyTextBox82.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyTextBox82.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyTextBox82.Location = new System.Drawing.Point(117,123);
this.solvencyTextBox82.Name = "solvencyTextBox82";
this.solvencyTextBox82.Size = new System.Drawing.Size(100, 13);
this.solvencyTextBox82.TabIndex = 82;
this.solvencyTextBox82.ColName = "R0160C0030";
this.solvencyTextBox82.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
//
// solvencyCurrencyTextBox83
//
this.solvencyCurrencyTextBox83.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox83.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox83.Location = new System.Drawing.Point(224,123);
this.solvencyCurrencyTextBox83.Name = "solvencyCurrencyTextBox83";
this.solvencyCurrencyTextBox83.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox83.TabIndex = 83;
this.solvencyCurrencyTextBox83.ColName = "R0160C0050";
this.solvencyCurrencyTextBox83.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox84
//
this.solvencyCurrencyTextBox84.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox84.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox84.Location = new System.Drawing.Point(331,123);
this.solvencyCurrencyTextBox84.Name = "solvencyCurrencyTextBox84";
this.solvencyCurrencyTextBox84.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox84.TabIndex = 84;
this.solvencyCurrencyTextBox84.ColName = "R0160C0060";
this.solvencyCurrencyTextBox84.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox85
//
this.solvencyCurrencyTextBox85.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox85.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox85.Location = new System.Drawing.Point(438,123);
this.solvencyCurrencyTextBox85.Name = "solvencyCurrencyTextBox85";
this.solvencyCurrencyTextBox85.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox85.TabIndex = 85;
this.solvencyCurrencyTextBox85.ColName = "R0160C0070";
this.solvencyCurrencyTextBox85.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox85.Enabled = false;
this.solvencyCurrencyTextBox85.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox86
//
this.solvencyCurrencyTextBox86.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox86.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox86.Location = new System.Drawing.Point(545,123);
this.solvencyCurrencyTextBox86.Name = "solvencyCurrencyTextBox86";
this.solvencyCurrencyTextBox86.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox86.TabIndex = 86;
this.solvencyCurrencyTextBox86.ColName = "R0160C0080";
this.solvencyCurrencyTextBox86.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox86.Enabled = false;
this.solvencyCurrencyTextBox86.BackColor = System.Drawing.Color.Gray;
//
// solvencyTextBox87
//
this.solvencyTextBox87.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyTextBox87.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyTextBox87.Location = new System.Drawing.Point(10,143);
this.solvencyTextBox87.Name = "solvencyTextBox87";
this.solvencyTextBox87.Size = new System.Drawing.Size(100, 13);
this.solvencyTextBox87.TabIndex = 87;
this.solvencyTextBox87.ColName = "R0170C0020";
this.solvencyTextBox87.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
//
// solvencyTextBox88
//
this.solvencyTextBox88.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyTextBox88.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyTextBox88.Location = new System.Drawing.Point(117,143);
this.solvencyTextBox88.Name = "solvencyTextBox88";
this.solvencyTextBox88.Size = new System.Drawing.Size(100, 13);
this.solvencyTextBox88.TabIndex = 88;
this.solvencyTextBox88.ColName = "R0170C0030";
this.solvencyTextBox88.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
//
// solvencyCurrencyTextBox89
//
this.solvencyCurrencyTextBox89.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox89.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox89.Location = new System.Drawing.Point(224,143);
this.solvencyCurrencyTextBox89.Name = "solvencyCurrencyTextBox89";
this.solvencyCurrencyTextBox89.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox89.TabIndex = 89;
this.solvencyCurrencyTextBox89.ColName = "R0170C0050";
this.solvencyCurrencyTextBox89.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox90
//
this.solvencyCurrencyTextBox90.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox90.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox90.Location = new System.Drawing.Point(331,143);
this.solvencyCurrencyTextBox90.Name = "solvencyCurrencyTextBox90";
this.solvencyCurrencyTextBox90.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox90.TabIndex = 90;
this.solvencyCurrencyTextBox90.ColName = "R0170C0060";
this.solvencyCurrencyTextBox90.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox91
//
this.solvencyCurrencyTextBox91.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox91.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox91.Location = new System.Drawing.Point(438,143);
this.solvencyCurrencyTextBox91.Name = "solvencyCurrencyTextBox91";
this.solvencyCurrencyTextBox91.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox91.TabIndex = 91;
this.solvencyCurrencyTextBox91.ColName = "R0170C0070";
this.solvencyCurrencyTextBox91.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox91.Enabled = false;
this.solvencyCurrencyTextBox91.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox92
//
this.solvencyCurrencyTextBox92.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox92.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox92.Location = new System.Drawing.Point(545,143);
this.solvencyCurrencyTextBox92.Name = "solvencyCurrencyTextBox92";
this.solvencyCurrencyTextBox92.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox92.TabIndex = 92;
this.solvencyCurrencyTextBox92.ColName = "R0170C0080";
this.solvencyCurrencyTextBox92.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox92.Enabled = false;
this.solvencyCurrencyTextBox92.BackColor = System.Drawing.Color.Gray;
//
// solvencyTextBox93
//
this.solvencyTextBox93.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyTextBox93.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyTextBox93.Location = new System.Drawing.Point(10,163);
this.solvencyTextBox93.Name = "solvencyTextBox93";
this.solvencyTextBox93.Size = new System.Drawing.Size(100, 13);
this.solvencyTextBox93.TabIndex = 93;
this.solvencyTextBox93.ColName = "R0180C0020";
this.solvencyTextBox93.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
//
// solvencyTextBox94
//
this.solvencyTextBox94.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyTextBox94.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyTextBox94.Location = new System.Drawing.Point(117,163);
this.solvencyTextBox94.Name = "solvencyTextBox94";
this.solvencyTextBox94.Size = new System.Drawing.Size(100, 13);
this.solvencyTextBox94.TabIndex = 94;
this.solvencyTextBox94.ColName = "R0180C0030";
this.solvencyTextBox94.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
//
// solvencyCurrencyTextBox95
//
this.solvencyCurrencyTextBox95.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox95.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox95.Location = new System.Drawing.Point(224,163);
this.solvencyCurrencyTextBox95.Name = "solvencyCurrencyTextBox95";
this.solvencyCurrencyTextBox95.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox95.TabIndex = 95;
this.solvencyCurrencyTextBox95.ColName = "R0180C0050";
this.solvencyCurrencyTextBox95.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox96
//
this.solvencyCurrencyTextBox96.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox96.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox96.Location = new System.Drawing.Point(331,163);
this.solvencyCurrencyTextBox96.Name = "solvencyCurrencyTextBox96";
this.solvencyCurrencyTextBox96.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox96.TabIndex = 96;
this.solvencyCurrencyTextBox96.ColName = "R0180C0060";
this.solvencyCurrencyTextBox96.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox97
//
this.solvencyCurrencyTextBox97.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox97.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox97.Location = new System.Drawing.Point(438,163);
this.solvencyCurrencyTextBox97.Name = "solvencyCurrencyTextBox97";
this.solvencyCurrencyTextBox97.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox97.TabIndex = 97;
this.solvencyCurrencyTextBox97.ColName = "R0180C0070";
this.solvencyCurrencyTextBox97.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox97.Enabled = false;
this.solvencyCurrencyTextBox97.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox98
//
this.solvencyCurrencyTextBox98.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox98.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox98.Location = new System.Drawing.Point(545,163);
this.solvencyCurrencyTextBox98.Name = "solvencyCurrencyTextBox98";
this.solvencyCurrencyTextBox98.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox98.TabIndex = 98;
this.solvencyCurrencyTextBox98.ColName = "R0180C0080";
this.solvencyCurrencyTextBox98.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox98.Enabled = false;
this.solvencyCurrencyTextBox98.BackColor = System.Drawing.Color.Gray;
//
// solvencyTextBox99
//
this.solvencyTextBox99.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyTextBox99.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyTextBox99.Location = new System.Drawing.Point(10,183);
this.solvencyTextBox99.Name = "solvencyTextBox99";
this.solvencyTextBox99.Size = new System.Drawing.Size(100, 13);
this.solvencyTextBox99.TabIndex = 99;
this.solvencyTextBox99.ColName = "R0190C0020";
this.solvencyTextBox99.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
//
// solvencyTextBox100
//
this.solvencyTextBox100.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyTextBox100.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyTextBox100.Location = new System.Drawing.Point(117,183);
this.solvencyTextBox100.Name = "solvencyTextBox100";
this.solvencyTextBox100.Size = new System.Drawing.Size(100, 13);
this.solvencyTextBox100.TabIndex = 100;
this.solvencyTextBox100.ColName = "R0190C0030";
this.solvencyTextBox100.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
//
// solvencyCurrencyTextBox101
//
this.solvencyCurrencyTextBox101.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox101.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox101.Location = new System.Drawing.Point(224,183);
this.solvencyCurrencyTextBox101.Name = "solvencyCurrencyTextBox101";
this.solvencyCurrencyTextBox101.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox101.TabIndex = 101;
this.solvencyCurrencyTextBox101.ColName = "R0190C0050";
this.solvencyCurrencyTextBox101.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox102
//
this.solvencyCurrencyTextBox102.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox102.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox102.Location = new System.Drawing.Point(331,183);
this.solvencyCurrencyTextBox102.Name = "solvencyCurrencyTextBox102";
this.solvencyCurrencyTextBox102.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox102.TabIndex = 102;
this.solvencyCurrencyTextBox102.ColName = "R0190C0060";
this.solvencyCurrencyTextBox102.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox103
//
this.solvencyCurrencyTextBox103.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox103.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox103.Location = new System.Drawing.Point(438,183);
this.solvencyCurrencyTextBox103.Name = "solvencyCurrencyTextBox103";
this.solvencyCurrencyTextBox103.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox103.TabIndex = 103;
this.solvencyCurrencyTextBox103.ColName = "R0190C0070";
this.solvencyCurrencyTextBox103.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox103.Enabled = false;
this.solvencyCurrencyTextBox103.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox104
//
this.solvencyCurrencyTextBox104.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox104.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox104.Location = new System.Drawing.Point(545,183);
this.solvencyCurrencyTextBox104.Name = "solvencyCurrencyTextBox104";
this.solvencyCurrencyTextBox104.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox104.TabIndex = 104;
this.solvencyCurrencyTextBox104.ColName = "R0190C0080";
this.solvencyCurrencyTextBox104.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox104.Enabled = false;
this.solvencyCurrencyTextBox104.BackColor = System.Drawing.Color.Gray;
//
// solvencyTextBox105
//
this.solvencyTextBox105.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyTextBox105.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyTextBox105.Location = new System.Drawing.Point(10,203);
this.solvencyTextBox105.Name = "solvencyTextBox105";
this.solvencyTextBox105.Size = new System.Drawing.Size(100, 13);
this.solvencyTextBox105.TabIndex = 105;
this.solvencyTextBox105.ColName = "R0200C0020";
this.solvencyTextBox105.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
//
// solvencyTextBox106
//
this.solvencyTextBox106.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyTextBox106.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyTextBox106.Location = new System.Drawing.Point(117,203);
this.solvencyTextBox106.Name = "solvencyTextBox106";
this.solvencyTextBox106.Size = new System.Drawing.Size(100, 13);
this.solvencyTextBox106.TabIndex = 106;
this.solvencyTextBox106.ColName = "R0200C0030";
this.solvencyTextBox106.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
//
// solvencyCurrencyTextBox107
//
this.solvencyCurrencyTextBox107.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox107.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox107.Location = new System.Drawing.Point(224,203);
this.solvencyCurrencyTextBox107.Name = "solvencyCurrencyTextBox107";
this.solvencyCurrencyTextBox107.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox107.TabIndex = 107;
this.solvencyCurrencyTextBox107.ColName = "R0200C0050";
this.solvencyCurrencyTextBox107.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox108
//
this.solvencyCurrencyTextBox108.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox108.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox108.Location = new System.Drawing.Point(331,203);
this.solvencyCurrencyTextBox108.Name = "solvencyCurrencyTextBox108";
this.solvencyCurrencyTextBox108.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox108.TabIndex = 108;
this.solvencyCurrencyTextBox108.ColName = "R0200C0060";
this.solvencyCurrencyTextBox108.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox109
//
this.solvencyCurrencyTextBox109.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox109.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox109.Location = new System.Drawing.Point(438,203);
this.solvencyCurrencyTextBox109.Name = "solvencyCurrencyTextBox109";
this.solvencyCurrencyTextBox109.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox109.TabIndex = 109;
this.solvencyCurrencyTextBox109.ColName = "R0200C0070";
this.solvencyCurrencyTextBox109.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox109.Enabled = false;
this.solvencyCurrencyTextBox109.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox110
//
this.solvencyCurrencyTextBox110.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox110.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox110.Location = new System.Drawing.Point(545,203);
this.solvencyCurrencyTextBox110.Name = "solvencyCurrencyTextBox110";
this.solvencyCurrencyTextBox110.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox110.TabIndex = 110;
this.solvencyCurrencyTextBox110.ColName = "R0200C0080";
this.solvencyCurrencyTextBox110.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox110.Enabled = false;
this.solvencyCurrencyTextBox110.BackColor = System.Drawing.Color.Gray;
//
// solvencyTextBox111
//
this.solvencyTextBox111.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyTextBox111.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyTextBox111.Location = new System.Drawing.Point(10,223);
this.solvencyTextBox111.Name = "solvencyTextBox111";
this.solvencyTextBox111.Size = new System.Drawing.Size(100, 13);
this.solvencyTextBox111.TabIndex = 111;
this.solvencyTextBox111.ColName = "R0300C0020";
this.solvencyTextBox111.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
this.solvencyTextBox111.Enabled = false;
this.solvencyTextBox111.BackColor = System.Drawing.Color.Gray;
//
// solvencyTextBox112
//
this.solvencyTextBox112.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyTextBox112.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyTextBox112.Location = new System.Drawing.Point(117,223);
this.solvencyTextBox112.Name = "solvencyTextBox112";
this.solvencyTextBox112.Size = new System.Drawing.Size(100, 13);
this.solvencyTextBox112.TabIndex = 112;
this.solvencyTextBox112.ColName = "R0300C0030";
this.solvencyTextBox112.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
this.solvencyTextBox112.Enabled = false;
this.solvencyTextBox112.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox113
//
this.solvencyCurrencyTextBox113.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox113.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox113.Location = new System.Drawing.Point(224,223);
this.solvencyCurrencyTextBox113.Name = "solvencyCurrencyTextBox113";
this.solvencyCurrencyTextBox113.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox113.TabIndex = 113;
this.solvencyCurrencyTextBox113.ColName = "R0300C0050";
this.solvencyCurrencyTextBox113.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox113.Enabled = false;
this.solvencyCurrencyTextBox113.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox114
//
this.solvencyCurrencyTextBox114.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox114.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox114.Location = new System.Drawing.Point(331,223);
this.solvencyCurrencyTextBox114.Name = "solvencyCurrencyTextBox114";
this.solvencyCurrencyTextBox114.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox114.TabIndex = 114;
this.solvencyCurrencyTextBox114.ColName = "R0300C0060";
this.solvencyCurrencyTextBox114.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox114.Enabled = false;
this.solvencyCurrencyTextBox114.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox115
//
this.solvencyCurrencyTextBox115.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox115.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox115.Location = new System.Drawing.Point(438,223);
this.solvencyCurrencyTextBox115.Name = "solvencyCurrencyTextBox115";
this.solvencyCurrencyTextBox115.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox115.TabIndex = 115;
this.solvencyCurrencyTextBox115.ColName = "R0300C0070";
this.solvencyCurrencyTextBox115.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox115.Enabled = false;
this.solvencyCurrencyTextBox115.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox116
//
this.solvencyCurrencyTextBox116.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox116.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox116.Location = new System.Drawing.Point(545,223);
this.solvencyCurrencyTextBox116.Name = "solvencyCurrencyTextBox116";
this.solvencyCurrencyTextBox116.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox116.TabIndex = 116;
this.solvencyCurrencyTextBox116.ColName = "R0300C0080";
this.solvencyCurrencyTextBox116.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyTextBox117
//
this.solvencyTextBox117.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyTextBox117.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyTextBox117.Location = new System.Drawing.Point(10,243);
this.solvencyTextBox117.Name = "solvencyTextBox117";
this.solvencyTextBox117.Size = new System.Drawing.Size(100, 13);
this.solvencyTextBox117.TabIndex = 117;
this.solvencyTextBox117.ColName = "R0310C0020";
this.solvencyTextBox117.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
this.solvencyTextBox117.Enabled = false;
this.solvencyTextBox117.BackColor = System.Drawing.Color.Gray;
//
// solvencyTextBox118
//
this.solvencyTextBox118.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyTextBox118.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyTextBox118.Location = new System.Drawing.Point(117,243);
this.solvencyTextBox118.Name = "solvencyTextBox118";
this.solvencyTextBox118.Size = new System.Drawing.Size(100, 13);
this.solvencyTextBox118.TabIndex = 118;
this.solvencyTextBox118.ColName = "R0310C0030";
this.solvencyTextBox118.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
this.solvencyTextBox118.Enabled = false;
this.solvencyTextBox118.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox119
//
this.solvencyCurrencyTextBox119.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox119.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox119.Location = new System.Drawing.Point(224,243);
this.solvencyCurrencyTextBox119.Name = "solvencyCurrencyTextBox119";
this.solvencyCurrencyTextBox119.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox119.TabIndex = 119;
this.solvencyCurrencyTextBox119.ColName = "R0310C0050";
this.solvencyCurrencyTextBox119.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox120
//
this.solvencyCurrencyTextBox120.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox120.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox120.Location = new System.Drawing.Point(331,243);
this.solvencyCurrencyTextBox120.Name = "solvencyCurrencyTextBox120";
this.solvencyCurrencyTextBox120.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox120.TabIndex = 120;
this.solvencyCurrencyTextBox120.ColName = "R0310C0060";
this.solvencyCurrencyTextBox120.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox120.Enabled = false;
this.solvencyCurrencyTextBox120.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox121
//
this.solvencyCurrencyTextBox121.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox121.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox121.Location = new System.Drawing.Point(438,243);
this.solvencyCurrencyTextBox121.Name = "solvencyCurrencyTextBox121";
this.solvencyCurrencyTextBox121.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox121.TabIndex = 121;
this.solvencyCurrencyTextBox121.ColName = "R0310C0070";
this.solvencyCurrencyTextBox121.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox121.Enabled = false;
this.solvencyCurrencyTextBox121.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox122
//
this.solvencyCurrencyTextBox122.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox122.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox122.Location = new System.Drawing.Point(545,243);
this.solvencyCurrencyTextBox122.Name = "solvencyCurrencyTextBox122";
this.solvencyCurrencyTextBox122.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox122.TabIndex = 122;
this.solvencyCurrencyTextBox122.ColName = "R0310C0080";
this.solvencyCurrencyTextBox122.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox122.Enabled = false;
this.solvencyCurrencyTextBox122.BackColor = System.Drawing.Color.Gray;
//
// solvencyTextBox123
//
this.solvencyTextBox123.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyTextBox123.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyTextBox123.Location = new System.Drawing.Point(10,276);
this.solvencyTextBox123.Name = "solvencyTextBox123";
this.solvencyTextBox123.Size = new System.Drawing.Size(100, 13);
this.solvencyTextBox123.TabIndex = 123;
this.solvencyTextBox123.ColName = "R0320C0020";
this.solvencyTextBox123.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
this.solvencyTextBox123.Enabled = false;
this.solvencyTextBox123.BackColor = System.Drawing.Color.Gray;
//
// solvencyTextBox124
//
this.solvencyTextBox124.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyTextBox124.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyTextBox124.Location = new System.Drawing.Point(117,276);
this.solvencyTextBox124.Name = "solvencyTextBox124";
this.solvencyTextBox124.Size = new System.Drawing.Size(100, 13);
this.solvencyTextBox124.TabIndex = 124;
this.solvencyTextBox124.ColName = "R0320C0030";
this.solvencyTextBox124.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
this.solvencyTextBox124.Enabled = false;
this.solvencyTextBox124.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox125
//
this.solvencyCurrencyTextBox125.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox125.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox125.Location = new System.Drawing.Point(224,276);
this.solvencyCurrencyTextBox125.Name = "solvencyCurrencyTextBox125";
this.solvencyCurrencyTextBox125.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox125.TabIndex = 125;
this.solvencyCurrencyTextBox125.ColName = "R0320C0050";
this.solvencyCurrencyTextBox125.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox126
//
this.solvencyCurrencyTextBox126.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox126.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox126.Location = new System.Drawing.Point(331,276);
this.solvencyCurrencyTextBox126.Name = "solvencyCurrencyTextBox126";
this.solvencyCurrencyTextBox126.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox126.TabIndex = 126;
this.solvencyCurrencyTextBox126.ColName = "R0320C0060";
this.solvencyCurrencyTextBox126.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox126.Enabled = false;
this.solvencyCurrencyTextBox126.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox127
//
this.solvencyCurrencyTextBox127.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox127.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox127.Location = new System.Drawing.Point(438,276);
this.solvencyCurrencyTextBox127.Name = "solvencyCurrencyTextBox127";
this.solvencyCurrencyTextBox127.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox127.TabIndex = 127;
this.solvencyCurrencyTextBox127.ColName = "R0320C0070";
this.solvencyCurrencyTextBox127.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox127.Enabled = false;
this.solvencyCurrencyTextBox127.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox128
//
this.solvencyCurrencyTextBox128.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox128.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox128.Location = new System.Drawing.Point(545,276);
this.solvencyCurrencyTextBox128.Name = "solvencyCurrencyTextBox128";
this.solvencyCurrencyTextBox128.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox128.TabIndex = 128;
this.solvencyCurrencyTextBox128.ColName = "R0320C0080";
this.solvencyCurrencyTextBox128.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox128.Enabled = false;
this.solvencyCurrencyTextBox128.BackColor = System.Drawing.Color.Gray;
//
// solvencyTextBox129
//
this.solvencyTextBox129.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyTextBox129.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyTextBox129.Location = new System.Drawing.Point(10,309);
this.solvencyTextBox129.Name = "solvencyTextBox129";
this.solvencyTextBox129.Size = new System.Drawing.Size(100, 13);
this.solvencyTextBox129.TabIndex = 129;
this.solvencyTextBox129.ColName = "R0330C0020";
this.solvencyTextBox129.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
this.solvencyTextBox129.Enabled = false;
this.solvencyTextBox129.BackColor = System.Drawing.Color.Gray;
//
// solvencyTextBox130
//
this.solvencyTextBox130.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyTextBox130.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyTextBox130.Location = new System.Drawing.Point(117,309);
this.solvencyTextBox130.Name = "solvencyTextBox130";
this.solvencyTextBox130.Size = new System.Drawing.Size(100, 13);
this.solvencyTextBox130.TabIndex = 130;
this.solvencyTextBox130.ColName = "R0330C0030";
this.solvencyTextBox130.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
this.solvencyTextBox130.Enabled = false;
this.solvencyTextBox130.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox131
//
this.solvencyCurrencyTextBox131.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox131.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox131.Location = new System.Drawing.Point(224,309);
this.solvencyCurrencyTextBox131.Name = "solvencyCurrencyTextBox131";
this.solvencyCurrencyTextBox131.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox131.TabIndex = 131;
this.solvencyCurrencyTextBox131.ColName = "R0330C0050";
this.solvencyCurrencyTextBox131.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox131.Enabled = false;
this.solvencyCurrencyTextBox131.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox132
//
this.solvencyCurrencyTextBox132.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox132.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox132.Location = new System.Drawing.Point(331,309);
this.solvencyCurrencyTextBox132.Name = "solvencyCurrencyTextBox132";
this.solvencyCurrencyTextBox132.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox132.TabIndex = 132;
this.solvencyCurrencyTextBox132.ColName = "R0330C0060";
this.solvencyCurrencyTextBox132.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox132.Enabled = false;
this.solvencyCurrencyTextBox132.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox133
//
this.solvencyCurrencyTextBox133.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox133.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox133.Location = new System.Drawing.Point(438,309);
this.solvencyCurrencyTextBox133.Name = "solvencyCurrencyTextBox133";
this.solvencyCurrencyTextBox133.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox133.TabIndex = 133;
this.solvencyCurrencyTextBox133.ColName = "R0330C0070";
this.solvencyCurrencyTextBox133.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox133.Enabled = false;
this.solvencyCurrencyTextBox133.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox134
//
this.solvencyCurrencyTextBox134.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox134.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox134.Location = new System.Drawing.Point(545,309);
this.solvencyCurrencyTextBox134.Name = "solvencyCurrencyTextBox134";
this.solvencyCurrencyTextBox134.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox134.TabIndex = 134;
this.solvencyCurrencyTextBox134.ColName = "R0330C0080";
this.solvencyCurrencyTextBox134.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyTextBox135
//
this.solvencyTextBox135.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyTextBox135.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyTextBox135.Location = new System.Drawing.Point(10,329);
this.solvencyTextBox135.Name = "solvencyTextBox135";
this.solvencyTextBox135.Size = new System.Drawing.Size(100, 13);
this.solvencyTextBox135.TabIndex = 135;
this.solvencyTextBox135.ColName = "R0400C0020";
this.solvencyTextBox135.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
this.solvencyTextBox135.Enabled = false;
this.solvencyTextBox135.BackColor = System.Drawing.Color.Gray;
//
// solvencyTextBox136
//
this.solvencyTextBox136.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyTextBox136.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyTextBox136.Location = new System.Drawing.Point(117,329);
this.solvencyTextBox136.Name = "solvencyTextBox136";
this.solvencyTextBox136.Size = new System.Drawing.Size(100, 13);
this.solvencyTextBox136.TabIndex = 136;
this.solvencyTextBox136.ColName = "R0400C0030";
this.solvencyTextBox136.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
this.solvencyTextBox136.Enabled = false;
this.solvencyTextBox136.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox137
//
this.solvencyCurrencyTextBox137.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox137.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox137.Location = new System.Drawing.Point(224,329);
this.solvencyCurrencyTextBox137.Name = "solvencyCurrencyTextBox137";
this.solvencyCurrencyTextBox137.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox137.TabIndex = 137;
this.solvencyCurrencyTextBox137.ColName = "R0400C0050";
this.solvencyCurrencyTextBox137.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox137.Enabled = false;
this.solvencyCurrencyTextBox137.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox138
//
this.solvencyCurrencyTextBox138.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox138.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox138.Location = new System.Drawing.Point(331,329);
this.solvencyCurrencyTextBox138.Name = "solvencyCurrencyTextBox138";
this.solvencyCurrencyTextBox138.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox138.TabIndex = 138;
this.solvencyCurrencyTextBox138.ColName = "R0400C0060";
this.solvencyCurrencyTextBox138.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox138.Enabled = false;
this.solvencyCurrencyTextBox138.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox139
//
this.solvencyCurrencyTextBox139.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox139.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox139.Location = new System.Drawing.Point(438,329);
this.solvencyCurrencyTextBox139.Name = "solvencyCurrencyTextBox139";
this.solvencyCurrencyTextBox139.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox139.TabIndex = 139;
this.solvencyCurrencyTextBox139.ColName = "R0400C0070";
this.solvencyCurrencyTextBox139.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox140
//
this.solvencyCurrencyTextBox140.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox140.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox140.Location = new System.Drawing.Point(545,329);
this.solvencyCurrencyTextBox140.Name = "solvencyCurrencyTextBox140";
this.solvencyCurrencyTextBox140.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox140.TabIndex = 140;
this.solvencyCurrencyTextBox140.ColName = "R0400C0080";
this.solvencyCurrencyTextBox140.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// splitContainerColTitles
//
this.splitContainerColTitles.Dock = System.Windows.Forms.DockStyle.Fill;
this.splitContainerColTitles.Location = new System.Drawing.Point(0,0);
this.splitContainerColTitles.Name = "splitContainerColTitles";
this.splitContainerColTitles.Orientation = System.Windows.Forms.Orientation.Vertical;
this.splitContainerColTitles.Panel1MinSize = 0;
//
// splitContainerColTitles.Panel1
//
//
// splitContainerColTitles.Panel2
//
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel0);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel1);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel2);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel3);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel4);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel5);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel6);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel7);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel8);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel9);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel10);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel11);
this.splitContainerColTitles.Size = new System.Drawing.Size(1091, 392);
this.splitContainerColTitles.SplitterDistance = 332;
//
// splitContainerRowTitles
//
this.splitContainerRowTitles.Dock = System.Windows.Forms.DockStyle.Fill;
this.splitContainerRowTitles.Location = new System.Drawing.Point(0,0);
this.splitContainerRowTitles.Name = "splitContainerRowTitles";
this.splitContainerRowTitles.Orientation = System.Windows.Forms.Orientation.Vertical;
this.splitContainerRowTitles.Panel1MinSize = 0;
//
// splitContainerRowTitles.Panel1
//
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel12);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel13);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel14);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel15);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel16);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel17);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel18);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel19);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel20);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel21);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel22);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel23);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel24);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel25);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel26);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel27);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel28);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel29);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel30);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel31);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel32);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel33);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel34);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel35);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel36);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel37);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel38);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel39);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel40);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel41);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel42);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel43);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel44);
//
// splitContainerRowTitles.Panel2
//
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyTextBox45);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyTextBox46);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox47);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox48);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox49);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox50);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyTextBox51);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyTextBox52);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox53);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox54);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox55);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox56);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyTextBox57);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyTextBox58);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox59);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox60);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox61);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox62);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyTextBox63);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyTextBox64);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox65);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox66);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox67);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox68);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyTextBox69);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyTextBox70);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox71);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox72);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox73);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox74);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyTextBox75);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyTextBox76);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox77);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox78);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox79);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox80);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyTextBox81);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyTextBox82);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox83);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox84);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox85);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox86);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyTextBox87);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyTextBox88);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox89);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox90);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox91);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox92);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyTextBox93);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyTextBox94);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox95);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox96);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox97);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox98);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyTextBox99);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyTextBox100);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox101);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox102);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox103);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox104);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyTextBox105);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyTextBox106);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox107);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox108);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox109);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox110);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyTextBox111);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyTextBox112);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox113);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox114);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox115);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox116);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyTextBox117);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyTextBox118);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox119);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox120);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox121);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox122);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyTextBox123);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyTextBox124);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox125);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox126);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox127);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox128);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyTextBox129);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyTextBox130);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox131);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox132);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox133);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox134);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyTextBox135);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyTextBox136);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox137);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox138);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox139);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox140);
this.splitContainerRowTitles.Panel2.AutoScroll = true;
this.splitContainerRowTitles.Size = new System.Drawing.Size(1091, 392);
this.splitContainerRowTitles.SplitterDistance = 332;
//
// spltMain
//
this.spltMain.Dock = System.Windows.Forms.DockStyle.Fill;
this.spltMain.Location = new System.Drawing.Point(0,0);
this.spltMain.Name = "spltMain";
this.spltMain.Orientation = System.Windows.Forms.Orientation.Horizontal;
this.spltMain.Panel1MinSize = 0;
//
// spltMain.Panel1
//
this.spltMain.Panel1.Controls.Add(this.splitContainerColTitles);
//
// spltMain.Panel2
//
this.spltMain.Panel2.Controls.Add(this.splitContainerRowTitles);
this.spltMain.Panel2.AutoScroll = true;
this.spltMain.Size = new System.Drawing.Size(1091, 472);
this.spltMain.SplitterDistance = 60;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F); 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font; 
this.Controls.Add(this.spltMain);
            this.Name = "S_26_02_01_01__sol2__2_0_1_ctrl"; 
            this.Size = new System.Drawing.Size(1091, 412); 
            this.Load += new System.EventHandler(this.BoundControl_Load);
            this.ResumeLayout(false); 
            this.PerformLayout(); 

      } 
private SolvencyLabel solvencyLabel0;
private SolvencyLabel solvencyLabel1;
private SolvencyLabel solvencyLabel2;
private SolvencyLabel solvencyLabel3;
private SolvencyLabel solvencyLabel4;
private SolvencyLabel solvencyLabel5;
private SolvencyLabel solvencyLabel6;
private SolvencyLabel solvencyLabel7;
private SolvencyLabel solvencyLabel8;
private SolvencyLabel solvencyLabel9;
private SolvencyLabel solvencyLabel10;
private SolvencyLabel solvencyLabel11;
private SolvencyLabel solvencyLabel12;
private SolvencyLabel solvencyLabel13;
private SolvencyLabel solvencyLabel14;
private SolvencyLabel solvencyLabel15;
private SolvencyLabel solvencyLabel16;
private SolvencyLabel solvencyLabel17;
private SolvencyLabel solvencyLabel18;
private SolvencyLabel solvencyLabel19;
private SolvencyLabel solvencyLabel20;
private SolvencyLabel solvencyLabel21;
private SolvencyLabel solvencyLabel22;
private SolvencyLabel solvencyLabel23;
private SolvencyLabel solvencyLabel24;
private SolvencyLabel solvencyLabel25;
private SolvencyLabel solvencyLabel26;
private SolvencyLabel solvencyLabel27;
private SolvencyLabel solvencyLabel28;
private SolvencyLabel solvencyLabel29;
private SolvencyLabel solvencyLabel30;
private SolvencyLabel solvencyLabel31;
private SolvencyLabel solvencyLabel32;
private SolvencyLabel solvencyLabel33;
private SolvencyLabel solvencyLabel34;
private SolvencyLabel solvencyLabel35;
private SolvencyLabel solvencyLabel36;
private SolvencyLabel solvencyLabel37;
private SolvencyLabel solvencyLabel38;
private SolvencyLabel solvencyLabel39;
private SolvencyLabel solvencyLabel40;
private SolvencyLabel solvencyLabel41;
private SolvencyLabel solvencyLabel42;
private SolvencyLabel solvencyLabel43;
private SolvencyLabel solvencyLabel44;
private SolvencyTextBox solvencyTextBox45;
private SolvencyTextBox solvencyTextBox46;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox47;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox48;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox49;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox50;
private SolvencyTextBox solvencyTextBox51;
private SolvencyTextBox solvencyTextBox52;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox53;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox54;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox55;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox56;
private SolvencyTextBox solvencyTextBox57;
private SolvencyTextBox solvencyTextBox58;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox59;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox60;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox61;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox62;
private SolvencyTextBox solvencyTextBox63;
private SolvencyTextBox solvencyTextBox64;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox65;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox66;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox67;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox68;
private SolvencyTextBox solvencyTextBox69;
private SolvencyTextBox solvencyTextBox70;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox71;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox72;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox73;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox74;
private SolvencyTextBox solvencyTextBox75;
private SolvencyTextBox solvencyTextBox76;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox77;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox78;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox79;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox80;
private SolvencyTextBox solvencyTextBox81;
private SolvencyTextBox solvencyTextBox82;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox83;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox84;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox85;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox86;
private SolvencyTextBox solvencyTextBox87;
private SolvencyTextBox solvencyTextBox88;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox89;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox90;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox91;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox92;
private SolvencyTextBox solvencyTextBox93;
private SolvencyTextBox solvencyTextBox94;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox95;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox96;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox97;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox98;
private SolvencyTextBox solvencyTextBox99;
private SolvencyTextBox solvencyTextBox100;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox101;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox102;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox103;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox104;
private SolvencyTextBox solvencyTextBox105;
private SolvencyTextBox solvencyTextBox106;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox107;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox108;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox109;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox110;
private SolvencyTextBox solvencyTextBox111;
private SolvencyTextBox solvencyTextBox112;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox113;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox114;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox115;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox116;
private SolvencyTextBox solvencyTextBox117;
private SolvencyTextBox solvencyTextBox118;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox119;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox120;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox121;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox122;
private SolvencyTextBox solvencyTextBox123;
private SolvencyTextBox solvencyTextBox124;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox125;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox126;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox127;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox128;
private SolvencyTextBox solvencyTextBox129;
private SolvencyTextBox solvencyTextBox130;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox131;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox132;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox133;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox134;
private SolvencyTextBox solvencyTextBox135;
private SolvencyTextBox solvencyTextBox136;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox137;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox138;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox139;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox140;
private SolvencySplitContainer splitContainerColTitles;
private SolvencySplitContainer splitContainerRowTitles;
private SolvencySplitContainer spltMain;

   }
}

