using SolvencyII.Domain.ENumerators; 
using SolvencyII.UI.Shared.Controls; 

namespace SolvencyII.UI.UserControls 
{ 
   partial class S_23_04_04_03__sol2__2_0_1_ctrl 
   { 
      private void InitializeComponent() 
      { 
this.solvencyLabel0 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel1 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel2 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel3 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel4 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel5 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel6 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel7 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel8 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel9 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel10 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel11 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel12 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel13 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel14 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel15 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel16 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel17 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel18 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel19 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel20 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel21 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel22 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel23 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel24 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel25 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel26 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel27 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel28 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel29 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel30 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel31 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel32 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel33 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel34 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel35 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel36 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel37 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel38 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel40 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyTextBox41 = new SolvencyII.UI.Shared.Controls.SolvencyTextBox();
this.solvencyTextBox42 = new SolvencyII.UI.Shared.Controls.SolvencyTextBox();
this.solvencyCurrencyTextBox43 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox44 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox45 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox46 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyTextBox47 = new SolvencyII.UI.Shared.Controls.SolvencyTextBox();
this.SolvencyDataComboBox48 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyTextBox49 = new SolvencyII.UI.Shared.Controls.SolvencyTextBox();
this.solvencyDateTimePicker50 = new SolvencyII.UI.Shared.Controls.SolvencyDateTimePicker();
this.solvencyDateTimePicker51 = new SolvencyII.UI.Shared.Controls.SolvencyDateTimePicker();
this.solvencyDateTimePicker52 = new SolvencyII.UI.Shared.Controls.SolvencyDateTimePicker();
this.solvencyTextBox53 = new SolvencyII.UI.Shared.Controls.SolvencyTextBox();
this.solvencyTextBox54 = new SolvencyII.UI.Shared.Controls.SolvencyTextBox();
this.solvencyDateTimePicker55 = new SolvencyII.UI.Shared.Controls.SolvencyDateTimePicker();
this.solvencyTextBox56 = new SolvencyII.UI.Shared.Controls.SolvencyTextBox();
this.solvencyTextBox57 = new SolvencyII.UI.Shared.Controls.SolvencyTextBox();
this.solvencyCurrencyTextBox58 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox59 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.splitContainerColTitles = new SolvencyII.UI.Shared.Controls.SolvencySplitContainer();
this.splitContainerRowTitles = new SolvencyII.UI.Shared.Controls.SolvencySplitContainer();
this.spltMain = new SolvencyII.UI.Shared.Controls.SolvencySplitContainer();
            this.SuspendLayout(); 

//
// solvencyLabel0
//
this.solvencyLabel0.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel0.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel0.Location = new System.Drawing.Point(2336,10);
this.solvencyLabel0.Name = "solvencyLabel0";
this.solvencyLabel0.OrdinateID_Label = 4760;
this.solvencyLabel0.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel0.TabIndex = 0;
this.solvencyLabel0.Text = "Contribution to group subordinated liabilities" ;
this.solvencyLabel0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel0.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel1
//
this.solvencyLabel1.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel1.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel1.Location = new System.Drawing.Point(2336,55);
this.solvencyLabel1.Name = "solvencyLabel1";
this.solvencyLabel1.OrdinateID_Label = 0;
this.solvencyLabel1.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel1.TabIndex = 1;
this.solvencyLabel1.Text = "C0440" ;
this.solvencyLabel1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel2
//
this.solvencyLabel2.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel2.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel2.Location = new System.Drawing.Point(2229,10);
this.solvencyLabel2.Name = "solvencyLabel2";
this.solvencyLabel2.OrdinateID_Label = 4759;
this.solvencyLabel2.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel2.TabIndex = 2;
this.solvencyLabel2.Text = "% of the issue held by entities in the group" ;
this.solvencyLabel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel3
//
this.solvencyLabel3.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel3.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel3.Location = new System.Drawing.Point(2229,55);
this.solvencyLabel3.Name = "solvencyLabel3";
this.solvencyLabel3.OrdinateID_Label = 0;
this.solvencyLabel3.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel3.TabIndex = 3;
this.solvencyLabel3.Text = "C0430" ;
this.solvencyLabel3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel4
//
this.solvencyLabel4.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel4.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel4.Location = new System.Drawing.Point(2122,10);
this.solvencyLabel4.Name = "solvencyLabel4";
this.solvencyLabel4.OrdinateID_Label = 4758;
this.solvencyLabel4.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel4.TabIndex = 4;
this.solvencyLabel4.Text = "Buy back during the year" ;
this.solvencyLabel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel5
//
this.solvencyLabel5.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel5.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel5.Location = new System.Drawing.Point(2122,55);
this.solvencyLabel5.Name = "solvencyLabel5";
this.solvencyLabel5.OrdinateID_Label = 0;
this.solvencyLabel5.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel5.TabIndex = 5;
this.solvencyLabel5.Text = "C0420" ;
this.solvencyLabel5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel6
//
this.solvencyLabel6.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel6.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel6.Location = new System.Drawing.Point(2015,10);
this.solvencyLabel6.Name = "solvencyLabel6";
this.solvencyLabel6.OrdinateID_Label = 4757;
this.solvencyLabel6.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel6.TabIndex = 6;
this.solvencyLabel6.Text = "Name of supervisory authority having given authorisation" ;
this.solvencyLabel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel6.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel7
//
this.solvencyLabel7.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel7.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel7.Location = new System.Drawing.Point(2015,55);
this.solvencyLabel7.Name = "solvencyLabel7";
this.solvencyLabel7.OrdinateID_Label = 0;
this.solvencyLabel7.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel7.TabIndex = 7;
this.solvencyLabel7.Text = "C0410" ;
this.solvencyLabel7.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel8
//
this.solvencyLabel8.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel8.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel8.Location = new System.Drawing.Point(1908,10);
this.solvencyLabel8.Name = "solvencyLabel8";
this.solvencyLabel8.OrdinateID_Label = 4756;
this.solvencyLabel8.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel8.TabIndex = 8;
this.solvencyLabel8.Text = "Notice period" ;
this.solvencyLabel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel8.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel9
//
this.solvencyLabel9.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel9.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel9.Location = new System.Drawing.Point(1908,55);
this.solvencyLabel9.Name = "solvencyLabel9";
this.solvencyLabel9.OrdinateID_Label = 0;
this.solvencyLabel9.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel9.TabIndex = 9;
this.solvencyLabel9.Text = "C0400" ;
this.solvencyLabel9.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel10
//
this.solvencyLabel10.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel10.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel10.Location = new System.Drawing.Point(1801,10);
this.solvencyLabel10.Name = "solvencyLabel10";
this.solvencyLabel10.OrdinateID_Label = 4755;
this.solvencyLabel10.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel10.TabIndex = 10;
this.solvencyLabel10.Text = "Details of incentives to redeem" ;
this.solvencyLabel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel10.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel11
//
this.solvencyLabel11.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel11.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel11.Location = new System.Drawing.Point(1801,55);
this.solvencyLabel11.Name = "solvencyLabel11";
this.solvencyLabel11.OrdinateID_Label = 0;
this.solvencyLabel11.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel11.TabIndex = 11;
this.solvencyLabel11.Text = "C0390" ;
this.solvencyLabel11.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel12
//
this.solvencyLabel12.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel12.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel12.Location = new System.Drawing.Point(1694,10);
this.solvencyLabel12.Name = "solvencyLabel12";
this.solvencyLabel12.OrdinateID_Label = 4754;
this.solvencyLabel12.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel12.TabIndex = 12;
this.solvencyLabel12.Text = "Further call dates" ;
this.solvencyLabel12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel12.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel13
//
this.solvencyLabel13.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel13.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel13.Location = new System.Drawing.Point(1694,55);
this.solvencyLabel13.Name = "solvencyLabel13";
this.solvencyLabel13.OrdinateID_Label = 0;
this.solvencyLabel13.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel13.TabIndex = 13;
this.solvencyLabel13.Text = "C0380" ;
this.solvencyLabel13.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel14
//
this.solvencyLabel14.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel14.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel14.Location = new System.Drawing.Point(1587,10);
this.solvencyLabel14.Name = "solvencyLabel14";
this.solvencyLabel14.OrdinateID_Label = 4753;
this.solvencyLabel14.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel14.TabIndex = 14;
this.solvencyLabel14.Text = "First call date" ;
this.solvencyLabel14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel14.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel15
//
this.solvencyLabel15.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel15.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel15.Location = new System.Drawing.Point(1587,55);
this.solvencyLabel15.Name = "solvencyLabel15";
this.solvencyLabel15.OrdinateID_Label = 0;
this.solvencyLabel15.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel15.TabIndex = 15;
this.solvencyLabel15.Text = "C0370" ;
this.solvencyLabel15.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel16
//
this.solvencyLabel16.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel16.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel16.Location = new System.Drawing.Point(1480,10);
this.solvencyLabel16.Name = "solvencyLabel16";
this.solvencyLabel16.OrdinateID_Label = 4752;
this.solvencyLabel16.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel16.TabIndex = 16;
this.solvencyLabel16.Text = "Maturity date" ;
this.solvencyLabel16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel16.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel17
//
this.solvencyLabel17.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel17.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel17.Location = new System.Drawing.Point(1480,55);
this.solvencyLabel17.Name = "solvencyLabel17";
this.solvencyLabel17.OrdinateID_Label = 0;
this.solvencyLabel17.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel17.TabIndex = 17;
this.solvencyLabel17.Text = "C0360" ;
this.solvencyLabel17.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel18
//
this.solvencyLabel18.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel18.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel18.Location = new System.Drawing.Point(1373,10);
this.solvencyLabel18.Name = "solvencyLabel18";
this.solvencyLabel18.OrdinateID_Label = 4751;
this.solvencyLabel18.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel18.TabIndex = 18;
this.solvencyLabel18.Text = "Issue date" ;
this.solvencyLabel18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel18.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel19
//
this.solvencyLabel19.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel19.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel19.Location = new System.Drawing.Point(1373,55);
this.solvencyLabel19.Name = "solvencyLabel19";
this.solvencyLabel19.OrdinateID_Label = 0;
this.solvencyLabel19.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel19.TabIndex = 19;
this.solvencyLabel19.Text = "C0350" ;
this.solvencyLabel19.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel20
//
this.solvencyLabel20.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel20.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel20.Location = new System.Drawing.Point(1266,10);
this.solvencyLabel20.Name = "solvencyLabel20";
this.solvencyLabel20.OrdinateID_Label = 4750;
this.solvencyLabel20.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel20.TabIndex = 20;
this.solvencyLabel20.Text = "Counterparty (if specific)" ;
this.solvencyLabel20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel20.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel21
//
this.solvencyLabel21.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel21.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel21.Location = new System.Drawing.Point(1266,55);
this.solvencyLabel21.Name = "solvencyLabel21";
this.solvencyLabel21.OrdinateID_Label = 0;
this.solvencyLabel21.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel21.TabIndex = 21;
this.solvencyLabel21.Text = "C0340" ;
this.solvencyLabel21.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel22
//
this.solvencyLabel22.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel22.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel22.Location = new System.Drawing.Point(1059,10);
this.solvencyLabel22.Name = "solvencyLabel22";
this.solvencyLabel22.OrdinateID_Label = 4749;
this.solvencyLabel22.Size = new System.Drawing.Size(208, 45);
this.solvencyLabel22.TabIndex = 22;
this.solvencyLabel22.Text = "Counted under transitionals?" ;
this.solvencyLabel22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel22.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel23
//
this.solvencyLabel23.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel23.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel23.Location = new System.Drawing.Point(1059,55);
this.solvencyLabel23.Name = "solvencyLabel23";
this.solvencyLabel23.OrdinateID_Label = 0;
this.solvencyLabel23.Size = new System.Drawing.Size(208, 13);
this.solvencyLabel23.TabIndex = 23;
this.solvencyLabel23.Text = "C0330" ;
this.solvencyLabel23.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel24
//
this.solvencyLabel24.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel24.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel24.Location = new System.Drawing.Point(952,10);
this.solvencyLabel24.Name = "solvencyLabel24";
this.solvencyLabel24.OrdinateID_Label = 4748;
this.solvencyLabel24.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel24.TabIndex = 24;
this.solvencyLabel24.Text = "Lender (if specific)" ;
this.solvencyLabel24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel24.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel25
//
this.solvencyLabel25.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel25.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel25.Location = new System.Drawing.Point(952,55);
this.solvencyLabel25.Name = "solvencyLabel25";
this.solvencyLabel25.OrdinateID_Label = 0;
this.solvencyLabel25.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel25.TabIndex = 25;
this.solvencyLabel25.Text = "C0320" ;
this.solvencyLabel25.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel26
//
this.solvencyLabel26.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel26.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel26.Location = new System.Drawing.Point(745,10);
this.solvencyLabel26.Name = "solvencyLabel26";
this.solvencyLabel26.OrdinateID_Label = 4747;
this.solvencyLabel26.Size = new System.Drawing.Size(208, 45);
this.solvencyLabel26.TabIndex = 26;
this.solvencyLabel26.Text = "Issuing entity" ;
this.solvencyLabel26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel26.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel27
//
this.solvencyLabel27.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel27.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel27.Location = new System.Drawing.Point(745,55);
this.solvencyLabel27.Name = "solvencyLabel27";
this.solvencyLabel27.OrdinateID_Label = 0;
this.solvencyLabel27.Size = new System.Drawing.Size(208, 13);
this.solvencyLabel27.TabIndex = 27;
this.solvencyLabel27.Text = "C0310" ;
this.solvencyLabel27.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel28
//
this.solvencyLabel28.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel28.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel28.Location = new System.Drawing.Point(538,10);
this.solvencyLabel28.Name = "solvencyLabel28";
this.solvencyLabel28.OrdinateID_Label = 4746;
this.solvencyLabel28.Size = new System.Drawing.Size(208, 45);
this.solvencyLabel28.TabIndex = 28;
this.solvencyLabel28.Text = "Currency Code" ;
this.solvencyLabel28.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel28.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel29
//
this.solvencyLabel29.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel29.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel29.Location = new System.Drawing.Point(538,55);
this.solvencyLabel29.Name = "solvencyLabel29";
this.solvencyLabel29.OrdinateID_Label = 0;
this.solvencyLabel29.Size = new System.Drawing.Size(208, 13);
this.solvencyLabel29.TabIndex = 29;
this.solvencyLabel29.Text = "C0300" ;
this.solvencyLabel29.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel30
//
this.solvencyLabel30.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel30.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel30.Location = new System.Drawing.Point(331,10);
this.solvencyLabel30.Name = "solvencyLabel30";
this.solvencyLabel30.OrdinateID_Label = 4745;
this.solvencyLabel30.Size = new System.Drawing.Size(208, 45);
this.solvencyLabel30.TabIndex = 30;
this.solvencyLabel30.Text = "Tier" ;
this.solvencyLabel30.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel30.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel31
//
this.solvencyLabel31.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel31.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel31.Location = new System.Drawing.Point(331,55);
this.solvencyLabel31.Name = "solvencyLabel31";
this.solvencyLabel31.OrdinateID_Label = 0;
this.solvencyLabel31.Size = new System.Drawing.Size(208, 13);
this.solvencyLabel31.TabIndex = 31;
this.solvencyLabel31.Text = "C0290" ;
this.solvencyLabel31.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel32
//
this.solvencyLabel32.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel32.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel32.Location = new System.Drawing.Point(224,10);
this.solvencyLabel32.Name = "solvencyLabel32";
this.solvencyLabel32.OrdinateID_Label = 4744;
this.solvencyLabel32.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel32.TabIndex = 32;
this.solvencyLabel32.Text = "Amount" ;
this.solvencyLabel32.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel32.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel33
//
this.solvencyLabel33.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel33.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel33.Location = new System.Drawing.Point(224,55);
this.solvencyLabel33.Name = "solvencyLabel33";
this.solvencyLabel33.OrdinateID_Label = 0;
this.solvencyLabel33.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel33.TabIndex = 33;
this.solvencyLabel33.Text = "C0280" ;
this.solvencyLabel33.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel34
//
this.solvencyLabel34.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel34.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel34.Location = new System.Drawing.Point(117,10);
this.solvencyLabel34.Name = "solvencyLabel34";
this.solvencyLabel34.OrdinateID_Label = 4743;
this.solvencyLabel34.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel34.TabIndex = 34;
this.solvencyLabel34.Text = "Description of subordinated liabilities" ;
this.solvencyLabel34.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel34.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel35
//
this.solvencyLabel35.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel35.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel35.Location = new System.Drawing.Point(117,55);
this.solvencyLabel35.Name = "solvencyLabel35";
this.solvencyLabel35.OrdinateID_Label = 0;
this.solvencyLabel35.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel35.TabIndex = 35;
this.solvencyLabel35.Text = "C0270" ;
this.solvencyLabel35.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel36
//
this.solvencyLabel36.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel36.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel36.Location = new System.Drawing.Point(10,10);
this.solvencyLabel36.Name = "solvencyLabel36";
this.solvencyLabel36.OrdinateID_Label = 4761;
this.solvencyLabel36.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel36.TabIndex = 36;
this.solvencyLabel36.Text = "Code of subordinated liability" ;
this.solvencyLabel36.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel36.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel37
//
this.solvencyLabel37.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel37.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel37.Location = new System.Drawing.Point(10,55);
this.solvencyLabel37.Name = "solvencyLabel37";
this.solvencyLabel37.OrdinateID_Label = 0;
this.solvencyLabel37.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel37.TabIndex = 37;
this.solvencyLabel37.Text = "C0265" ;
this.solvencyLabel37.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel38
//
this.solvencyLabel38.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel38.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel38.Location = new System.Drawing.Point(3,3);
this.solvencyLabel38.Name = "solvencyLabel38";
this.solvencyLabel38.OrdinateID_Label = 0;
this.solvencyLabel38.Size = new System.Drawing.Size(21, 0);
this.solvencyLabel38.TabIndex = 38;
this.solvencyLabel38.Text = "" ;
this.solvencyLabel38.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel40
//
this.solvencyLabel40.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel40.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel40.Location = new System.Drawing.Point(38,23);
this.solvencyLabel40.Name = "solvencyLabel40";
this.solvencyLabel40.OrdinateID_Label = 0;
this.solvencyLabel40.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel40.TabIndex = 40;
this.solvencyLabel40.Text = "." ;
this.solvencyLabel40.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyTextBox41
//
this.solvencyTextBox41.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyTextBox41.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyTextBox41.Location = new System.Drawing.Point(10,3);
this.solvencyTextBox41.Name = "solvencyTextBox41";
this.solvencyTextBox41.Size = new System.Drawing.Size(100, 13);
this.solvencyTextBox41.TabIndex = 41;
this.solvencyTextBox41.ColName = "C0265";
this.solvencyTextBox41.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
//
// solvencyTextBox42
//
this.solvencyTextBox42.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyTextBox42.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyTextBox42.Location = new System.Drawing.Point(117,3);
this.solvencyTextBox42.Name = "solvencyTextBox42";
this.solvencyTextBox42.Size = new System.Drawing.Size(100, 13);
this.solvencyTextBox42.TabIndex = 42;
this.solvencyTextBox42.ColName = "C0270";
this.solvencyTextBox42.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
//
// solvencyCurrencyTextBox43
//
this.solvencyCurrencyTextBox43.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox43.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox43.Location = new System.Drawing.Point(224,3);
this.solvencyCurrencyTextBox43.Name = "solvencyCurrencyTextBox43";
this.solvencyCurrencyTextBox43.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox43.TabIndex = 43;
this.solvencyCurrencyTextBox43.ColName = "C0280";
this.solvencyCurrencyTextBox43.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// SolvencyDataComboBox44
//
this.SolvencyDataComboBox44.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox44.Location = new System.Drawing.Point(331,3);
this.SolvencyDataComboBox44.Name = "SolvencyDataComboBox44";
this.SolvencyDataComboBox44.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox44.TabIndex = 44;
this.SolvencyDataComboBox44.ColName = "C0290";
this.SolvencyDataComboBox44.AxisID = 709;
this.SolvencyDataComboBox44.OrdinateID = 4745;
this.SolvencyDataComboBox44.StartOrder = 0;
this.SolvencyDataComboBox44.NextOrder = 0;
//
// SolvencyDataComboBox45
//
this.SolvencyDataComboBox45.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox45.Location = new System.Drawing.Point(538,3);
this.SolvencyDataComboBox45.Name = "SolvencyDataComboBox45";
this.SolvencyDataComboBox45.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox45.TabIndex = 45;
this.SolvencyDataComboBox45.ColName = "C0300";
this.SolvencyDataComboBox45.AxisID = 709;
this.SolvencyDataComboBox45.OrdinateID = 4746;
this.SolvencyDataComboBox45.StartOrder = 0;
this.SolvencyDataComboBox45.NextOrder = 0;
//
// SolvencyDataComboBox46
//
this.SolvencyDataComboBox46.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox46.Location = new System.Drawing.Point(745,3);
this.SolvencyDataComboBox46.Name = "SolvencyDataComboBox46";
this.SolvencyDataComboBox46.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox46.TabIndex = 46;
this.SolvencyDataComboBox46.ColName = "C0310";
this.SolvencyDataComboBox46.AxisID = 709;
this.SolvencyDataComboBox46.OrdinateID = 4747;
this.SolvencyDataComboBox46.StartOrder = 0;
this.SolvencyDataComboBox46.NextOrder = 0;
//
// solvencyTextBox47
//
this.solvencyTextBox47.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyTextBox47.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyTextBox47.Location = new System.Drawing.Point(952,3);
this.solvencyTextBox47.Name = "solvencyTextBox47";
this.solvencyTextBox47.Size = new System.Drawing.Size(100, 13);
this.solvencyTextBox47.TabIndex = 47;
this.solvencyTextBox47.ColName = "C0320";
this.solvencyTextBox47.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
//
// SolvencyDataComboBox48
//
this.SolvencyDataComboBox48.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox48.Location = new System.Drawing.Point(1059,3);
this.SolvencyDataComboBox48.Name = "SolvencyDataComboBox48";
this.SolvencyDataComboBox48.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox48.TabIndex = 48;
this.SolvencyDataComboBox48.ColName = "C0330";
this.SolvencyDataComboBox48.AxisID = 709;
this.SolvencyDataComboBox48.OrdinateID = 4749;
this.SolvencyDataComboBox48.StartOrder = 0;
this.SolvencyDataComboBox48.NextOrder = 0;
//
// solvencyTextBox49
//
this.solvencyTextBox49.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyTextBox49.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyTextBox49.Location = new System.Drawing.Point(1266,3);
this.solvencyTextBox49.Name = "solvencyTextBox49";
this.solvencyTextBox49.Size = new System.Drawing.Size(100, 13);
this.solvencyTextBox49.TabIndex = 49;
this.solvencyTextBox49.ColName = "C0340";
this.solvencyTextBox49.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
//
// solvencyDateTimePicker50
//
this.solvencyDateTimePicker50.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Date;
this.solvencyDateTimePicker50.Location = new System.Drawing.Point(1373,1);
this.solvencyDateTimePicker50.Name = "solvencyDateTimePicker50";
this.solvencyDateTimePicker50.Size = new System.Drawing.Size(100, 13);
this.solvencyDateTimePicker50.TabIndex = 50;
this.solvencyDateTimePicker50.ColName = "C0350";
//
// solvencyDateTimePicker51
//
this.solvencyDateTimePicker51.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Date;
this.solvencyDateTimePicker51.Location = new System.Drawing.Point(1480,1);
this.solvencyDateTimePicker51.Name = "solvencyDateTimePicker51";
this.solvencyDateTimePicker51.Size = new System.Drawing.Size(100, 13);
this.solvencyDateTimePicker51.TabIndex = 51;
this.solvencyDateTimePicker51.ColName = "C0360";
//
// solvencyDateTimePicker52
//
this.solvencyDateTimePicker52.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Date;
this.solvencyDateTimePicker52.Location = new System.Drawing.Point(1587,1);
this.solvencyDateTimePicker52.Name = "solvencyDateTimePicker52";
this.solvencyDateTimePicker52.Size = new System.Drawing.Size(100, 13);
this.solvencyDateTimePicker52.TabIndex = 52;
this.solvencyDateTimePicker52.ColName = "C0370";
//
// solvencyTextBox53
//
this.solvencyTextBox53.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyTextBox53.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyTextBox53.Location = new System.Drawing.Point(1694,3);
this.solvencyTextBox53.Name = "solvencyTextBox53";
this.solvencyTextBox53.Size = new System.Drawing.Size(100, 13);
this.solvencyTextBox53.TabIndex = 53;
this.solvencyTextBox53.ColName = "C0380";
this.solvencyTextBox53.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
//
// solvencyTextBox54
//
this.solvencyTextBox54.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyTextBox54.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyTextBox54.Location = new System.Drawing.Point(1801,3);
this.solvencyTextBox54.Name = "solvencyTextBox54";
this.solvencyTextBox54.Size = new System.Drawing.Size(100, 13);
this.solvencyTextBox54.TabIndex = 54;
this.solvencyTextBox54.ColName = "C0390";
this.solvencyTextBox54.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
//
// solvencyDateTimePicker55
//
this.solvencyDateTimePicker55.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Date;
this.solvencyDateTimePicker55.Location = new System.Drawing.Point(1908,1);
this.solvencyDateTimePicker55.Name = "solvencyDateTimePicker55";
this.solvencyDateTimePicker55.Size = new System.Drawing.Size(100, 13);
this.solvencyDateTimePicker55.TabIndex = 55;
this.solvencyDateTimePicker55.ColName = "C0400";
//
// solvencyTextBox56
//
this.solvencyTextBox56.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyTextBox56.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyTextBox56.Location = new System.Drawing.Point(2015,3);
this.solvencyTextBox56.Name = "solvencyTextBox56";
this.solvencyTextBox56.Size = new System.Drawing.Size(100, 13);
this.solvencyTextBox56.TabIndex = 56;
this.solvencyTextBox56.ColName = "C0410";
this.solvencyTextBox56.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
//
// solvencyTextBox57
//
this.solvencyTextBox57.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyTextBox57.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyTextBox57.Location = new System.Drawing.Point(2122,3);
this.solvencyTextBox57.Name = "solvencyTextBox57";
this.solvencyTextBox57.Size = new System.Drawing.Size(100, 13);
this.solvencyTextBox57.TabIndex = 57;
this.solvencyTextBox57.ColName = "C0420";
this.solvencyTextBox57.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
//
// solvencyCurrencyTextBox58
//
this.solvencyCurrencyTextBox58.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox58.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox58.Location = new System.Drawing.Point(2229,3);
this.solvencyCurrencyTextBox58.Name = "solvencyCurrencyTextBox58";
this.solvencyCurrencyTextBox58.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox58.TabIndex = 58;
this.solvencyCurrencyTextBox58.ColName = "C0430";
this.solvencyCurrencyTextBox58.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox59
//
this.solvencyCurrencyTextBox59.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox59.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox59.Location = new System.Drawing.Point(2336,3);
this.solvencyCurrencyTextBox59.Name = "solvencyCurrencyTextBox59";
this.solvencyCurrencyTextBox59.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox59.TabIndex = 59;
this.solvencyCurrencyTextBox59.ColName = "C0440";
this.solvencyCurrencyTextBox59.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// splitContainerColTitles
//
this.splitContainerColTitles.Dock = System.Windows.Forms.DockStyle.Fill;
this.splitContainerColTitles.Location = new System.Drawing.Point(0,0);
this.splitContainerColTitles.Name = "splitContainerColTitles";
this.splitContainerColTitles.Orientation = System.Windows.Forms.Orientation.Vertical;
this.splitContainerColTitles.Panel1MinSize = 0;
//
// splitContainerColTitles.Panel1
//
//
// splitContainerColTitles.Panel2
//
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel0);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel1);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel2);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel3);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel4);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel5);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel6);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel7);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel8);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel9);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel10);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel11);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel12);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel13);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel14);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel15);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel16);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel17);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel18);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel19);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel20);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel21);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel22);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel23);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel24);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel25);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel26);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel27);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel28);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel29);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel30);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel31);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel32);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel33);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel34);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel35);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel36);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel37);
this.splitContainerColTitles.Size = new System.Drawing.Size(2635, 160);
this.splitContainerColTitles.SplitterDistance = 85;
//
// splitContainerRowTitles
//
this.splitContainerRowTitles.Dock = System.Windows.Forms.DockStyle.Fill;
this.splitContainerRowTitles.Location = new System.Drawing.Point(0,0);
this.splitContainerRowTitles.Name = "splitContainerRowTitles";
this.splitContainerRowTitles.Orientation = System.Windows.Forms.Orientation.Vertical;
this.splitContainerRowTitles.Panel1MinSize = 0;
//
// splitContainerRowTitles.Panel1
//
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel38);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel40);
//
// splitContainerRowTitles.Panel2
//
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyTextBox41);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyTextBox42);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox43);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox44);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox45);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox46);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyTextBox47);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox48);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyTextBox49);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyDateTimePicker50);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyDateTimePicker51);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyDateTimePicker52);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyTextBox53);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyTextBox54);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyDateTimePicker55);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyTextBox56);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyTextBox57);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox58);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox59);
this.splitContainerRowTitles.Panel2.AutoScroll = true;
this.splitContainerRowTitles.Size = new System.Drawing.Size(2635, 160);
this.splitContainerRowTitles.SplitterDistance = 85;
//
// spltMain
//
this.spltMain.Dock = System.Windows.Forms.DockStyle.Fill;
this.spltMain.Location = new System.Drawing.Point(0,0);
this.spltMain.Name = "spltMain";
this.spltMain.Orientation = System.Windows.Forms.Orientation.Horizontal;
this.spltMain.Panel1MinSize = 0;
//
// spltMain.Panel1
//
this.spltMain.Panel1.Controls.Add(this.splitContainerColTitles);
//
// spltMain.Panel2
//
this.spltMain.Panel2.Controls.Add(this.splitContainerRowTitles);
this.spltMain.Panel2.AutoScroll = true;
this.spltMain.Size = new System.Drawing.Size(2635, 176);
this.spltMain.SplitterDistance = 75;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F); 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font; 
this.Controls.Add(this.spltMain);
            this.Name = "S_23_04_04_03__sol2__2_0_1_ctrl"; 
            this.Size = new System.Drawing.Size(2635, 101); 
            this.Load += new System.EventHandler(this.BoundControl_Load);
            this.ResumeLayout(false); 
            this.PerformLayout(); 

      } 
private SolvencyLabel solvencyLabel0;
private SolvencyLabel solvencyLabel1;
private SolvencyLabel solvencyLabel2;
private SolvencyLabel solvencyLabel3;
private SolvencyLabel solvencyLabel4;
private SolvencyLabel solvencyLabel5;
private SolvencyLabel solvencyLabel6;
private SolvencyLabel solvencyLabel7;
private SolvencyLabel solvencyLabel8;
private SolvencyLabel solvencyLabel9;
private SolvencyLabel solvencyLabel10;
private SolvencyLabel solvencyLabel11;
private SolvencyLabel solvencyLabel12;
private SolvencyLabel solvencyLabel13;
private SolvencyLabel solvencyLabel14;
private SolvencyLabel solvencyLabel15;
private SolvencyLabel solvencyLabel16;
private SolvencyLabel solvencyLabel17;
private SolvencyLabel solvencyLabel18;
private SolvencyLabel solvencyLabel19;
private SolvencyLabel solvencyLabel20;
private SolvencyLabel solvencyLabel21;
private SolvencyLabel solvencyLabel22;
private SolvencyLabel solvencyLabel23;
private SolvencyLabel solvencyLabel24;
private SolvencyLabel solvencyLabel25;
private SolvencyLabel solvencyLabel26;
private SolvencyLabel solvencyLabel27;
private SolvencyLabel solvencyLabel28;
private SolvencyLabel solvencyLabel29;
private SolvencyLabel solvencyLabel30;
private SolvencyLabel solvencyLabel31;
private SolvencyLabel solvencyLabel32;
private SolvencyLabel solvencyLabel33;
private SolvencyLabel solvencyLabel34;
private SolvencyLabel solvencyLabel35;
private SolvencyLabel solvencyLabel36;
private SolvencyLabel solvencyLabel37;
private SolvencyLabel solvencyLabel38;
private SolvencyLabel solvencyLabel40;
private SolvencyTextBox solvencyTextBox41;
private SolvencyTextBox solvencyTextBox42;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox43;
private SolvencyDataComboBox SolvencyDataComboBox44;
private SolvencyDataComboBox SolvencyDataComboBox45;
private SolvencyDataComboBox SolvencyDataComboBox46;
private SolvencyTextBox solvencyTextBox47;
private SolvencyDataComboBox SolvencyDataComboBox48;
private SolvencyTextBox solvencyTextBox49;
private SolvencyDateTimePicker solvencyDateTimePicker50;
private SolvencyDateTimePicker solvencyDateTimePicker51;
private SolvencyDateTimePicker solvencyDateTimePicker52;
private SolvencyTextBox solvencyTextBox53;
private SolvencyTextBox solvencyTextBox54;
private SolvencyDateTimePicker solvencyDateTimePicker55;
private SolvencyTextBox solvencyTextBox56;
private SolvencyTextBox solvencyTextBox57;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox58;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox59;
private SolvencySplitContainer splitContainerColTitles;
private SolvencySplitContainer splitContainerRowTitles;
private SolvencySplitContainer spltMain;

   }
}

