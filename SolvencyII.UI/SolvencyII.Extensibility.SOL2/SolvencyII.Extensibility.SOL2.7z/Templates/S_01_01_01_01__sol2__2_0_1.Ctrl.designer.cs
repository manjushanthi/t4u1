using SolvencyII.Domain.ENumerators; 
using SolvencyII.UI.Shared.Controls; 

namespace SolvencyII.UI.UserControls 
{ 
   partial class S_01_01_01_01__sol2__2_0_1_ctrl 
   { 
      private void InitializeComponent() 
      { 
this.solvencyLabel1 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel2 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel3 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel4 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel5 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel6 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel7 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel8 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel9 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel10 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel11 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel12 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel13 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel14 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel15 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel16 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel17 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel18 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel19 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel20 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel21 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel22 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel23 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel24 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel25 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel26 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel27 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel28 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel29 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel30 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel31 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel32 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel33 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel34 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel35 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel36 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel37 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel38 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel39 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel40 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel41 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel42 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel43 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel44 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel45 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel46 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel47 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel48 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel49 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel50 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel51 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel52 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel53 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel54 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel55 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel56 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel57 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel58 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel59 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel60 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel61 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel62 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel63 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel64 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel65 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel66 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel67 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel68 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel69 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel70 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel71 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel72 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel73 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel74 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel75 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel76 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel77 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel78 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel79 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel80 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel81 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel82 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel83 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel84 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel85 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel86 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel87 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel88 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel89 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel90 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel91 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel92 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel93 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel94 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel95 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel96 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel97 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel98 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel99 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel100 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel101 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel102 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel103 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel104 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel105 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel106 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel107 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel108 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel109 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel110 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel111 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel112 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel113 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel114 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel115 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel116 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel117 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel118 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel119 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel120 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel121 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel122 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel123 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel124 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel125 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel126 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel127 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel128 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel129 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel130 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel131 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel132 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel133 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel134 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel135 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel136 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel137 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel138 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel139 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel140 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel141 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel142 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel143 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel144 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel145 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel146 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.SolvencyDataComboBox147 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox148 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox149 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox150 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox151 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox152 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox153 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox154 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox155 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox156 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox157 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox158 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox159 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox160 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox161 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox162 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox163 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox164 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox165 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox166 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox167 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox168 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox169 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox170 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox171 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox172 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox173 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox174 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox175 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox176 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox177 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox178 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox179 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox180 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox181 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox182 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox183 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox184 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox185 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox186 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox187 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox188 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox189 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox190 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox191 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox192 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox193 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox194 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox195 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox196 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox197 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox198 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox199 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox200 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox201 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox202 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox203 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox204 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox205 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox206 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox207 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox208 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox209 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox210 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox211 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox212 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox213 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox214 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox215 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox216 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox217 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.splitContainerColTitles = new SolvencyII.UI.Shared.Controls.SolvencySplitContainer();
this.splitContainerRowTitles = new SolvencyII.UI.Shared.Controls.SolvencySplitContainer();
this.spltMain = new SolvencyII.UI.Shared.Controls.SolvencySplitContainer();
            this.SuspendLayout(); 

//
// solvencyLabel1
//
this.solvencyLabel1.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel1.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel1.Location = new System.Drawing.Point(10,30);
this.solvencyLabel1.Name = "solvencyLabel1";
this.solvencyLabel1.OrdinateID_Label = 0;
this.solvencyLabel1.Size = new System.Drawing.Size(208, 13);
this.solvencyLabel1.TabIndex = 1;
this.solvencyLabel1.Text = "C0010" ;
this.solvencyLabel1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel2
//
this.solvencyLabel2.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel2.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel2.Location = new System.Drawing.Point(10,3);
this.solvencyLabel2.Name = "solvencyLabel2";
this.solvencyLabel2.OrdinateID_Label = 2;
this.solvencyLabel2.Size = new System.Drawing.Size(261, 15);
this.solvencyLabel2.TabIndex = 2;
this.solvencyLabel2.Text = "Template Code - Template name" ;
this.solvencyLabel2.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel3
//
this.solvencyLabel3.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel3.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel3.Location = new System.Drawing.Point(285,3);
this.solvencyLabel3.Name = "solvencyLabel3";
this.solvencyLabel3.OrdinateID_Label = 0;
this.solvencyLabel3.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel3.TabIndex = 3;
this.solvencyLabel3.Text = "" ;
this.solvencyLabel3.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel4
//
this.solvencyLabel4.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel4.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel4.Location = new System.Drawing.Point(17,23);
this.solvencyLabel4.Name = "solvencyLabel4";
this.solvencyLabel4.OrdinateID_Label = 3;
this.solvencyLabel4.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel4.TabIndex = 4;
this.solvencyLabel4.Text = "S.01.02.01 - Basic Information - General" ;
this.solvencyLabel4.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel5
//
this.solvencyLabel5.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel5.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel5.Location = new System.Drawing.Point(285,23);
this.solvencyLabel5.Name = "solvencyLabel5";
this.solvencyLabel5.OrdinateID_Label = 0;
this.solvencyLabel5.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel5.TabIndex = 5;
this.solvencyLabel5.Text = "R0010" ;
this.solvencyLabel5.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel6
//
this.solvencyLabel6.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel6.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel6.Location = new System.Drawing.Point(17,43);
this.solvencyLabel6.Name = "solvencyLabel6";
this.solvencyLabel6.OrdinateID_Label = 4;
this.solvencyLabel6.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel6.TabIndex = 6;
this.solvencyLabel6.Text = "S.01.03.01 - Basic Information - RFF and matching adjustment portfolios" ;
this.solvencyLabel6.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel7
//
this.solvencyLabel7.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel7.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel7.Location = new System.Drawing.Point(285,43);
this.solvencyLabel7.Name = "solvencyLabel7";
this.solvencyLabel7.OrdinateID_Label = 0;
this.solvencyLabel7.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel7.TabIndex = 7;
this.solvencyLabel7.Text = "R0020" ;
this.solvencyLabel7.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel8
//
this.solvencyLabel8.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel8.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel8.Location = new System.Drawing.Point(17,76);
this.solvencyLabel8.Name = "solvencyLabel8";
this.solvencyLabel8.OrdinateID_Label = 5;
this.solvencyLabel8.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel8.TabIndex = 8;
this.solvencyLabel8.Text = "S.02.01.01 - Balance sheet" ;
this.solvencyLabel8.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel9
//
this.solvencyLabel9.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel9.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel9.Location = new System.Drawing.Point(285,76);
this.solvencyLabel9.Name = "solvencyLabel9";
this.solvencyLabel9.OrdinateID_Label = 0;
this.solvencyLabel9.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel9.TabIndex = 9;
this.solvencyLabel9.Text = "R0030" ;
this.solvencyLabel9.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel10
//
this.solvencyLabel10.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel10.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel10.Location = new System.Drawing.Point(17,96);
this.solvencyLabel10.Name = "solvencyLabel10";
this.solvencyLabel10.OrdinateID_Label = 6;
this.solvencyLabel10.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel10.TabIndex = 10;
this.solvencyLabel10.Text = "S.02.02.01 - Assets and liabilities by currency" ;
this.solvencyLabel10.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel11
//
this.solvencyLabel11.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel11.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel11.Location = new System.Drawing.Point(285,96);
this.solvencyLabel11.Name = "solvencyLabel11";
this.solvencyLabel11.OrdinateID_Label = 0;
this.solvencyLabel11.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel11.TabIndex = 11;
this.solvencyLabel11.Text = "R0040" ;
this.solvencyLabel11.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel12
//
this.solvencyLabel12.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel12.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel12.Location = new System.Drawing.Point(17,116);
this.solvencyLabel12.Name = "solvencyLabel12";
this.solvencyLabel12.OrdinateID_Label = 7;
this.solvencyLabel12.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel12.TabIndex = 12;
this.solvencyLabel12.Text = "S.03.01.01 - Off-balance sheet items - general" ;
this.solvencyLabel12.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel13
//
this.solvencyLabel13.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel13.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel13.Location = new System.Drawing.Point(285,116);
this.solvencyLabel13.Name = "solvencyLabel13";
this.solvencyLabel13.OrdinateID_Label = 0;
this.solvencyLabel13.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel13.TabIndex = 13;
this.solvencyLabel13.Text = "R0060" ;
this.solvencyLabel13.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel14
//
this.solvencyLabel14.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel14.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel14.Location = new System.Drawing.Point(17,136);
this.solvencyLabel14.Name = "solvencyLabel14";
this.solvencyLabel14.OrdinateID_Label = 8;
this.solvencyLabel14.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel14.TabIndex = 14;
this.solvencyLabel14.Text = "S.03.02.01 - Off-balance sheet items - List of unlimited guarantees received by the undertaking" ;
this.solvencyLabel14.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel15
//
this.solvencyLabel15.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel15.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel15.Location = new System.Drawing.Point(285,136);
this.solvencyLabel15.Name = "solvencyLabel15";
this.solvencyLabel15.OrdinateID_Label = 0;
this.solvencyLabel15.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel15.TabIndex = 15;
this.solvencyLabel15.Text = "R0070" ;
this.solvencyLabel15.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel16
//
this.solvencyLabel16.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel16.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel16.Location = new System.Drawing.Point(17,169);
this.solvencyLabel16.Name = "solvencyLabel16";
this.solvencyLabel16.OrdinateID_Label = 9;
this.solvencyLabel16.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel16.TabIndex = 16;
this.solvencyLabel16.Text = "S.03.03.01 - Off-balance sheet items - List of unlimited guarantees provided by the undertaking" ;
this.solvencyLabel16.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel17
//
this.solvencyLabel17.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel17.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel17.Location = new System.Drawing.Point(285,169);
this.solvencyLabel17.Name = "solvencyLabel17";
this.solvencyLabel17.OrdinateID_Label = 0;
this.solvencyLabel17.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel17.TabIndex = 17;
this.solvencyLabel17.Text = "R0080" ;
this.solvencyLabel17.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel18
//
this.solvencyLabel18.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel18.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel18.Location = new System.Drawing.Point(17,202);
this.solvencyLabel18.Name = "solvencyLabel18";
this.solvencyLabel18.OrdinateID_Label = 10;
this.solvencyLabel18.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel18.TabIndex = 18;
this.solvencyLabel18.Text = "S.04.01.01 - Activity by country" ;
this.solvencyLabel18.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel19
//
this.solvencyLabel19.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel19.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel19.Location = new System.Drawing.Point(285,202);
this.solvencyLabel19.Name = "solvencyLabel19";
this.solvencyLabel19.OrdinateID_Label = 0;
this.solvencyLabel19.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel19.TabIndex = 19;
this.solvencyLabel19.Text = "R0090" ;
this.solvencyLabel19.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel20
//
this.solvencyLabel20.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel20.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel20.Location = new System.Drawing.Point(17,222);
this.solvencyLabel20.Name = "solvencyLabel20";
this.solvencyLabel20.OrdinateID_Label = 11;
this.solvencyLabel20.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel20.TabIndex = 20;
this.solvencyLabel20.Text = "S.04.02.01 - Information on class 10 in Part A of Annex I of Solvency II Directive, excluding carrier's liability" ;
this.solvencyLabel20.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel21
//
this.solvencyLabel21.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel21.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel21.Location = new System.Drawing.Point(285,222);
this.solvencyLabel21.Name = "solvencyLabel21";
this.solvencyLabel21.OrdinateID_Label = 0;
this.solvencyLabel21.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel21.TabIndex = 21;
this.solvencyLabel21.Text = "R0100" ;
this.solvencyLabel21.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel22
//
this.solvencyLabel22.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel22.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel22.Location = new System.Drawing.Point(17,255);
this.solvencyLabel22.Name = "solvencyLabel22";
this.solvencyLabel22.OrdinateID_Label = 12;
this.solvencyLabel22.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel22.TabIndex = 22;
this.solvencyLabel22.Text = "S.05.01.01 - Premiums, claims and expenses by line of business" ;
this.solvencyLabel22.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel23
//
this.solvencyLabel23.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel23.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel23.Location = new System.Drawing.Point(285,255);
this.solvencyLabel23.Name = "solvencyLabel23";
this.solvencyLabel23.OrdinateID_Label = 0;
this.solvencyLabel23.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel23.TabIndex = 23;
this.solvencyLabel23.Text = "R0110" ;
this.solvencyLabel23.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel24
//
this.solvencyLabel24.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel24.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel24.Location = new System.Drawing.Point(17,288);
this.solvencyLabel24.Name = "solvencyLabel24";
this.solvencyLabel24.OrdinateID_Label = 13;
this.solvencyLabel24.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel24.TabIndex = 24;
this.solvencyLabel24.Text = "S.05.02.01 - Premiums, claims and expenses by country" ;
this.solvencyLabel24.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel25
//
this.solvencyLabel25.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel25.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel25.Location = new System.Drawing.Point(285,288);
this.solvencyLabel25.Name = "solvencyLabel25";
this.solvencyLabel25.OrdinateID_Label = 0;
this.solvencyLabel25.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel25.TabIndex = 25;
this.solvencyLabel25.Text = "R0120" ;
this.solvencyLabel25.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel26
//
this.solvencyLabel26.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel26.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel26.Location = new System.Drawing.Point(17,321);
this.solvencyLabel26.Name = "solvencyLabel26";
this.solvencyLabel26.OrdinateID_Label = 14;
this.solvencyLabel26.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel26.TabIndex = 26;
this.solvencyLabel26.Text = "S.06.01.01 - Summary of assets" ;
this.solvencyLabel26.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel27
//
this.solvencyLabel27.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel27.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel27.Location = new System.Drawing.Point(285,321);
this.solvencyLabel27.Name = "solvencyLabel27";
this.solvencyLabel27.OrdinateID_Label = 0;
this.solvencyLabel27.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel27.TabIndex = 27;
this.solvencyLabel27.Text = "R0130" ;
this.solvencyLabel27.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel28
//
this.solvencyLabel28.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel28.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel28.Location = new System.Drawing.Point(17,341);
this.solvencyLabel28.Name = "solvencyLabel28";
this.solvencyLabel28.OrdinateID_Label = 15;
this.solvencyLabel28.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel28.TabIndex = 28;
this.solvencyLabel28.Text = "S.06.02.01 - List of assets" ;
this.solvencyLabel28.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel29
//
this.solvencyLabel29.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel29.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel29.Location = new System.Drawing.Point(285,341);
this.solvencyLabel29.Name = "solvencyLabel29";
this.solvencyLabel29.OrdinateID_Label = 0;
this.solvencyLabel29.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel29.TabIndex = 29;
this.solvencyLabel29.Text = "R0140" ;
this.solvencyLabel29.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel30
//
this.solvencyLabel30.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel30.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel30.Location = new System.Drawing.Point(17,361);
this.solvencyLabel30.Name = "solvencyLabel30";
this.solvencyLabel30.OrdinateID_Label = 16;
this.solvencyLabel30.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel30.TabIndex = 30;
this.solvencyLabel30.Text = "S.06.03.01 - Collective investment undertakings - look-through approach" ;
this.solvencyLabel30.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel31
//
this.solvencyLabel31.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel31.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel31.Location = new System.Drawing.Point(285,361);
this.solvencyLabel31.Name = "solvencyLabel31";
this.solvencyLabel31.OrdinateID_Label = 0;
this.solvencyLabel31.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel31.TabIndex = 31;
this.solvencyLabel31.Text = "R0150" ;
this.solvencyLabel31.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel32
//
this.solvencyLabel32.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel32.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel32.Location = new System.Drawing.Point(17,394);
this.solvencyLabel32.Name = "solvencyLabel32";
this.solvencyLabel32.OrdinateID_Label = 17;
this.solvencyLabel32.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel32.TabIndex = 32;
this.solvencyLabel32.Text = "S.07.01.01 - Structured products" ;
this.solvencyLabel32.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel33
//
this.solvencyLabel33.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel33.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel33.Location = new System.Drawing.Point(285,394);
this.solvencyLabel33.Name = "solvencyLabel33";
this.solvencyLabel33.OrdinateID_Label = 0;
this.solvencyLabel33.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel33.TabIndex = 33;
this.solvencyLabel33.Text = "R0160" ;
this.solvencyLabel33.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel34
//
this.solvencyLabel34.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel34.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel34.Location = new System.Drawing.Point(17,414);
this.solvencyLabel34.Name = "solvencyLabel34";
this.solvencyLabel34.OrdinateID_Label = 18;
this.solvencyLabel34.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel34.TabIndex = 34;
this.solvencyLabel34.Text = "S.08.01.01 - Open derivatives" ;
this.solvencyLabel34.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel35
//
this.solvencyLabel35.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel35.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel35.Location = new System.Drawing.Point(285,414);
this.solvencyLabel35.Name = "solvencyLabel35";
this.solvencyLabel35.OrdinateID_Label = 0;
this.solvencyLabel35.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel35.TabIndex = 35;
this.solvencyLabel35.Text = "R0170" ;
this.solvencyLabel35.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel36
//
this.solvencyLabel36.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel36.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel36.Location = new System.Drawing.Point(17,434);
this.solvencyLabel36.Name = "solvencyLabel36";
this.solvencyLabel36.OrdinateID_Label = 19;
this.solvencyLabel36.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel36.TabIndex = 36;
this.solvencyLabel36.Text = "S.08.02.01 - Derivatives Transactions" ;
this.solvencyLabel36.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel37
//
this.solvencyLabel37.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel37.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel37.Location = new System.Drawing.Point(285,434);
this.solvencyLabel37.Name = "solvencyLabel37";
this.solvencyLabel37.OrdinateID_Label = 0;
this.solvencyLabel37.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel37.TabIndex = 37;
this.solvencyLabel37.Text = "R0180" ;
this.solvencyLabel37.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel38
//
this.solvencyLabel38.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel38.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel38.Location = new System.Drawing.Point(17,454);
this.solvencyLabel38.Name = "solvencyLabel38";
this.solvencyLabel38.OrdinateID_Label = 20;
this.solvencyLabel38.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel38.TabIndex = 38;
this.solvencyLabel38.Text = "S.09.01.01 - Income/gains and losses in the period" ;
this.solvencyLabel38.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel39
//
this.solvencyLabel39.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel39.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel39.Location = new System.Drawing.Point(285,454);
this.solvencyLabel39.Name = "solvencyLabel39";
this.solvencyLabel39.OrdinateID_Label = 0;
this.solvencyLabel39.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel39.TabIndex = 39;
this.solvencyLabel39.Text = "R0190" ;
this.solvencyLabel39.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel40
//
this.solvencyLabel40.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel40.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel40.Location = new System.Drawing.Point(17,474);
this.solvencyLabel40.Name = "solvencyLabel40";
this.solvencyLabel40.OrdinateID_Label = 21;
this.solvencyLabel40.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel40.TabIndex = 40;
this.solvencyLabel40.Text = "S.10.01.01 - Securities lending and repos" ;
this.solvencyLabel40.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel41
//
this.solvencyLabel41.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel41.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel41.Location = new System.Drawing.Point(285,474);
this.solvencyLabel41.Name = "solvencyLabel41";
this.solvencyLabel41.OrdinateID_Label = 0;
this.solvencyLabel41.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel41.TabIndex = 41;
this.solvencyLabel41.Text = "R0200" ;
this.solvencyLabel41.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel42
//
this.solvencyLabel42.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel42.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel42.Location = new System.Drawing.Point(17,494);
this.solvencyLabel42.Name = "solvencyLabel42";
this.solvencyLabel42.OrdinateID_Label = 22;
this.solvencyLabel42.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel42.TabIndex = 42;
this.solvencyLabel42.Text = "S.11.01.01 - Assets held as collateral" ;
this.solvencyLabel42.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel43
//
this.solvencyLabel43.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel43.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel43.Location = new System.Drawing.Point(285,494);
this.solvencyLabel43.Name = "solvencyLabel43";
this.solvencyLabel43.OrdinateID_Label = 0;
this.solvencyLabel43.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel43.TabIndex = 43;
this.solvencyLabel43.Text = "R0210" ;
this.solvencyLabel43.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel44
//
this.solvencyLabel44.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel44.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel44.Location = new System.Drawing.Point(17,514);
this.solvencyLabel44.Name = "solvencyLabel44";
this.solvencyLabel44.OrdinateID_Label = 23;
this.solvencyLabel44.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel44.TabIndex = 44;
this.solvencyLabel44.Text = "S.12.01.01 - Life and Health SLT Technical Provisions" ;
this.solvencyLabel44.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel45
//
this.solvencyLabel45.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel45.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel45.Location = new System.Drawing.Point(285,514);
this.solvencyLabel45.Name = "solvencyLabel45";
this.solvencyLabel45.OrdinateID_Label = 0;
this.solvencyLabel45.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel45.TabIndex = 45;
this.solvencyLabel45.Text = "R0220" ;
this.solvencyLabel45.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel46
//
this.solvencyLabel46.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel46.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel46.Location = new System.Drawing.Point(17,547);
this.solvencyLabel46.Name = "solvencyLabel46";
this.solvencyLabel46.OrdinateID_Label = 24;
this.solvencyLabel46.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel46.TabIndex = 46;
this.solvencyLabel46.Text = "S.12.02.01 - Life and Health SLT Technical Provisions - by country" ;
this.solvencyLabel46.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel47
//
this.solvencyLabel47.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel47.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel47.Location = new System.Drawing.Point(285,547);
this.solvencyLabel47.Name = "solvencyLabel47";
this.solvencyLabel47.OrdinateID_Label = 0;
this.solvencyLabel47.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel47.TabIndex = 47;
this.solvencyLabel47.Text = "R0230" ;
this.solvencyLabel47.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel48
//
this.solvencyLabel48.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel48.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel48.Location = new System.Drawing.Point(17,580);
this.solvencyLabel48.Name = "solvencyLabel48";
this.solvencyLabel48.OrdinateID_Label = 25;
this.solvencyLabel48.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel48.TabIndex = 48;
this.solvencyLabel48.Text = "S.13.01.01 - Projection of future gross cash flows" ;
this.solvencyLabel48.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel49
//
this.solvencyLabel49.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel49.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel49.Location = new System.Drawing.Point(285,580);
this.solvencyLabel49.Name = "solvencyLabel49";
this.solvencyLabel49.OrdinateID_Label = 0;
this.solvencyLabel49.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel49.TabIndex = 49;
this.solvencyLabel49.Text = "R0240" ;
this.solvencyLabel49.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel50
//
this.solvencyLabel50.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel50.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel50.Location = new System.Drawing.Point(17,600);
this.solvencyLabel50.Name = "solvencyLabel50";
this.solvencyLabel50.OrdinateID_Label = 26;
this.solvencyLabel50.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel50.TabIndex = 50;
this.solvencyLabel50.Text = "S.14.01.01 - Life obligations analysis" ;
this.solvencyLabel50.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel51
//
this.solvencyLabel51.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel51.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel51.Location = new System.Drawing.Point(285,600);
this.solvencyLabel51.Name = "solvencyLabel51";
this.solvencyLabel51.OrdinateID_Label = 0;
this.solvencyLabel51.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel51.TabIndex = 51;
this.solvencyLabel51.Text = "R0250" ;
this.solvencyLabel51.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel52
//
this.solvencyLabel52.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel52.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel52.Location = new System.Drawing.Point(17,620);
this.solvencyLabel52.Name = "solvencyLabel52";
this.solvencyLabel52.OrdinateID_Label = 27;
this.solvencyLabel52.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel52.TabIndex = 52;
this.solvencyLabel52.Text = "S.15.01.01 - Description of the guarantees of variable annuities" ;
this.solvencyLabel52.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel53
//
this.solvencyLabel53.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel53.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel53.Location = new System.Drawing.Point(285,620);
this.solvencyLabel53.Name = "solvencyLabel53";
this.solvencyLabel53.OrdinateID_Label = 0;
this.solvencyLabel53.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel53.TabIndex = 53;
this.solvencyLabel53.Text = "R0260" ;
this.solvencyLabel53.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel54
//
this.solvencyLabel54.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel54.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel54.Location = new System.Drawing.Point(17,653);
this.solvencyLabel54.Name = "solvencyLabel54";
this.solvencyLabel54.OrdinateID_Label = 28;
this.solvencyLabel54.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel54.TabIndex = 54;
this.solvencyLabel54.Text = "S.15.02.01 - Hedging of guarantees of variable annuities" ;
this.solvencyLabel54.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel55
//
this.solvencyLabel55.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel55.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel55.Location = new System.Drawing.Point(285,653);
this.solvencyLabel55.Name = "solvencyLabel55";
this.solvencyLabel55.OrdinateID_Label = 0;
this.solvencyLabel55.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel55.TabIndex = 55;
this.solvencyLabel55.Text = "R0270" ;
this.solvencyLabel55.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel56
//
this.solvencyLabel56.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel56.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel56.Location = new System.Drawing.Point(17,686);
this.solvencyLabel56.Name = "solvencyLabel56";
this.solvencyLabel56.OrdinateID_Label = 29;
this.solvencyLabel56.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel56.TabIndex = 56;
this.solvencyLabel56.Text = "S.16.01.01 - Information on annuities stemming from Non-Life Insurance obligations" ;
this.solvencyLabel56.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel57
//
this.solvencyLabel57.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel57.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel57.Location = new System.Drawing.Point(285,686);
this.solvencyLabel57.Name = "solvencyLabel57";
this.solvencyLabel57.OrdinateID_Label = 0;
this.solvencyLabel57.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel57.TabIndex = 57;
this.solvencyLabel57.Text = "R0280" ;
this.solvencyLabel57.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel58
//
this.solvencyLabel58.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel58.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel58.Location = new System.Drawing.Point(17,719);
this.solvencyLabel58.Name = "solvencyLabel58";
this.solvencyLabel58.OrdinateID_Label = 30;
this.solvencyLabel58.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel58.TabIndex = 58;
this.solvencyLabel58.Text = "S.17.01.01 - Non-Life Technical Provisions" ;
this.solvencyLabel58.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel59
//
this.solvencyLabel59.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel59.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel59.Location = new System.Drawing.Point(285,719);
this.solvencyLabel59.Name = "solvencyLabel59";
this.solvencyLabel59.OrdinateID_Label = 0;
this.solvencyLabel59.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel59.TabIndex = 59;
this.solvencyLabel59.Text = "R0290" ;
this.solvencyLabel59.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel60
//
this.solvencyLabel60.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel60.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel60.Location = new System.Drawing.Point(17,739);
this.solvencyLabel60.Name = "solvencyLabel60";
this.solvencyLabel60.OrdinateID_Label = 31;
this.solvencyLabel60.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel60.TabIndex = 60;
this.solvencyLabel60.Text = "S.17.02.01 - Non-Life Technical Provisions - By country" ;
this.solvencyLabel60.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel61
//
this.solvencyLabel61.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel61.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel61.Location = new System.Drawing.Point(285,739);
this.solvencyLabel61.Name = "solvencyLabel61";
this.solvencyLabel61.OrdinateID_Label = 0;
this.solvencyLabel61.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel61.TabIndex = 61;
this.solvencyLabel61.Text = "R0300" ;
this.solvencyLabel61.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel62
//
this.solvencyLabel62.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel62.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel62.Location = new System.Drawing.Point(17,772);
this.solvencyLabel62.Name = "solvencyLabel62";
this.solvencyLabel62.OrdinateID_Label = 32;
this.solvencyLabel62.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel62.TabIndex = 62;
this.solvencyLabel62.Text = "S.18.01.01 - Projection of future cash flows (Best Estimate - Non Life)" ;
this.solvencyLabel62.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel63
//
this.solvencyLabel63.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel63.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel63.Location = new System.Drawing.Point(285,772);
this.solvencyLabel63.Name = "solvencyLabel63";
this.solvencyLabel63.OrdinateID_Label = 0;
this.solvencyLabel63.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel63.TabIndex = 63;
this.solvencyLabel63.Text = "R0310" ;
this.solvencyLabel63.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel64
//
this.solvencyLabel64.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel64.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel64.Location = new System.Drawing.Point(17,805);
this.solvencyLabel64.Name = "solvencyLabel64";
this.solvencyLabel64.OrdinateID_Label = 33;
this.solvencyLabel64.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel64.TabIndex = 64;
this.solvencyLabel64.Text = "S.19.01.01 - Non-life insurance claims" ;
this.solvencyLabel64.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel65
//
this.solvencyLabel65.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel65.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel65.Location = new System.Drawing.Point(285,805);
this.solvencyLabel65.Name = "solvencyLabel65";
this.solvencyLabel65.OrdinateID_Label = 0;
this.solvencyLabel65.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel65.TabIndex = 65;
this.solvencyLabel65.Text = "R0320" ;
this.solvencyLabel65.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel66
//
this.solvencyLabel66.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel66.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel66.Location = new System.Drawing.Point(17,825);
this.solvencyLabel66.Name = "solvencyLabel66";
this.solvencyLabel66.OrdinateID_Label = 34;
this.solvencyLabel66.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel66.TabIndex = 66;
this.solvencyLabel66.Text = "S.20.01.01 - Development of the distribution of the claims incurred" ;
this.solvencyLabel66.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel67
//
this.solvencyLabel67.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel67.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel67.Location = new System.Drawing.Point(285,825);
this.solvencyLabel67.Name = "solvencyLabel67";
this.solvencyLabel67.OrdinateID_Label = 0;
this.solvencyLabel67.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel67.TabIndex = 67;
this.solvencyLabel67.Text = "R0330" ;
this.solvencyLabel67.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel68
//
this.solvencyLabel68.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel68.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel68.Location = new System.Drawing.Point(17,858);
this.solvencyLabel68.Name = "solvencyLabel68";
this.solvencyLabel68.OrdinateID_Label = 35;
this.solvencyLabel68.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel68.TabIndex = 68;
this.solvencyLabel68.Text = "S.21.01.01 - Loss distribution risk profile" ;
this.solvencyLabel68.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel69
//
this.solvencyLabel69.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel69.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel69.Location = new System.Drawing.Point(285,858);
this.solvencyLabel69.Name = "solvencyLabel69";
this.solvencyLabel69.OrdinateID_Label = 0;
this.solvencyLabel69.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel69.TabIndex = 69;
this.solvencyLabel69.Text = "R0340" ;
this.solvencyLabel69.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel70
//
this.solvencyLabel70.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel70.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel70.Location = new System.Drawing.Point(17,878);
this.solvencyLabel70.Name = "solvencyLabel70";
this.solvencyLabel70.OrdinateID_Label = 36;
this.solvencyLabel70.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel70.TabIndex = 70;
this.solvencyLabel70.Text = "S.21.02.01 - Underwriting risks non-life" ;
this.solvencyLabel70.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel71
//
this.solvencyLabel71.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel71.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel71.Location = new System.Drawing.Point(285,878);
this.solvencyLabel71.Name = "solvencyLabel71";
this.solvencyLabel71.OrdinateID_Label = 0;
this.solvencyLabel71.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel71.TabIndex = 71;
this.solvencyLabel71.Text = "R0350" ;
this.solvencyLabel71.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel72
//
this.solvencyLabel72.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel72.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel72.Location = new System.Drawing.Point(17,898);
this.solvencyLabel72.Name = "solvencyLabel72";
this.solvencyLabel72.OrdinateID_Label = 37;
this.solvencyLabel72.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel72.TabIndex = 72;
this.solvencyLabel72.Text = "S.21.03.01 - Non-life distribution of underwriting risks - by sum insured" ;
this.solvencyLabel72.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel73
//
this.solvencyLabel73.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel73.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel73.Location = new System.Drawing.Point(285,898);
this.solvencyLabel73.Name = "solvencyLabel73";
this.solvencyLabel73.OrdinateID_Label = 0;
this.solvencyLabel73.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel73.TabIndex = 73;
this.solvencyLabel73.Text = "R0360" ;
this.solvencyLabel73.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel74
//
this.solvencyLabel74.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel74.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel74.Location = new System.Drawing.Point(17,931);
this.solvencyLabel74.Name = "solvencyLabel74";
this.solvencyLabel74.OrdinateID_Label = 38;
this.solvencyLabel74.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel74.TabIndex = 74;
this.solvencyLabel74.Text = "S.22.01.01 - Impact of long term guarantees measures and transitionals" ;
this.solvencyLabel74.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel75
//
this.solvencyLabel75.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel75.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel75.Location = new System.Drawing.Point(285,931);
this.solvencyLabel75.Name = "solvencyLabel75";
this.solvencyLabel75.OrdinateID_Label = 0;
this.solvencyLabel75.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel75.TabIndex = 75;
this.solvencyLabel75.Text = "R0370" ;
this.solvencyLabel75.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel76
//
this.solvencyLabel76.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel76.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel76.Location = new System.Drawing.Point(17,964);
this.solvencyLabel76.Name = "solvencyLabel76";
this.solvencyLabel76.OrdinateID_Label = 39;
this.solvencyLabel76.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel76.TabIndex = 76;
this.solvencyLabel76.Text = "S.22.04.01 - Information on the transitional on interest rates calculation" ;
this.solvencyLabel76.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel77
//
this.solvencyLabel77.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel77.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel77.Location = new System.Drawing.Point(285,964);
this.solvencyLabel77.Name = "solvencyLabel77";
this.solvencyLabel77.OrdinateID_Label = 0;
this.solvencyLabel77.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel77.TabIndex = 77;
this.solvencyLabel77.Text = "R0380" ;
this.solvencyLabel77.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel78
//
this.solvencyLabel78.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel78.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel78.Location = new System.Drawing.Point(17,997);
this.solvencyLabel78.Name = "solvencyLabel78";
this.solvencyLabel78.OrdinateID_Label = 40;
this.solvencyLabel78.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel78.TabIndex = 78;
this.solvencyLabel78.Text = "S.22.05.01 - Overall calculation of the transitional on technical provisions" ;
this.solvencyLabel78.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel79
//
this.solvencyLabel79.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel79.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel79.Location = new System.Drawing.Point(285,997);
this.solvencyLabel79.Name = "solvencyLabel79";
this.solvencyLabel79.OrdinateID_Label = 0;
this.solvencyLabel79.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel79.TabIndex = 79;
this.solvencyLabel79.Text = "R0390" ;
this.solvencyLabel79.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel80
//
this.solvencyLabel80.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel80.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel80.Location = new System.Drawing.Point(17,1030);
this.solvencyLabel80.Name = "solvencyLabel80";
this.solvencyLabel80.OrdinateID_Label = 41;
this.solvencyLabel80.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel80.TabIndex = 80;
this.solvencyLabel80.Text = "S.22.06.01 - Best estimate subject to volatility adjustment by country and currency" ;
this.solvencyLabel80.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel81
//
this.solvencyLabel81.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel81.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel81.Location = new System.Drawing.Point(285,1030);
this.solvencyLabel81.Name = "solvencyLabel81";
this.solvencyLabel81.OrdinateID_Label = 0;
this.solvencyLabel81.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel81.TabIndex = 81;
this.solvencyLabel81.Text = "R0400" ;
this.solvencyLabel81.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel82
//
this.solvencyLabel82.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel82.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel82.Location = new System.Drawing.Point(17,1063);
this.solvencyLabel82.Name = "solvencyLabel82";
this.solvencyLabel82.OrdinateID_Label = 42;
this.solvencyLabel82.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel82.TabIndex = 82;
this.solvencyLabel82.Text = "S.23.01.01 - Own funds" ;
this.solvencyLabel82.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel83
//
this.solvencyLabel83.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel83.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel83.Location = new System.Drawing.Point(285,1063);
this.solvencyLabel83.Name = "solvencyLabel83";
this.solvencyLabel83.OrdinateID_Label = 0;
this.solvencyLabel83.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel83.TabIndex = 83;
this.solvencyLabel83.Text = "R0410" ;
this.solvencyLabel83.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel84
//
this.solvencyLabel84.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel84.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel84.Location = new System.Drawing.Point(17,1083);
this.solvencyLabel84.Name = "solvencyLabel84";
this.solvencyLabel84.OrdinateID_Label = 43;
this.solvencyLabel84.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel84.TabIndex = 84;
this.solvencyLabel84.Text = "S.23.02.01 - Detailed information by tiers on own funds" ;
this.solvencyLabel84.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel85
//
this.solvencyLabel85.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel85.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel85.Location = new System.Drawing.Point(285,1083);
this.solvencyLabel85.Name = "solvencyLabel85";
this.solvencyLabel85.OrdinateID_Label = 0;
this.solvencyLabel85.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel85.TabIndex = 85;
this.solvencyLabel85.Text = "R0420" ;
this.solvencyLabel85.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel86
//
this.solvencyLabel86.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel86.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel86.Location = new System.Drawing.Point(17,1116);
this.solvencyLabel86.Name = "solvencyLabel86";
this.solvencyLabel86.OrdinateID_Label = 44;
this.solvencyLabel86.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel86.TabIndex = 86;
this.solvencyLabel86.Text = "S.23.03.01 - Annual movements on own funds" ;
this.solvencyLabel86.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel87
//
this.solvencyLabel87.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel87.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel87.Location = new System.Drawing.Point(285,1116);
this.solvencyLabel87.Name = "solvencyLabel87";
this.solvencyLabel87.OrdinateID_Label = 0;
this.solvencyLabel87.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel87.TabIndex = 87;
this.solvencyLabel87.Text = "R0430" ;
this.solvencyLabel87.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel88
//
this.solvencyLabel88.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel88.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel88.Location = new System.Drawing.Point(17,1136);
this.solvencyLabel88.Name = "solvencyLabel88";
this.solvencyLabel88.OrdinateID_Label = 45;
this.solvencyLabel88.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel88.TabIndex = 88;
this.solvencyLabel88.Text = "S.23.04.01 - List of items on own funds" ;
this.solvencyLabel88.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel89
//
this.solvencyLabel89.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel89.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel89.Location = new System.Drawing.Point(285,1136);
this.solvencyLabel89.Name = "solvencyLabel89";
this.solvencyLabel89.OrdinateID_Label = 0;
this.solvencyLabel89.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel89.TabIndex = 89;
this.solvencyLabel89.Text = "R0440" ;
this.solvencyLabel89.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel90
//
this.solvencyLabel90.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel90.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel90.Location = new System.Drawing.Point(17,1156);
this.solvencyLabel90.Name = "solvencyLabel90";
this.solvencyLabel90.OrdinateID_Label = 46;
this.solvencyLabel90.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel90.TabIndex = 90;
this.solvencyLabel90.Text = "S.24.01.01 - Participations held" ;
this.solvencyLabel90.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel91
//
this.solvencyLabel91.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel91.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel91.Location = new System.Drawing.Point(285,1156);
this.solvencyLabel91.Name = "solvencyLabel91";
this.solvencyLabel91.OrdinateID_Label = 0;
this.solvencyLabel91.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel91.TabIndex = 91;
this.solvencyLabel91.Text = "R0450" ;
this.solvencyLabel91.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel92
//
this.solvencyLabel92.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel92.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel92.Location = new System.Drawing.Point(17,1176);
this.solvencyLabel92.Name = "solvencyLabel92";
this.solvencyLabel92.OrdinateID_Label = 47;
this.solvencyLabel92.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel92.TabIndex = 92;
this.solvencyLabel92.Text = "S.25.01.01 - Solvency Capital Requirement - for undertakings on Standard Formula" ;
this.solvencyLabel92.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel93
//
this.solvencyLabel93.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel93.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel93.Location = new System.Drawing.Point(285,1176);
this.solvencyLabel93.Name = "solvencyLabel93";
this.solvencyLabel93.OrdinateID_Label = 0;
this.solvencyLabel93.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel93.TabIndex = 93;
this.solvencyLabel93.Text = "R0460" ;
this.solvencyLabel93.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel94
//
this.solvencyLabel94.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel94.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel94.Location = new System.Drawing.Point(17,1209);
this.solvencyLabel94.Name = "solvencyLabel94";
this.solvencyLabel94.OrdinateID_Label = 48;
this.solvencyLabel94.Size = new System.Drawing.Size(254, 45);
this.solvencyLabel94.TabIndex = 94;
this.solvencyLabel94.Text = "S.25.02.01 - Solvency Capital Requirement - for undertakings using the standard formula and partial internal model" ;
this.solvencyLabel94.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel95
//
this.solvencyLabel95.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel95.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel95.Location = new System.Drawing.Point(285,1209);
this.solvencyLabel95.Name = "solvencyLabel95";
this.solvencyLabel95.OrdinateID_Label = 0;
this.solvencyLabel95.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel95.TabIndex = 95;
this.solvencyLabel95.Text = "R0470" ;
this.solvencyLabel95.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel96
//
this.solvencyLabel96.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel96.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel96.Location = new System.Drawing.Point(17,1257);
this.solvencyLabel96.Name = "solvencyLabel96";
this.solvencyLabel96.OrdinateID_Label = 49;
this.solvencyLabel96.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel96.TabIndex = 96;
this.solvencyLabel96.Text = "S.25.03.01 - Solvency Capital Requirement - for undertakings on Full Internal Models" ;
this.solvencyLabel96.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel97
//
this.solvencyLabel97.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel97.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel97.Location = new System.Drawing.Point(285,1257);
this.solvencyLabel97.Name = "solvencyLabel97";
this.solvencyLabel97.OrdinateID_Label = 0;
this.solvencyLabel97.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel97.TabIndex = 97;
this.solvencyLabel97.Text = "R0480" ;
this.solvencyLabel97.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel98
//
this.solvencyLabel98.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel98.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel98.Location = new System.Drawing.Point(17,1290);
this.solvencyLabel98.Name = "solvencyLabel98";
this.solvencyLabel98.OrdinateID_Label = 50;
this.solvencyLabel98.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel98.TabIndex = 98;
this.solvencyLabel98.Text = "S.26.01.01 - Solvency Capital Requirement - Market risk" ;
this.solvencyLabel98.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel99
//
this.solvencyLabel99.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel99.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel99.Location = new System.Drawing.Point(285,1290);
this.solvencyLabel99.Name = "solvencyLabel99";
this.solvencyLabel99.OrdinateID_Label = 0;
this.solvencyLabel99.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel99.TabIndex = 99;
this.solvencyLabel99.Text = "R0500" ;
this.solvencyLabel99.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel100
//
this.solvencyLabel100.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel100.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel100.Location = new System.Drawing.Point(17,1323);
this.solvencyLabel100.Name = "solvencyLabel100";
this.solvencyLabel100.OrdinateID_Label = 51;
this.solvencyLabel100.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel100.TabIndex = 100;
this.solvencyLabel100.Text = "S.26.02.01 - Solvency Capital Requirement - Counterparty default risk" ;
this.solvencyLabel100.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel101
//
this.solvencyLabel101.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel101.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel101.Location = new System.Drawing.Point(285,1323);
this.solvencyLabel101.Name = "solvencyLabel101";
this.solvencyLabel101.OrdinateID_Label = 0;
this.solvencyLabel101.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel101.TabIndex = 101;
this.solvencyLabel101.Text = "R0510" ;
this.solvencyLabel101.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel102
//
this.solvencyLabel102.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel102.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel102.Location = new System.Drawing.Point(17,1356);
this.solvencyLabel102.Name = "solvencyLabel102";
this.solvencyLabel102.OrdinateID_Label = 52;
this.solvencyLabel102.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel102.TabIndex = 102;
this.solvencyLabel102.Text = "S.26.03.01 - Solvency Capital Requirement - Life underwriting risk" ;
this.solvencyLabel102.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel103
//
this.solvencyLabel103.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel103.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel103.Location = new System.Drawing.Point(285,1356);
this.solvencyLabel103.Name = "solvencyLabel103";
this.solvencyLabel103.OrdinateID_Label = 0;
this.solvencyLabel103.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel103.TabIndex = 103;
this.solvencyLabel103.Text = "R0520" ;
this.solvencyLabel103.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel104
//
this.solvencyLabel104.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel104.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel104.Location = new System.Drawing.Point(17,1389);
this.solvencyLabel104.Name = "solvencyLabel104";
this.solvencyLabel104.OrdinateID_Label = 53;
this.solvencyLabel104.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel104.TabIndex = 104;
this.solvencyLabel104.Text = "S.26.04.01 - Solvency Capital Requirement - Health underwriting risk" ;
this.solvencyLabel104.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel105
//
this.solvencyLabel105.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel105.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel105.Location = new System.Drawing.Point(285,1389);
this.solvencyLabel105.Name = "solvencyLabel105";
this.solvencyLabel105.OrdinateID_Label = 0;
this.solvencyLabel105.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel105.TabIndex = 105;
this.solvencyLabel105.Text = "R0530" ;
this.solvencyLabel105.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel106
//
this.solvencyLabel106.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel106.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel106.Location = new System.Drawing.Point(17,1422);
this.solvencyLabel106.Name = "solvencyLabel106";
this.solvencyLabel106.OrdinateID_Label = 54;
this.solvencyLabel106.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel106.TabIndex = 106;
this.solvencyLabel106.Text = "S.26.05.01 - Solvency Capital Requirement - Non-Life underwriting risk" ;
this.solvencyLabel106.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel107
//
this.solvencyLabel107.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel107.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel107.Location = new System.Drawing.Point(285,1422);
this.solvencyLabel107.Name = "solvencyLabel107";
this.solvencyLabel107.OrdinateID_Label = 0;
this.solvencyLabel107.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel107.TabIndex = 107;
this.solvencyLabel107.Text = "R0540" ;
this.solvencyLabel107.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel108
//
this.solvencyLabel108.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel108.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel108.Location = new System.Drawing.Point(17,1455);
this.solvencyLabel108.Name = "solvencyLabel108";
this.solvencyLabel108.OrdinateID_Label = 55;
this.solvencyLabel108.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel108.TabIndex = 108;
this.solvencyLabel108.Text = "S.26.06.01 - Solvency Capital Requirement - Operational risk" ;
this.solvencyLabel108.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel109
//
this.solvencyLabel109.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel109.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel109.Location = new System.Drawing.Point(285,1455);
this.solvencyLabel109.Name = "solvencyLabel109";
this.solvencyLabel109.OrdinateID_Label = 0;
this.solvencyLabel109.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel109.TabIndex = 109;
this.solvencyLabel109.Text = "R0550" ;
this.solvencyLabel109.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel110
//
this.solvencyLabel110.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel110.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel110.Location = new System.Drawing.Point(17,1488);
this.solvencyLabel110.Name = "solvencyLabel110";
this.solvencyLabel110.OrdinateID_Label = 56;
this.solvencyLabel110.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel110.TabIndex = 110;
this.solvencyLabel110.Text = "S.26.07.01 - Solvency Capital Requirement - Simplifications" ;
this.solvencyLabel110.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel111
//
this.solvencyLabel111.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel111.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel111.Location = new System.Drawing.Point(285,1488);
this.solvencyLabel111.Name = "solvencyLabel111";
this.solvencyLabel111.OrdinateID_Label = 0;
this.solvencyLabel111.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel111.TabIndex = 111;
this.solvencyLabel111.Text = "R0560" ;
this.solvencyLabel111.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel112
//
this.solvencyLabel112.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel112.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel112.Location = new System.Drawing.Point(17,1521);
this.solvencyLabel112.Name = "solvencyLabel112";
this.solvencyLabel112.OrdinateID_Label = 57;
this.solvencyLabel112.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel112.TabIndex = 112;
this.solvencyLabel112.Text = "S.27.01.01 - Solvency Capital Requirement - Non-life and Health catastrophe risk" ;
this.solvencyLabel112.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel113
//
this.solvencyLabel113.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel113.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel113.Location = new System.Drawing.Point(285,1521);
this.solvencyLabel113.Name = "solvencyLabel113";
this.solvencyLabel113.OrdinateID_Label = 0;
this.solvencyLabel113.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel113.TabIndex = 113;
this.solvencyLabel113.Text = "R0570" ;
this.solvencyLabel113.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel114
//
this.solvencyLabel114.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel114.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel114.Location = new System.Drawing.Point(17,1554);
this.solvencyLabel114.Name = "solvencyLabel114";
this.solvencyLabel114.OrdinateID_Label = 58;
this.solvencyLabel114.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel114.TabIndex = 114;
this.solvencyLabel114.Text = "S.28.01.01 - Minimum Capital Requirement - Only life or only non-life insurance or reinsurance activity" ;
this.solvencyLabel114.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel115
//
this.solvencyLabel115.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel115.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel115.Location = new System.Drawing.Point(285,1554);
this.solvencyLabel115.Name = "solvencyLabel115";
this.solvencyLabel115.OrdinateID_Label = 0;
this.solvencyLabel115.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel115.TabIndex = 115;
this.solvencyLabel115.Text = "R0580" ;
this.solvencyLabel115.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel116
//
this.solvencyLabel116.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel116.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel116.Location = new System.Drawing.Point(17,1587);
this.solvencyLabel116.Name = "solvencyLabel116";
this.solvencyLabel116.OrdinateID_Label = 59;
this.solvencyLabel116.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel116.TabIndex = 116;
this.solvencyLabel116.Text = "S.28.02.01 - Minimum Capital Requirement - Both life and non-life insurance activity" ;
this.solvencyLabel116.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel117
//
this.solvencyLabel117.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel117.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel117.Location = new System.Drawing.Point(285,1587);
this.solvencyLabel117.Name = "solvencyLabel117";
this.solvencyLabel117.OrdinateID_Label = 0;
this.solvencyLabel117.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel117.TabIndex = 117;
this.solvencyLabel117.Text = "R0590" ;
this.solvencyLabel117.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel118
//
this.solvencyLabel118.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel118.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel118.Location = new System.Drawing.Point(17,1620);
this.solvencyLabel118.Name = "solvencyLabel118";
this.solvencyLabel118.OrdinateID_Label = 60;
this.solvencyLabel118.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel118.TabIndex = 118;
this.solvencyLabel118.Text = "S.29.01.01 - Excess of Assets over Liabilities" ;
this.solvencyLabel118.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel119
//
this.solvencyLabel119.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel119.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel119.Location = new System.Drawing.Point(285,1620);
this.solvencyLabel119.Name = "solvencyLabel119";
this.solvencyLabel119.OrdinateID_Label = 0;
this.solvencyLabel119.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel119.TabIndex = 119;
this.solvencyLabel119.Text = "R0600" ;
this.solvencyLabel119.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel120
//
this.solvencyLabel120.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel120.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel120.Location = new System.Drawing.Point(17,1640);
this.solvencyLabel120.Name = "solvencyLabel120";
this.solvencyLabel120.OrdinateID_Label = 61;
this.solvencyLabel120.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel120.TabIndex = 120;
this.solvencyLabel120.Text = "S.29.02.01 - Excess of Assets over Liabilities - explained by investments and financial liabilities" ;
this.solvencyLabel120.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel121
//
this.solvencyLabel121.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel121.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel121.Location = new System.Drawing.Point(285,1640);
this.solvencyLabel121.Name = "solvencyLabel121";
this.solvencyLabel121.OrdinateID_Label = 0;
this.solvencyLabel121.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel121.TabIndex = 121;
this.solvencyLabel121.Text = "R0610" ;
this.solvencyLabel121.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel122
//
this.solvencyLabel122.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel122.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel122.Location = new System.Drawing.Point(17,1673);
this.solvencyLabel122.Name = "solvencyLabel122";
this.solvencyLabel122.OrdinateID_Label = 62;
this.solvencyLabel122.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel122.TabIndex = 122;
this.solvencyLabel122.Text = "S.29.03.01 - Excess of Assets over Liabilities - explained by technical provisions" ;
this.solvencyLabel122.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel123
//
this.solvencyLabel123.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel123.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel123.Location = new System.Drawing.Point(285,1673);
this.solvencyLabel123.Name = "solvencyLabel123";
this.solvencyLabel123.OrdinateID_Label = 0;
this.solvencyLabel123.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel123.TabIndex = 123;
this.solvencyLabel123.Text = "R0620" ;
this.solvencyLabel123.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel124
//
this.solvencyLabel124.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel124.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel124.Location = new System.Drawing.Point(17,1706);
this.solvencyLabel124.Name = "solvencyLabel124";
this.solvencyLabel124.OrdinateID_Label = 63;
this.solvencyLabel124.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel124.TabIndex = 124;
this.solvencyLabel124.Text = "S.29.04.01 - Detailed analysis per period - Technical flows versus Technical provisions" ;
this.solvencyLabel124.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel125
//
this.solvencyLabel125.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel125.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel125.Location = new System.Drawing.Point(285,1706);
this.solvencyLabel125.Name = "solvencyLabel125";
this.solvencyLabel125.OrdinateID_Label = 0;
this.solvencyLabel125.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel125.TabIndex = 125;
this.solvencyLabel125.Text = "R0630" ;
this.solvencyLabel125.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel126
//
this.solvencyLabel126.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel126.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel126.Location = new System.Drawing.Point(17,1739);
this.solvencyLabel126.Name = "solvencyLabel126";
this.solvencyLabel126.OrdinateID_Label = 64;
this.solvencyLabel126.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel126.TabIndex = 126;
this.solvencyLabel126.Text = "S.30.01.01 - Facultative covers for non-life and life business basic data" ;
this.solvencyLabel126.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel127
//
this.solvencyLabel127.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel127.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel127.Location = new System.Drawing.Point(285,1739);
this.solvencyLabel127.Name = "solvencyLabel127";
this.solvencyLabel127.OrdinateID_Label = 0;
this.solvencyLabel127.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel127.TabIndex = 127;
this.solvencyLabel127.Text = "R0640" ;
this.solvencyLabel127.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel128
//
this.solvencyLabel128.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel128.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel128.Location = new System.Drawing.Point(17,1772);
this.solvencyLabel128.Name = "solvencyLabel128";
this.solvencyLabel128.OrdinateID_Label = 65;
this.solvencyLabel128.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel128.TabIndex = 128;
this.solvencyLabel128.Text = "S.30.02.01 - Facultative covers for non-life and life business shares data" ;
this.solvencyLabel128.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel129
//
this.solvencyLabel129.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel129.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel129.Location = new System.Drawing.Point(285,1772);
this.solvencyLabel129.Name = "solvencyLabel129";
this.solvencyLabel129.OrdinateID_Label = 0;
this.solvencyLabel129.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel129.TabIndex = 129;
this.solvencyLabel129.Text = "R0650" ;
this.solvencyLabel129.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel130
//
this.solvencyLabel130.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel130.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel130.Location = new System.Drawing.Point(17,1805);
this.solvencyLabel130.Name = "solvencyLabel130";
this.solvencyLabel130.OrdinateID_Label = 66;
this.solvencyLabel130.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel130.TabIndex = 130;
this.solvencyLabel130.Text = "S.30.03.01 - Outgoing Reinsurance Program basic data" ;
this.solvencyLabel130.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel131
//
this.solvencyLabel131.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel131.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel131.Location = new System.Drawing.Point(285,1805);
this.solvencyLabel131.Name = "solvencyLabel131";
this.solvencyLabel131.OrdinateID_Label = 0;
this.solvencyLabel131.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel131.TabIndex = 131;
this.solvencyLabel131.Text = "R0660" ;
this.solvencyLabel131.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel132
//
this.solvencyLabel132.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel132.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel132.Location = new System.Drawing.Point(17,1838);
this.solvencyLabel132.Name = "solvencyLabel132";
this.solvencyLabel132.OrdinateID_Label = 67;
this.solvencyLabel132.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel132.TabIndex = 132;
this.solvencyLabel132.Text = "S.30.04.01 - Outgoing Reinsurance Program shares data" ;
this.solvencyLabel132.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel133
//
this.solvencyLabel133.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel133.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel133.Location = new System.Drawing.Point(285,1838);
this.solvencyLabel133.Name = "solvencyLabel133";
this.solvencyLabel133.OrdinateID_Label = 0;
this.solvencyLabel133.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel133.TabIndex = 133;
this.solvencyLabel133.Text = "R0670" ;
this.solvencyLabel133.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel134
//
this.solvencyLabel134.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel134.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel134.Location = new System.Drawing.Point(17,1871);
this.solvencyLabel134.Name = "solvencyLabel134";
this.solvencyLabel134.OrdinateID_Label = 68;
this.solvencyLabel134.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel134.TabIndex = 134;
this.solvencyLabel134.Text = "S.31.01.01 - Share of reinsurers (including Finite Reinsurance and SPV's)" ;
this.solvencyLabel134.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel135
//
this.solvencyLabel135.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel135.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel135.Location = new System.Drawing.Point(285,1871);
this.solvencyLabel135.Name = "solvencyLabel135";
this.solvencyLabel135.OrdinateID_Label = 0;
this.solvencyLabel135.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel135.TabIndex = 135;
this.solvencyLabel135.Text = "R0680" ;
this.solvencyLabel135.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel136
//
this.solvencyLabel136.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel136.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel136.Location = new System.Drawing.Point(17,1904);
this.solvencyLabel136.Name = "solvencyLabel136";
this.solvencyLabel136.OrdinateID_Label = 69;
this.solvencyLabel136.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel136.TabIndex = 136;
this.solvencyLabel136.Text = "S.31.02.01 - Special Purpose Vehicles" ;
this.solvencyLabel136.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel137
//
this.solvencyLabel137.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel137.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel137.Location = new System.Drawing.Point(285,1904);
this.solvencyLabel137.Name = "solvencyLabel137";
this.solvencyLabel137.OrdinateID_Label = 0;
this.solvencyLabel137.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel137.TabIndex = 137;
this.solvencyLabel137.Text = "R0690" ;
this.solvencyLabel137.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel138
//
this.solvencyLabel138.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel138.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel138.Location = new System.Drawing.Point(17,1924);
this.solvencyLabel138.Name = "solvencyLabel138";
this.solvencyLabel138.OrdinateID_Label = 70;
this.solvencyLabel138.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel138.TabIndex = 138;
this.solvencyLabel138.Text = "S.36.01.01 - IGT - Equity-type transactions, debt and asset transfer" ;
this.solvencyLabel138.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel139
//
this.solvencyLabel139.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel139.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel139.Location = new System.Drawing.Point(285,1924);
this.solvencyLabel139.Name = "solvencyLabel139";
this.solvencyLabel139.OrdinateID_Label = 0;
this.solvencyLabel139.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel139.TabIndex = 139;
this.solvencyLabel139.Text = "R0740" ;
this.solvencyLabel139.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel140
//
this.solvencyLabel140.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel140.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel140.Location = new System.Drawing.Point(17,1957);
this.solvencyLabel140.Name = "solvencyLabel140";
this.solvencyLabel140.OrdinateID_Label = 71;
this.solvencyLabel140.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel140.TabIndex = 140;
this.solvencyLabel140.Text = "S.36.02.01 - IGT - Derivatives" ;
this.solvencyLabel140.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel141
//
this.solvencyLabel141.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel141.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel141.Location = new System.Drawing.Point(285,1957);
this.solvencyLabel141.Name = "solvencyLabel141";
this.solvencyLabel141.OrdinateID_Label = 0;
this.solvencyLabel141.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel141.TabIndex = 141;
this.solvencyLabel141.Text = "R0750" ;
this.solvencyLabel141.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel142
//
this.solvencyLabel142.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel142.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel142.Location = new System.Drawing.Point(17,1977);
this.solvencyLabel142.Name = "solvencyLabel142";
this.solvencyLabel142.OrdinateID_Label = 72;
this.solvencyLabel142.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel142.TabIndex = 142;
this.solvencyLabel142.Text = "S.36.03.01 - IGT - Internal reinsurance" ;
this.solvencyLabel142.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel143
//
this.solvencyLabel143.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel143.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel143.Location = new System.Drawing.Point(285,1977);
this.solvencyLabel143.Name = "solvencyLabel143";
this.solvencyLabel143.OrdinateID_Label = 0;
this.solvencyLabel143.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel143.TabIndex = 143;
this.solvencyLabel143.Text = "R0760" ;
this.solvencyLabel143.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel144
//
this.solvencyLabel144.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel144.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel144.Location = new System.Drawing.Point(17,1997);
this.solvencyLabel144.Name = "solvencyLabel144";
this.solvencyLabel144.OrdinateID_Label = 73;
this.solvencyLabel144.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel144.TabIndex = 144;
this.solvencyLabel144.Text = "S.36.04.01 - IGT - Cost Sharing, contingent liabilities, off BS and other items" ;
this.solvencyLabel144.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel145
//
this.solvencyLabel145.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel145.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel145.Location = new System.Drawing.Point(285,1997);
this.solvencyLabel145.Name = "solvencyLabel145";
this.solvencyLabel145.OrdinateID_Label = 0;
this.solvencyLabel145.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel145.TabIndex = 145;
this.solvencyLabel145.Text = "R0770" ;
this.solvencyLabel145.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel146
//
this.solvencyLabel146.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel146.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel146.Location = new System.Drawing.Point(285,2017);
this.solvencyLabel146.Name = "solvencyLabel146";
this.solvencyLabel146.OrdinateID_Label = 0;
this.solvencyLabel146.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel146.TabIndex = 146;
this.solvencyLabel146.Text = "." ;
this.solvencyLabel146.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// SolvencyDataComboBox147
//
this.SolvencyDataComboBox147.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox147.Location = new System.Drawing.Point(10,23);
this.SolvencyDataComboBox147.Name = "SolvencyDataComboBox147";
this.SolvencyDataComboBox147.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox147.TabIndex = 147;
this.SolvencyDataComboBox147.ColName = "R0010C0010";
this.SolvencyDataComboBox147.AxisID = 2;
this.SolvencyDataComboBox147.OrdinateID = 3;
this.SolvencyDataComboBox147.StartOrder = 0;
this.SolvencyDataComboBox147.NextOrder = 0;
//
// SolvencyDataComboBox148
//
this.SolvencyDataComboBox148.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox148.Location = new System.Drawing.Point(10,43);
this.SolvencyDataComboBox148.Name = "SolvencyDataComboBox148";
this.SolvencyDataComboBox148.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox148.TabIndex = 148;
this.SolvencyDataComboBox148.ColName = "R0020C0010";
this.SolvencyDataComboBox148.AxisID = 2;
this.SolvencyDataComboBox148.OrdinateID = 4;
this.SolvencyDataComboBox148.StartOrder = 0;
this.SolvencyDataComboBox148.NextOrder = 0;
//
// SolvencyDataComboBox149
//
this.SolvencyDataComboBox149.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox149.Location = new System.Drawing.Point(10,76);
this.SolvencyDataComboBox149.Name = "SolvencyDataComboBox149";
this.SolvencyDataComboBox149.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox149.TabIndex = 149;
this.SolvencyDataComboBox149.ColName = "R0030C0010";
this.SolvencyDataComboBox149.AxisID = 2;
this.SolvencyDataComboBox149.OrdinateID = 5;
this.SolvencyDataComboBox149.StartOrder = 0;
this.SolvencyDataComboBox149.NextOrder = 0;
//
// SolvencyDataComboBox150
//
this.SolvencyDataComboBox150.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox150.Location = new System.Drawing.Point(10,96);
this.SolvencyDataComboBox150.Name = "SolvencyDataComboBox150";
this.SolvencyDataComboBox150.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox150.TabIndex = 150;
this.SolvencyDataComboBox150.ColName = "R0040C0010";
this.SolvencyDataComboBox150.AxisID = 2;
this.SolvencyDataComboBox150.OrdinateID = 6;
this.SolvencyDataComboBox150.StartOrder = 0;
this.SolvencyDataComboBox150.NextOrder = 0;
//
// SolvencyDataComboBox151
//
this.SolvencyDataComboBox151.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox151.Location = new System.Drawing.Point(10,116);
this.SolvencyDataComboBox151.Name = "SolvencyDataComboBox151";
this.SolvencyDataComboBox151.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox151.TabIndex = 151;
this.SolvencyDataComboBox151.ColName = "R0060C0010";
this.SolvencyDataComboBox151.AxisID = 2;
this.SolvencyDataComboBox151.OrdinateID = 7;
this.SolvencyDataComboBox151.StartOrder = 0;
this.SolvencyDataComboBox151.NextOrder = 0;
//
// SolvencyDataComboBox152
//
this.SolvencyDataComboBox152.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox152.Location = new System.Drawing.Point(10,136);
this.SolvencyDataComboBox152.Name = "SolvencyDataComboBox152";
this.SolvencyDataComboBox152.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox152.TabIndex = 152;
this.SolvencyDataComboBox152.ColName = "R0070C0010";
this.SolvencyDataComboBox152.AxisID = 2;
this.SolvencyDataComboBox152.OrdinateID = 8;
this.SolvencyDataComboBox152.StartOrder = 0;
this.SolvencyDataComboBox152.NextOrder = 0;
//
// SolvencyDataComboBox153
//
this.SolvencyDataComboBox153.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox153.Location = new System.Drawing.Point(10,169);
this.SolvencyDataComboBox153.Name = "SolvencyDataComboBox153";
this.SolvencyDataComboBox153.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox153.TabIndex = 153;
this.SolvencyDataComboBox153.ColName = "R0080C0010";
this.SolvencyDataComboBox153.AxisID = 2;
this.SolvencyDataComboBox153.OrdinateID = 9;
this.SolvencyDataComboBox153.StartOrder = 0;
this.SolvencyDataComboBox153.NextOrder = 0;
//
// SolvencyDataComboBox154
//
this.SolvencyDataComboBox154.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox154.Location = new System.Drawing.Point(10,202);
this.SolvencyDataComboBox154.Name = "SolvencyDataComboBox154";
this.SolvencyDataComboBox154.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox154.TabIndex = 154;
this.SolvencyDataComboBox154.ColName = "R0090C0010";
this.SolvencyDataComboBox154.AxisID = 2;
this.SolvencyDataComboBox154.OrdinateID = 10;
this.SolvencyDataComboBox154.StartOrder = 0;
this.SolvencyDataComboBox154.NextOrder = 0;
//
// SolvencyDataComboBox155
//
this.SolvencyDataComboBox155.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox155.Location = new System.Drawing.Point(10,222);
this.SolvencyDataComboBox155.Name = "SolvencyDataComboBox155";
this.SolvencyDataComboBox155.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox155.TabIndex = 155;
this.SolvencyDataComboBox155.ColName = "R0100C0010";
this.SolvencyDataComboBox155.AxisID = 2;
this.SolvencyDataComboBox155.OrdinateID = 11;
this.SolvencyDataComboBox155.StartOrder = 0;
this.SolvencyDataComboBox155.NextOrder = 0;
//
// SolvencyDataComboBox156
//
this.SolvencyDataComboBox156.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox156.Location = new System.Drawing.Point(10,255);
this.SolvencyDataComboBox156.Name = "SolvencyDataComboBox156";
this.SolvencyDataComboBox156.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox156.TabIndex = 156;
this.SolvencyDataComboBox156.ColName = "R0110C0010";
this.SolvencyDataComboBox156.AxisID = 2;
this.SolvencyDataComboBox156.OrdinateID = 12;
this.SolvencyDataComboBox156.StartOrder = 0;
this.SolvencyDataComboBox156.NextOrder = 0;
//
// SolvencyDataComboBox157
//
this.SolvencyDataComboBox157.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox157.Location = new System.Drawing.Point(10,288);
this.SolvencyDataComboBox157.Name = "SolvencyDataComboBox157";
this.SolvencyDataComboBox157.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox157.TabIndex = 157;
this.SolvencyDataComboBox157.ColName = "R0120C0010";
this.SolvencyDataComboBox157.AxisID = 2;
this.SolvencyDataComboBox157.OrdinateID = 13;
this.SolvencyDataComboBox157.StartOrder = 0;
this.SolvencyDataComboBox157.NextOrder = 0;
//
// SolvencyDataComboBox158
//
this.SolvencyDataComboBox158.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox158.Location = new System.Drawing.Point(10,321);
this.SolvencyDataComboBox158.Name = "SolvencyDataComboBox158";
this.SolvencyDataComboBox158.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox158.TabIndex = 158;
this.SolvencyDataComboBox158.ColName = "R0130C0010";
this.SolvencyDataComboBox158.AxisID = 2;
this.SolvencyDataComboBox158.OrdinateID = 14;
this.SolvencyDataComboBox158.StartOrder = 0;
this.SolvencyDataComboBox158.NextOrder = 0;
//
// SolvencyDataComboBox159
//
this.SolvencyDataComboBox159.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox159.Location = new System.Drawing.Point(10,341);
this.SolvencyDataComboBox159.Name = "SolvencyDataComboBox159";
this.SolvencyDataComboBox159.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox159.TabIndex = 159;
this.SolvencyDataComboBox159.ColName = "R0140C0010";
this.SolvencyDataComboBox159.AxisID = 2;
this.SolvencyDataComboBox159.OrdinateID = 15;
this.SolvencyDataComboBox159.StartOrder = 0;
this.SolvencyDataComboBox159.NextOrder = 0;
//
// SolvencyDataComboBox160
//
this.SolvencyDataComboBox160.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox160.Location = new System.Drawing.Point(10,361);
this.SolvencyDataComboBox160.Name = "SolvencyDataComboBox160";
this.SolvencyDataComboBox160.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox160.TabIndex = 160;
this.SolvencyDataComboBox160.ColName = "R0150C0010";
this.SolvencyDataComboBox160.AxisID = 2;
this.SolvencyDataComboBox160.OrdinateID = 16;
this.SolvencyDataComboBox160.StartOrder = 0;
this.SolvencyDataComboBox160.NextOrder = 0;
//
// SolvencyDataComboBox161
//
this.SolvencyDataComboBox161.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox161.Location = new System.Drawing.Point(10,394);
this.SolvencyDataComboBox161.Name = "SolvencyDataComboBox161";
this.SolvencyDataComboBox161.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox161.TabIndex = 161;
this.SolvencyDataComboBox161.ColName = "R0160C0010";
this.SolvencyDataComboBox161.AxisID = 2;
this.SolvencyDataComboBox161.OrdinateID = 17;
this.SolvencyDataComboBox161.StartOrder = 0;
this.SolvencyDataComboBox161.NextOrder = 0;
//
// SolvencyDataComboBox162
//
this.SolvencyDataComboBox162.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox162.Location = new System.Drawing.Point(10,414);
this.SolvencyDataComboBox162.Name = "SolvencyDataComboBox162";
this.SolvencyDataComboBox162.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox162.TabIndex = 162;
this.SolvencyDataComboBox162.ColName = "R0170C0010";
this.SolvencyDataComboBox162.AxisID = 2;
this.SolvencyDataComboBox162.OrdinateID = 18;
this.SolvencyDataComboBox162.StartOrder = 0;
this.SolvencyDataComboBox162.NextOrder = 0;
//
// SolvencyDataComboBox163
//
this.SolvencyDataComboBox163.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox163.Location = new System.Drawing.Point(10,434);
this.SolvencyDataComboBox163.Name = "SolvencyDataComboBox163";
this.SolvencyDataComboBox163.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox163.TabIndex = 163;
this.SolvencyDataComboBox163.ColName = "R0180C0010";
this.SolvencyDataComboBox163.AxisID = 2;
this.SolvencyDataComboBox163.OrdinateID = 19;
this.SolvencyDataComboBox163.StartOrder = 0;
this.SolvencyDataComboBox163.NextOrder = 0;
//
// SolvencyDataComboBox164
//
this.SolvencyDataComboBox164.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox164.Location = new System.Drawing.Point(10,454);
this.SolvencyDataComboBox164.Name = "SolvencyDataComboBox164";
this.SolvencyDataComboBox164.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox164.TabIndex = 164;
this.SolvencyDataComboBox164.ColName = "R0190C0010";
this.SolvencyDataComboBox164.AxisID = 2;
this.SolvencyDataComboBox164.OrdinateID = 20;
this.SolvencyDataComboBox164.StartOrder = 0;
this.SolvencyDataComboBox164.NextOrder = 0;
//
// SolvencyDataComboBox165
//
this.SolvencyDataComboBox165.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox165.Location = new System.Drawing.Point(10,474);
this.SolvencyDataComboBox165.Name = "SolvencyDataComboBox165";
this.SolvencyDataComboBox165.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox165.TabIndex = 165;
this.SolvencyDataComboBox165.ColName = "R0200C0010";
this.SolvencyDataComboBox165.AxisID = 2;
this.SolvencyDataComboBox165.OrdinateID = 21;
this.SolvencyDataComboBox165.StartOrder = 0;
this.SolvencyDataComboBox165.NextOrder = 0;
//
// SolvencyDataComboBox166
//
this.SolvencyDataComboBox166.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox166.Location = new System.Drawing.Point(10,494);
this.SolvencyDataComboBox166.Name = "SolvencyDataComboBox166";
this.SolvencyDataComboBox166.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox166.TabIndex = 166;
this.SolvencyDataComboBox166.ColName = "R0210C0010";
this.SolvencyDataComboBox166.AxisID = 2;
this.SolvencyDataComboBox166.OrdinateID = 22;
this.SolvencyDataComboBox166.StartOrder = 0;
this.SolvencyDataComboBox166.NextOrder = 0;
//
// SolvencyDataComboBox167
//
this.SolvencyDataComboBox167.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox167.Location = new System.Drawing.Point(10,514);
this.SolvencyDataComboBox167.Name = "SolvencyDataComboBox167";
this.SolvencyDataComboBox167.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox167.TabIndex = 167;
this.SolvencyDataComboBox167.ColName = "R0220C0010";
this.SolvencyDataComboBox167.AxisID = 2;
this.SolvencyDataComboBox167.OrdinateID = 23;
this.SolvencyDataComboBox167.StartOrder = 0;
this.SolvencyDataComboBox167.NextOrder = 0;
//
// SolvencyDataComboBox168
//
this.SolvencyDataComboBox168.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox168.Location = new System.Drawing.Point(10,547);
this.SolvencyDataComboBox168.Name = "SolvencyDataComboBox168";
this.SolvencyDataComboBox168.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox168.TabIndex = 168;
this.SolvencyDataComboBox168.ColName = "R0230C0010";
this.SolvencyDataComboBox168.AxisID = 2;
this.SolvencyDataComboBox168.OrdinateID = 24;
this.SolvencyDataComboBox168.StartOrder = 0;
this.SolvencyDataComboBox168.NextOrder = 0;
//
// SolvencyDataComboBox169
//
this.SolvencyDataComboBox169.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox169.Location = new System.Drawing.Point(10,580);
this.SolvencyDataComboBox169.Name = "SolvencyDataComboBox169";
this.SolvencyDataComboBox169.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox169.TabIndex = 169;
this.SolvencyDataComboBox169.ColName = "R0240C0010";
this.SolvencyDataComboBox169.AxisID = 2;
this.SolvencyDataComboBox169.OrdinateID = 25;
this.SolvencyDataComboBox169.StartOrder = 0;
this.SolvencyDataComboBox169.NextOrder = 0;
//
// SolvencyDataComboBox170
//
this.SolvencyDataComboBox170.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox170.Location = new System.Drawing.Point(10,600);
this.SolvencyDataComboBox170.Name = "SolvencyDataComboBox170";
this.SolvencyDataComboBox170.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox170.TabIndex = 170;
this.SolvencyDataComboBox170.ColName = "R0250C0010";
this.SolvencyDataComboBox170.AxisID = 2;
this.SolvencyDataComboBox170.OrdinateID = 26;
this.SolvencyDataComboBox170.StartOrder = 0;
this.SolvencyDataComboBox170.NextOrder = 0;
//
// SolvencyDataComboBox171
//
this.SolvencyDataComboBox171.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox171.Location = new System.Drawing.Point(10,620);
this.SolvencyDataComboBox171.Name = "SolvencyDataComboBox171";
this.SolvencyDataComboBox171.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox171.TabIndex = 171;
this.SolvencyDataComboBox171.ColName = "R0260C0010";
this.SolvencyDataComboBox171.AxisID = 2;
this.SolvencyDataComboBox171.OrdinateID = 27;
this.SolvencyDataComboBox171.StartOrder = 0;
this.SolvencyDataComboBox171.NextOrder = 0;
//
// SolvencyDataComboBox172
//
this.SolvencyDataComboBox172.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox172.Location = new System.Drawing.Point(10,653);
this.SolvencyDataComboBox172.Name = "SolvencyDataComboBox172";
this.SolvencyDataComboBox172.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox172.TabIndex = 172;
this.SolvencyDataComboBox172.ColName = "R0270C0010";
this.SolvencyDataComboBox172.AxisID = 2;
this.SolvencyDataComboBox172.OrdinateID = 28;
this.SolvencyDataComboBox172.StartOrder = 0;
this.SolvencyDataComboBox172.NextOrder = 0;
//
// SolvencyDataComboBox173
//
this.SolvencyDataComboBox173.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox173.Location = new System.Drawing.Point(10,686);
this.SolvencyDataComboBox173.Name = "SolvencyDataComboBox173";
this.SolvencyDataComboBox173.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox173.TabIndex = 173;
this.SolvencyDataComboBox173.ColName = "R0280C0010";
this.SolvencyDataComboBox173.AxisID = 2;
this.SolvencyDataComboBox173.OrdinateID = 29;
this.SolvencyDataComboBox173.StartOrder = 0;
this.SolvencyDataComboBox173.NextOrder = 0;
//
// SolvencyDataComboBox174
//
this.SolvencyDataComboBox174.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox174.Location = new System.Drawing.Point(10,719);
this.SolvencyDataComboBox174.Name = "SolvencyDataComboBox174";
this.SolvencyDataComboBox174.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox174.TabIndex = 174;
this.SolvencyDataComboBox174.ColName = "R0290C0010";
this.SolvencyDataComboBox174.AxisID = 2;
this.SolvencyDataComboBox174.OrdinateID = 30;
this.SolvencyDataComboBox174.StartOrder = 0;
this.SolvencyDataComboBox174.NextOrder = 0;
//
// SolvencyDataComboBox175
//
this.SolvencyDataComboBox175.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox175.Location = new System.Drawing.Point(10,739);
this.SolvencyDataComboBox175.Name = "SolvencyDataComboBox175";
this.SolvencyDataComboBox175.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox175.TabIndex = 175;
this.SolvencyDataComboBox175.ColName = "R0300C0010";
this.SolvencyDataComboBox175.AxisID = 2;
this.SolvencyDataComboBox175.OrdinateID = 31;
this.SolvencyDataComboBox175.StartOrder = 0;
this.SolvencyDataComboBox175.NextOrder = 0;
//
// SolvencyDataComboBox176
//
this.SolvencyDataComboBox176.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox176.Location = new System.Drawing.Point(10,772);
this.SolvencyDataComboBox176.Name = "SolvencyDataComboBox176";
this.SolvencyDataComboBox176.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox176.TabIndex = 176;
this.SolvencyDataComboBox176.ColName = "R0310C0010";
this.SolvencyDataComboBox176.AxisID = 2;
this.SolvencyDataComboBox176.OrdinateID = 32;
this.SolvencyDataComboBox176.StartOrder = 0;
this.SolvencyDataComboBox176.NextOrder = 0;
//
// SolvencyDataComboBox177
//
this.SolvencyDataComboBox177.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox177.Location = new System.Drawing.Point(10,805);
this.SolvencyDataComboBox177.Name = "SolvencyDataComboBox177";
this.SolvencyDataComboBox177.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox177.TabIndex = 177;
this.SolvencyDataComboBox177.ColName = "R0320C0010";
this.SolvencyDataComboBox177.AxisID = 2;
this.SolvencyDataComboBox177.OrdinateID = 33;
this.SolvencyDataComboBox177.StartOrder = 0;
this.SolvencyDataComboBox177.NextOrder = 0;
//
// SolvencyDataComboBox178
//
this.SolvencyDataComboBox178.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox178.Location = new System.Drawing.Point(10,825);
this.SolvencyDataComboBox178.Name = "SolvencyDataComboBox178";
this.SolvencyDataComboBox178.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox178.TabIndex = 178;
this.SolvencyDataComboBox178.ColName = "R0330C0010";
this.SolvencyDataComboBox178.AxisID = 2;
this.SolvencyDataComboBox178.OrdinateID = 34;
this.SolvencyDataComboBox178.StartOrder = 0;
this.SolvencyDataComboBox178.NextOrder = 0;
//
// SolvencyDataComboBox179
//
this.SolvencyDataComboBox179.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox179.Location = new System.Drawing.Point(10,858);
this.SolvencyDataComboBox179.Name = "SolvencyDataComboBox179";
this.SolvencyDataComboBox179.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox179.TabIndex = 179;
this.SolvencyDataComboBox179.ColName = "R0340C0010";
this.SolvencyDataComboBox179.AxisID = 2;
this.SolvencyDataComboBox179.OrdinateID = 35;
this.SolvencyDataComboBox179.StartOrder = 0;
this.SolvencyDataComboBox179.NextOrder = 0;
//
// SolvencyDataComboBox180
//
this.SolvencyDataComboBox180.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox180.Location = new System.Drawing.Point(10,878);
this.SolvencyDataComboBox180.Name = "SolvencyDataComboBox180";
this.SolvencyDataComboBox180.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox180.TabIndex = 180;
this.SolvencyDataComboBox180.ColName = "R0350C0010";
this.SolvencyDataComboBox180.AxisID = 2;
this.SolvencyDataComboBox180.OrdinateID = 36;
this.SolvencyDataComboBox180.StartOrder = 0;
this.SolvencyDataComboBox180.NextOrder = 0;
//
// SolvencyDataComboBox181
//
this.SolvencyDataComboBox181.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox181.Location = new System.Drawing.Point(10,898);
this.SolvencyDataComboBox181.Name = "SolvencyDataComboBox181";
this.SolvencyDataComboBox181.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox181.TabIndex = 181;
this.SolvencyDataComboBox181.ColName = "R0360C0010";
this.SolvencyDataComboBox181.AxisID = 2;
this.SolvencyDataComboBox181.OrdinateID = 37;
this.SolvencyDataComboBox181.StartOrder = 0;
this.SolvencyDataComboBox181.NextOrder = 0;
//
// SolvencyDataComboBox182
//
this.SolvencyDataComboBox182.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox182.Location = new System.Drawing.Point(10,931);
this.SolvencyDataComboBox182.Name = "SolvencyDataComboBox182";
this.SolvencyDataComboBox182.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox182.TabIndex = 182;
this.SolvencyDataComboBox182.ColName = "R0370C0010";
this.SolvencyDataComboBox182.AxisID = 2;
this.SolvencyDataComboBox182.OrdinateID = 38;
this.SolvencyDataComboBox182.StartOrder = 0;
this.SolvencyDataComboBox182.NextOrder = 0;
//
// SolvencyDataComboBox183
//
this.SolvencyDataComboBox183.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox183.Location = new System.Drawing.Point(10,964);
this.SolvencyDataComboBox183.Name = "SolvencyDataComboBox183";
this.SolvencyDataComboBox183.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox183.TabIndex = 183;
this.SolvencyDataComboBox183.ColName = "R0380C0010";
this.SolvencyDataComboBox183.AxisID = 2;
this.SolvencyDataComboBox183.OrdinateID = 39;
this.SolvencyDataComboBox183.StartOrder = 0;
this.SolvencyDataComboBox183.NextOrder = 0;
//
// SolvencyDataComboBox184
//
this.SolvencyDataComboBox184.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox184.Location = new System.Drawing.Point(10,997);
this.SolvencyDataComboBox184.Name = "SolvencyDataComboBox184";
this.SolvencyDataComboBox184.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox184.TabIndex = 184;
this.SolvencyDataComboBox184.ColName = "R0390C0010";
this.SolvencyDataComboBox184.AxisID = 2;
this.SolvencyDataComboBox184.OrdinateID = 40;
this.SolvencyDataComboBox184.StartOrder = 0;
this.SolvencyDataComboBox184.NextOrder = 0;
//
// SolvencyDataComboBox185
//
this.SolvencyDataComboBox185.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox185.Location = new System.Drawing.Point(10,1030);
this.SolvencyDataComboBox185.Name = "SolvencyDataComboBox185";
this.SolvencyDataComboBox185.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox185.TabIndex = 185;
this.SolvencyDataComboBox185.ColName = "R0400C0010";
this.SolvencyDataComboBox185.AxisID = 2;
this.SolvencyDataComboBox185.OrdinateID = 41;
this.SolvencyDataComboBox185.StartOrder = 0;
this.SolvencyDataComboBox185.NextOrder = 0;
//
// SolvencyDataComboBox186
//
this.SolvencyDataComboBox186.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox186.Location = new System.Drawing.Point(10,1063);
this.SolvencyDataComboBox186.Name = "SolvencyDataComboBox186";
this.SolvencyDataComboBox186.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox186.TabIndex = 186;
this.SolvencyDataComboBox186.ColName = "R0410C0010";
this.SolvencyDataComboBox186.AxisID = 2;
this.SolvencyDataComboBox186.OrdinateID = 42;
this.SolvencyDataComboBox186.StartOrder = 0;
this.SolvencyDataComboBox186.NextOrder = 0;
//
// SolvencyDataComboBox187
//
this.SolvencyDataComboBox187.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox187.Location = new System.Drawing.Point(10,1083);
this.SolvencyDataComboBox187.Name = "SolvencyDataComboBox187";
this.SolvencyDataComboBox187.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox187.TabIndex = 187;
this.SolvencyDataComboBox187.ColName = "R0420C0010";
this.SolvencyDataComboBox187.AxisID = 2;
this.SolvencyDataComboBox187.OrdinateID = 43;
this.SolvencyDataComboBox187.StartOrder = 0;
this.SolvencyDataComboBox187.NextOrder = 0;
//
// SolvencyDataComboBox188
//
this.SolvencyDataComboBox188.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox188.Location = new System.Drawing.Point(10,1116);
this.SolvencyDataComboBox188.Name = "SolvencyDataComboBox188";
this.SolvencyDataComboBox188.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox188.TabIndex = 188;
this.SolvencyDataComboBox188.ColName = "R0430C0010";
this.SolvencyDataComboBox188.AxisID = 2;
this.SolvencyDataComboBox188.OrdinateID = 44;
this.SolvencyDataComboBox188.StartOrder = 0;
this.SolvencyDataComboBox188.NextOrder = 0;
//
// SolvencyDataComboBox189
//
this.SolvencyDataComboBox189.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox189.Location = new System.Drawing.Point(10,1136);
this.SolvencyDataComboBox189.Name = "SolvencyDataComboBox189";
this.SolvencyDataComboBox189.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox189.TabIndex = 189;
this.SolvencyDataComboBox189.ColName = "R0440C0010";
this.SolvencyDataComboBox189.AxisID = 2;
this.SolvencyDataComboBox189.OrdinateID = 45;
this.SolvencyDataComboBox189.StartOrder = 0;
this.SolvencyDataComboBox189.NextOrder = 0;
//
// SolvencyDataComboBox190
//
this.SolvencyDataComboBox190.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox190.Location = new System.Drawing.Point(10,1156);
this.SolvencyDataComboBox190.Name = "SolvencyDataComboBox190";
this.SolvencyDataComboBox190.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox190.TabIndex = 190;
this.SolvencyDataComboBox190.ColName = "R0450C0010";
this.SolvencyDataComboBox190.AxisID = 2;
this.SolvencyDataComboBox190.OrdinateID = 46;
this.SolvencyDataComboBox190.StartOrder = 0;
this.SolvencyDataComboBox190.NextOrder = 0;
//
// SolvencyDataComboBox191
//
this.SolvencyDataComboBox191.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox191.Location = new System.Drawing.Point(10,1176);
this.SolvencyDataComboBox191.Name = "SolvencyDataComboBox191";
this.SolvencyDataComboBox191.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox191.TabIndex = 191;
this.SolvencyDataComboBox191.ColName = "R0460C0010";
this.SolvencyDataComboBox191.AxisID = 2;
this.SolvencyDataComboBox191.OrdinateID = 47;
this.SolvencyDataComboBox191.StartOrder = 0;
this.SolvencyDataComboBox191.NextOrder = 0;
//
// SolvencyDataComboBox192
//
this.SolvencyDataComboBox192.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox192.Location = new System.Drawing.Point(10,1209);
this.SolvencyDataComboBox192.Name = "SolvencyDataComboBox192";
this.SolvencyDataComboBox192.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox192.TabIndex = 192;
this.SolvencyDataComboBox192.ColName = "R0470C0010";
this.SolvencyDataComboBox192.AxisID = 2;
this.SolvencyDataComboBox192.OrdinateID = 48;
this.SolvencyDataComboBox192.StartOrder = 0;
this.SolvencyDataComboBox192.NextOrder = 0;
//
// SolvencyDataComboBox193
//
this.SolvencyDataComboBox193.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox193.Location = new System.Drawing.Point(10,1257);
this.SolvencyDataComboBox193.Name = "SolvencyDataComboBox193";
this.SolvencyDataComboBox193.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox193.TabIndex = 193;
this.SolvencyDataComboBox193.ColName = "R0480C0010";
this.SolvencyDataComboBox193.AxisID = 2;
this.SolvencyDataComboBox193.OrdinateID = 49;
this.SolvencyDataComboBox193.StartOrder = 0;
this.SolvencyDataComboBox193.NextOrder = 0;
//
// SolvencyDataComboBox194
//
this.SolvencyDataComboBox194.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox194.Location = new System.Drawing.Point(10,1290);
this.SolvencyDataComboBox194.Name = "SolvencyDataComboBox194";
this.SolvencyDataComboBox194.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox194.TabIndex = 194;
this.SolvencyDataComboBox194.ColName = "R0500C0010";
this.SolvencyDataComboBox194.AxisID = 2;
this.SolvencyDataComboBox194.OrdinateID = 50;
this.SolvencyDataComboBox194.StartOrder = 0;
this.SolvencyDataComboBox194.NextOrder = 0;
//
// SolvencyDataComboBox195
//
this.SolvencyDataComboBox195.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox195.Location = new System.Drawing.Point(10,1323);
this.SolvencyDataComboBox195.Name = "SolvencyDataComboBox195";
this.SolvencyDataComboBox195.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox195.TabIndex = 195;
this.SolvencyDataComboBox195.ColName = "R0510C0010";
this.SolvencyDataComboBox195.AxisID = 2;
this.SolvencyDataComboBox195.OrdinateID = 51;
this.SolvencyDataComboBox195.StartOrder = 0;
this.SolvencyDataComboBox195.NextOrder = 0;
//
// SolvencyDataComboBox196
//
this.SolvencyDataComboBox196.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox196.Location = new System.Drawing.Point(10,1356);
this.SolvencyDataComboBox196.Name = "SolvencyDataComboBox196";
this.SolvencyDataComboBox196.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox196.TabIndex = 196;
this.SolvencyDataComboBox196.ColName = "R0520C0010";
this.SolvencyDataComboBox196.AxisID = 2;
this.SolvencyDataComboBox196.OrdinateID = 52;
this.SolvencyDataComboBox196.StartOrder = 0;
this.SolvencyDataComboBox196.NextOrder = 0;
//
// SolvencyDataComboBox197
//
this.SolvencyDataComboBox197.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox197.Location = new System.Drawing.Point(10,1389);
this.SolvencyDataComboBox197.Name = "SolvencyDataComboBox197";
this.SolvencyDataComboBox197.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox197.TabIndex = 197;
this.SolvencyDataComboBox197.ColName = "R0530C0010";
this.SolvencyDataComboBox197.AxisID = 2;
this.SolvencyDataComboBox197.OrdinateID = 53;
this.SolvencyDataComboBox197.StartOrder = 0;
this.SolvencyDataComboBox197.NextOrder = 0;
//
// SolvencyDataComboBox198
//
this.SolvencyDataComboBox198.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox198.Location = new System.Drawing.Point(10,1422);
this.SolvencyDataComboBox198.Name = "SolvencyDataComboBox198";
this.SolvencyDataComboBox198.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox198.TabIndex = 198;
this.SolvencyDataComboBox198.ColName = "R0540C0010";
this.SolvencyDataComboBox198.AxisID = 2;
this.SolvencyDataComboBox198.OrdinateID = 54;
this.SolvencyDataComboBox198.StartOrder = 0;
this.SolvencyDataComboBox198.NextOrder = 0;
//
// SolvencyDataComboBox199
//
this.SolvencyDataComboBox199.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox199.Location = new System.Drawing.Point(10,1455);
this.SolvencyDataComboBox199.Name = "SolvencyDataComboBox199";
this.SolvencyDataComboBox199.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox199.TabIndex = 199;
this.SolvencyDataComboBox199.ColName = "R0550C0010";
this.SolvencyDataComboBox199.AxisID = 2;
this.SolvencyDataComboBox199.OrdinateID = 55;
this.SolvencyDataComboBox199.StartOrder = 0;
this.SolvencyDataComboBox199.NextOrder = 0;
//
// SolvencyDataComboBox200
//
this.SolvencyDataComboBox200.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox200.Location = new System.Drawing.Point(10,1488);
this.SolvencyDataComboBox200.Name = "SolvencyDataComboBox200";
this.SolvencyDataComboBox200.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox200.TabIndex = 200;
this.SolvencyDataComboBox200.ColName = "R0560C0010";
this.SolvencyDataComboBox200.AxisID = 2;
this.SolvencyDataComboBox200.OrdinateID = 56;
this.SolvencyDataComboBox200.StartOrder = 0;
this.SolvencyDataComboBox200.NextOrder = 0;
//
// SolvencyDataComboBox201
//
this.SolvencyDataComboBox201.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox201.Location = new System.Drawing.Point(10,1521);
this.SolvencyDataComboBox201.Name = "SolvencyDataComboBox201";
this.SolvencyDataComboBox201.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox201.TabIndex = 201;
this.SolvencyDataComboBox201.ColName = "R0570C0010";
this.SolvencyDataComboBox201.AxisID = 2;
this.SolvencyDataComboBox201.OrdinateID = 57;
this.SolvencyDataComboBox201.StartOrder = 0;
this.SolvencyDataComboBox201.NextOrder = 0;
//
// SolvencyDataComboBox202
//
this.SolvencyDataComboBox202.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox202.Location = new System.Drawing.Point(10,1554);
this.SolvencyDataComboBox202.Name = "SolvencyDataComboBox202";
this.SolvencyDataComboBox202.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox202.TabIndex = 202;
this.SolvencyDataComboBox202.ColName = "R0580C0010";
this.SolvencyDataComboBox202.AxisID = 2;
this.SolvencyDataComboBox202.OrdinateID = 58;
this.SolvencyDataComboBox202.StartOrder = 0;
this.SolvencyDataComboBox202.NextOrder = 0;
//
// SolvencyDataComboBox203
//
this.SolvencyDataComboBox203.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox203.Location = new System.Drawing.Point(10,1587);
this.SolvencyDataComboBox203.Name = "SolvencyDataComboBox203";
this.SolvencyDataComboBox203.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox203.TabIndex = 203;
this.SolvencyDataComboBox203.ColName = "R0590C0010";
this.SolvencyDataComboBox203.AxisID = 2;
this.SolvencyDataComboBox203.OrdinateID = 59;
this.SolvencyDataComboBox203.StartOrder = 0;
this.SolvencyDataComboBox203.NextOrder = 0;
//
// SolvencyDataComboBox204
//
this.SolvencyDataComboBox204.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox204.Location = new System.Drawing.Point(10,1620);
this.SolvencyDataComboBox204.Name = "SolvencyDataComboBox204";
this.SolvencyDataComboBox204.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox204.TabIndex = 204;
this.SolvencyDataComboBox204.ColName = "R0600C0010";
this.SolvencyDataComboBox204.AxisID = 2;
this.SolvencyDataComboBox204.OrdinateID = 60;
this.SolvencyDataComboBox204.StartOrder = 0;
this.SolvencyDataComboBox204.NextOrder = 0;
//
// SolvencyDataComboBox205
//
this.SolvencyDataComboBox205.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox205.Location = new System.Drawing.Point(10,1640);
this.SolvencyDataComboBox205.Name = "SolvencyDataComboBox205";
this.SolvencyDataComboBox205.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox205.TabIndex = 205;
this.SolvencyDataComboBox205.ColName = "R0610C0010";
this.SolvencyDataComboBox205.AxisID = 2;
this.SolvencyDataComboBox205.OrdinateID = 61;
this.SolvencyDataComboBox205.StartOrder = 0;
this.SolvencyDataComboBox205.NextOrder = 0;
//
// SolvencyDataComboBox206
//
this.SolvencyDataComboBox206.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox206.Location = new System.Drawing.Point(10,1673);
this.SolvencyDataComboBox206.Name = "SolvencyDataComboBox206";
this.SolvencyDataComboBox206.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox206.TabIndex = 206;
this.SolvencyDataComboBox206.ColName = "R0620C0010";
this.SolvencyDataComboBox206.AxisID = 2;
this.SolvencyDataComboBox206.OrdinateID = 62;
this.SolvencyDataComboBox206.StartOrder = 0;
this.SolvencyDataComboBox206.NextOrder = 0;
//
// SolvencyDataComboBox207
//
this.SolvencyDataComboBox207.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox207.Location = new System.Drawing.Point(10,1706);
this.SolvencyDataComboBox207.Name = "SolvencyDataComboBox207";
this.SolvencyDataComboBox207.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox207.TabIndex = 207;
this.SolvencyDataComboBox207.ColName = "R0630C0010";
this.SolvencyDataComboBox207.AxisID = 2;
this.SolvencyDataComboBox207.OrdinateID = 63;
this.SolvencyDataComboBox207.StartOrder = 0;
this.SolvencyDataComboBox207.NextOrder = 0;
//
// SolvencyDataComboBox208
//
this.SolvencyDataComboBox208.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox208.Location = new System.Drawing.Point(10,1739);
this.SolvencyDataComboBox208.Name = "SolvencyDataComboBox208";
this.SolvencyDataComboBox208.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox208.TabIndex = 208;
this.SolvencyDataComboBox208.ColName = "R0640C0010";
this.SolvencyDataComboBox208.AxisID = 2;
this.SolvencyDataComboBox208.OrdinateID = 64;
this.SolvencyDataComboBox208.StartOrder = 0;
this.SolvencyDataComboBox208.NextOrder = 0;
//
// SolvencyDataComboBox209
//
this.SolvencyDataComboBox209.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox209.Location = new System.Drawing.Point(10,1772);
this.SolvencyDataComboBox209.Name = "SolvencyDataComboBox209";
this.SolvencyDataComboBox209.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox209.TabIndex = 209;
this.SolvencyDataComboBox209.ColName = "R0650C0010";
this.SolvencyDataComboBox209.AxisID = 2;
this.SolvencyDataComboBox209.OrdinateID = 65;
this.SolvencyDataComboBox209.StartOrder = 0;
this.SolvencyDataComboBox209.NextOrder = 0;
//
// SolvencyDataComboBox210
//
this.SolvencyDataComboBox210.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox210.Location = new System.Drawing.Point(10,1805);
this.SolvencyDataComboBox210.Name = "SolvencyDataComboBox210";
this.SolvencyDataComboBox210.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox210.TabIndex = 210;
this.SolvencyDataComboBox210.ColName = "R0660C0010";
this.SolvencyDataComboBox210.AxisID = 2;
this.SolvencyDataComboBox210.OrdinateID = 66;
this.SolvencyDataComboBox210.StartOrder = 0;
this.SolvencyDataComboBox210.NextOrder = 0;
//
// SolvencyDataComboBox211
//
this.SolvencyDataComboBox211.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox211.Location = new System.Drawing.Point(10,1838);
this.SolvencyDataComboBox211.Name = "SolvencyDataComboBox211";
this.SolvencyDataComboBox211.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox211.TabIndex = 211;
this.SolvencyDataComboBox211.ColName = "R0670C0010";
this.SolvencyDataComboBox211.AxisID = 2;
this.SolvencyDataComboBox211.OrdinateID = 67;
this.SolvencyDataComboBox211.StartOrder = 0;
this.SolvencyDataComboBox211.NextOrder = 0;
//
// SolvencyDataComboBox212
//
this.SolvencyDataComboBox212.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox212.Location = new System.Drawing.Point(10,1871);
this.SolvencyDataComboBox212.Name = "SolvencyDataComboBox212";
this.SolvencyDataComboBox212.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox212.TabIndex = 212;
this.SolvencyDataComboBox212.ColName = "R0680C0010";
this.SolvencyDataComboBox212.AxisID = 2;
this.SolvencyDataComboBox212.OrdinateID = 68;
this.SolvencyDataComboBox212.StartOrder = 0;
this.SolvencyDataComboBox212.NextOrder = 0;
//
// SolvencyDataComboBox213
//
this.SolvencyDataComboBox213.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox213.Location = new System.Drawing.Point(10,1904);
this.SolvencyDataComboBox213.Name = "SolvencyDataComboBox213";
this.SolvencyDataComboBox213.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox213.TabIndex = 213;
this.SolvencyDataComboBox213.ColName = "R0690C0010";
this.SolvencyDataComboBox213.AxisID = 2;
this.SolvencyDataComboBox213.OrdinateID = 69;
this.SolvencyDataComboBox213.StartOrder = 0;
this.SolvencyDataComboBox213.NextOrder = 0;
//
// SolvencyDataComboBox214
//
this.SolvencyDataComboBox214.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox214.Location = new System.Drawing.Point(10,1924);
this.SolvencyDataComboBox214.Name = "SolvencyDataComboBox214";
this.SolvencyDataComboBox214.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox214.TabIndex = 214;
this.SolvencyDataComboBox214.ColName = "R0740C0010";
this.SolvencyDataComboBox214.AxisID = 2;
this.SolvencyDataComboBox214.OrdinateID = 70;
this.SolvencyDataComboBox214.StartOrder = 0;
this.SolvencyDataComboBox214.NextOrder = 0;
//
// SolvencyDataComboBox215
//
this.SolvencyDataComboBox215.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox215.Location = new System.Drawing.Point(10,1957);
this.SolvencyDataComboBox215.Name = "SolvencyDataComboBox215";
this.SolvencyDataComboBox215.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox215.TabIndex = 215;
this.SolvencyDataComboBox215.ColName = "R0750C0010";
this.SolvencyDataComboBox215.AxisID = 2;
this.SolvencyDataComboBox215.OrdinateID = 71;
this.SolvencyDataComboBox215.StartOrder = 0;
this.SolvencyDataComboBox215.NextOrder = 0;
//
// SolvencyDataComboBox216
//
this.SolvencyDataComboBox216.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox216.Location = new System.Drawing.Point(10,1977);
this.SolvencyDataComboBox216.Name = "SolvencyDataComboBox216";
this.SolvencyDataComboBox216.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox216.TabIndex = 216;
this.SolvencyDataComboBox216.ColName = "R0760C0010";
this.SolvencyDataComboBox216.AxisID = 2;
this.SolvencyDataComboBox216.OrdinateID = 72;
this.SolvencyDataComboBox216.StartOrder = 0;
this.SolvencyDataComboBox216.NextOrder = 0;
//
// SolvencyDataComboBox217
//
this.SolvencyDataComboBox217.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox217.Location = new System.Drawing.Point(10,1997);
this.SolvencyDataComboBox217.Name = "SolvencyDataComboBox217";
this.SolvencyDataComboBox217.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox217.TabIndex = 217;
this.SolvencyDataComboBox217.ColName = "R0770C0010";
this.SolvencyDataComboBox217.AxisID = 2;
this.SolvencyDataComboBox217.OrdinateID = 73;
this.SolvencyDataComboBox217.StartOrder = 0;
this.SolvencyDataComboBox217.NextOrder = 0;
//
// splitContainerColTitles
//
this.splitContainerColTitles.Dock = System.Windows.Forms.DockStyle.Fill;
this.splitContainerColTitles.Location = new System.Drawing.Point(0,0);
this.splitContainerColTitles.Name = "splitContainerColTitles";
this.splitContainerColTitles.Orientation = System.Windows.Forms.Orientation.Vertical;
this.splitContainerColTitles.Panel1MinSize = 0;
//
// splitContainerColTitles.Panel1
//
//
// splitContainerColTitles.Panel2
//
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel1);
this.splitContainerColTitles.Size = new System.Drawing.Size(756, 382);
this.splitContainerColTitles.SplitterDistance = 332;
//
// splitContainerRowTitles
//
this.splitContainerRowTitles.Dock = System.Windows.Forms.DockStyle.Fill;
this.splitContainerRowTitles.Location = new System.Drawing.Point(0,0);
this.splitContainerRowTitles.Name = "splitContainerRowTitles";
this.splitContainerRowTitles.Orientation = System.Windows.Forms.Orientation.Vertical;
this.splitContainerRowTitles.Panel1MinSize = 0;
//
// splitContainerRowTitles.Panel1
//
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel2);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel3);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel4);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel5);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel6);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel7);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel8);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel9);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel10);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel11);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel12);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel13);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel14);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel15);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel16);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel17);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel18);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel19);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel20);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel21);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel22);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel23);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel24);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel25);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel26);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel27);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel28);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel29);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel30);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel31);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel32);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel33);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel34);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel35);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel36);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel37);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel38);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel39);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel40);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel41);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel42);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel43);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel44);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel45);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel46);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel47);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel48);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel49);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel50);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel51);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel52);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel53);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel54);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel55);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel56);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel57);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel58);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel59);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel60);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel61);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel62);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel63);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel64);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel65);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel66);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel67);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel68);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel69);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel70);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel71);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel72);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel73);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel74);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel75);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel76);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel77);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel78);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel79);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel80);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel81);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel82);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel83);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel84);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel85);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel86);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel87);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel88);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel89);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel90);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel91);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel92);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel93);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel94);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel95);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel96);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel97);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel98);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel99);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel100);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel101);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel102);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel103);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel104);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel105);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel106);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel107);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel108);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel109);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel110);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel111);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel112);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel113);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel114);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel115);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel116);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel117);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel118);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel119);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel120);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel121);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel122);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel123);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel124);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel125);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel126);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel127);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel128);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel129);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel130);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel131);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel132);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel133);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel134);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel135);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel136);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel137);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel138);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel139);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel140);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel141);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel142);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel143);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel144);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel145);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel146);
//
// splitContainerRowTitles.Panel2
//
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox147);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox148);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox149);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox150);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox151);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox152);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox153);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox154);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox155);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox156);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox157);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox158);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox159);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox160);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox161);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox162);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox163);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox164);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox165);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox166);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox167);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox168);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox169);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox170);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox171);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox172);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox173);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox174);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox175);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox176);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox177);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox178);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox179);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox180);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox181);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox182);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox183);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox184);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox185);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox186);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox187);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox188);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox189);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox190);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox191);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox192);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox193);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox194);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox195);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox196);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox197);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox198);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox199);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox200);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox201);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox202);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox203);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox204);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox205);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox206);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox207);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox208);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox209);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox210);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox211);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox212);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox213);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox214);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox215);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox216);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox217);
this.splitContainerRowTitles.Panel2.AutoScroll = true;
this.splitContainerRowTitles.Size = new System.Drawing.Size(756, 382);
this.splitContainerRowTitles.SplitterDistance = 332;
//
// spltMain
//
this.spltMain.Dock = System.Windows.Forms.DockStyle.Fill;
this.spltMain.Location = new System.Drawing.Point(0,0);
this.spltMain.Name = "spltMain";
this.spltMain.Orientation = System.Windows.Forms.Orientation.Horizontal;
this.spltMain.Panel1MinSize = 0;
//
// spltMain.Panel1
//
this.spltMain.Panel1.Controls.Add(this.splitContainerColTitles);
//
// spltMain.Panel2
//
this.spltMain.Panel2.Controls.Add(this.splitContainerRowTitles);
this.spltMain.Panel2.AutoScroll = true;
this.spltMain.Size = new System.Drawing.Size(756, 2120);
this.spltMain.SplitterDistance = 50;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F); 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font; 
this.Controls.Add(this.spltMain);
            this.Name = "S_01_01_01_01__sol2__2_0_1_ctrl"; 
            this.Size = new System.Drawing.Size(756, 2070); 
            this.Load += new System.EventHandler(this.BoundControl_Load);
            this.ResumeLayout(false); 
            this.PerformLayout(); 

      } 
private SolvencyLabel solvencyLabel1;
private SolvencyLabel solvencyLabel2;
private SolvencyLabel solvencyLabel3;
private SolvencyLabel solvencyLabel4;
private SolvencyLabel solvencyLabel5;
private SolvencyLabel solvencyLabel6;
private SolvencyLabel solvencyLabel7;
private SolvencyLabel solvencyLabel8;
private SolvencyLabel solvencyLabel9;
private SolvencyLabel solvencyLabel10;
private SolvencyLabel solvencyLabel11;
private SolvencyLabel solvencyLabel12;
private SolvencyLabel solvencyLabel13;
private SolvencyLabel solvencyLabel14;
private SolvencyLabel solvencyLabel15;
private SolvencyLabel solvencyLabel16;
private SolvencyLabel solvencyLabel17;
private SolvencyLabel solvencyLabel18;
private SolvencyLabel solvencyLabel19;
private SolvencyLabel solvencyLabel20;
private SolvencyLabel solvencyLabel21;
private SolvencyLabel solvencyLabel22;
private SolvencyLabel solvencyLabel23;
private SolvencyLabel solvencyLabel24;
private SolvencyLabel solvencyLabel25;
private SolvencyLabel solvencyLabel26;
private SolvencyLabel solvencyLabel27;
private SolvencyLabel solvencyLabel28;
private SolvencyLabel solvencyLabel29;
private SolvencyLabel solvencyLabel30;
private SolvencyLabel solvencyLabel31;
private SolvencyLabel solvencyLabel32;
private SolvencyLabel solvencyLabel33;
private SolvencyLabel solvencyLabel34;
private SolvencyLabel solvencyLabel35;
private SolvencyLabel solvencyLabel36;
private SolvencyLabel solvencyLabel37;
private SolvencyLabel solvencyLabel38;
private SolvencyLabel solvencyLabel39;
private SolvencyLabel solvencyLabel40;
private SolvencyLabel solvencyLabel41;
private SolvencyLabel solvencyLabel42;
private SolvencyLabel solvencyLabel43;
private SolvencyLabel solvencyLabel44;
private SolvencyLabel solvencyLabel45;
private SolvencyLabel solvencyLabel46;
private SolvencyLabel solvencyLabel47;
private SolvencyLabel solvencyLabel48;
private SolvencyLabel solvencyLabel49;
private SolvencyLabel solvencyLabel50;
private SolvencyLabel solvencyLabel51;
private SolvencyLabel solvencyLabel52;
private SolvencyLabel solvencyLabel53;
private SolvencyLabel solvencyLabel54;
private SolvencyLabel solvencyLabel55;
private SolvencyLabel solvencyLabel56;
private SolvencyLabel solvencyLabel57;
private SolvencyLabel solvencyLabel58;
private SolvencyLabel solvencyLabel59;
private SolvencyLabel solvencyLabel60;
private SolvencyLabel solvencyLabel61;
private SolvencyLabel solvencyLabel62;
private SolvencyLabel solvencyLabel63;
private SolvencyLabel solvencyLabel64;
private SolvencyLabel solvencyLabel65;
private SolvencyLabel solvencyLabel66;
private SolvencyLabel solvencyLabel67;
private SolvencyLabel solvencyLabel68;
private SolvencyLabel solvencyLabel69;
private SolvencyLabel solvencyLabel70;
private SolvencyLabel solvencyLabel71;
private SolvencyLabel solvencyLabel72;
private SolvencyLabel solvencyLabel73;
private SolvencyLabel solvencyLabel74;
private SolvencyLabel solvencyLabel75;
private SolvencyLabel solvencyLabel76;
private SolvencyLabel solvencyLabel77;
private SolvencyLabel solvencyLabel78;
private SolvencyLabel solvencyLabel79;
private SolvencyLabel solvencyLabel80;
private SolvencyLabel solvencyLabel81;
private SolvencyLabel solvencyLabel82;
private SolvencyLabel solvencyLabel83;
private SolvencyLabel solvencyLabel84;
private SolvencyLabel solvencyLabel85;
private SolvencyLabel solvencyLabel86;
private SolvencyLabel solvencyLabel87;
private SolvencyLabel solvencyLabel88;
private SolvencyLabel solvencyLabel89;
private SolvencyLabel solvencyLabel90;
private SolvencyLabel solvencyLabel91;
private SolvencyLabel solvencyLabel92;
private SolvencyLabel solvencyLabel93;
private SolvencyLabel solvencyLabel94;
private SolvencyLabel solvencyLabel95;
private SolvencyLabel solvencyLabel96;
private SolvencyLabel solvencyLabel97;
private SolvencyLabel solvencyLabel98;
private SolvencyLabel solvencyLabel99;
private SolvencyLabel solvencyLabel100;
private SolvencyLabel solvencyLabel101;
private SolvencyLabel solvencyLabel102;
private SolvencyLabel solvencyLabel103;
private SolvencyLabel solvencyLabel104;
private SolvencyLabel solvencyLabel105;
private SolvencyLabel solvencyLabel106;
private SolvencyLabel solvencyLabel107;
private SolvencyLabel solvencyLabel108;
private SolvencyLabel solvencyLabel109;
private SolvencyLabel solvencyLabel110;
private SolvencyLabel solvencyLabel111;
private SolvencyLabel solvencyLabel112;
private SolvencyLabel solvencyLabel113;
private SolvencyLabel solvencyLabel114;
private SolvencyLabel solvencyLabel115;
private SolvencyLabel solvencyLabel116;
private SolvencyLabel solvencyLabel117;
private SolvencyLabel solvencyLabel118;
private SolvencyLabel solvencyLabel119;
private SolvencyLabel solvencyLabel120;
private SolvencyLabel solvencyLabel121;
private SolvencyLabel solvencyLabel122;
private SolvencyLabel solvencyLabel123;
private SolvencyLabel solvencyLabel124;
private SolvencyLabel solvencyLabel125;
private SolvencyLabel solvencyLabel126;
private SolvencyLabel solvencyLabel127;
private SolvencyLabel solvencyLabel128;
private SolvencyLabel solvencyLabel129;
private SolvencyLabel solvencyLabel130;
private SolvencyLabel solvencyLabel131;
private SolvencyLabel solvencyLabel132;
private SolvencyLabel solvencyLabel133;
private SolvencyLabel solvencyLabel134;
private SolvencyLabel solvencyLabel135;
private SolvencyLabel solvencyLabel136;
private SolvencyLabel solvencyLabel137;
private SolvencyLabel solvencyLabel138;
private SolvencyLabel solvencyLabel139;
private SolvencyLabel solvencyLabel140;
private SolvencyLabel solvencyLabel141;
private SolvencyLabel solvencyLabel142;
private SolvencyLabel solvencyLabel143;
private SolvencyLabel solvencyLabel144;
private SolvencyLabel solvencyLabel145;
private SolvencyLabel solvencyLabel146;
private SolvencyDataComboBox SolvencyDataComboBox147;
private SolvencyDataComboBox SolvencyDataComboBox148;
private SolvencyDataComboBox SolvencyDataComboBox149;
private SolvencyDataComboBox SolvencyDataComboBox150;
private SolvencyDataComboBox SolvencyDataComboBox151;
private SolvencyDataComboBox SolvencyDataComboBox152;
private SolvencyDataComboBox SolvencyDataComboBox153;
private SolvencyDataComboBox SolvencyDataComboBox154;
private SolvencyDataComboBox SolvencyDataComboBox155;
private SolvencyDataComboBox SolvencyDataComboBox156;
private SolvencyDataComboBox SolvencyDataComboBox157;
private SolvencyDataComboBox SolvencyDataComboBox158;
private SolvencyDataComboBox SolvencyDataComboBox159;
private SolvencyDataComboBox SolvencyDataComboBox160;
private SolvencyDataComboBox SolvencyDataComboBox161;
private SolvencyDataComboBox SolvencyDataComboBox162;
private SolvencyDataComboBox SolvencyDataComboBox163;
private SolvencyDataComboBox SolvencyDataComboBox164;
private SolvencyDataComboBox SolvencyDataComboBox165;
private SolvencyDataComboBox SolvencyDataComboBox166;
private SolvencyDataComboBox SolvencyDataComboBox167;
private SolvencyDataComboBox SolvencyDataComboBox168;
private SolvencyDataComboBox SolvencyDataComboBox169;
private SolvencyDataComboBox SolvencyDataComboBox170;
private SolvencyDataComboBox SolvencyDataComboBox171;
private SolvencyDataComboBox SolvencyDataComboBox172;
private SolvencyDataComboBox SolvencyDataComboBox173;
private SolvencyDataComboBox SolvencyDataComboBox174;
private SolvencyDataComboBox SolvencyDataComboBox175;
private SolvencyDataComboBox SolvencyDataComboBox176;
private SolvencyDataComboBox SolvencyDataComboBox177;
private SolvencyDataComboBox SolvencyDataComboBox178;
private SolvencyDataComboBox SolvencyDataComboBox179;
private SolvencyDataComboBox SolvencyDataComboBox180;
private SolvencyDataComboBox SolvencyDataComboBox181;
private SolvencyDataComboBox SolvencyDataComboBox182;
private SolvencyDataComboBox SolvencyDataComboBox183;
private SolvencyDataComboBox SolvencyDataComboBox184;
private SolvencyDataComboBox SolvencyDataComboBox185;
private SolvencyDataComboBox SolvencyDataComboBox186;
private SolvencyDataComboBox SolvencyDataComboBox187;
private SolvencyDataComboBox SolvencyDataComboBox188;
private SolvencyDataComboBox SolvencyDataComboBox189;
private SolvencyDataComboBox SolvencyDataComboBox190;
private SolvencyDataComboBox SolvencyDataComboBox191;
private SolvencyDataComboBox SolvencyDataComboBox192;
private SolvencyDataComboBox SolvencyDataComboBox193;
private SolvencyDataComboBox SolvencyDataComboBox194;
private SolvencyDataComboBox SolvencyDataComboBox195;
private SolvencyDataComboBox SolvencyDataComboBox196;
private SolvencyDataComboBox SolvencyDataComboBox197;
private SolvencyDataComboBox SolvencyDataComboBox198;
private SolvencyDataComboBox SolvencyDataComboBox199;
private SolvencyDataComboBox SolvencyDataComboBox200;
private SolvencyDataComboBox SolvencyDataComboBox201;
private SolvencyDataComboBox SolvencyDataComboBox202;
private SolvencyDataComboBox SolvencyDataComboBox203;
private SolvencyDataComboBox SolvencyDataComboBox204;
private SolvencyDataComboBox SolvencyDataComboBox205;
private SolvencyDataComboBox SolvencyDataComboBox206;
private SolvencyDataComboBox SolvencyDataComboBox207;
private SolvencyDataComboBox SolvencyDataComboBox208;
private SolvencyDataComboBox SolvencyDataComboBox209;
private SolvencyDataComboBox SolvencyDataComboBox210;
private SolvencyDataComboBox SolvencyDataComboBox211;
private SolvencyDataComboBox SolvencyDataComboBox212;
private SolvencyDataComboBox SolvencyDataComboBox213;
private SolvencyDataComboBox SolvencyDataComboBox214;
private SolvencyDataComboBox SolvencyDataComboBox215;
private SolvencyDataComboBox SolvencyDataComboBox216;
private SolvencyDataComboBox SolvencyDataComboBox217;
private SolvencySplitContainer splitContainerColTitles;
private SolvencySplitContainer splitContainerRowTitles;
private SolvencySplitContainer spltMain;

   }
}

