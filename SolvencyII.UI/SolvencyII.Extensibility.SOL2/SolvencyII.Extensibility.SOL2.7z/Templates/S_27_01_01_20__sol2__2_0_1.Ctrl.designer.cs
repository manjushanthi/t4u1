using SolvencyII.Domain.ENumerators; 
using SolvencyII.UI.Shared.Controls; 

namespace SolvencyII.UI.UserControls 
{ 
   partial class S_27_01_01_20__sol2__2_0_1_ctrl 
   { 
      private void InitializeComponent() 
      { 
this.solvencyLabel0 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel1 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel2 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel3 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel4 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel5 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel6 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel7 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel8 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel9 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel10 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel11 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel12 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel13 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel14 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel15 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel16 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel17 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel18 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel19 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel20 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel21 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel22 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel23 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel24 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel25 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel26 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel27 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel28 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel29 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel30 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel31 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel32 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel33 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel34 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel35 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel36 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel37 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel38 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel39 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel40 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel41 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel42 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel43 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel44 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel45 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel46 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel47 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel48 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel49 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel50 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel51 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel52 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel53 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel54 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel55 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel56 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel57 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel58 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel59 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel60 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel61 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel62 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel63 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel64 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel65 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel66 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel67 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel68 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel69 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel70 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel71 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel72 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel73 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel74 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel75 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel76 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel77 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel78 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel79 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel80 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel81 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel82 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel83 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel84 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel85 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel86 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel87 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel88 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel89 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel90 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel91 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel92 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel93 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel94 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel95 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel96 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel97 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel98 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel99 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel100 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel101 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel102 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel103 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyCurrencyTextBox104 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox105 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox106 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox107 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox108 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox109 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox110 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox111 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox112 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox113 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox114 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox115 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox116 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox117 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox118 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox119 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox120 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox121 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox122 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox123 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox124 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox125 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox126 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox127 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox128 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox129 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox130 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox131 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox132 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox133 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox134 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox135 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox136 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox137 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox138 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox139 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox140 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox141 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox142 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox143 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox144 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox145 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox146 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox147 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox148 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox149 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox150 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox151 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox152 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox153 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox154 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox155 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox156 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox157 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox158 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox159 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox160 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox161 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox162 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox163 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox164 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox165 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox166 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox167 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox168 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox169 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox170 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox171 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox172 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox173 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox174 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox175 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox176 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox177 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox178 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox179 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox180 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox181 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox182 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox183 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox184 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox185 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox186 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox187 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox188 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox189 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox190 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox191 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox192 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox193 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox194 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox195 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox196 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox197 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox198 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox199 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox200 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox201 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox202 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox203 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox204 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox205 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox206 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox207 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox208 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox209 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox210 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox211 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox212 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox213 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox214 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox215 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox216 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox217 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox218 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox219 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox220 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox221 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox222 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox223 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox224 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox225 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox226 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox227 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox228 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox229 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox230 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox231 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox232 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox233 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox234 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox235 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox236 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox237 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox238 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox239 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox240 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox241 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox242 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox243 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox244 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox245 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox246 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox247 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox248 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox249 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox250 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox251 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox252 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox253 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox254 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox255 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox256 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox257 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox258 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox259 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox260 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox261 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox262 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox263 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox264 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox265 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox266 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox267 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox268 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox269 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox270 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox271 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox272 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox273 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox274 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox275 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox276 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox277 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox278 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox279 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox280 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox281 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox282 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox283 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox284 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox285 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox286 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox287 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox288 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox289 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox290 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox291 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox292 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox293 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox294 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox295 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox296 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox297 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox298 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox299 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox300 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox301 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox302 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox303 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox304 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox305 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox306 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox307 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox308 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox309 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox310 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox311 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox312 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox313 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox314 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox315 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox316 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox317 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox318 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox319 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox320 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox321 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox322 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox323 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox324 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox325 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox326 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox327 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox328 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox329 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox330 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox331 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox332 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox333 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox334 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox335 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox336 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox337 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox338 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox339 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox340 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox341 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox342 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox343 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox344 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox345 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox346 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox347 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox348 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox349 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox350 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox351 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox352 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox353 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox354 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox355 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox356 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox357 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox358 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox359 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox360 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox361 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox362 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox363 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox364 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox365 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox366 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox367 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox368 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox369 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox370 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox371 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox372 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox373 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox374 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox375 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox376 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox377 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox378 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox379 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox380 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox381 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox382 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox383 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox384 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox385 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox386 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox387 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox388 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox389 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox390 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox391 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox392 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox393 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox394 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox395 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox396 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox397 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox398 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox399 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox400 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox401 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox402 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox403 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox404 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox405 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox406 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox407 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox408 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox409 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox410 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox411 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox412 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox413 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox414 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox415 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox416 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox417 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox418 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox419 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox420 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox421 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox422 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox423 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox424 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox425 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox426 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox427 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox428 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox429 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox430 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox431 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox432 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox433 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox434 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox435 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox436 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox437 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox438 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox439 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox440 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox441 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox442 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox443 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox444 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox445 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox446 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox447 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox448 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox449 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox450 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox451 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox452 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox453 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox454 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox455 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox456 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox457 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox458 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox459 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox460 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox461 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox462 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox463 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox464 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox465 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox466 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox467 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox468 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox469 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox470 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox471 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox472 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox473 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox474 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox475 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox476 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox477 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox478 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox479 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox480 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox481 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox482 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox483 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox484 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox485 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox486 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox487 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox488 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox489 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox490 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox491 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox492 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox493 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox494 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox495 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox496 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox497 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox498 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox499 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox500 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox501 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox502 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox503 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox504 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox505 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox506 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox507 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox508 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox509 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox510 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox511 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox512 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox513 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox514 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox515 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox516 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox517 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox518 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox519 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox520 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox521 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox522 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox523 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox524 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox525 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox526 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox527 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox528 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox529 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox530 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox531 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox532 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox533 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox534 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox535 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox536 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox537 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox538 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox539 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox540 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox541 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox542 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox543 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox544 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox545 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox546 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox547 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox548 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox549 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox550 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox551 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox552 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox553 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox554 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox555 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox556 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox557 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox558 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox559 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox560 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox561 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox562 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox563 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox564 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox565 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox566 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox567 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox568 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox569 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox570 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox571 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox572 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox573 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox574 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox575 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox576 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox577 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox578 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox579 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.splitContainerColTitles = new SolvencyII.UI.Shared.Controls.SolvencySplitContainer();
this.splitContainerRowTitles = new SolvencyII.UI.Shared.Controls.SolvencySplitContainer();
this.spltMain = new SolvencyII.UI.Shared.Controls.SolvencySplitContainer();
            this.SuspendLayout(); 

//
// solvencyLabel0
//
this.solvencyLabel0.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel0.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel0.Location = new System.Drawing.Point(1401,10);
this.solvencyLabel0.Name = "solvencyLabel0";
this.solvencyLabel0.OrdinateID_Label = 6694;
this.solvencyLabel0.Size = new System.Drawing.Size(108, 50);
this.solvencyLabel0.TabIndex = 0;
this.solvencyLabel0.Text = "Catastrophe Risk Charge after risk mitigation" ;
this.solvencyLabel0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel0.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel1
//
this.solvencyLabel1.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel1.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel1.Location = new System.Drawing.Point(1401,60);
this.solvencyLabel1.Name = "solvencyLabel1";
this.solvencyLabel1.OrdinateID_Label = 0;
this.solvencyLabel1.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel1.TabIndex = 1;
this.solvencyLabel1.Text = "C1300" ;
this.solvencyLabel1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel2
//
this.solvencyLabel2.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel2.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel2.Location = new System.Drawing.Point(1294,10);
this.solvencyLabel2.Name = "solvencyLabel2";
this.solvencyLabel2.OrdinateID_Label = 6693;
this.solvencyLabel2.Size = new System.Drawing.Size(108, 50);
this.solvencyLabel2.TabIndex = 2;
this.solvencyLabel2.Text = "Estimated Reinstatement Premiums" ;
this.solvencyLabel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel3
//
this.solvencyLabel3.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel3.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel3.Location = new System.Drawing.Point(1294,60);
this.solvencyLabel3.Name = "solvencyLabel3";
this.solvencyLabel3.OrdinateID_Label = 0;
this.solvencyLabel3.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel3.TabIndex = 3;
this.solvencyLabel3.Text = "C1290" ;
this.solvencyLabel3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel4
//
this.solvencyLabel4.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel4.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel4.Location = new System.Drawing.Point(1187,10);
this.solvencyLabel4.Name = "solvencyLabel4";
this.solvencyLabel4.OrdinateID_Label = 6692;
this.solvencyLabel4.Size = new System.Drawing.Size(108, 50);
this.solvencyLabel4.TabIndex = 4;
this.solvencyLabel4.Text = "Estimated Risk Mitigation" ;
this.solvencyLabel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel5
//
this.solvencyLabel5.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel5.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel5.Location = new System.Drawing.Point(1187,60);
this.solvencyLabel5.Name = "solvencyLabel5";
this.solvencyLabel5.OrdinateID_Label = 0;
this.solvencyLabel5.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel5.TabIndex = 5;
this.solvencyLabel5.Text = "C1280" ;
this.solvencyLabel5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel6
//
this.solvencyLabel6.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel6.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel6.Location = new System.Drawing.Point(1080,10);
this.solvencyLabel6.Name = "solvencyLabel6";
this.solvencyLabel6.OrdinateID_Label = 6691;
this.solvencyLabel6.Size = new System.Drawing.Size(108, 50);
this.solvencyLabel6.TabIndex = 6;
this.solvencyLabel6.Text = "Catastrophe Risk Charge before risk mitigation" ;
this.solvencyLabel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel6.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel7
//
this.solvencyLabel7.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel7.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel7.Location = new System.Drawing.Point(1080,60);
this.solvencyLabel7.Name = "solvencyLabel7";
this.solvencyLabel7.OrdinateID_Label = 0;
this.solvencyLabel7.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel7.TabIndex = 7;
this.solvencyLabel7.Text = "C1270" ;
this.solvencyLabel7.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel8
//
this.solvencyLabel8.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel8.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel8.Location = new System.Drawing.Point(973,30);
this.solvencyLabel8.Name = "solvencyLabel8";
this.solvencyLabel8.OrdinateID_Label = 6690;
this.solvencyLabel8.Size = new System.Drawing.Size(108, 30);
this.solvencyLabel8.TabIndex = 8;
this.solvencyLabel8.Text = "Total value of benefits payable" ;
this.solvencyLabel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel8.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel9
//
this.solvencyLabel9.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel9.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel9.Location = new System.Drawing.Point(973,60);
this.solvencyLabel9.Name = "solvencyLabel9";
this.solvencyLabel9.OrdinateID_Label = 0;
this.solvencyLabel9.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel9.TabIndex = 9;
this.solvencyLabel9.Text = "C1260" ;
this.solvencyLabel9.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel10
//
this.solvencyLabel10.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel10.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel10.Location = new System.Drawing.Point(866,30);
this.solvencyLabel10.Name = "solvencyLabel10";
this.solvencyLabel10.OrdinateID_Label = 6689;
this.solvencyLabel10.Size = new System.Drawing.Size(108, 30);
this.solvencyLabel10.TabIndex = 10;
this.solvencyLabel10.Text = "# Policyholders" ;
this.solvencyLabel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel10.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel11
//
this.solvencyLabel11.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel11.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel11.Location = new System.Drawing.Point(866,60);
this.solvencyLabel11.Name = "solvencyLabel11";
this.solvencyLabel11.OrdinateID_Label = 0;
this.solvencyLabel11.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel11.TabIndex = 11;
this.solvencyLabel11.Text = "C1250" ;
this.solvencyLabel11.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel12
//
this.solvencyLabel12.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel12.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel12.Location = new System.Drawing.Point(866,10);
this.solvencyLabel12.Name = "solvencyLabel12";
this.solvencyLabel12.OrdinateID_Label = 6688;
this.solvencyLabel12.Size = new System.Drawing.Size(215, 50);
this.solvencyLabel12.TabIndex = 12;
this.solvencyLabel12.Text = "Medical treatment" ;
this.solvencyLabel12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel12.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel13
//
this.solvencyLabel13.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel13.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel13.Location = new System.Drawing.Point(759,30);
this.solvencyLabel13.Name = "solvencyLabel13";
this.solvencyLabel13.OrdinateID_Label = 6687;
this.solvencyLabel13.Size = new System.Drawing.Size(108, 30);
this.solvencyLabel13.TabIndex = 13;
this.solvencyLabel13.Text = "Total value of benefits payable" ;
this.solvencyLabel13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel13.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel14
//
this.solvencyLabel14.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel14.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel14.Location = new System.Drawing.Point(759,60);
this.solvencyLabel14.Name = "solvencyLabel14";
this.solvencyLabel14.OrdinateID_Label = 0;
this.solvencyLabel14.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel14.TabIndex = 14;
this.solvencyLabel14.Text = "C1240" ;
this.solvencyLabel14.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel15
//
this.solvencyLabel15.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel15.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel15.Location = new System.Drawing.Point(652,30);
this.solvencyLabel15.Name = "solvencyLabel15";
this.solvencyLabel15.OrdinateID_Label = 6686;
this.solvencyLabel15.Size = new System.Drawing.Size(108, 30);
this.solvencyLabel15.TabIndex = 15;
this.solvencyLabel15.Text = "# Policyholders" ;
this.solvencyLabel15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel15.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel16
//
this.solvencyLabel16.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel16.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel16.Location = new System.Drawing.Point(652,60);
this.solvencyLabel16.Name = "solvencyLabel16";
this.solvencyLabel16.OrdinateID_Label = 0;
this.solvencyLabel16.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel16.TabIndex = 16;
this.solvencyLabel16.Text = "C1230" ;
this.solvencyLabel16.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel17
//
this.solvencyLabel17.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel17.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel17.Location = new System.Drawing.Point(652,10);
this.solvencyLabel17.Name = "solvencyLabel17";
this.solvencyLabel17.OrdinateID_Label = 6685;
this.solvencyLabel17.Size = new System.Drawing.Size(215, 50);
this.solvencyLabel17.TabIndex = 17;
this.solvencyLabel17.Text = "Disability 12 months" ;
this.solvencyLabel17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel17.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel18
//
this.solvencyLabel18.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel18.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel18.Location = new System.Drawing.Point(545,30);
this.solvencyLabel18.Name = "solvencyLabel18";
this.solvencyLabel18.OrdinateID_Label = 6684;
this.solvencyLabel18.Size = new System.Drawing.Size(108, 30);
this.solvencyLabel18.TabIndex = 18;
this.solvencyLabel18.Text = "Total value of benefits payable" ;
this.solvencyLabel18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel18.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel19
//
this.solvencyLabel19.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel19.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel19.Location = new System.Drawing.Point(545,60);
this.solvencyLabel19.Name = "solvencyLabel19";
this.solvencyLabel19.OrdinateID_Label = 0;
this.solvencyLabel19.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel19.TabIndex = 19;
this.solvencyLabel19.Text = "C1220" ;
this.solvencyLabel19.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel20
//
this.solvencyLabel20.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel20.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel20.Location = new System.Drawing.Point(438,30);
this.solvencyLabel20.Name = "solvencyLabel20";
this.solvencyLabel20.OrdinateID_Label = 6683;
this.solvencyLabel20.Size = new System.Drawing.Size(108, 30);
this.solvencyLabel20.TabIndex = 20;
this.solvencyLabel20.Text = "# Policyholders" ;
this.solvencyLabel20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel20.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel21
//
this.solvencyLabel21.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel21.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel21.Location = new System.Drawing.Point(438,60);
this.solvencyLabel21.Name = "solvencyLabel21";
this.solvencyLabel21.OrdinateID_Label = 0;
this.solvencyLabel21.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel21.TabIndex = 21;
this.solvencyLabel21.Text = "C1210" ;
this.solvencyLabel21.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel22
//
this.solvencyLabel22.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel22.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel22.Location = new System.Drawing.Point(438,10);
this.solvencyLabel22.Name = "solvencyLabel22";
this.solvencyLabel22.OrdinateID_Label = 6682;
this.solvencyLabel22.Size = new System.Drawing.Size(215, 50);
this.solvencyLabel22.TabIndex = 22;
this.solvencyLabel22.Text = "Disability 10 years" ;
this.solvencyLabel22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel22.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel23
//
this.solvencyLabel23.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel23.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel23.Location = new System.Drawing.Point(331,30);
this.solvencyLabel23.Name = "solvencyLabel23";
this.solvencyLabel23.OrdinateID_Label = 6681;
this.solvencyLabel23.Size = new System.Drawing.Size(108, 30);
this.solvencyLabel23.TabIndex = 23;
this.solvencyLabel23.Text = "Total value of benefits payable" ;
this.solvencyLabel23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel23.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel24
//
this.solvencyLabel24.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel24.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel24.Location = new System.Drawing.Point(331,60);
this.solvencyLabel24.Name = "solvencyLabel24";
this.solvencyLabel24.OrdinateID_Label = 0;
this.solvencyLabel24.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel24.TabIndex = 24;
this.solvencyLabel24.Text = "C1200" ;
this.solvencyLabel24.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel25
//
this.solvencyLabel25.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel25.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel25.Location = new System.Drawing.Point(224,30);
this.solvencyLabel25.Name = "solvencyLabel25";
this.solvencyLabel25.OrdinateID_Label = 6680;
this.solvencyLabel25.Size = new System.Drawing.Size(108, 30);
this.solvencyLabel25.TabIndex = 25;
this.solvencyLabel25.Text = "# Policyholders" ;
this.solvencyLabel25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel25.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel26
//
this.solvencyLabel26.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel26.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel26.Location = new System.Drawing.Point(224,60);
this.solvencyLabel26.Name = "solvencyLabel26";
this.solvencyLabel26.OrdinateID_Label = 0;
this.solvencyLabel26.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel26.TabIndex = 26;
this.solvencyLabel26.Text = "C1190" ;
this.solvencyLabel26.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel27
//
this.solvencyLabel27.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel27.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel27.Location = new System.Drawing.Point(224,10);
this.solvencyLabel27.Name = "solvencyLabel27";
this.solvencyLabel27.OrdinateID_Label = 6679;
this.solvencyLabel27.Size = new System.Drawing.Size(215, 50);
this.solvencyLabel27.TabIndex = 27;
this.solvencyLabel27.Text = "Permanent disability" ;
this.solvencyLabel27.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel27.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel28
//
this.solvencyLabel28.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel28.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel28.Location = new System.Drawing.Point(117,30);
this.solvencyLabel28.Name = "solvencyLabel28";
this.solvencyLabel28.OrdinateID_Label = 6678;
this.solvencyLabel28.Size = new System.Drawing.Size(108, 30);
this.solvencyLabel28.TabIndex = 28;
this.solvencyLabel28.Text = "Total value of benefits payable" ;
this.solvencyLabel28.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel28.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel29
//
this.solvencyLabel29.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel29.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel29.Location = new System.Drawing.Point(117,60);
this.solvencyLabel29.Name = "solvencyLabel29";
this.solvencyLabel29.OrdinateID_Label = 0;
this.solvencyLabel29.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel29.TabIndex = 29;
this.solvencyLabel29.Text = "C1180" ;
this.solvencyLabel29.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel30
//
this.solvencyLabel30.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel30.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel30.Location = new System.Drawing.Point(10,30);
this.solvencyLabel30.Name = "solvencyLabel30";
this.solvencyLabel30.OrdinateID_Label = 6677;
this.solvencyLabel30.Size = new System.Drawing.Size(108, 30);
this.solvencyLabel30.TabIndex = 30;
this.solvencyLabel30.Text = "# Policyholders" ;
this.solvencyLabel30.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel30.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel31
//
this.solvencyLabel31.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel31.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel31.Location = new System.Drawing.Point(10,60);
this.solvencyLabel31.Name = "solvencyLabel31";
this.solvencyLabel31.OrdinateID_Label = 0;
this.solvencyLabel31.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel31.TabIndex = 31;
this.solvencyLabel31.Text = "C1170" ;
this.solvencyLabel31.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel32
//
this.solvencyLabel32.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel32.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel32.Location = new System.Drawing.Point(10,10);
this.solvencyLabel32.Name = "solvencyLabel32";
this.solvencyLabel32.OrdinateID_Label = 6676;
this.solvencyLabel32.Size = new System.Drawing.Size(215, 50);
this.solvencyLabel32.TabIndex = 32;
this.solvencyLabel32.Text = "Accidental death" ;
this.solvencyLabel32.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel32.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel33
//
this.solvencyLabel33.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel33.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel33.Location = new System.Drawing.Point(10,3);
this.solvencyLabel33.Name = "solvencyLabel33";
this.solvencyLabel33.OrdinateID_Label = 6695;
this.solvencyLabel33.Size = new System.Drawing.Size(261, 15);
this.solvencyLabel33.TabIndex = 33;
this.solvencyLabel33.Text = "Health Catastrophe risk - Mass accident" ;
this.solvencyLabel33.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel34
//
this.solvencyLabel34.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel34.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel34.Location = new System.Drawing.Point(285,3);
this.solvencyLabel34.Name = "solvencyLabel34";
this.solvencyLabel34.OrdinateID_Label = 0;
this.solvencyLabel34.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel34.TabIndex = 34;
this.solvencyLabel34.Text = "" ;
this.solvencyLabel34.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel35
//
this.solvencyLabel35.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel35.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel35.Location = new System.Drawing.Point(17,23);
this.solvencyLabel35.Name = "solvencyLabel35";
this.solvencyLabel35.OrdinateID_Label = 6696;
this.solvencyLabel35.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel35.TabIndex = 35;
this.solvencyLabel35.Text = "Republic of Austria" ;
this.solvencyLabel35.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel36
//
this.solvencyLabel36.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel36.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel36.Location = new System.Drawing.Point(285,23);
this.solvencyLabel36.Name = "solvencyLabel36";
this.solvencyLabel36.OrdinateID_Label = 0;
this.solvencyLabel36.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel36.TabIndex = 36;
this.solvencyLabel36.Text = "R3300" ;
this.solvencyLabel36.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel37
//
this.solvencyLabel37.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel37.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel37.Location = new System.Drawing.Point(17,43);
this.solvencyLabel37.Name = "solvencyLabel37";
this.solvencyLabel37.OrdinateID_Label = 6697;
this.solvencyLabel37.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel37.TabIndex = 37;
this.solvencyLabel37.Text = "Kingdom of Belgium" ;
this.solvencyLabel37.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel38
//
this.solvencyLabel38.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel38.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel38.Location = new System.Drawing.Point(285,43);
this.solvencyLabel38.Name = "solvencyLabel38";
this.solvencyLabel38.OrdinateID_Label = 0;
this.solvencyLabel38.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel38.TabIndex = 38;
this.solvencyLabel38.Text = "R3310" ;
this.solvencyLabel38.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel39
//
this.solvencyLabel39.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel39.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel39.Location = new System.Drawing.Point(17,63);
this.solvencyLabel39.Name = "solvencyLabel39";
this.solvencyLabel39.OrdinateID_Label = 6698;
this.solvencyLabel39.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel39.TabIndex = 39;
this.solvencyLabel39.Text = "Republic of Bulgaria" ;
this.solvencyLabel39.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel40
//
this.solvencyLabel40.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel40.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel40.Location = new System.Drawing.Point(285,63);
this.solvencyLabel40.Name = "solvencyLabel40";
this.solvencyLabel40.OrdinateID_Label = 0;
this.solvencyLabel40.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel40.TabIndex = 40;
this.solvencyLabel40.Text = "R3320" ;
this.solvencyLabel40.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel41
//
this.solvencyLabel41.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel41.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel41.Location = new System.Drawing.Point(17,83);
this.solvencyLabel41.Name = "solvencyLabel41";
this.solvencyLabel41.OrdinateID_Label = 6699;
this.solvencyLabel41.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel41.TabIndex = 41;
this.solvencyLabel41.Text = "Republic of Croatia" ;
this.solvencyLabel41.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel42
//
this.solvencyLabel42.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel42.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel42.Location = new System.Drawing.Point(285,83);
this.solvencyLabel42.Name = "solvencyLabel42";
this.solvencyLabel42.OrdinateID_Label = 0;
this.solvencyLabel42.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel42.TabIndex = 42;
this.solvencyLabel42.Text = "R3330" ;
this.solvencyLabel42.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel43
//
this.solvencyLabel43.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel43.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel43.Location = new System.Drawing.Point(17,103);
this.solvencyLabel43.Name = "solvencyLabel43";
this.solvencyLabel43.OrdinateID_Label = 6700;
this.solvencyLabel43.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel43.TabIndex = 43;
this.solvencyLabel43.Text = "Republic of Cyprus" ;
this.solvencyLabel43.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel44
//
this.solvencyLabel44.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel44.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel44.Location = new System.Drawing.Point(285,103);
this.solvencyLabel44.Name = "solvencyLabel44";
this.solvencyLabel44.OrdinateID_Label = 0;
this.solvencyLabel44.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel44.TabIndex = 44;
this.solvencyLabel44.Text = "R3340" ;
this.solvencyLabel44.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel45
//
this.solvencyLabel45.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel45.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel45.Location = new System.Drawing.Point(17,123);
this.solvencyLabel45.Name = "solvencyLabel45";
this.solvencyLabel45.OrdinateID_Label = 6701;
this.solvencyLabel45.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel45.TabIndex = 45;
this.solvencyLabel45.Text = "Czech Republic" ;
this.solvencyLabel45.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel46
//
this.solvencyLabel46.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel46.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel46.Location = new System.Drawing.Point(285,123);
this.solvencyLabel46.Name = "solvencyLabel46";
this.solvencyLabel46.OrdinateID_Label = 0;
this.solvencyLabel46.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel46.TabIndex = 46;
this.solvencyLabel46.Text = "R3350" ;
this.solvencyLabel46.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel47
//
this.solvencyLabel47.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel47.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel47.Location = new System.Drawing.Point(17,143);
this.solvencyLabel47.Name = "solvencyLabel47";
this.solvencyLabel47.OrdinateID_Label = 6702;
this.solvencyLabel47.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel47.TabIndex = 47;
this.solvencyLabel47.Text = "Kingdom of Denmark" ;
this.solvencyLabel47.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel48
//
this.solvencyLabel48.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel48.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel48.Location = new System.Drawing.Point(285,143);
this.solvencyLabel48.Name = "solvencyLabel48";
this.solvencyLabel48.OrdinateID_Label = 0;
this.solvencyLabel48.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel48.TabIndex = 48;
this.solvencyLabel48.Text = "R3360" ;
this.solvencyLabel48.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel49
//
this.solvencyLabel49.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel49.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel49.Location = new System.Drawing.Point(17,163);
this.solvencyLabel49.Name = "solvencyLabel49";
this.solvencyLabel49.OrdinateID_Label = 6703;
this.solvencyLabel49.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel49.TabIndex = 49;
this.solvencyLabel49.Text = "Republic of Estonia" ;
this.solvencyLabel49.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel50
//
this.solvencyLabel50.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel50.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel50.Location = new System.Drawing.Point(285,163);
this.solvencyLabel50.Name = "solvencyLabel50";
this.solvencyLabel50.OrdinateID_Label = 0;
this.solvencyLabel50.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel50.TabIndex = 50;
this.solvencyLabel50.Text = "R3370" ;
this.solvencyLabel50.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel51
//
this.solvencyLabel51.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel51.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel51.Location = new System.Drawing.Point(17,183);
this.solvencyLabel51.Name = "solvencyLabel51";
this.solvencyLabel51.OrdinateID_Label = 6704;
this.solvencyLabel51.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel51.TabIndex = 51;
this.solvencyLabel51.Text = "Republic of Finland" ;
this.solvencyLabel51.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel52
//
this.solvencyLabel52.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel52.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel52.Location = new System.Drawing.Point(285,183);
this.solvencyLabel52.Name = "solvencyLabel52";
this.solvencyLabel52.OrdinateID_Label = 0;
this.solvencyLabel52.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel52.TabIndex = 52;
this.solvencyLabel52.Text = "R3380" ;
this.solvencyLabel52.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel53
//
this.solvencyLabel53.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel53.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel53.Location = new System.Drawing.Point(17,203);
this.solvencyLabel53.Name = "solvencyLabel53";
this.solvencyLabel53.OrdinateID_Label = 6705;
this.solvencyLabel53.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel53.TabIndex = 53;
this.solvencyLabel53.Text = "French Republic; Principality of Monaco; Principality of Andorra" ;
this.solvencyLabel53.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel54
//
this.solvencyLabel54.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel54.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel54.Location = new System.Drawing.Point(285,203);
this.solvencyLabel54.Name = "solvencyLabel54";
this.solvencyLabel54.OrdinateID_Label = 0;
this.solvencyLabel54.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel54.TabIndex = 54;
this.solvencyLabel54.Text = "R3390" ;
this.solvencyLabel54.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel55
//
this.solvencyLabel55.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel55.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel55.Location = new System.Drawing.Point(17,236);
this.solvencyLabel55.Name = "solvencyLabel55";
this.solvencyLabel55.OrdinateID_Label = 6706;
this.solvencyLabel55.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel55.TabIndex = 55;
this.solvencyLabel55.Text = "Hellenic Republic" ;
this.solvencyLabel55.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel56
//
this.solvencyLabel56.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel56.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel56.Location = new System.Drawing.Point(285,236);
this.solvencyLabel56.Name = "solvencyLabel56";
this.solvencyLabel56.OrdinateID_Label = 0;
this.solvencyLabel56.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel56.TabIndex = 56;
this.solvencyLabel56.Text = "R3400" ;
this.solvencyLabel56.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel57
//
this.solvencyLabel57.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel57.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel57.Location = new System.Drawing.Point(17,256);
this.solvencyLabel57.Name = "solvencyLabel57";
this.solvencyLabel57.OrdinateID_Label = 6707;
this.solvencyLabel57.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel57.TabIndex = 57;
this.solvencyLabel57.Text = "Federal Republic of Germany" ;
this.solvencyLabel57.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel58
//
this.solvencyLabel58.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel58.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel58.Location = new System.Drawing.Point(285,256);
this.solvencyLabel58.Name = "solvencyLabel58";
this.solvencyLabel58.OrdinateID_Label = 0;
this.solvencyLabel58.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel58.TabIndex = 58;
this.solvencyLabel58.Text = "R3410" ;
this.solvencyLabel58.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel59
//
this.solvencyLabel59.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel59.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel59.Location = new System.Drawing.Point(17,276);
this.solvencyLabel59.Name = "solvencyLabel59";
this.solvencyLabel59.OrdinateID_Label = 6708;
this.solvencyLabel59.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel59.TabIndex = 59;
this.solvencyLabel59.Text = "Republic of Hungary" ;
this.solvencyLabel59.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel60
//
this.solvencyLabel60.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel60.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel60.Location = new System.Drawing.Point(285,276);
this.solvencyLabel60.Name = "solvencyLabel60";
this.solvencyLabel60.OrdinateID_Label = 0;
this.solvencyLabel60.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel60.TabIndex = 60;
this.solvencyLabel60.Text = "R3420" ;
this.solvencyLabel60.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel61
//
this.solvencyLabel61.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel61.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel61.Location = new System.Drawing.Point(17,296);
this.solvencyLabel61.Name = "solvencyLabel61";
this.solvencyLabel61.OrdinateID_Label = 6709;
this.solvencyLabel61.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel61.TabIndex = 61;
this.solvencyLabel61.Text = "Republic of Iceland" ;
this.solvencyLabel61.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel62
//
this.solvencyLabel62.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel62.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel62.Location = new System.Drawing.Point(285,296);
this.solvencyLabel62.Name = "solvencyLabel62";
this.solvencyLabel62.OrdinateID_Label = 0;
this.solvencyLabel62.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel62.TabIndex = 62;
this.solvencyLabel62.Text = "R3430" ;
this.solvencyLabel62.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel63
//
this.solvencyLabel63.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel63.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel63.Location = new System.Drawing.Point(17,316);
this.solvencyLabel63.Name = "solvencyLabel63";
this.solvencyLabel63.OrdinateID_Label = 6710;
this.solvencyLabel63.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel63.TabIndex = 63;
this.solvencyLabel63.Text = "Ireland" ;
this.solvencyLabel63.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel64
//
this.solvencyLabel64.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel64.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel64.Location = new System.Drawing.Point(285,316);
this.solvencyLabel64.Name = "solvencyLabel64";
this.solvencyLabel64.OrdinateID_Label = 0;
this.solvencyLabel64.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel64.TabIndex = 64;
this.solvencyLabel64.Text = "R3440" ;
this.solvencyLabel64.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel65
//
this.solvencyLabel65.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel65.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel65.Location = new System.Drawing.Point(17,336);
this.solvencyLabel65.Name = "solvencyLabel65";
this.solvencyLabel65.OrdinateID_Label = 6711;
this.solvencyLabel65.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel65.TabIndex = 65;
this.solvencyLabel65.Text = "Italian Republic; Republic of San Marino; Vatican City State" ;
this.solvencyLabel65.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel66
//
this.solvencyLabel66.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel66.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel66.Location = new System.Drawing.Point(285,336);
this.solvencyLabel66.Name = "solvencyLabel66";
this.solvencyLabel66.OrdinateID_Label = 0;
this.solvencyLabel66.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel66.TabIndex = 66;
this.solvencyLabel66.Text = "R3450" ;
this.solvencyLabel66.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel67
//
this.solvencyLabel67.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel67.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel67.Location = new System.Drawing.Point(17,369);
this.solvencyLabel67.Name = "solvencyLabel67";
this.solvencyLabel67.OrdinateID_Label = 6712;
this.solvencyLabel67.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel67.TabIndex = 67;
this.solvencyLabel67.Text = "Republic of Latvia" ;
this.solvencyLabel67.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel68
//
this.solvencyLabel68.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel68.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel68.Location = new System.Drawing.Point(285,369);
this.solvencyLabel68.Name = "solvencyLabel68";
this.solvencyLabel68.OrdinateID_Label = 0;
this.solvencyLabel68.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel68.TabIndex = 68;
this.solvencyLabel68.Text = "R3460" ;
this.solvencyLabel68.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel69
//
this.solvencyLabel69.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel69.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel69.Location = new System.Drawing.Point(17,389);
this.solvencyLabel69.Name = "solvencyLabel69";
this.solvencyLabel69.OrdinateID_Label = 6713;
this.solvencyLabel69.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel69.TabIndex = 69;
this.solvencyLabel69.Text = "Republic of Lithuania" ;
this.solvencyLabel69.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel70
//
this.solvencyLabel70.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel70.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel70.Location = new System.Drawing.Point(285,389);
this.solvencyLabel70.Name = "solvencyLabel70";
this.solvencyLabel70.OrdinateID_Label = 0;
this.solvencyLabel70.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel70.TabIndex = 70;
this.solvencyLabel70.Text = "R3470" ;
this.solvencyLabel70.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel71
//
this.solvencyLabel71.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel71.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel71.Location = new System.Drawing.Point(17,409);
this.solvencyLabel71.Name = "solvencyLabel71";
this.solvencyLabel71.OrdinateID_Label = 6714;
this.solvencyLabel71.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel71.TabIndex = 71;
this.solvencyLabel71.Text = "Grand Duchy of Luxemburg" ;
this.solvencyLabel71.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel72
//
this.solvencyLabel72.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel72.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel72.Location = new System.Drawing.Point(285,409);
this.solvencyLabel72.Name = "solvencyLabel72";
this.solvencyLabel72.OrdinateID_Label = 0;
this.solvencyLabel72.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel72.TabIndex = 72;
this.solvencyLabel72.Text = "R3480" ;
this.solvencyLabel72.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel73
//
this.solvencyLabel73.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel73.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel73.Location = new System.Drawing.Point(17,429);
this.solvencyLabel73.Name = "solvencyLabel73";
this.solvencyLabel73.OrdinateID_Label = 6715;
this.solvencyLabel73.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel73.TabIndex = 73;
this.solvencyLabel73.Text = "Republic of Malta" ;
this.solvencyLabel73.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel74
//
this.solvencyLabel74.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel74.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel74.Location = new System.Drawing.Point(285,429);
this.solvencyLabel74.Name = "solvencyLabel74";
this.solvencyLabel74.OrdinateID_Label = 0;
this.solvencyLabel74.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel74.TabIndex = 74;
this.solvencyLabel74.Text = "R3490" ;
this.solvencyLabel74.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel75
//
this.solvencyLabel75.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel75.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel75.Location = new System.Drawing.Point(17,449);
this.solvencyLabel75.Name = "solvencyLabel75";
this.solvencyLabel75.OrdinateID_Label = 6716;
this.solvencyLabel75.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel75.TabIndex = 75;
this.solvencyLabel75.Text = "Kingdom of the Netherlands" ;
this.solvencyLabel75.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel76
//
this.solvencyLabel76.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel76.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel76.Location = new System.Drawing.Point(285,449);
this.solvencyLabel76.Name = "solvencyLabel76";
this.solvencyLabel76.OrdinateID_Label = 0;
this.solvencyLabel76.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel76.TabIndex = 76;
this.solvencyLabel76.Text = "R3500" ;
this.solvencyLabel76.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel77
//
this.solvencyLabel77.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel77.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel77.Location = new System.Drawing.Point(17,469);
this.solvencyLabel77.Name = "solvencyLabel77";
this.solvencyLabel77.OrdinateID_Label = 6717;
this.solvencyLabel77.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel77.TabIndex = 77;
this.solvencyLabel77.Text = "Kingdom of Norway" ;
this.solvencyLabel77.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel78
//
this.solvencyLabel78.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel78.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel78.Location = new System.Drawing.Point(285,469);
this.solvencyLabel78.Name = "solvencyLabel78";
this.solvencyLabel78.OrdinateID_Label = 0;
this.solvencyLabel78.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel78.TabIndex = 78;
this.solvencyLabel78.Text = "R3510" ;
this.solvencyLabel78.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel79
//
this.solvencyLabel79.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel79.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel79.Location = new System.Drawing.Point(17,489);
this.solvencyLabel79.Name = "solvencyLabel79";
this.solvencyLabel79.OrdinateID_Label = 6718;
this.solvencyLabel79.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel79.TabIndex = 79;
this.solvencyLabel79.Text = "Republic of Poland" ;
this.solvencyLabel79.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel80
//
this.solvencyLabel80.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel80.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel80.Location = new System.Drawing.Point(285,489);
this.solvencyLabel80.Name = "solvencyLabel80";
this.solvencyLabel80.OrdinateID_Label = 0;
this.solvencyLabel80.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel80.TabIndex = 80;
this.solvencyLabel80.Text = "R3520" ;
this.solvencyLabel80.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel81
//
this.solvencyLabel81.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel81.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel81.Location = new System.Drawing.Point(17,509);
this.solvencyLabel81.Name = "solvencyLabel81";
this.solvencyLabel81.OrdinateID_Label = 6719;
this.solvencyLabel81.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel81.TabIndex = 81;
this.solvencyLabel81.Text = "Portuguese Republic" ;
this.solvencyLabel81.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel82
//
this.solvencyLabel82.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel82.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel82.Location = new System.Drawing.Point(285,509);
this.solvencyLabel82.Name = "solvencyLabel82";
this.solvencyLabel82.OrdinateID_Label = 0;
this.solvencyLabel82.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel82.TabIndex = 82;
this.solvencyLabel82.Text = "R3530" ;
this.solvencyLabel82.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel83
//
this.solvencyLabel83.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel83.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel83.Location = new System.Drawing.Point(17,529);
this.solvencyLabel83.Name = "solvencyLabel83";
this.solvencyLabel83.OrdinateID_Label = 6720;
this.solvencyLabel83.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel83.TabIndex = 83;
this.solvencyLabel83.Text = "Romania" ;
this.solvencyLabel83.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel84
//
this.solvencyLabel84.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel84.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel84.Location = new System.Drawing.Point(285,529);
this.solvencyLabel84.Name = "solvencyLabel84";
this.solvencyLabel84.OrdinateID_Label = 0;
this.solvencyLabel84.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel84.TabIndex = 84;
this.solvencyLabel84.Text = "R3540" ;
this.solvencyLabel84.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel85
//
this.solvencyLabel85.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel85.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel85.Location = new System.Drawing.Point(17,549);
this.solvencyLabel85.Name = "solvencyLabel85";
this.solvencyLabel85.OrdinateID_Label = 6721;
this.solvencyLabel85.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel85.TabIndex = 85;
this.solvencyLabel85.Text = "Slovak Republic" ;
this.solvencyLabel85.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel86
//
this.solvencyLabel86.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel86.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel86.Location = new System.Drawing.Point(285,549);
this.solvencyLabel86.Name = "solvencyLabel86";
this.solvencyLabel86.OrdinateID_Label = 0;
this.solvencyLabel86.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel86.TabIndex = 86;
this.solvencyLabel86.Text = "R3550" ;
this.solvencyLabel86.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel87
//
this.solvencyLabel87.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel87.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel87.Location = new System.Drawing.Point(17,569);
this.solvencyLabel87.Name = "solvencyLabel87";
this.solvencyLabel87.OrdinateID_Label = 6722;
this.solvencyLabel87.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel87.TabIndex = 87;
this.solvencyLabel87.Text = "Republic of Slovenia" ;
this.solvencyLabel87.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel88
//
this.solvencyLabel88.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel88.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel88.Location = new System.Drawing.Point(285,569);
this.solvencyLabel88.Name = "solvencyLabel88";
this.solvencyLabel88.OrdinateID_Label = 0;
this.solvencyLabel88.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel88.TabIndex = 88;
this.solvencyLabel88.Text = "R3560" ;
this.solvencyLabel88.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel89
//
this.solvencyLabel89.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel89.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel89.Location = new System.Drawing.Point(17,589);
this.solvencyLabel89.Name = "solvencyLabel89";
this.solvencyLabel89.OrdinateID_Label = 6723;
this.solvencyLabel89.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel89.TabIndex = 89;
this.solvencyLabel89.Text = "Kingdom of Spain" ;
this.solvencyLabel89.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel90
//
this.solvencyLabel90.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel90.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel90.Location = new System.Drawing.Point(285,589);
this.solvencyLabel90.Name = "solvencyLabel90";
this.solvencyLabel90.OrdinateID_Label = 0;
this.solvencyLabel90.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel90.TabIndex = 90;
this.solvencyLabel90.Text = "R3570" ;
this.solvencyLabel90.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel91
//
this.solvencyLabel91.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel91.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel91.Location = new System.Drawing.Point(17,609);
this.solvencyLabel91.Name = "solvencyLabel91";
this.solvencyLabel91.OrdinateID_Label = 6724;
this.solvencyLabel91.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel91.TabIndex = 91;
this.solvencyLabel91.Text = "Kingdom of Sweden" ;
this.solvencyLabel91.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel92
//
this.solvencyLabel92.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel92.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel92.Location = new System.Drawing.Point(285,609);
this.solvencyLabel92.Name = "solvencyLabel92";
this.solvencyLabel92.OrdinateID_Label = 0;
this.solvencyLabel92.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel92.TabIndex = 92;
this.solvencyLabel92.Text = "R3580" ;
this.solvencyLabel92.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel93
//
this.solvencyLabel93.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel93.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel93.Location = new System.Drawing.Point(17,629);
this.solvencyLabel93.Name = "solvencyLabel93";
this.solvencyLabel93.OrdinateID_Label = 6725;
this.solvencyLabel93.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel93.TabIndex = 93;
this.solvencyLabel93.Text = "Swiss Confederation" ;
this.solvencyLabel93.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel94
//
this.solvencyLabel94.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel94.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel94.Location = new System.Drawing.Point(285,629);
this.solvencyLabel94.Name = "solvencyLabel94";
this.solvencyLabel94.OrdinateID_Label = 0;
this.solvencyLabel94.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel94.TabIndex = 94;
this.solvencyLabel94.Text = "R3590" ;
this.solvencyLabel94.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel95
//
this.solvencyLabel95.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel95.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel95.Location = new System.Drawing.Point(17,649);
this.solvencyLabel95.Name = "solvencyLabel95";
this.solvencyLabel95.OrdinateID_Label = 6726;
this.solvencyLabel95.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel95.TabIndex = 95;
this.solvencyLabel95.Text = "United Kingdom of Great Britain and Northern Ireland" ;
this.solvencyLabel95.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel96
//
this.solvencyLabel96.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel96.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel96.Location = new System.Drawing.Point(285,649);
this.solvencyLabel96.Name = "solvencyLabel96";
this.solvencyLabel96.OrdinateID_Label = 0;
this.solvencyLabel96.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel96.TabIndex = 96;
this.solvencyLabel96.Text = "R3600" ;
this.solvencyLabel96.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel97
//
this.solvencyLabel97.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel97.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel97.Location = new System.Drawing.Point(17,682);
this.solvencyLabel97.Name = "solvencyLabel97";
this.solvencyLabel97.OrdinateID_Label = 6727;
this.solvencyLabel97.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel97.TabIndex = 97;
this.solvencyLabel97.Text = "Total Mass accident all countries before diversification" ;
this.solvencyLabel97.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel98
//
this.solvencyLabel98.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel98.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel98.Location = new System.Drawing.Point(285,682);
this.solvencyLabel98.Name = "solvencyLabel98";
this.solvencyLabel98.OrdinateID_Label = 0;
this.solvencyLabel98.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel98.TabIndex = 98;
this.solvencyLabel98.Text = "R3610" ;
this.solvencyLabel98.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel99
//
this.solvencyLabel99.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel99.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel99.Location = new System.Drawing.Point(17,715);
this.solvencyLabel99.Name = "solvencyLabel99";
this.solvencyLabel99.OrdinateID_Label = 6728;
this.solvencyLabel99.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel99.TabIndex = 99;
this.solvencyLabel99.Text = "Diversification effect between countries" ;
this.solvencyLabel99.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel100
//
this.solvencyLabel100.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel100.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel100.Location = new System.Drawing.Point(285,715);
this.solvencyLabel100.Name = "solvencyLabel100";
this.solvencyLabel100.OrdinateID_Label = 0;
this.solvencyLabel100.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel100.TabIndex = 100;
this.solvencyLabel100.Text = "R3620" ;
this.solvencyLabel100.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel101
//
this.solvencyLabel101.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel101.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel101.Location = new System.Drawing.Point(17,735);
this.solvencyLabel101.Name = "solvencyLabel101";
this.solvencyLabel101.OrdinateID_Label = 6729;
this.solvencyLabel101.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel101.TabIndex = 101;
this.solvencyLabel101.Text = "Total Mass accident all countries after diversification" ;
this.solvencyLabel101.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel102
//
this.solvencyLabel102.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel102.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel102.Location = new System.Drawing.Point(285,735);
this.solvencyLabel102.Name = "solvencyLabel102";
this.solvencyLabel102.OrdinateID_Label = 0;
this.solvencyLabel102.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel102.TabIndex = 102;
this.solvencyLabel102.Text = "R3630" ;
this.solvencyLabel102.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel103
//
this.solvencyLabel103.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel103.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel103.Location = new System.Drawing.Point(285,755);
this.solvencyLabel103.Name = "solvencyLabel103";
this.solvencyLabel103.OrdinateID_Label = 0;
this.solvencyLabel103.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel103.TabIndex = 103;
this.solvencyLabel103.Text = "." ;
this.solvencyLabel103.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyCurrencyTextBox104
//
this.solvencyCurrencyTextBox104.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox104.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox104.Location = new System.Drawing.Point(10,23);
this.solvencyCurrencyTextBox104.Name = "solvencyCurrencyTextBox104";
this.solvencyCurrencyTextBox104.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox104.TabIndex = 104;
this.solvencyCurrencyTextBox104.ColName = "R3300C1170";
this.solvencyCurrencyTextBox104.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox105
//
this.solvencyCurrencyTextBox105.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox105.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox105.Location = new System.Drawing.Point(117,23);
this.solvencyCurrencyTextBox105.Name = "solvencyCurrencyTextBox105";
this.solvencyCurrencyTextBox105.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox105.TabIndex = 105;
this.solvencyCurrencyTextBox105.ColName = "R3300C1180";
this.solvencyCurrencyTextBox105.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox106
//
this.solvencyCurrencyTextBox106.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox106.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox106.Location = new System.Drawing.Point(224,23);
this.solvencyCurrencyTextBox106.Name = "solvencyCurrencyTextBox106";
this.solvencyCurrencyTextBox106.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox106.TabIndex = 106;
this.solvencyCurrencyTextBox106.ColName = "R3300C1190";
this.solvencyCurrencyTextBox106.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox107
//
this.solvencyCurrencyTextBox107.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox107.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox107.Location = new System.Drawing.Point(331,23);
this.solvencyCurrencyTextBox107.Name = "solvencyCurrencyTextBox107";
this.solvencyCurrencyTextBox107.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox107.TabIndex = 107;
this.solvencyCurrencyTextBox107.ColName = "R3300C1200";
this.solvencyCurrencyTextBox107.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox108
//
this.solvencyCurrencyTextBox108.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox108.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox108.Location = new System.Drawing.Point(438,23);
this.solvencyCurrencyTextBox108.Name = "solvencyCurrencyTextBox108";
this.solvencyCurrencyTextBox108.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox108.TabIndex = 108;
this.solvencyCurrencyTextBox108.ColName = "R3300C1210";
this.solvencyCurrencyTextBox108.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox109
//
this.solvencyCurrencyTextBox109.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox109.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox109.Location = new System.Drawing.Point(545,23);
this.solvencyCurrencyTextBox109.Name = "solvencyCurrencyTextBox109";
this.solvencyCurrencyTextBox109.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox109.TabIndex = 109;
this.solvencyCurrencyTextBox109.ColName = "R3300C1220";
this.solvencyCurrencyTextBox109.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox110
//
this.solvencyCurrencyTextBox110.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox110.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox110.Location = new System.Drawing.Point(652,23);
this.solvencyCurrencyTextBox110.Name = "solvencyCurrencyTextBox110";
this.solvencyCurrencyTextBox110.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox110.TabIndex = 110;
this.solvencyCurrencyTextBox110.ColName = "R3300C1230";
this.solvencyCurrencyTextBox110.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox111
//
this.solvencyCurrencyTextBox111.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox111.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox111.Location = new System.Drawing.Point(759,23);
this.solvencyCurrencyTextBox111.Name = "solvencyCurrencyTextBox111";
this.solvencyCurrencyTextBox111.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox111.TabIndex = 111;
this.solvencyCurrencyTextBox111.ColName = "R3300C1240";
this.solvencyCurrencyTextBox111.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox112
//
this.solvencyCurrencyTextBox112.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox112.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox112.Location = new System.Drawing.Point(866,23);
this.solvencyCurrencyTextBox112.Name = "solvencyCurrencyTextBox112";
this.solvencyCurrencyTextBox112.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox112.TabIndex = 112;
this.solvencyCurrencyTextBox112.ColName = "R3300C1250";
this.solvencyCurrencyTextBox112.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox113
//
this.solvencyCurrencyTextBox113.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox113.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox113.Location = new System.Drawing.Point(973,23);
this.solvencyCurrencyTextBox113.Name = "solvencyCurrencyTextBox113";
this.solvencyCurrencyTextBox113.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox113.TabIndex = 113;
this.solvencyCurrencyTextBox113.ColName = "R3300C1260";
this.solvencyCurrencyTextBox113.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox114
//
this.solvencyCurrencyTextBox114.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox114.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox114.Location = new System.Drawing.Point(1080,23);
this.solvencyCurrencyTextBox114.Name = "solvencyCurrencyTextBox114";
this.solvencyCurrencyTextBox114.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox114.TabIndex = 114;
this.solvencyCurrencyTextBox114.ColName = "R3300C1270";
this.solvencyCurrencyTextBox114.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox115
//
this.solvencyCurrencyTextBox115.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox115.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox115.Location = new System.Drawing.Point(1187,23);
this.solvencyCurrencyTextBox115.Name = "solvencyCurrencyTextBox115";
this.solvencyCurrencyTextBox115.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox115.TabIndex = 115;
this.solvencyCurrencyTextBox115.ColName = "R3300C1280";
this.solvencyCurrencyTextBox115.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox116
//
this.solvencyCurrencyTextBox116.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox116.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox116.Location = new System.Drawing.Point(1294,23);
this.solvencyCurrencyTextBox116.Name = "solvencyCurrencyTextBox116";
this.solvencyCurrencyTextBox116.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox116.TabIndex = 116;
this.solvencyCurrencyTextBox116.ColName = "R3300C1290";
this.solvencyCurrencyTextBox116.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox117
//
this.solvencyCurrencyTextBox117.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox117.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox117.Location = new System.Drawing.Point(1401,23);
this.solvencyCurrencyTextBox117.Name = "solvencyCurrencyTextBox117";
this.solvencyCurrencyTextBox117.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox117.TabIndex = 117;
this.solvencyCurrencyTextBox117.ColName = "R3300C1300";
this.solvencyCurrencyTextBox117.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox118
//
this.solvencyCurrencyTextBox118.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox118.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox118.Location = new System.Drawing.Point(10,43);
this.solvencyCurrencyTextBox118.Name = "solvencyCurrencyTextBox118";
this.solvencyCurrencyTextBox118.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox118.TabIndex = 118;
this.solvencyCurrencyTextBox118.ColName = "R3310C1170";
this.solvencyCurrencyTextBox118.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox119
//
this.solvencyCurrencyTextBox119.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox119.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox119.Location = new System.Drawing.Point(117,43);
this.solvencyCurrencyTextBox119.Name = "solvencyCurrencyTextBox119";
this.solvencyCurrencyTextBox119.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox119.TabIndex = 119;
this.solvencyCurrencyTextBox119.ColName = "R3310C1180";
this.solvencyCurrencyTextBox119.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox120
//
this.solvencyCurrencyTextBox120.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox120.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox120.Location = new System.Drawing.Point(224,43);
this.solvencyCurrencyTextBox120.Name = "solvencyCurrencyTextBox120";
this.solvencyCurrencyTextBox120.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox120.TabIndex = 120;
this.solvencyCurrencyTextBox120.ColName = "R3310C1190";
this.solvencyCurrencyTextBox120.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox121
//
this.solvencyCurrencyTextBox121.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox121.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox121.Location = new System.Drawing.Point(331,43);
this.solvencyCurrencyTextBox121.Name = "solvencyCurrencyTextBox121";
this.solvencyCurrencyTextBox121.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox121.TabIndex = 121;
this.solvencyCurrencyTextBox121.ColName = "R3310C1200";
this.solvencyCurrencyTextBox121.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox122
//
this.solvencyCurrencyTextBox122.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox122.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox122.Location = new System.Drawing.Point(438,43);
this.solvencyCurrencyTextBox122.Name = "solvencyCurrencyTextBox122";
this.solvencyCurrencyTextBox122.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox122.TabIndex = 122;
this.solvencyCurrencyTextBox122.ColName = "R3310C1210";
this.solvencyCurrencyTextBox122.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox123
//
this.solvencyCurrencyTextBox123.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox123.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox123.Location = new System.Drawing.Point(545,43);
this.solvencyCurrencyTextBox123.Name = "solvencyCurrencyTextBox123";
this.solvencyCurrencyTextBox123.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox123.TabIndex = 123;
this.solvencyCurrencyTextBox123.ColName = "R3310C1220";
this.solvencyCurrencyTextBox123.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox124
//
this.solvencyCurrencyTextBox124.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox124.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox124.Location = new System.Drawing.Point(652,43);
this.solvencyCurrencyTextBox124.Name = "solvencyCurrencyTextBox124";
this.solvencyCurrencyTextBox124.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox124.TabIndex = 124;
this.solvencyCurrencyTextBox124.ColName = "R3310C1230";
this.solvencyCurrencyTextBox124.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox125
//
this.solvencyCurrencyTextBox125.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox125.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox125.Location = new System.Drawing.Point(759,43);
this.solvencyCurrencyTextBox125.Name = "solvencyCurrencyTextBox125";
this.solvencyCurrencyTextBox125.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox125.TabIndex = 125;
this.solvencyCurrencyTextBox125.ColName = "R3310C1240";
this.solvencyCurrencyTextBox125.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox126
//
this.solvencyCurrencyTextBox126.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox126.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox126.Location = new System.Drawing.Point(866,43);
this.solvencyCurrencyTextBox126.Name = "solvencyCurrencyTextBox126";
this.solvencyCurrencyTextBox126.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox126.TabIndex = 126;
this.solvencyCurrencyTextBox126.ColName = "R3310C1250";
this.solvencyCurrencyTextBox126.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox127
//
this.solvencyCurrencyTextBox127.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox127.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox127.Location = new System.Drawing.Point(973,43);
this.solvencyCurrencyTextBox127.Name = "solvencyCurrencyTextBox127";
this.solvencyCurrencyTextBox127.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox127.TabIndex = 127;
this.solvencyCurrencyTextBox127.ColName = "R3310C1260";
this.solvencyCurrencyTextBox127.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox128
//
this.solvencyCurrencyTextBox128.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox128.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox128.Location = new System.Drawing.Point(1080,43);
this.solvencyCurrencyTextBox128.Name = "solvencyCurrencyTextBox128";
this.solvencyCurrencyTextBox128.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox128.TabIndex = 128;
this.solvencyCurrencyTextBox128.ColName = "R3310C1270";
this.solvencyCurrencyTextBox128.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox129
//
this.solvencyCurrencyTextBox129.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox129.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox129.Location = new System.Drawing.Point(1187,43);
this.solvencyCurrencyTextBox129.Name = "solvencyCurrencyTextBox129";
this.solvencyCurrencyTextBox129.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox129.TabIndex = 129;
this.solvencyCurrencyTextBox129.ColName = "R3310C1280";
this.solvencyCurrencyTextBox129.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox130
//
this.solvencyCurrencyTextBox130.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox130.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox130.Location = new System.Drawing.Point(1294,43);
this.solvencyCurrencyTextBox130.Name = "solvencyCurrencyTextBox130";
this.solvencyCurrencyTextBox130.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox130.TabIndex = 130;
this.solvencyCurrencyTextBox130.ColName = "R3310C1290";
this.solvencyCurrencyTextBox130.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox131
//
this.solvencyCurrencyTextBox131.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox131.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox131.Location = new System.Drawing.Point(1401,43);
this.solvencyCurrencyTextBox131.Name = "solvencyCurrencyTextBox131";
this.solvencyCurrencyTextBox131.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox131.TabIndex = 131;
this.solvencyCurrencyTextBox131.ColName = "R3310C1300";
this.solvencyCurrencyTextBox131.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox132
//
this.solvencyCurrencyTextBox132.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox132.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox132.Location = new System.Drawing.Point(10,63);
this.solvencyCurrencyTextBox132.Name = "solvencyCurrencyTextBox132";
this.solvencyCurrencyTextBox132.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox132.TabIndex = 132;
this.solvencyCurrencyTextBox132.ColName = "R3320C1170";
this.solvencyCurrencyTextBox132.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox133
//
this.solvencyCurrencyTextBox133.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox133.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox133.Location = new System.Drawing.Point(117,63);
this.solvencyCurrencyTextBox133.Name = "solvencyCurrencyTextBox133";
this.solvencyCurrencyTextBox133.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox133.TabIndex = 133;
this.solvencyCurrencyTextBox133.ColName = "R3320C1180";
this.solvencyCurrencyTextBox133.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox134
//
this.solvencyCurrencyTextBox134.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox134.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox134.Location = new System.Drawing.Point(224,63);
this.solvencyCurrencyTextBox134.Name = "solvencyCurrencyTextBox134";
this.solvencyCurrencyTextBox134.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox134.TabIndex = 134;
this.solvencyCurrencyTextBox134.ColName = "R3320C1190";
this.solvencyCurrencyTextBox134.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox135
//
this.solvencyCurrencyTextBox135.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox135.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox135.Location = new System.Drawing.Point(331,63);
this.solvencyCurrencyTextBox135.Name = "solvencyCurrencyTextBox135";
this.solvencyCurrencyTextBox135.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox135.TabIndex = 135;
this.solvencyCurrencyTextBox135.ColName = "R3320C1200";
this.solvencyCurrencyTextBox135.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox136
//
this.solvencyCurrencyTextBox136.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox136.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox136.Location = new System.Drawing.Point(438,63);
this.solvencyCurrencyTextBox136.Name = "solvencyCurrencyTextBox136";
this.solvencyCurrencyTextBox136.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox136.TabIndex = 136;
this.solvencyCurrencyTextBox136.ColName = "R3320C1210";
this.solvencyCurrencyTextBox136.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox137
//
this.solvencyCurrencyTextBox137.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox137.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox137.Location = new System.Drawing.Point(545,63);
this.solvencyCurrencyTextBox137.Name = "solvencyCurrencyTextBox137";
this.solvencyCurrencyTextBox137.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox137.TabIndex = 137;
this.solvencyCurrencyTextBox137.ColName = "R3320C1220";
this.solvencyCurrencyTextBox137.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox138
//
this.solvencyCurrencyTextBox138.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox138.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox138.Location = new System.Drawing.Point(652,63);
this.solvencyCurrencyTextBox138.Name = "solvencyCurrencyTextBox138";
this.solvencyCurrencyTextBox138.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox138.TabIndex = 138;
this.solvencyCurrencyTextBox138.ColName = "R3320C1230";
this.solvencyCurrencyTextBox138.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox139
//
this.solvencyCurrencyTextBox139.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox139.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox139.Location = new System.Drawing.Point(759,63);
this.solvencyCurrencyTextBox139.Name = "solvencyCurrencyTextBox139";
this.solvencyCurrencyTextBox139.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox139.TabIndex = 139;
this.solvencyCurrencyTextBox139.ColName = "R3320C1240";
this.solvencyCurrencyTextBox139.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox140
//
this.solvencyCurrencyTextBox140.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox140.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox140.Location = new System.Drawing.Point(866,63);
this.solvencyCurrencyTextBox140.Name = "solvencyCurrencyTextBox140";
this.solvencyCurrencyTextBox140.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox140.TabIndex = 140;
this.solvencyCurrencyTextBox140.ColName = "R3320C1250";
this.solvencyCurrencyTextBox140.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox141
//
this.solvencyCurrencyTextBox141.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox141.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox141.Location = new System.Drawing.Point(973,63);
this.solvencyCurrencyTextBox141.Name = "solvencyCurrencyTextBox141";
this.solvencyCurrencyTextBox141.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox141.TabIndex = 141;
this.solvencyCurrencyTextBox141.ColName = "R3320C1260";
this.solvencyCurrencyTextBox141.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox142
//
this.solvencyCurrencyTextBox142.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox142.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox142.Location = new System.Drawing.Point(1080,63);
this.solvencyCurrencyTextBox142.Name = "solvencyCurrencyTextBox142";
this.solvencyCurrencyTextBox142.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox142.TabIndex = 142;
this.solvencyCurrencyTextBox142.ColName = "R3320C1270";
this.solvencyCurrencyTextBox142.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox143
//
this.solvencyCurrencyTextBox143.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox143.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox143.Location = new System.Drawing.Point(1187,63);
this.solvencyCurrencyTextBox143.Name = "solvencyCurrencyTextBox143";
this.solvencyCurrencyTextBox143.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox143.TabIndex = 143;
this.solvencyCurrencyTextBox143.ColName = "R3320C1280";
this.solvencyCurrencyTextBox143.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox144
//
this.solvencyCurrencyTextBox144.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox144.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox144.Location = new System.Drawing.Point(1294,63);
this.solvencyCurrencyTextBox144.Name = "solvencyCurrencyTextBox144";
this.solvencyCurrencyTextBox144.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox144.TabIndex = 144;
this.solvencyCurrencyTextBox144.ColName = "R3320C1290";
this.solvencyCurrencyTextBox144.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox145
//
this.solvencyCurrencyTextBox145.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox145.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox145.Location = new System.Drawing.Point(1401,63);
this.solvencyCurrencyTextBox145.Name = "solvencyCurrencyTextBox145";
this.solvencyCurrencyTextBox145.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox145.TabIndex = 145;
this.solvencyCurrencyTextBox145.ColName = "R3320C1300";
this.solvencyCurrencyTextBox145.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox146
//
this.solvencyCurrencyTextBox146.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox146.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox146.Location = new System.Drawing.Point(10,83);
this.solvencyCurrencyTextBox146.Name = "solvencyCurrencyTextBox146";
this.solvencyCurrencyTextBox146.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox146.TabIndex = 146;
this.solvencyCurrencyTextBox146.ColName = "R3330C1170";
this.solvencyCurrencyTextBox146.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox147
//
this.solvencyCurrencyTextBox147.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox147.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox147.Location = new System.Drawing.Point(117,83);
this.solvencyCurrencyTextBox147.Name = "solvencyCurrencyTextBox147";
this.solvencyCurrencyTextBox147.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox147.TabIndex = 147;
this.solvencyCurrencyTextBox147.ColName = "R3330C1180";
this.solvencyCurrencyTextBox147.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox148
//
this.solvencyCurrencyTextBox148.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox148.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox148.Location = new System.Drawing.Point(224,83);
this.solvencyCurrencyTextBox148.Name = "solvencyCurrencyTextBox148";
this.solvencyCurrencyTextBox148.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox148.TabIndex = 148;
this.solvencyCurrencyTextBox148.ColName = "R3330C1190";
this.solvencyCurrencyTextBox148.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox149
//
this.solvencyCurrencyTextBox149.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox149.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox149.Location = new System.Drawing.Point(331,83);
this.solvencyCurrencyTextBox149.Name = "solvencyCurrencyTextBox149";
this.solvencyCurrencyTextBox149.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox149.TabIndex = 149;
this.solvencyCurrencyTextBox149.ColName = "R3330C1200";
this.solvencyCurrencyTextBox149.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox150
//
this.solvencyCurrencyTextBox150.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox150.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox150.Location = new System.Drawing.Point(438,83);
this.solvencyCurrencyTextBox150.Name = "solvencyCurrencyTextBox150";
this.solvencyCurrencyTextBox150.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox150.TabIndex = 150;
this.solvencyCurrencyTextBox150.ColName = "R3330C1210";
this.solvencyCurrencyTextBox150.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox151
//
this.solvencyCurrencyTextBox151.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox151.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox151.Location = new System.Drawing.Point(545,83);
this.solvencyCurrencyTextBox151.Name = "solvencyCurrencyTextBox151";
this.solvencyCurrencyTextBox151.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox151.TabIndex = 151;
this.solvencyCurrencyTextBox151.ColName = "R3330C1220";
this.solvencyCurrencyTextBox151.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox152
//
this.solvencyCurrencyTextBox152.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox152.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox152.Location = new System.Drawing.Point(652,83);
this.solvencyCurrencyTextBox152.Name = "solvencyCurrencyTextBox152";
this.solvencyCurrencyTextBox152.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox152.TabIndex = 152;
this.solvencyCurrencyTextBox152.ColName = "R3330C1230";
this.solvencyCurrencyTextBox152.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox153
//
this.solvencyCurrencyTextBox153.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox153.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox153.Location = new System.Drawing.Point(759,83);
this.solvencyCurrencyTextBox153.Name = "solvencyCurrencyTextBox153";
this.solvencyCurrencyTextBox153.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox153.TabIndex = 153;
this.solvencyCurrencyTextBox153.ColName = "R3330C1240";
this.solvencyCurrencyTextBox153.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox154
//
this.solvencyCurrencyTextBox154.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox154.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox154.Location = new System.Drawing.Point(866,83);
this.solvencyCurrencyTextBox154.Name = "solvencyCurrencyTextBox154";
this.solvencyCurrencyTextBox154.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox154.TabIndex = 154;
this.solvencyCurrencyTextBox154.ColName = "R3330C1250";
this.solvencyCurrencyTextBox154.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox155
//
this.solvencyCurrencyTextBox155.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox155.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox155.Location = new System.Drawing.Point(973,83);
this.solvencyCurrencyTextBox155.Name = "solvencyCurrencyTextBox155";
this.solvencyCurrencyTextBox155.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox155.TabIndex = 155;
this.solvencyCurrencyTextBox155.ColName = "R3330C1260";
this.solvencyCurrencyTextBox155.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox156
//
this.solvencyCurrencyTextBox156.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox156.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox156.Location = new System.Drawing.Point(1080,83);
this.solvencyCurrencyTextBox156.Name = "solvencyCurrencyTextBox156";
this.solvencyCurrencyTextBox156.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox156.TabIndex = 156;
this.solvencyCurrencyTextBox156.ColName = "R3330C1270";
this.solvencyCurrencyTextBox156.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox157
//
this.solvencyCurrencyTextBox157.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox157.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox157.Location = new System.Drawing.Point(1187,83);
this.solvencyCurrencyTextBox157.Name = "solvencyCurrencyTextBox157";
this.solvencyCurrencyTextBox157.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox157.TabIndex = 157;
this.solvencyCurrencyTextBox157.ColName = "R3330C1280";
this.solvencyCurrencyTextBox157.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox158
//
this.solvencyCurrencyTextBox158.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox158.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox158.Location = new System.Drawing.Point(1294,83);
this.solvencyCurrencyTextBox158.Name = "solvencyCurrencyTextBox158";
this.solvencyCurrencyTextBox158.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox158.TabIndex = 158;
this.solvencyCurrencyTextBox158.ColName = "R3330C1290";
this.solvencyCurrencyTextBox158.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox159
//
this.solvencyCurrencyTextBox159.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox159.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox159.Location = new System.Drawing.Point(1401,83);
this.solvencyCurrencyTextBox159.Name = "solvencyCurrencyTextBox159";
this.solvencyCurrencyTextBox159.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox159.TabIndex = 159;
this.solvencyCurrencyTextBox159.ColName = "R3330C1300";
this.solvencyCurrencyTextBox159.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox160
//
this.solvencyCurrencyTextBox160.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox160.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox160.Location = new System.Drawing.Point(10,103);
this.solvencyCurrencyTextBox160.Name = "solvencyCurrencyTextBox160";
this.solvencyCurrencyTextBox160.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox160.TabIndex = 160;
this.solvencyCurrencyTextBox160.ColName = "R3340C1170";
this.solvencyCurrencyTextBox160.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox161
//
this.solvencyCurrencyTextBox161.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox161.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox161.Location = new System.Drawing.Point(117,103);
this.solvencyCurrencyTextBox161.Name = "solvencyCurrencyTextBox161";
this.solvencyCurrencyTextBox161.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox161.TabIndex = 161;
this.solvencyCurrencyTextBox161.ColName = "R3340C1180";
this.solvencyCurrencyTextBox161.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox162
//
this.solvencyCurrencyTextBox162.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox162.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox162.Location = new System.Drawing.Point(224,103);
this.solvencyCurrencyTextBox162.Name = "solvencyCurrencyTextBox162";
this.solvencyCurrencyTextBox162.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox162.TabIndex = 162;
this.solvencyCurrencyTextBox162.ColName = "R3340C1190";
this.solvencyCurrencyTextBox162.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox163
//
this.solvencyCurrencyTextBox163.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox163.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox163.Location = new System.Drawing.Point(331,103);
this.solvencyCurrencyTextBox163.Name = "solvencyCurrencyTextBox163";
this.solvencyCurrencyTextBox163.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox163.TabIndex = 163;
this.solvencyCurrencyTextBox163.ColName = "R3340C1200";
this.solvencyCurrencyTextBox163.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox164
//
this.solvencyCurrencyTextBox164.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox164.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox164.Location = new System.Drawing.Point(438,103);
this.solvencyCurrencyTextBox164.Name = "solvencyCurrencyTextBox164";
this.solvencyCurrencyTextBox164.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox164.TabIndex = 164;
this.solvencyCurrencyTextBox164.ColName = "R3340C1210";
this.solvencyCurrencyTextBox164.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox165
//
this.solvencyCurrencyTextBox165.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox165.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox165.Location = new System.Drawing.Point(545,103);
this.solvencyCurrencyTextBox165.Name = "solvencyCurrencyTextBox165";
this.solvencyCurrencyTextBox165.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox165.TabIndex = 165;
this.solvencyCurrencyTextBox165.ColName = "R3340C1220";
this.solvencyCurrencyTextBox165.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox166
//
this.solvencyCurrencyTextBox166.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox166.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox166.Location = new System.Drawing.Point(652,103);
this.solvencyCurrencyTextBox166.Name = "solvencyCurrencyTextBox166";
this.solvencyCurrencyTextBox166.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox166.TabIndex = 166;
this.solvencyCurrencyTextBox166.ColName = "R3340C1230";
this.solvencyCurrencyTextBox166.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox167
//
this.solvencyCurrencyTextBox167.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox167.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox167.Location = new System.Drawing.Point(759,103);
this.solvencyCurrencyTextBox167.Name = "solvencyCurrencyTextBox167";
this.solvencyCurrencyTextBox167.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox167.TabIndex = 167;
this.solvencyCurrencyTextBox167.ColName = "R3340C1240";
this.solvencyCurrencyTextBox167.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox168
//
this.solvencyCurrencyTextBox168.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox168.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox168.Location = new System.Drawing.Point(866,103);
this.solvencyCurrencyTextBox168.Name = "solvencyCurrencyTextBox168";
this.solvencyCurrencyTextBox168.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox168.TabIndex = 168;
this.solvencyCurrencyTextBox168.ColName = "R3340C1250";
this.solvencyCurrencyTextBox168.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox169
//
this.solvencyCurrencyTextBox169.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox169.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox169.Location = new System.Drawing.Point(973,103);
this.solvencyCurrencyTextBox169.Name = "solvencyCurrencyTextBox169";
this.solvencyCurrencyTextBox169.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox169.TabIndex = 169;
this.solvencyCurrencyTextBox169.ColName = "R3340C1260";
this.solvencyCurrencyTextBox169.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox170
//
this.solvencyCurrencyTextBox170.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox170.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox170.Location = new System.Drawing.Point(1080,103);
this.solvencyCurrencyTextBox170.Name = "solvencyCurrencyTextBox170";
this.solvencyCurrencyTextBox170.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox170.TabIndex = 170;
this.solvencyCurrencyTextBox170.ColName = "R3340C1270";
this.solvencyCurrencyTextBox170.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox171
//
this.solvencyCurrencyTextBox171.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox171.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox171.Location = new System.Drawing.Point(1187,103);
this.solvencyCurrencyTextBox171.Name = "solvencyCurrencyTextBox171";
this.solvencyCurrencyTextBox171.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox171.TabIndex = 171;
this.solvencyCurrencyTextBox171.ColName = "R3340C1280";
this.solvencyCurrencyTextBox171.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox172
//
this.solvencyCurrencyTextBox172.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox172.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox172.Location = new System.Drawing.Point(1294,103);
this.solvencyCurrencyTextBox172.Name = "solvencyCurrencyTextBox172";
this.solvencyCurrencyTextBox172.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox172.TabIndex = 172;
this.solvencyCurrencyTextBox172.ColName = "R3340C1290";
this.solvencyCurrencyTextBox172.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox173
//
this.solvencyCurrencyTextBox173.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox173.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox173.Location = new System.Drawing.Point(1401,103);
this.solvencyCurrencyTextBox173.Name = "solvencyCurrencyTextBox173";
this.solvencyCurrencyTextBox173.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox173.TabIndex = 173;
this.solvencyCurrencyTextBox173.ColName = "R3340C1300";
this.solvencyCurrencyTextBox173.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox174
//
this.solvencyCurrencyTextBox174.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox174.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox174.Location = new System.Drawing.Point(10,123);
this.solvencyCurrencyTextBox174.Name = "solvencyCurrencyTextBox174";
this.solvencyCurrencyTextBox174.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox174.TabIndex = 174;
this.solvencyCurrencyTextBox174.ColName = "R3350C1170";
this.solvencyCurrencyTextBox174.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox175
//
this.solvencyCurrencyTextBox175.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox175.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox175.Location = new System.Drawing.Point(117,123);
this.solvencyCurrencyTextBox175.Name = "solvencyCurrencyTextBox175";
this.solvencyCurrencyTextBox175.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox175.TabIndex = 175;
this.solvencyCurrencyTextBox175.ColName = "R3350C1180";
this.solvencyCurrencyTextBox175.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox176
//
this.solvencyCurrencyTextBox176.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox176.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox176.Location = new System.Drawing.Point(224,123);
this.solvencyCurrencyTextBox176.Name = "solvencyCurrencyTextBox176";
this.solvencyCurrencyTextBox176.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox176.TabIndex = 176;
this.solvencyCurrencyTextBox176.ColName = "R3350C1190";
this.solvencyCurrencyTextBox176.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox177
//
this.solvencyCurrencyTextBox177.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox177.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox177.Location = new System.Drawing.Point(331,123);
this.solvencyCurrencyTextBox177.Name = "solvencyCurrencyTextBox177";
this.solvencyCurrencyTextBox177.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox177.TabIndex = 177;
this.solvencyCurrencyTextBox177.ColName = "R3350C1200";
this.solvencyCurrencyTextBox177.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox178
//
this.solvencyCurrencyTextBox178.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox178.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox178.Location = new System.Drawing.Point(438,123);
this.solvencyCurrencyTextBox178.Name = "solvencyCurrencyTextBox178";
this.solvencyCurrencyTextBox178.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox178.TabIndex = 178;
this.solvencyCurrencyTextBox178.ColName = "R3350C1210";
this.solvencyCurrencyTextBox178.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox179
//
this.solvencyCurrencyTextBox179.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox179.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox179.Location = new System.Drawing.Point(545,123);
this.solvencyCurrencyTextBox179.Name = "solvencyCurrencyTextBox179";
this.solvencyCurrencyTextBox179.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox179.TabIndex = 179;
this.solvencyCurrencyTextBox179.ColName = "R3350C1220";
this.solvencyCurrencyTextBox179.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox180
//
this.solvencyCurrencyTextBox180.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox180.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox180.Location = new System.Drawing.Point(652,123);
this.solvencyCurrencyTextBox180.Name = "solvencyCurrencyTextBox180";
this.solvencyCurrencyTextBox180.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox180.TabIndex = 180;
this.solvencyCurrencyTextBox180.ColName = "R3350C1230";
this.solvencyCurrencyTextBox180.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox181
//
this.solvencyCurrencyTextBox181.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox181.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox181.Location = new System.Drawing.Point(759,123);
this.solvencyCurrencyTextBox181.Name = "solvencyCurrencyTextBox181";
this.solvencyCurrencyTextBox181.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox181.TabIndex = 181;
this.solvencyCurrencyTextBox181.ColName = "R3350C1240";
this.solvencyCurrencyTextBox181.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox182
//
this.solvencyCurrencyTextBox182.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox182.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox182.Location = new System.Drawing.Point(866,123);
this.solvencyCurrencyTextBox182.Name = "solvencyCurrencyTextBox182";
this.solvencyCurrencyTextBox182.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox182.TabIndex = 182;
this.solvencyCurrencyTextBox182.ColName = "R3350C1250";
this.solvencyCurrencyTextBox182.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox183
//
this.solvencyCurrencyTextBox183.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox183.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox183.Location = new System.Drawing.Point(973,123);
this.solvencyCurrencyTextBox183.Name = "solvencyCurrencyTextBox183";
this.solvencyCurrencyTextBox183.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox183.TabIndex = 183;
this.solvencyCurrencyTextBox183.ColName = "R3350C1260";
this.solvencyCurrencyTextBox183.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox184
//
this.solvencyCurrencyTextBox184.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox184.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox184.Location = new System.Drawing.Point(1080,123);
this.solvencyCurrencyTextBox184.Name = "solvencyCurrencyTextBox184";
this.solvencyCurrencyTextBox184.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox184.TabIndex = 184;
this.solvencyCurrencyTextBox184.ColName = "R3350C1270";
this.solvencyCurrencyTextBox184.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox185
//
this.solvencyCurrencyTextBox185.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox185.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox185.Location = new System.Drawing.Point(1187,123);
this.solvencyCurrencyTextBox185.Name = "solvencyCurrencyTextBox185";
this.solvencyCurrencyTextBox185.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox185.TabIndex = 185;
this.solvencyCurrencyTextBox185.ColName = "R3350C1280";
this.solvencyCurrencyTextBox185.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox186
//
this.solvencyCurrencyTextBox186.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox186.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox186.Location = new System.Drawing.Point(1294,123);
this.solvencyCurrencyTextBox186.Name = "solvencyCurrencyTextBox186";
this.solvencyCurrencyTextBox186.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox186.TabIndex = 186;
this.solvencyCurrencyTextBox186.ColName = "R3350C1290";
this.solvencyCurrencyTextBox186.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox187
//
this.solvencyCurrencyTextBox187.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox187.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox187.Location = new System.Drawing.Point(1401,123);
this.solvencyCurrencyTextBox187.Name = "solvencyCurrencyTextBox187";
this.solvencyCurrencyTextBox187.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox187.TabIndex = 187;
this.solvencyCurrencyTextBox187.ColName = "R3350C1300";
this.solvencyCurrencyTextBox187.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox188
//
this.solvencyCurrencyTextBox188.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox188.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox188.Location = new System.Drawing.Point(10,143);
this.solvencyCurrencyTextBox188.Name = "solvencyCurrencyTextBox188";
this.solvencyCurrencyTextBox188.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox188.TabIndex = 188;
this.solvencyCurrencyTextBox188.ColName = "R3360C1170";
this.solvencyCurrencyTextBox188.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox189
//
this.solvencyCurrencyTextBox189.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox189.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox189.Location = new System.Drawing.Point(117,143);
this.solvencyCurrencyTextBox189.Name = "solvencyCurrencyTextBox189";
this.solvencyCurrencyTextBox189.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox189.TabIndex = 189;
this.solvencyCurrencyTextBox189.ColName = "R3360C1180";
this.solvencyCurrencyTextBox189.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox190
//
this.solvencyCurrencyTextBox190.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox190.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox190.Location = new System.Drawing.Point(224,143);
this.solvencyCurrencyTextBox190.Name = "solvencyCurrencyTextBox190";
this.solvencyCurrencyTextBox190.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox190.TabIndex = 190;
this.solvencyCurrencyTextBox190.ColName = "R3360C1190";
this.solvencyCurrencyTextBox190.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox191
//
this.solvencyCurrencyTextBox191.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox191.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox191.Location = new System.Drawing.Point(331,143);
this.solvencyCurrencyTextBox191.Name = "solvencyCurrencyTextBox191";
this.solvencyCurrencyTextBox191.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox191.TabIndex = 191;
this.solvencyCurrencyTextBox191.ColName = "R3360C1200";
this.solvencyCurrencyTextBox191.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox192
//
this.solvencyCurrencyTextBox192.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox192.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox192.Location = new System.Drawing.Point(438,143);
this.solvencyCurrencyTextBox192.Name = "solvencyCurrencyTextBox192";
this.solvencyCurrencyTextBox192.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox192.TabIndex = 192;
this.solvencyCurrencyTextBox192.ColName = "R3360C1210";
this.solvencyCurrencyTextBox192.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox193
//
this.solvencyCurrencyTextBox193.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox193.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox193.Location = new System.Drawing.Point(545,143);
this.solvencyCurrencyTextBox193.Name = "solvencyCurrencyTextBox193";
this.solvencyCurrencyTextBox193.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox193.TabIndex = 193;
this.solvencyCurrencyTextBox193.ColName = "R3360C1220";
this.solvencyCurrencyTextBox193.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox194
//
this.solvencyCurrencyTextBox194.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox194.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox194.Location = new System.Drawing.Point(652,143);
this.solvencyCurrencyTextBox194.Name = "solvencyCurrencyTextBox194";
this.solvencyCurrencyTextBox194.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox194.TabIndex = 194;
this.solvencyCurrencyTextBox194.ColName = "R3360C1230";
this.solvencyCurrencyTextBox194.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox195
//
this.solvencyCurrencyTextBox195.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox195.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox195.Location = new System.Drawing.Point(759,143);
this.solvencyCurrencyTextBox195.Name = "solvencyCurrencyTextBox195";
this.solvencyCurrencyTextBox195.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox195.TabIndex = 195;
this.solvencyCurrencyTextBox195.ColName = "R3360C1240";
this.solvencyCurrencyTextBox195.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox196
//
this.solvencyCurrencyTextBox196.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox196.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox196.Location = new System.Drawing.Point(866,143);
this.solvencyCurrencyTextBox196.Name = "solvencyCurrencyTextBox196";
this.solvencyCurrencyTextBox196.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox196.TabIndex = 196;
this.solvencyCurrencyTextBox196.ColName = "R3360C1250";
this.solvencyCurrencyTextBox196.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox197
//
this.solvencyCurrencyTextBox197.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox197.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox197.Location = new System.Drawing.Point(973,143);
this.solvencyCurrencyTextBox197.Name = "solvencyCurrencyTextBox197";
this.solvencyCurrencyTextBox197.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox197.TabIndex = 197;
this.solvencyCurrencyTextBox197.ColName = "R3360C1260";
this.solvencyCurrencyTextBox197.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox198
//
this.solvencyCurrencyTextBox198.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox198.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox198.Location = new System.Drawing.Point(1080,143);
this.solvencyCurrencyTextBox198.Name = "solvencyCurrencyTextBox198";
this.solvencyCurrencyTextBox198.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox198.TabIndex = 198;
this.solvencyCurrencyTextBox198.ColName = "R3360C1270";
this.solvencyCurrencyTextBox198.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox199
//
this.solvencyCurrencyTextBox199.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox199.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox199.Location = new System.Drawing.Point(1187,143);
this.solvencyCurrencyTextBox199.Name = "solvencyCurrencyTextBox199";
this.solvencyCurrencyTextBox199.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox199.TabIndex = 199;
this.solvencyCurrencyTextBox199.ColName = "R3360C1280";
this.solvencyCurrencyTextBox199.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox200
//
this.solvencyCurrencyTextBox200.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox200.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox200.Location = new System.Drawing.Point(1294,143);
this.solvencyCurrencyTextBox200.Name = "solvencyCurrencyTextBox200";
this.solvencyCurrencyTextBox200.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox200.TabIndex = 200;
this.solvencyCurrencyTextBox200.ColName = "R3360C1290";
this.solvencyCurrencyTextBox200.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox201
//
this.solvencyCurrencyTextBox201.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox201.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox201.Location = new System.Drawing.Point(1401,143);
this.solvencyCurrencyTextBox201.Name = "solvencyCurrencyTextBox201";
this.solvencyCurrencyTextBox201.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox201.TabIndex = 201;
this.solvencyCurrencyTextBox201.ColName = "R3360C1300";
this.solvencyCurrencyTextBox201.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox202
//
this.solvencyCurrencyTextBox202.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox202.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox202.Location = new System.Drawing.Point(10,163);
this.solvencyCurrencyTextBox202.Name = "solvencyCurrencyTextBox202";
this.solvencyCurrencyTextBox202.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox202.TabIndex = 202;
this.solvencyCurrencyTextBox202.ColName = "R3370C1170";
this.solvencyCurrencyTextBox202.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox203
//
this.solvencyCurrencyTextBox203.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox203.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox203.Location = new System.Drawing.Point(117,163);
this.solvencyCurrencyTextBox203.Name = "solvencyCurrencyTextBox203";
this.solvencyCurrencyTextBox203.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox203.TabIndex = 203;
this.solvencyCurrencyTextBox203.ColName = "R3370C1180";
this.solvencyCurrencyTextBox203.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox204
//
this.solvencyCurrencyTextBox204.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox204.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox204.Location = new System.Drawing.Point(224,163);
this.solvencyCurrencyTextBox204.Name = "solvencyCurrencyTextBox204";
this.solvencyCurrencyTextBox204.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox204.TabIndex = 204;
this.solvencyCurrencyTextBox204.ColName = "R3370C1190";
this.solvencyCurrencyTextBox204.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox205
//
this.solvencyCurrencyTextBox205.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox205.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox205.Location = new System.Drawing.Point(331,163);
this.solvencyCurrencyTextBox205.Name = "solvencyCurrencyTextBox205";
this.solvencyCurrencyTextBox205.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox205.TabIndex = 205;
this.solvencyCurrencyTextBox205.ColName = "R3370C1200";
this.solvencyCurrencyTextBox205.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox206
//
this.solvencyCurrencyTextBox206.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox206.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox206.Location = new System.Drawing.Point(438,163);
this.solvencyCurrencyTextBox206.Name = "solvencyCurrencyTextBox206";
this.solvencyCurrencyTextBox206.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox206.TabIndex = 206;
this.solvencyCurrencyTextBox206.ColName = "R3370C1210";
this.solvencyCurrencyTextBox206.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox207
//
this.solvencyCurrencyTextBox207.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox207.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox207.Location = new System.Drawing.Point(545,163);
this.solvencyCurrencyTextBox207.Name = "solvencyCurrencyTextBox207";
this.solvencyCurrencyTextBox207.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox207.TabIndex = 207;
this.solvencyCurrencyTextBox207.ColName = "R3370C1220";
this.solvencyCurrencyTextBox207.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox208
//
this.solvencyCurrencyTextBox208.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox208.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox208.Location = new System.Drawing.Point(652,163);
this.solvencyCurrencyTextBox208.Name = "solvencyCurrencyTextBox208";
this.solvencyCurrencyTextBox208.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox208.TabIndex = 208;
this.solvencyCurrencyTextBox208.ColName = "R3370C1230";
this.solvencyCurrencyTextBox208.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox209
//
this.solvencyCurrencyTextBox209.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox209.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox209.Location = new System.Drawing.Point(759,163);
this.solvencyCurrencyTextBox209.Name = "solvencyCurrencyTextBox209";
this.solvencyCurrencyTextBox209.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox209.TabIndex = 209;
this.solvencyCurrencyTextBox209.ColName = "R3370C1240";
this.solvencyCurrencyTextBox209.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox210
//
this.solvencyCurrencyTextBox210.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox210.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox210.Location = new System.Drawing.Point(866,163);
this.solvencyCurrencyTextBox210.Name = "solvencyCurrencyTextBox210";
this.solvencyCurrencyTextBox210.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox210.TabIndex = 210;
this.solvencyCurrencyTextBox210.ColName = "R3370C1250";
this.solvencyCurrencyTextBox210.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox211
//
this.solvencyCurrencyTextBox211.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox211.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox211.Location = new System.Drawing.Point(973,163);
this.solvencyCurrencyTextBox211.Name = "solvencyCurrencyTextBox211";
this.solvencyCurrencyTextBox211.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox211.TabIndex = 211;
this.solvencyCurrencyTextBox211.ColName = "R3370C1260";
this.solvencyCurrencyTextBox211.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox212
//
this.solvencyCurrencyTextBox212.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox212.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox212.Location = new System.Drawing.Point(1080,163);
this.solvencyCurrencyTextBox212.Name = "solvencyCurrencyTextBox212";
this.solvencyCurrencyTextBox212.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox212.TabIndex = 212;
this.solvencyCurrencyTextBox212.ColName = "R3370C1270";
this.solvencyCurrencyTextBox212.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox213
//
this.solvencyCurrencyTextBox213.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox213.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox213.Location = new System.Drawing.Point(1187,163);
this.solvencyCurrencyTextBox213.Name = "solvencyCurrencyTextBox213";
this.solvencyCurrencyTextBox213.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox213.TabIndex = 213;
this.solvencyCurrencyTextBox213.ColName = "R3370C1280";
this.solvencyCurrencyTextBox213.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox214
//
this.solvencyCurrencyTextBox214.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox214.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox214.Location = new System.Drawing.Point(1294,163);
this.solvencyCurrencyTextBox214.Name = "solvencyCurrencyTextBox214";
this.solvencyCurrencyTextBox214.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox214.TabIndex = 214;
this.solvencyCurrencyTextBox214.ColName = "R3370C1290";
this.solvencyCurrencyTextBox214.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox215
//
this.solvencyCurrencyTextBox215.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox215.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox215.Location = new System.Drawing.Point(1401,163);
this.solvencyCurrencyTextBox215.Name = "solvencyCurrencyTextBox215";
this.solvencyCurrencyTextBox215.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox215.TabIndex = 215;
this.solvencyCurrencyTextBox215.ColName = "R3370C1300";
this.solvencyCurrencyTextBox215.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox216
//
this.solvencyCurrencyTextBox216.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox216.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox216.Location = new System.Drawing.Point(10,183);
this.solvencyCurrencyTextBox216.Name = "solvencyCurrencyTextBox216";
this.solvencyCurrencyTextBox216.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox216.TabIndex = 216;
this.solvencyCurrencyTextBox216.ColName = "R3380C1170";
this.solvencyCurrencyTextBox216.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox217
//
this.solvencyCurrencyTextBox217.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox217.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox217.Location = new System.Drawing.Point(117,183);
this.solvencyCurrencyTextBox217.Name = "solvencyCurrencyTextBox217";
this.solvencyCurrencyTextBox217.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox217.TabIndex = 217;
this.solvencyCurrencyTextBox217.ColName = "R3380C1180";
this.solvencyCurrencyTextBox217.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox218
//
this.solvencyCurrencyTextBox218.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox218.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox218.Location = new System.Drawing.Point(224,183);
this.solvencyCurrencyTextBox218.Name = "solvencyCurrencyTextBox218";
this.solvencyCurrencyTextBox218.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox218.TabIndex = 218;
this.solvencyCurrencyTextBox218.ColName = "R3380C1190";
this.solvencyCurrencyTextBox218.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox219
//
this.solvencyCurrencyTextBox219.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox219.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox219.Location = new System.Drawing.Point(331,183);
this.solvencyCurrencyTextBox219.Name = "solvencyCurrencyTextBox219";
this.solvencyCurrencyTextBox219.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox219.TabIndex = 219;
this.solvencyCurrencyTextBox219.ColName = "R3380C1200";
this.solvencyCurrencyTextBox219.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox220
//
this.solvencyCurrencyTextBox220.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox220.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox220.Location = new System.Drawing.Point(438,183);
this.solvencyCurrencyTextBox220.Name = "solvencyCurrencyTextBox220";
this.solvencyCurrencyTextBox220.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox220.TabIndex = 220;
this.solvencyCurrencyTextBox220.ColName = "R3380C1210";
this.solvencyCurrencyTextBox220.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox221
//
this.solvencyCurrencyTextBox221.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox221.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox221.Location = new System.Drawing.Point(545,183);
this.solvencyCurrencyTextBox221.Name = "solvencyCurrencyTextBox221";
this.solvencyCurrencyTextBox221.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox221.TabIndex = 221;
this.solvencyCurrencyTextBox221.ColName = "R3380C1220";
this.solvencyCurrencyTextBox221.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox222
//
this.solvencyCurrencyTextBox222.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox222.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox222.Location = new System.Drawing.Point(652,183);
this.solvencyCurrencyTextBox222.Name = "solvencyCurrencyTextBox222";
this.solvencyCurrencyTextBox222.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox222.TabIndex = 222;
this.solvencyCurrencyTextBox222.ColName = "R3380C1230";
this.solvencyCurrencyTextBox222.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox223
//
this.solvencyCurrencyTextBox223.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox223.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox223.Location = new System.Drawing.Point(759,183);
this.solvencyCurrencyTextBox223.Name = "solvencyCurrencyTextBox223";
this.solvencyCurrencyTextBox223.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox223.TabIndex = 223;
this.solvencyCurrencyTextBox223.ColName = "R3380C1240";
this.solvencyCurrencyTextBox223.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox224
//
this.solvencyCurrencyTextBox224.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox224.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox224.Location = new System.Drawing.Point(866,183);
this.solvencyCurrencyTextBox224.Name = "solvencyCurrencyTextBox224";
this.solvencyCurrencyTextBox224.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox224.TabIndex = 224;
this.solvencyCurrencyTextBox224.ColName = "R3380C1250";
this.solvencyCurrencyTextBox224.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox225
//
this.solvencyCurrencyTextBox225.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox225.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox225.Location = new System.Drawing.Point(973,183);
this.solvencyCurrencyTextBox225.Name = "solvencyCurrencyTextBox225";
this.solvencyCurrencyTextBox225.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox225.TabIndex = 225;
this.solvencyCurrencyTextBox225.ColName = "R3380C1260";
this.solvencyCurrencyTextBox225.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox226
//
this.solvencyCurrencyTextBox226.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox226.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox226.Location = new System.Drawing.Point(1080,183);
this.solvencyCurrencyTextBox226.Name = "solvencyCurrencyTextBox226";
this.solvencyCurrencyTextBox226.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox226.TabIndex = 226;
this.solvencyCurrencyTextBox226.ColName = "R3380C1270";
this.solvencyCurrencyTextBox226.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox227
//
this.solvencyCurrencyTextBox227.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox227.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox227.Location = new System.Drawing.Point(1187,183);
this.solvencyCurrencyTextBox227.Name = "solvencyCurrencyTextBox227";
this.solvencyCurrencyTextBox227.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox227.TabIndex = 227;
this.solvencyCurrencyTextBox227.ColName = "R3380C1280";
this.solvencyCurrencyTextBox227.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox228
//
this.solvencyCurrencyTextBox228.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox228.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox228.Location = new System.Drawing.Point(1294,183);
this.solvencyCurrencyTextBox228.Name = "solvencyCurrencyTextBox228";
this.solvencyCurrencyTextBox228.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox228.TabIndex = 228;
this.solvencyCurrencyTextBox228.ColName = "R3380C1290";
this.solvencyCurrencyTextBox228.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox229
//
this.solvencyCurrencyTextBox229.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox229.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox229.Location = new System.Drawing.Point(1401,183);
this.solvencyCurrencyTextBox229.Name = "solvencyCurrencyTextBox229";
this.solvencyCurrencyTextBox229.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox229.TabIndex = 229;
this.solvencyCurrencyTextBox229.ColName = "R3380C1300";
this.solvencyCurrencyTextBox229.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox230
//
this.solvencyCurrencyTextBox230.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox230.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox230.Location = new System.Drawing.Point(10,203);
this.solvencyCurrencyTextBox230.Name = "solvencyCurrencyTextBox230";
this.solvencyCurrencyTextBox230.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox230.TabIndex = 230;
this.solvencyCurrencyTextBox230.ColName = "R3390C1170";
this.solvencyCurrencyTextBox230.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox231
//
this.solvencyCurrencyTextBox231.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox231.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox231.Location = new System.Drawing.Point(117,203);
this.solvencyCurrencyTextBox231.Name = "solvencyCurrencyTextBox231";
this.solvencyCurrencyTextBox231.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox231.TabIndex = 231;
this.solvencyCurrencyTextBox231.ColName = "R3390C1180";
this.solvencyCurrencyTextBox231.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox232
//
this.solvencyCurrencyTextBox232.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox232.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox232.Location = new System.Drawing.Point(224,203);
this.solvencyCurrencyTextBox232.Name = "solvencyCurrencyTextBox232";
this.solvencyCurrencyTextBox232.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox232.TabIndex = 232;
this.solvencyCurrencyTextBox232.ColName = "R3390C1190";
this.solvencyCurrencyTextBox232.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox233
//
this.solvencyCurrencyTextBox233.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox233.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox233.Location = new System.Drawing.Point(331,203);
this.solvencyCurrencyTextBox233.Name = "solvencyCurrencyTextBox233";
this.solvencyCurrencyTextBox233.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox233.TabIndex = 233;
this.solvencyCurrencyTextBox233.ColName = "R3390C1200";
this.solvencyCurrencyTextBox233.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox234
//
this.solvencyCurrencyTextBox234.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox234.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox234.Location = new System.Drawing.Point(438,203);
this.solvencyCurrencyTextBox234.Name = "solvencyCurrencyTextBox234";
this.solvencyCurrencyTextBox234.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox234.TabIndex = 234;
this.solvencyCurrencyTextBox234.ColName = "R3390C1210";
this.solvencyCurrencyTextBox234.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox235
//
this.solvencyCurrencyTextBox235.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox235.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox235.Location = new System.Drawing.Point(545,203);
this.solvencyCurrencyTextBox235.Name = "solvencyCurrencyTextBox235";
this.solvencyCurrencyTextBox235.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox235.TabIndex = 235;
this.solvencyCurrencyTextBox235.ColName = "R3390C1220";
this.solvencyCurrencyTextBox235.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox236
//
this.solvencyCurrencyTextBox236.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox236.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox236.Location = new System.Drawing.Point(652,203);
this.solvencyCurrencyTextBox236.Name = "solvencyCurrencyTextBox236";
this.solvencyCurrencyTextBox236.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox236.TabIndex = 236;
this.solvencyCurrencyTextBox236.ColName = "R3390C1230";
this.solvencyCurrencyTextBox236.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox237
//
this.solvencyCurrencyTextBox237.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox237.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox237.Location = new System.Drawing.Point(759,203);
this.solvencyCurrencyTextBox237.Name = "solvencyCurrencyTextBox237";
this.solvencyCurrencyTextBox237.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox237.TabIndex = 237;
this.solvencyCurrencyTextBox237.ColName = "R3390C1240";
this.solvencyCurrencyTextBox237.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox238
//
this.solvencyCurrencyTextBox238.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox238.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox238.Location = new System.Drawing.Point(866,203);
this.solvencyCurrencyTextBox238.Name = "solvencyCurrencyTextBox238";
this.solvencyCurrencyTextBox238.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox238.TabIndex = 238;
this.solvencyCurrencyTextBox238.ColName = "R3390C1250";
this.solvencyCurrencyTextBox238.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox239
//
this.solvencyCurrencyTextBox239.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox239.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox239.Location = new System.Drawing.Point(973,203);
this.solvencyCurrencyTextBox239.Name = "solvencyCurrencyTextBox239";
this.solvencyCurrencyTextBox239.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox239.TabIndex = 239;
this.solvencyCurrencyTextBox239.ColName = "R3390C1260";
this.solvencyCurrencyTextBox239.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox240
//
this.solvencyCurrencyTextBox240.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox240.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox240.Location = new System.Drawing.Point(1080,203);
this.solvencyCurrencyTextBox240.Name = "solvencyCurrencyTextBox240";
this.solvencyCurrencyTextBox240.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox240.TabIndex = 240;
this.solvencyCurrencyTextBox240.ColName = "R3390C1270";
this.solvencyCurrencyTextBox240.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox241
//
this.solvencyCurrencyTextBox241.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox241.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox241.Location = new System.Drawing.Point(1187,203);
this.solvencyCurrencyTextBox241.Name = "solvencyCurrencyTextBox241";
this.solvencyCurrencyTextBox241.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox241.TabIndex = 241;
this.solvencyCurrencyTextBox241.ColName = "R3390C1280";
this.solvencyCurrencyTextBox241.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox242
//
this.solvencyCurrencyTextBox242.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox242.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox242.Location = new System.Drawing.Point(1294,203);
this.solvencyCurrencyTextBox242.Name = "solvencyCurrencyTextBox242";
this.solvencyCurrencyTextBox242.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox242.TabIndex = 242;
this.solvencyCurrencyTextBox242.ColName = "R3390C1290";
this.solvencyCurrencyTextBox242.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox243
//
this.solvencyCurrencyTextBox243.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox243.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox243.Location = new System.Drawing.Point(1401,203);
this.solvencyCurrencyTextBox243.Name = "solvencyCurrencyTextBox243";
this.solvencyCurrencyTextBox243.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox243.TabIndex = 243;
this.solvencyCurrencyTextBox243.ColName = "R3390C1300";
this.solvencyCurrencyTextBox243.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox244
//
this.solvencyCurrencyTextBox244.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox244.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox244.Location = new System.Drawing.Point(10,236);
this.solvencyCurrencyTextBox244.Name = "solvencyCurrencyTextBox244";
this.solvencyCurrencyTextBox244.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox244.TabIndex = 244;
this.solvencyCurrencyTextBox244.ColName = "R3400C1170";
this.solvencyCurrencyTextBox244.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox245
//
this.solvencyCurrencyTextBox245.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox245.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox245.Location = new System.Drawing.Point(117,236);
this.solvencyCurrencyTextBox245.Name = "solvencyCurrencyTextBox245";
this.solvencyCurrencyTextBox245.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox245.TabIndex = 245;
this.solvencyCurrencyTextBox245.ColName = "R3400C1180";
this.solvencyCurrencyTextBox245.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox246
//
this.solvencyCurrencyTextBox246.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox246.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox246.Location = new System.Drawing.Point(224,236);
this.solvencyCurrencyTextBox246.Name = "solvencyCurrencyTextBox246";
this.solvencyCurrencyTextBox246.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox246.TabIndex = 246;
this.solvencyCurrencyTextBox246.ColName = "R3400C1190";
this.solvencyCurrencyTextBox246.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox247
//
this.solvencyCurrencyTextBox247.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox247.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox247.Location = new System.Drawing.Point(331,236);
this.solvencyCurrencyTextBox247.Name = "solvencyCurrencyTextBox247";
this.solvencyCurrencyTextBox247.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox247.TabIndex = 247;
this.solvencyCurrencyTextBox247.ColName = "R3400C1200";
this.solvencyCurrencyTextBox247.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox248
//
this.solvencyCurrencyTextBox248.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox248.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox248.Location = new System.Drawing.Point(438,236);
this.solvencyCurrencyTextBox248.Name = "solvencyCurrencyTextBox248";
this.solvencyCurrencyTextBox248.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox248.TabIndex = 248;
this.solvencyCurrencyTextBox248.ColName = "R3400C1210";
this.solvencyCurrencyTextBox248.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox249
//
this.solvencyCurrencyTextBox249.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox249.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox249.Location = new System.Drawing.Point(545,236);
this.solvencyCurrencyTextBox249.Name = "solvencyCurrencyTextBox249";
this.solvencyCurrencyTextBox249.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox249.TabIndex = 249;
this.solvencyCurrencyTextBox249.ColName = "R3400C1220";
this.solvencyCurrencyTextBox249.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox250
//
this.solvencyCurrencyTextBox250.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox250.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox250.Location = new System.Drawing.Point(652,236);
this.solvencyCurrencyTextBox250.Name = "solvencyCurrencyTextBox250";
this.solvencyCurrencyTextBox250.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox250.TabIndex = 250;
this.solvencyCurrencyTextBox250.ColName = "R3400C1230";
this.solvencyCurrencyTextBox250.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox251
//
this.solvencyCurrencyTextBox251.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox251.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox251.Location = new System.Drawing.Point(759,236);
this.solvencyCurrencyTextBox251.Name = "solvencyCurrencyTextBox251";
this.solvencyCurrencyTextBox251.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox251.TabIndex = 251;
this.solvencyCurrencyTextBox251.ColName = "R3400C1240";
this.solvencyCurrencyTextBox251.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox252
//
this.solvencyCurrencyTextBox252.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox252.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox252.Location = new System.Drawing.Point(866,236);
this.solvencyCurrencyTextBox252.Name = "solvencyCurrencyTextBox252";
this.solvencyCurrencyTextBox252.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox252.TabIndex = 252;
this.solvencyCurrencyTextBox252.ColName = "R3400C1250";
this.solvencyCurrencyTextBox252.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox253
//
this.solvencyCurrencyTextBox253.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox253.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox253.Location = new System.Drawing.Point(973,236);
this.solvencyCurrencyTextBox253.Name = "solvencyCurrencyTextBox253";
this.solvencyCurrencyTextBox253.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox253.TabIndex = 253;
this.solvencyCurrencyTextBox253.ColName = "R3400C1260";
this.solvencyCurrencyTextBox253.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox254
//
this.solvencyCurrencyTextBox254.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox254.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox254.Location = new System.Drawing.Point(1080,236);
this.solvencyCurrencyTextBox254.Name = "solvencyCurrencyTextBox254";
this.solvencyCurrencyTextBox254.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox254.TabIndex = 254;
this.solvencyCurrencyTextBox254.ColName = "R3400C1270";
this.solvencyCurrencyTextBox254.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox255
//
this.solvencyCurrencyTextBox255.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox255.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox255.Location = new System.Drawing.Point(1187,236);
this.solvencyCurrencyTextBox255.Name = "solvencyCurrencyTextBox255";
this.solvencyCurrencyTextBox255.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox255.TabIndex = 255;
this.solvencyCurrencyTextBox255.ColName = "R3400C1280";
this.solvencyCurrencyTextBox255.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox256
//
this.solvencyCurrencyTextBox256.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox256.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox256.Location = new System.Drawing.Point(1294,236);
this.solvencyCurrencyTextBox256.Name = "solvencyCurrencyTextBox256";
this.solvencyCurrencyTextBox256.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox256.TabIndex = 256;
this.solvencyCurrencyTextBox256.ColName = "R3400C1290";
this.solvencyCurrencyTextBox256.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox257
//
this.solvencyCurrencyTextBox257.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox257.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox257.Location = new System.Drawing.Point(1401,236);
this.solvencyCurrencyTextBox257.Name = "solvencyCurrencyTextBox257";
this.solvencyCurrencyTextBox257.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox257.TabIndex = 257;
this.solvencyCurrencyTextBox257.ColName = "R3400C1300";
this.solvencyCurrencyTextBox257.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox258
//
this.solvencyCurrencyTextBox258.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox258.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox258.Location = new System.Drawing.Point(10,256);
this.solvencyCurrencyTextBox258.Name = "solvencyCurrencyTextBox258";
this.solvencyCurrencyTextBox258.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox258.TabIndex = 258;
this.solvencyCurrencyTextBox258.ColName = "R3410C1170";
this.solvencyCurrencyTextBox258.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox259
//
this.solvencyCurrencyTextBox259.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox259.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox259.Location = new System.Drawing.Point(117,256);
this.solvencyCurrencyTextBox259.Name = "solvencyCurrencyTextBox259";
this.solvencyCurrencyTextBox259.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox259.TabIndex = 259;
this.solvencyCurrencyTextBox259.ColName = "R3410C1180";
this.solvencyCurrencyTextBox259.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox260
//
this.solvencyCurrencyTextBox260.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox260.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox260.Location = new System.Drawing.Point(224,256);
this.solvencyCurrencyTextBox260.Name = "solvencyCurrencyTextBox260";
this.solvencyCurrencyTextBox260.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox260.TabIndex = 260;
this.solvencyCurrencyTextBox260.ColName = "R3410C1190";
this.solvencyCurrencyTextBox260.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox261
//
this.solvencyCurrencyTextBox261.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox261.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox261.Location = new System.Drawing.Point(331,256);
this.solvencyCurrencyTextBox261.Name = "solvencyCurrencyTextBox261";
this.solvencyCurrencyTextBox261.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox261.TabIndex = 261;
this.solvencyCurrencyTextBox261.ColName = "R3410C1200";
this.solvencyCurrencyTextBox261.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox262
//
this.solvencyCurrencyTextBox262.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox262.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox262.Location = new System.Drawing.Point(438,256);
this.solvencyCurrencyTextBox262.Name = "solvencyCurrencyTextBox262";
this.solvencyCurrencyTextBox262.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox262.TabIndex = 262;
this.solvencyCurrencyTextBox262.ColName = "R3410C1210";
this.solvencyCurrencyTextBox262.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox263
//
this.solvencyCurrencyTextBox263.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox263.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox263.Location = new System.Drawing.Point(545,256);
this.solvencyCurrencyTextBox263.Name = "solvencyCurrencyTextBox263";
this.solvencyCurrencyTextBox263.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox263.TabIndex = 263;
this.solvencyCurrencyTextBox263.ColName = "R3410C1220";
this.solvencyCurrencyTextBox263.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox264
//
this.solvencyCurrencyTextBox264.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox264.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox264.Location = new System.Drawing.Point(652,256);
this.solvencyCurrencyTextBox264.Name = "solvencyCurrencyTextBox264";
this.solvencyCurrencyTextBox264.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox264.TabIndex = 264;
this.solvencyCurrencyTextBox264.ColName = "R3410C1230";
this.solvencyCurrencyTextBox264.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox265
//
this.solvencyCurrencyTextBox265.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox265.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox265.Location = new System.Drawing.Point(759,256);
this.solvencyCurrencyTextBox265.Name = "solvencyCurrencyTextBox265";
this.solvencyCurrencyTextBox265.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox265.TabIndex = 265;
this.solvencyCurrencyTextBox265.ColName = "R3410C1240";
this.solvencyCurrencyTextBox265.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox266
//
this.solvencyCurrencyTextBox266.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox266.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox266.Location = new System.Drawing.Point(866,256);
this.solvencyCurrencyTextBox266.Name = "solvencyCurrencyTextBox266";
this.solvencyCurrencyTextBox266.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox266.TabIndex = 266;
this.solvencyCurrencyTextBox266.ColName = "R3410C1250";
this.solvencyCurrencyTextBox266.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox267
//
this.solvencyCurrencyTextBox267.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox267.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox267.Location = new System.Drawing.Point(973,256);
this.solvencyCurrencyTextBox267.Name = "solvencyCurrencyTextBox267";
this.solvencyCurrencyTextBox267.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox267.TabIndex = 267;
this.solvencyCurrencyTextBox267.ColName = "R3410C1260";
this.solvencyCurrencyTextBox267.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox268
//
this.solvencyCurrencyTextBox268.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox268.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox268.Location = new System.Drawing.Point(1080,256);
this.solvencyCurrencyTextBox268.Name = "solvencyCurrencyTextBox268";
this.solvencyCurrencyTextBox268.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox268.TabIndex = 268;
this.solvencyCurrencyTextBox268.ColName = "R3410C1270";
this.solvencyCurrencyTextBox268.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox269
//
this.solvencyCurrencyTextBox269.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox269.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox269.Location = new System.Drawing.Point(1187,256);
this.solvencyCurrencyTextBox269.Name = "solvencyCurrencyTextBox269";
this.solvencyCurrencyTextBox269.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox269.TabIndex = 269;
this.solvencyCurrencyTextBox269.ColName = "R3410C1280";
this.solvencyCurrencyTextBox269.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox270
//
this.solvencyCurrencyTextBox270.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox270.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox270.Location = new System.Drawing.Point(1294,256);
this.solvencyCurrencyTextBox270.Name = "solvencyCurrencyTextBox270";
this.solvencyCurrencyTextBox270.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox270.TabIndex = 270;
this.solvencyCurrencyTextBox270.ColName = "R3410C1290";
this.solvencyCurrencyTextBox270.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox271
//
this.solvencyCurrencyTextBox271.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox271.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox271.Location = new System.Drawing.Point(1401,256);
this.solvencyCurrencyTextBox271.Name = "solvencyCurrencyTextBox271";
this.solvencyCurrencyTextBox271.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox271.TabIndex = 271;
this.solvencyCurrencyTextBox271.ColName = "R3410C1300";
this.solvencyCurrencyTextBox271.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox272
//
this.solvencyCurrencyTextBox272.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox272.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox272.Location = new System.Drawing.Point(10,276);
this.solvencyCurrencyTextBox272.Name = "solvencyCurrencyTextBox272";
this.solvencyCurrencyTextBox272.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox272.TabIndex = 272;
this.solvencyCurrencyTextBox272.ColName = "R3420C1170";
this.solvencyCurrencyTextBox272.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox273
//
this.solvencyCurrencyTextBox273.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox273.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox273.Location = new System.Drawing.Point(117,276);
this.solvencyCurrencyTextBox273.Name = "solvencyCurrencyTextBox273";
this.solvencyCurrencyTextBox273.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox273.TabIndex = 273;
this.solvencyCurrencyTextBox273.ColName = "R3420C1180";
this.solvencyCurrencyTextBox273.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox274
//
this.solvencyCurrencyTextBox274.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox274.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox274.Location = new System.Drawing.Point(224,276);
this.solvencyCurrencyTextBox274.Name = "solvencyCurrencyTextBox274";
this.solvencyCurrencyTextBox274.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox274.TabIndex = 274;
this.solvencyCurrencyTextBox274.ColName = "R3420C1190";
this.solvencyCurrencyTextBox274.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox275
//
this.solvencyCurrencyTextBox275.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox275.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox275.Location = new System.Drawing.Point(331,276);
this.solvencyCurrencyTextBox275.Name = "solvencyCurrencyTextBox275";
this.solvencyCurrencyTextBox275.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox275.TabIndex = 275;
this.solvencyCurrencyTextBox275.ColName = "R3420C1200";
this.solvencyCurrencyTextBox275.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox276
//
this.solvencyCurrencyTextBox276.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox276.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox276.Location = new System.Drawing.Point(438,276);
this.solvencyCurrencyTextBox276.Name = "solvencyCurrencyTextBox276";
this.solvencyCurrencyTextBox276.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox276.TabIndex = 276;
this.solvencyCurrencyTextBox276.ColName = "R3420C1210";
this.solvencyCurrencyTextBox276.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox277
//
this.solvencyCurrencyTextBox277.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox277.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox277.Location = new System.Drawing.Point(545,276);
this.solvencyCurrencyTextBox277.Name = "solvencyCurrencyTextBox277";
this.solvencyCurrencyTextBox277.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox277.TabIndex = 277;
this.solvencyCurrencyTextBox277.ColName = "R3420C1220";
this.solvencyCurrencyTextBox277.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox278
//
this.solvencyCurrencyTextBox278.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox278.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox278.Location = new System.Drawing.Point(652,276);
this.solvencyCurrencyTextBox278.Name = "solvencyCurrencyTextBox278";
this.solvencyCurrencyTextBox278.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox278.TabIndex = 278;
this.solvencyCurrencyTextBox278.ColName = "R3420C1230";
this.solvencyCurrencyTextBox278.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox279
//
this.solvencyCurrencyTextBox279.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox279.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox279.Location = new System.Drawing.Point(759,276);
this.solvencyCurrencyTextBox279.Name = "solvencyCurrencyTextBox279";
this.solvencyCurrencyTextBox279.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox279.TabIndex = 279;
this.solvencyCurrencyTextBox279.ColName = "R3420C1240";
this.solvencyCurrencyTextBox279.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox280
//
this.solvencyCurrencyTextBox280.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox280.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox280.Location = new System.Drawing.Point(866,276);
this.solvencyCurrencyTextBox280.Name = "solvencyCurrencyTextBox280";
this.solvencyCurrencyTextBox280.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox280.TabIndex = 280;
this.solvencyCurrencyTextBox280.ColName = "R3420C1250";
this.solvencyCurrencyTextBox280.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox281
//
this.solvencyCurrencyTextBox281.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox281.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox281.Location = new System.Drawing.Point(973,276);
this.solvencyCurrencyTextBox281.Name = "solvencyCurrencyTextBox281";
this.solvencyCurrencyTextBox281.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox281.TabIndex = 281;
this.solvencyCurrencyTextBox281.ColName = "R3420C1260";
this.solvencyCurrencyTextBox281.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox282
//
this.solvencyCurrencyTextBox282.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox282.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox282.Location = new System.Drawing.Point(1080,276);
this.solvencyCurrencyTextBox282.Name = "solvencyCurrencyTextBox282";
this.solvencyCurrencyTextBox282.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox282.TabIndex = 282;
this.solvencyCurrencyTextBox282.ColName = "R3420C1270";
this.solvencyCurrencyTextBox282.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox283
//
this.solvencyCurrencyTextBox283.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox283.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox283.Location = new System.Drawing.Point(1187,276);
this.solvencyCurrencyTextBox283.Name = "solvencyCurrencyTextBox283";
this.solvencyCurrencyTextBox283.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox283.TabIndex = 283;
this.solvencyCurrencyTextBox283.ColName = "R3420C1280";
this.solvencyCurrencyTextBox283.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox284
//
this.solvencyCurrencyTextBox284.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox284.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox284.Location = new System.Drawing.Point(1294,276);
this.solvencyCurrencyTextBox284.Name = "solvencyCurrencyTextBox284";
this.solvencyCurrencyTextBox284.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox284.TabIndex = 284;
this.solvencyCurrencyTextBox284.ColName = "R3420C1290";
this.solvencyCurrencyTextBox284.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox285
//
this.solvencyCurrencyTextBox285.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox285.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox285.Location = new System.Drawing.Point(1401,276);
this.solvencyCurrencyTextBox285.Name = "solvencyCurrencyTextBox285";
this.solvencyCurrencyTextBox285.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox285.TabIndex = 285;
this.solvencyCurrencyTextBox285.ColName = "R3420C1300";
this.solvencyCurrencyTextBox285.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox286
//
this.solvencyCurrencyTextBox286.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox286.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox286.Location = new System.Drawing.Point(10,296);
this.solvencyCurrencyTextBox286.Name = "solvencyCurrencyTextBox286";
this.solvencyCurrencyTextBox286.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox286.TabIndex = 286;
this.solvencyCurrencyTextBox286.ColName = "R3430C1170";
this.solvencyCurrencyTextBox286.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox287
//
this.solvencyCurrencyTextBox287.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox287.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox287.Location = new System.Drawing.Point(117,296);
this.solvencyCurrencyTextBox287.Name = "solvencyCurrencyTextBox287";
this.solvencyCurrencyTextBox287.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox287.TabIndex = 287;
this.solvencyCurrencyTextBox287.ColName = "R3430C1180";
this.solvencyCurrencyTextBox287.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox288
//
this.solvencyCurrencyTextBox288.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox288.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox288.Location = new System.Drawing.Point(224,296);
this.solvencyCurrencyTextBox288.Name = "solvencyCurrencyTextBox288";
this.solvencyCurrencyTextBox288.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox288.TabIndex = 288;
this.solvencyCurrencyTextBox288.ColName = "R3430C1190";
this.solvencyCurrencyTextBox288.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox289
//
this.solvencyCurrencyTextBox289.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox289.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox289.Location = new System.Drawing.Point(331,296);
this.solvencyCurrencyTextBox289.Name = "solvencyCurrencyTextBox289";
this.solvencyCurrencyTextBox289.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox289.TabIndex = 289;
this.solvencyCurrencyTextBox289.ColName = "R3430C1200";
this.solvencyCurrencyTextBox289.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox290
//
this.solvencyCurrencyTextBox290.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox290.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox290.Location = new System.Drawing.Point(438,296);
this.solvencyCurrencyTextBox290.Name = "solvencyCurrencyTextBox290";
this.solvencyCurrencyTextBox290.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox290.TabIndex = 290;
this.solvencyCurrencyTextBox290.ColName = "R3430C1210";
this.solvencyCurrencyTextBox290.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox291
//
this.solvencyCurrencyTextBox291.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox291.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox291.Location = new System.Drawing.Point(545,296);
this.solvencyCurrencyTextBox291.Name = "solvencyCurrencyTextBox291";
this.solvencyCurrencyTextBox291.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox291.TabIndex = 291;
this.solvencyCurrencyTextBox291.ColName = "R3430C1220";
this.solvencyCurrencyTextBox291.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox292
//
this.solvencyCurrencyTextBox292.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox292.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox292.Location = new System.Drawing.Point(652,296);
this.solvencyCurrencyTextBox292.Name = "solvencyCurrencyTextBox292";
this.solvencyCurrencyTextBox292.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox292.TabIndex = 292;
this.solvencyCurrencyTextBox292.ColName = "R3430C1230";
this.solvencyCurrencyTextBox292.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox293
//
this.solvencyCurrencyTextBox293.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox293.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox293.Location = new System.Drawing.Point(759,296);
this.solvencyCurrencyTextBox293.Name = "solvencyCurrencyTextBox293";
this.solvencyCurrencyTextBox293.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox293.TabIndex = 293;
this.solvencyCurrencyTextBox293.ColName = "R3430C1240";
this.solvencyCurrencyTextBox293.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox294
//
this.solvencyCurrencyTextBox294.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox294.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox294.Location = new System.Drawing.Point(866,296);
this.solvencyCurrencyTextBox294.Name = "solvencyCurrencyTextBox294";
this.solvencyCurrencyTextBox294.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox294.TabIndex = 294;
this.solvencyCurrencyTextBox294.ColName = "R3430C1250";
this.solvencyCurrencyTextBox294.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox295
//
this.solvencyCurrencyTextBox295.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox295.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox295.Location = new System.Drawing.Point(973,296);
this.solvencyCurrencyTextBox295.Name = "solvencyCurrencyTextBox295";
this.solvencyCurrencyTextBox295.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox295.TabIndex = 295;
this.solvencyCurrencyTextBox295.ColName = "R3430C1260";
this.solvencyCurrencyTextBox295.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox296
//
this.solvencyCurrencyTextBox296.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox296.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox296.Location = new System.Drawing.Point(1080,296);
this.solvencyCurrencyTextBox296.Name = "solvencyCurrencyTextBox296";
this.solvencyCurrencyTextBox296.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox296.TabIndex = 296;
this.solvencyCurrencyTextBox296.ColName = "R3430C1270";
this.solvencyCurrencyTextBox296.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox297
//
this.solvencyCurrencyTextBox297.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox297.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox297.Location = new System.Drawing.Point(1187,296);
this.solvencyCurrencyTextBox297.Name = "solvencyCurrencyTextBox297";
this.solvencyCurrencyTextBox297.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox297.TabIndex = 297;
this.solvencyCurrencyTextBox297.ColName = "R3430C1280";
this.solvencyCurrencyTextBox297.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox298
//
this.solvencyCurrencyTextBox298.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox298.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox298.Location = new System.Drawing.Point(1294,296);
this.solvencyCurrencyTextBox298.Name = "solvencyCurrencyTextBox298";
this.solvencyCurrencyTextBox298.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox298.TabIndex = 298;
this.solvencyCurrencyTextBox298.ColName = "R3430C1290";
this.solvencyCurrencyTextBox298.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox299
//
this.solvencyCurrencyTextBox299.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox299.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox299.Location = new System.Drawing.Point(1401,296);
this.solvencyCurrencyTextBox299.Name = "solvencyCurrencyTextBox299";
this.solvencyCurrencyTextBox299.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox299.TabIndex = 299;
this.solvencyCurrencyTextBox299.ColName = "R3430C1300";
this.solvencyCurrencyTextBox299.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox300
//
this.solvencyCurrencyTextBox300.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox300.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox300.Location = new System.Drawing.Point(10,316);
this.solvencyCurrencyTextBox300.Name = "solvencyCurrencyTextBox300";
this.solvencyCurrencyTextBox300.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox300.TabIndex = 300;
this.solvencyCurrencyTextBox300.ColName = "R3440C1170";
this.solvencyCurrencyTextBox300.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox301
//
this.solvencyCurrencyTextBox301.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox301.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox301.Location = new System.Drawing.Point(117,316);
this.solvencyCurrencyTextBox301.Name = "solvencyCurrencyTextBox301";
this.solvencyCurrencyTextBox301.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox301.TabIndex = 301;
this.solvencyCurrencyTextBox301.ColName = "R3440C1180";
this.solvencyCurrencyTextBox301.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox302
//
this.solvencyCurrencyTextBox302.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox302.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox302.Location = new System.Drawing.Point(224,316);
this.solvencyCurrencyTextBox302.Name = "solvencyCurrencyTextBox302";
this.solvencyCurrencyTextBox302.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox302.TabIndex = 302;
this.solvencyCurrencyTextBox302.ColName = "R3440C1190";
this.solvencyCurrencyTextBox302.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox303
//
this.solvencyCurrencyTextBox303.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox303.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox303.Location = new System.Drawing.Point(331,316);
this.solvencyCurrencyTextBox303.Name = "solvencyCurrencyTextBox303";
this.solvencyCurrencyTextBox303.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox303.TabIndex = 303;
this.solvencyCurrencyTextBox303.ColName = "R3440C1200";
this.solvencyCurrencyTextBox303.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox304
//
this.solvencyCurrencyTextBox304.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox304.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox304.Location = new System.Drawing.Point(438,316);
this.solvencyCurrencyTextBox304.Name = "solvencyCurrencyTextBox304";
this.solvencyCurrencyTextBox304.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox304.TabIndex = 304;
this.solvencyCurrencyTextBox304.ColName = "R3440C1210";
this.solvencyCurrencyTextBox304.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox305
//
this.solvencyCurrencyTextBox305.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox305.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox305.Location = new System.Drawing.Point(545,316);
this.solvencyCurrencyTextBox305.Name = "solvencyCurrencyTextBox305";
this.solvencyCurrencyTextBox305.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox305.TabIndex = 305;
this.solvencyCurrencyTextBox305.ColName = "R3440C1220";
this.solvencyCurrencyTextBox305.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox306
//
this.solvencyCurrencyTextBox306.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox306.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox306.Location = new System.Drawing.Point(652,316);
this.solvencyCurrencyTextBox306.Name = "solvencyCurrencyTextBox306";
this.solvencyCurrencyTextBox306.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox306.TabIndex = 306;
this.solvencyCurrencyTextBox306.ColName = "R3440C1230";
this.solvencyCurrencyTextBox306.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox307
//
this.solvencyCurrencyTextBox307.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox307.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox307.Location = new System.Drawing.Point(759,316);
this.solvencyCurrencyTextBox307.Name = "solvencyCurrencyTextBox307";
this.solvencyCurrencyTextBox307.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox307.TabIndex = 307;
this.solvencyCurrencyTextBox307.ColName = "R3440C1240";
this.solvencyCurrencyTextBox307.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox308
//
this.solvencyCurrencyTextBox308.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox308.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox308.Location = new System.Drawing.Point(866,316);
this.solvencyCurrencyTextBox308.Name = "solvencyCurrencyTextBox308";
this.solvencyCurrencyTextBox308.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox308.TabIndex = 308;
this.solvencyCurrencyTextBox308.ColName = "R3440C1250";
this.solvencyCurrencyTextBox308.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox309
//
this.solvencyCurrencyTextBox309.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox309.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox309.Location = new System.Drawing.Point(973,316);
this.solvencyCurrencyTextBox309.Name = "solvencyCurrencyTextBox309";
this.solvencyCurrencyTextBox309.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox309.TabIndex = 309;
this.solvencyCurrencyTextBox309.ColName = "R3440C1260";
this.solvencyCurrencyTextBox309.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox310
//
this.solvencyCurrencyTextBox310.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox310.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox310.Location = new System.Drawing.Point(1080,316);
this.solvencyCurrencyTextBox310.Name = "solvencyCurrencyTextBox310";
this.solvencyCurrencyTextBox310.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox310.TabIndex = 310;
this.solvencyCurrencyTextBox310.ColName = "R3440C1270";
this.solvencyCurrencyTextBox310.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox311
//
this.solvencyCurrencyTextBox311.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox311.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox311.Location = new System.Drawing.Point(1187,316);
this.solvencyCurrencyTextBox311.Name = "solvencyCurrencyTextBox311";
this.solvencyCurrencyTextBox311.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox311.TabIndex = 311;
this.solvencyCurrencyTextBox311.ColName = "R3440C1280";
this.solvencyCurrencyTextBox311.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox312
//
this.solvencyCurrencyTextBox312.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox312.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox312.Location = new System.Drawing.Point(1294,316);
this.solvencyCurrencyTextBox312.Name = "solvencyCurrencyTextBox312";
this.solvencyCurrencyTextBox312.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox312.TabIndex = 312;
this.solvencyCurrencyTextBox312.ColName = "R3440C1290";
this.solvencyCurrencyTextBox312.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox313
//
this.solvencyCurrencyTextBox313.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox313.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox313.Location = new System.Drawing.Point(1401,316);
this.solvencyCurrencyTextBox313.Name = "solvencyCurrencyTextBox313";
this.solvencyCurrencyTextBox313.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox313.TabIndex = 313;
this.solvencyCurrencyTextBox313.ColName = "R3440C1300";
this.solvencyCurrencyTextBox313.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox314
//
this.solvencyCurrencyTextBox314.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox314.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox314.Location = new System.Drawing.Point(10,336);
this.solvencyCurrencyTextBox314.Name = "solvencyCurrencyTextBox314";
this.solvencyCurrencyTextBox314.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox314.TabIndex = 314;
this.solvencyCurrencyTextBox314.ColName = "R3450C1170";
this.solvencyCurrencyTextBox314.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox315
//
this.solvencyCurrencyTextBox315.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox315.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox315.Location = new System.Drawing.Point(117,336);
this.solvencyCurrencyTextBox315.Name = "solvencyCurrencyTextBox315";
this.solvencyCurrencyTextBox315.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox315.TabIndex = 315;
this.solvencyCurrencyTextBox315.ColName = "R3450C1180";
this.solvencyCurrencyTextBox315.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox316
//
this.solvencyCurrencyTextBox316.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox316.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox316.Location = new System.Drawing.Point(224,336);
this.solvencyCurrencyTextBox316.Name = "solvencyCurrencyTextBox316";
this.solvencyCurrencyTextBox316.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox316.TabIndex = 316;
this.solvencyCurrencyTextBox316.ColName = "R3450C1190";
this.solvencyCurrencyTextBox316.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox317
//
this.solvencyCurrencyTextBox317.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox317.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox317.Location = new System.Drawing.Point(331,336);
this.solvencyCurrencyTextBox317.Name = "solvencyCurrencyTextBox317";
this.solvencyCurrencyTextBox317.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox317.TabIndex = 317;
this.solvencyCurrencyTextBox317.ColName = "R3450C1200";
this.solvencyCurrencyTextBox317.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox318
//
this.solvencyCurrencyTextBox318.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox318.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox318.Location = new System.Drawing.Point(438,336);
this.solvencyCurrencyTextBox318.Name = "solvencyCurrencyTextBox318";
this.solvencyCurrencyTextBox318.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox318.TabIndex = 318;
this.solvencyCurrencyTextBox318.ColName = "R3450C1210";
this.solvencyCurrencyTextBox318.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox319
//
this.solvencyCurrencyTextBox319.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox319.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox319.Location = new System.Drawing.Point(545,336);
this.solvencyCurrencyTextBox319.Name = "solvencyCurrencyTextBox319";
this.solvencyCurrencyTextBox319.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox319.TabIndex = 319;
this.solvencyCurrencyTextBox319.ColName = "R3450C1220";
this.solvencyCurrencyTextBox319.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox320
//
this.solvencyCurrencyTextBox320.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox320.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox320.Location = new System.Drawing.Point(652,336);
this.solvencyCurrencyTextBox320.Name = "solvencyCurrencyTextBox320";
this.solvencyCurrencyTextBox320.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox320.TabIndex = 320;
this.solvencyCurrencyTextBox320.ColName = "R3450C1230";
this.solvencyCurrencyTextBox320.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox321
//
this.solvencyCurrencyTextBox321.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox321.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox321.Location = new System.Drawing.Point(759,336);
this.solvencyCurrencyTextBox321.Name = "solvencyCurrencyTextBox321";
this.solvencyCurrencyTextBox321.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox321.TabIndex = 321;
this.solvencyCurrencyTextBox321.ColName = "R3450C1240";
this.solvencyCurrencyTextBox321.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox322
//
this.solvencyCurrencyTextBox322.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox322.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox322.Location = new System.Drawing.Point(866,336);
this.solvencyCurrencyTextBox322.Name = "solvencyCurrencyTextBox322";
this.solvencyCurrencyTextBox322.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox322.TabIndex = 322;
this.solvencyCurrencyTextBox322.ColName = "R3450C1250";
this.solvencyCurrencyTextBox322.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox323
//
this.solvencyCurrencyTextBox323.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox323.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox323.Location = new System.Drawing.Point(973,336);
this.solvencyCurrencyTextBox323.Name = "solvencyCurrencyTextBox323";
this.solvencyCurrencyTextBox323.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox323.TabIndex = 323;
this.solvencyCurrencyTextBox323.ColName = "R3450C1260";
this.solvencyCurrencyTextBox323.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox324
//
this.solvencyCurrencyTextBox324.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox324.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox324.Location = new System.Drawing.Point(1080,336);
this.solvencyCurrencyTextBox324.Name = "solvencyCurrencyTextBox324";
this.solvencyCurrencyTextBox324.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox324.TabIndex = 324;
this.solvencyCurrencyTextBox324.ColName = "R3450C1270";
this.solvencyCurrencyTextBox324.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox325
//
this.solvencyCurrencyTextBox325.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox325.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox325.Location = new System.Drawing.Point(1187,336);
this.solvencyCurrencyTextBox325.Name = "solvencyCurrencyTextBox325";
this.solvencyCurrencyTextBox325.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox325.TabIndex = 325;
this.solvencyCurrencyTextBox325.ColName = "R3450C1280";
this.solvencyCurrencyTextBox325.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox326
//
this.solvencyCurrencyTextBox326.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox326.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox326.Location = new System.Drawing.Point(1294,336);
this.solvencyCurrencyTextBox326.Name = "solvencyCurrencyTextBox326";
this.solvencyCurrencyTextBox326.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox326.TabIndex = 326;
this.solvencyCurrencyTextBox326.ColName = "R3450C1290";
this.solvencyCurrencyTextBox326.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox327
//
this.solvencyCurrencyTextBox327.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox327.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox327.Location = new System.Drawing.Point(1401,336);
this.solvencyCurrencyTextBox327.Name = "solvencyCurrencyTextBox327";
this.solvencyCurrencyTextBox327.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox327.TabIndex = 327;
this.solvencyCurrencyTextBox327.ColName = "R3450C1300";
this.solvencyCurrencyTextBox327.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox328
//
this.solvencyCurrencyTextBox328.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox328.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox328.Location = new System.Drawing.Point(10,369);
this.solvencyCurrencyTextBox328.Name = "solvencyCurrencyTextBox328";
this.solvencyCurrencyTextBox328.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox328.TabIndex = 328;
this.solvencyCurrencyTextBox328.ColName = "R3460C1170";
this.solvencyCurrencyTextBox328.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox329
//
this.solvencyCurrencyTextBox329.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox329.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox329.Location = new System.Drawing.Point(117,369);
this.solvencyCurrencyTextBox329.Name = "solvencyCurrencyTextBox329";
this.solvencyCurrencyTextBox329.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox329.TabIndex = 329;
this.solvencyCurrencyTextBox329.ColName = "R3460C1180";
this.solvencyCurrencyTextBox329.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox330
//
this.solvencyCurrencyTextBox330.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox330.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox330.Location = new System.Drawing.Point(224,369);
this.solvencyCurrencyTextBox330.Name = "solvencyCurrencyTextBox330";
this.solvencyCurrencyTextBox330.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox330.TabIndex = 330;
this.solvencyCurrencyTextBox330.ColName = "R3460C1190";
this.solvencyCurrencyTextBox330.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox331
//
this.solvencyCurrencyTextBox331.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox331.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox331.Location = new System.Drawing.Point(331,369);
this.solvencyCurrencyTextBox331.Name = "solvencyCurrencyTextBox331";
this.solvencyCurrencyTextBox331.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox331.TabIndex = 331;
this.solvencyCurrencyTextBox331.ColName = "R3460C1200";
this.solvencyCurrencyTextBox331.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox332
//
this.solvencyCurrencyTextBox332.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox332.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox332.Location = new System.Drawing.Point(438,369);
this.solvencyCurrencyTextBox332.Name = "solvencyCurrencyTextBox332";
this.solvencyCurrencyTextBox332.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox332.TabIndex = 332;
this.solvencyCurrencyTextBox332.ColName = "R3460C1210";
this.solvencyCurrencyTextBox332.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox333
//
this.solvencyCurrencyTextBox333.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox333.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox333.Location = new System.Drawing.Point(545,369);
this.solvencyCurrencyTextBox333.Name = "solvencyCurrencyTextBox333";
this.solvencyCurrencyTextBox333.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox333.TabIndex = 333;
this.solvencyCurrencyTextBox333.ColName = "R3460C1220";
this.solvencyCurrencyTextBox333.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox334
//
this.solvencyCurrencyTextBox334.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox334.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox334.Location = new System.Drawing.Point(652,369);
this.solvencyCurrencyTextBox334.Name = "solvencyCurrencyTextBox334";
this.solvencyCurrencyTextBox334.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox334.TabIndex = 334;
this.solvencyCurrencyTextBox334.ColName = "R3460C1230";
this.solvencyCurrencyTextBox334.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox335
//
this.solvencyCurrencyTextBox335.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox335.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox335.Location = new System.Drawing.Point(759,369);
this.solvencyCurrencyTextBox335.Name = "solvencyCurrencyTextBox335";
this.solvencyCurrencyTextBox335.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox335.TabIndex = 335;
this.solvencyCurrencyTextBox335.ColName = "R3460C1240";
this.solvencyCurrencyTextBox335.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox336
//
this.solvencyCurrencyTextBox336.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox336.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox336.Location = new System.Drawing.Point(866,369);
this.solvencyCurrencyTextBox336.Name = "solvencyCurrencyTextBox336";
this.solvencyCurrencyTextBox336.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox336.TabIndex = 336;
this.solvencyCurrencyTextBox336.ColName = "R3460C1250";
this.solvencyCurrencyTextBox336.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox337
//
this.solvencyCurrencyTextBox337.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox337.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox337.Location = new System.Drawing.Point(973,369);
this.solvencyCurrencyTextBox337.Name = "solvencyCurrencyTextBox337";
this.solvencyCurrencyTextBox337.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox337.TabIndex = 337;
this.solvencyCurrencyTextBox337.ColName = "R3460C1260";
this.solvencyCurrencyTextBox337.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox338
//
this.solvencyCurrencyTextBox338.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox338.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox338.Location = new System.Drawing.Point(1080,369);
this.solvencyCurrencyTextBox338.Name = "solvencyCurrencyTextBox338";
this.solvencyCurrencyTextBox338.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox338.TabIndex = 338;
this.solvencyCurrencyTextBox338.ColName = "R3460C1270";
this.solvencyCurrencyTextBox338.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox339
//
this.solvencyCurrencyTextBox339.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox339.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox339.Location = new System.Drawing.Point(1187,369);
this.solvencyCurrencyTextBox339.Name = "solvencyCurrencyTextBox339";
this.solvencyCurrencyTextBox339.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox339.TabIndex = 339;
this.solvencyCurrencyTextBox339.ColName = "R3460C1280";
this.solvencyCurrencyTextBox339.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox340
//
this.solvencyCurrencyTextBox340.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox340.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox340.Location = new System.Drawing.Point(1294,369);
this.solvencyCurrencyTextBox340.Name = "solvencyCurrencyTextBox340";
this.solvencyCurrencyTextBox340.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox340.TabIndex = 340;
this.solvencyCurrencyTextBox340.ColName = "R3460C1290";
this.solvencyCurrencyTextBox340.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox341
//
this.solvencyCurrencyTextBox341.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox341.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox341.Location = new System.Drawing.Point(1401,369);
this.solvencyCurrencyTextBox341.Name = "solvencyCurrencyTextBox341";
this.solvencyCurrencyTextBox341.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox341.TabIndex = 341;
this.solvencyCurrencyTextBox341.ColName = "R3460C1300";
this.solvencyCurrencyTextBox341.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox342
//
this.solvencyCurrencyTextBox342.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox342.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox342.Location = new System.Drawing.Point(10,389);
this.solvencyCurrencyTextBox342.Name = "solvencyCurrencyTextBox342";
this.solvencyCurrencyTextBox342.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox342.TabIndex = 342;
this.solvencyCurrencyTextBox342.ColName = "R3470C1170";
this.solvencyCurrencyTextBox342.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox343
//
this.solvencyCurrencyTextBox343.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox343.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox343.Location = new System.Drawing.Point(117,389);
this.solvencyCurrencyTextBox343.Name = "solvencyCurrencyTextBox343";
this.solvencyCurrencyTextBox343.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox343.TabIndex = 343;
this.solvencyCurrencyTextBox343.ColName = "R3470C1180";
this.solvencyCurrencyTextBox343.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox344
//
this.solvencyCurrencyTextBox344.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox344.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox344.Location = new System.Drawing.Point(224,389);
this.solvencyCurrencyTextBox344.Name = "solvencyCurrencyTextBox344";
this.solvencyCurrencyTextBox344.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox344.TabIndex = 344;
this.solvencyCurrencyTextBox344.ColName = "R3470C1190";
this.solvencyCurrencyTextBox344.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox345
//
this.solvencyCurrencyTextBox345.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox345.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox345.Location = new System.Drawing.Point(331,389);
this.solvencyCurrencyTextBox345.Name = "solvencyCurrencyTextBox345";
this.solvencyCurrencyTextBox345.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox345.TabIndex = 345;
this.solvencyCurrencyTextBox345.ColName = "R3470C1200";
this.solvencyCurrencyTextBox345.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox346
//
this.solvencyCurrencyTextBox346.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox346.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox346.Location = new System.Drawing.Point(438,389);
this.solvencyCurrencyTextBox346.Name = "solvencyCurrencyTextBox346";
this.solvencyCurrencyTextBox346.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox346.TabIndex = 346;
this.solvencyCurrencyTextBox346.ColName = "R3470C1210";
this.solvencyCurrencyTextBox346.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox347
//
this.solvencyCurrencyTextBox347.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox347.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox347.Location = new System.Drawing.Point(545,389);
this.solvencyCurrencyTextBox347.Name = "solvencyCurrencyTextBox347";
this.solvencyCurrencyTextBox347.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox347.TabIndex = 347;
this.solvencyCurrencyTextBox347.ColName = "R3470C1220";
this.solvencyCurrencyTextBox347.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox348
//
this.solvencyCurrencyTextBox348.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox348.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox348.Location = new System.Drawing.Point(652,389);
this.solvencyCurrencyTextBox348.Name = "solvencyCurrencyTextBox348";
this.solvencyCurrencyTextBox348.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox348.TabIndex = 348;
this.solvencyCurrencyTextBox348.ColName = "R3470C1230";
this.solvencyCurrencyTextBox348.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox349
//
this.solvencyCurrencyTextBox349.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox349.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox349.Location = new System.Drawing.Point(759,389);
this.solvencyCurrencyTextBox349.Name = "solvencyCurrencyTextBox349";
this.solvencyCurrencyTextBox349.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox349.TabIndex = 349;
this.solvencyCurrencyTextBox349.ColName = "R3470C1240";
this.solvencyCurrencyTextBox349.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox350
//
this.solvencyCurrencyTextBox350.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox350.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox350.Location = new System.Drawing.Point(866,389);
this.solvencyCurrencyTextBox350.Name = "solvencyCurrencyTextBox350";
this.solvencyCurrencyTextBox350.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox350.TabIndex = 350;
this.solvencyCurrencyTextBox350.ColName = "R3470C1250";
this.solvencyCurrencyTextBox350.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox351
//
this.solvencyCurrencyTextBox351.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox351.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox351.Location = new System.Drawing.Point(973,389);
this.solvencyCurrencyTextBox351.Name = "solvencyCurrencyTextBox351";
this.solvencyCurrencyTextBox351.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox351.TabIndex = 351;
this.solvencyCurrencyTextBox351.ColName = "R3470C1260";
this.solvencyCurrencyTextBox351.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox352
//
this.solvencyCurrencyTextBox352.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox352.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox352.Location = new System.Drawing.Point(1080,389);
this.solvencyCurrencyTextBox352.Name = "solvencyCurrencyTextBox352";
this.solvencyCurrencyTextBox352.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox352.TabIndex = 352;
this.solvencyCurrencyTextBox352.ColName = "R3470C1270";
this.solvencyCurrencyTextBox352.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox353
//
this.solvencyCurrencyTextBox353.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox353.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox353.Location = new System.Drawing.Point(1187,389);
this.solvencyCurrencyTextBox353.Name = "solvencyCurrencyTextBox353";
this.solvencyCurrencyTextBox353.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox353.TabIndex = 353;
this.solvencyCurrencyTextBox353.ColName = "R3470C1280";
this.solvencyCurrencyTextBox353.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox354
//
this.solvencyCurrencyTextBox354.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox354.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox354.Location = new System.Drawing.Point(1294,389);
this.solvencyCurrencyTextBox354.Name = "solvencyCurrencyTextBox354";
this.solvencyCurrencyTextBox354.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox354.TabIndex = 354;
this.solvencyCurrencyTextBox354.ColName = "R3470C1290";
this.solvencyCurrencyTextBox354.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox355
//
this.solvencyCurrencyTextBox355.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox355.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox355.Location = new System.Drawing.Point(1401,389);
this.solvencyCurrencyTextBox355.Name = "solvencyCurrencyTextBox355";
this.solvencyCurrencyTextBox355.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox355.TabIndex = 355;
this.solvencyCurrencyTextBox355.ColName = "R3470C1300";
this.solvencyCurrencyTextBox355.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox356
//
this.solvencyCurrencyTextBox356.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox356.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox356.Location = new System.Drawing.Point(10,409);
this.solvencyCurrencyTextBox356.Name = "solvencyCurrencyTextBox356";
this.solvencyCurrencyTextBox356.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox356.TabIndex = 356;
this.solvencyCurrencyTextBox356.ColName = "R3480C1170";
this.solvencyCurrencyTextBox356.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox357
//
this.solvencyCurrencyTextBox357.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox357.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox357.Location = new System.Drawing.Point(117,409);
this.solvencyCurrencyTextBox357.Name = "solvencyCurrencyTextBox357";
this.solvencyCurrencyTextBox357.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox357.TabIndex = 357;
this.solvencyCurrencyTextBox357.ColName = "R3480C1180";
this.solvencyCurrencyTextBox357.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox358
//
this.solvencyCurrencyTextBox358.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox358.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox358.Location = new System.Drawing.Point(224,409);
this.solvencyCurrencyTextBox358.Name = "solvencyCurrencyTextBox358";
this.solvencyCurrencyTextBox358.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox358.TabIndex = 358;
this.solvencyCurrencyTextBox358.ColName = "R3480C1190";
this.solvencyCurrencyTextBox358.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox359
//
this.solvencyCurrencyTextBox359.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox359.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox359.Location = new System.Drawing.Point(331,409);
this.solvencyCurrencyTextBox359.Name = "solvencyCurrencyTextBox359";
this.solvencyCurrencyTextBox359.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox359.TabIndex = 359;
this.solvencyCurrencyTextBox359.ColName = "R3480C1200";
this.solvencyCurrencyTextBox359.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox360
//
this.solvencyCurrencyTextBox360.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox360.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox360.Location = new System.Drawing.Point(438,409);
this.solvencyCurrencyTextBox360.Name = "solvencyCurrencyTextBox360";
this.solvencyCurrencyTextBox360.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox360.TabIndex = 360;
this.solvencyCurrencyTextBox360.ColName = "R3480C1210";
this.solvencyCurrencyTextBox360.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox361
//
this.solvencyCurrencyTextBox361.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox361.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox361.Location = new System.Drawing.Point(545,409);
this.solvencyCurrencyTextBox361.Name = "solvencyCurrencyTextBox361";
this.solvencyCurrencyTextBox361.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox361.TabIndex = 361;
this.solvencyCurrencyTextBox361.ColName = "R3480C1220";
this.solvencyCurrencyTextBox361.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox362
//
this.solvencyCurrencyTextBox362.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox362.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox362.Location = new System.Drawing.Point(652,409);
this.solvencyCurrencyTextBox362.Name = "solvencyCurrencyTextBox362";
this.solvencyCurrencyTextBox362.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox362.TabIndex = 362;
this.solvencyCurrencyTextBox362.ColName = "R3480C1230";
this.solvencyCurrencyTextBox362.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox363
//
this.solvencyCurrencyTextBox363.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox363.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox363.Location = new System.Drawing.Point(759,409);
this.solvencyCurrencyTextBox363.Name = "solvencyCurrencyTextBox363";
this.solvencyCurrencyTextBox363.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox363.TabIndex = 363;
this.solvencyCurrencyTextBox363.ColName = "R3480C1240";
this.solvencyCurrencyTextBox363.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox364
//
this.solvencyCurrencyTextBox364.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox364.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox364.Location = new System.Drawing.Point(866,409);
this.solvencyCurrencyTextBox364.Name = "solvencyCurrencyTextBox364";
this.solvencyCurrencyTextBox364.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox364.TabIndex = 364;
this.solvencyCurrencyTextBox364.ColName = "R3480C1250";
this.solvencyCurrencyTextBox364.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox365
//
this.solvencyCurrencyTextBox365.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox365.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox365.Location = new System.Drawing.Point(973,409);
this.solvencyCurrencyTextBox365.Name = "solvencyCurrencyTextBox365";
this.solvencyCurrencyTextBox365.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox365.TabIndex = 365;
this.solvencyCurrencyTextBox365.ColName = "R3480C1260";
this.solvencyCurrencyTextBox365.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox366
//
this.solvencyCurrencyTextBox366.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox366.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox366.Location = new System.Drawing.Point(1080,409);
this.solvencyCurrencyTextBox366.Name = "solvencyCurrencyTextBox366";
this.solvencyCurrencyTextBox366.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox366.TabIndex = 366;
this.solvencyCurrencyTextBox366.ColName = "R3480C1270";
this.solvencyCurrencyTextBox366.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox367
//
this.solvencyCurrencyTextBox367.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox367.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox367.Location = new System.Drawing.Point(1187,409);
this.solvencyCurrencyTextBox367.Name = "solvencyCurrencyTextBox367";
this.solvencyCurrencyTextBox367.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox367.TabIndex = 367;
this.solvencyCurrencyTextBox367.ColName = "R3480C1280";
this.solvencyCurrencyTextBox367.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox368
//
this.solvencyCurrencyTextBox368.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox368.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox368.Location = new System.Drawing.Point(1294,409);
this.solvencyCurrencyTextBox368.Name = "solvencyCurrencyTextBox368";
this.solvencyCurrencyTextBox368.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox368.TabIndex = 368;
this.solvencyCurrencyTextBox368.ColName = "R3480C1290";
this.solvencyCurrencyTextBox368.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox369
//
this.solvencyCurrencyTextBox369.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox369.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox369.Location = new System.Drawing.Point(1401,409);
this.solvencyCurrencyTextBox369.Name = "solvencyCurrencyTextBox369";
this.solvencyCurrencyTextBox369.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox369.TabIndex = 369;
this.solvencyCurrencyTextBox369.ColName = "R3480C1300";
this.solvencyCurrencyTextBox369.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox370
//
this.solvencyCurrencyTextBox370.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox370.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox370.Location = new System.Drawing.Point(10,429);
this.solvencyCurrencyTextBox370.Name = "solvencyCurrencyTextBox370";
this.solvencyCurrencyTextBox370.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox370.TabIndex = 370;
this.solvencyCurrencyTextBox370.ColName = "R3490C1170";
this.solvencyCurrencyTextBox370.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox371
//
this.solvencyCurrencyTextBox371.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox371.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox371.Location = new System.Drawing.Point(117,429);
this.solvencyCurrencyTextBox371.Name = "solvencyCurrencyTextBox371";
this.solvencyCurrencyTextBox371.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox371.TabIndex = 371;
this.solvencyCurrencyTextBox371.ColName = "R3490C1180";
this.solvencyCurrencyTextBox371.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox372
//
this.solvencyCurrencyTextBox372.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox372.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox372.Location = new System.Drawing.Point(224,429);
this.solvencyCurrencyTextBox372.Name = "solvencyCurrencyTextBox372";
this.solvencyCurrencyTextBox372.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox372.TabIndex = 372;
this.solvencyCurrencyTextBox372.ColName = "R3490C1190";
this.solvencyCurrencyTextBox372.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox373
//
this.solvencyCurrencyTextBox373.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox373.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox373.Location = new System.Drawing.Point(331,429);
this.solvencyCurrencyTextBox373.Name = "solvencyCurrencyTextBox373";
this.solvencyCurrencyTextBox373.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox373.TabIndex = 373;
this.solvencyCurrencyTextBox373.ColName = "R3490C1200";
this.solvencyCurrencyTextBox373.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox374
//
this.solvencyCurrencyTextBox374.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox374.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox374.Location = new System.Drawing.Point(438,429);
this.solvencyCurrencyTextBox374.Name = "solvencyCurrencyTextBox374";
this.solvencyCurrencyTextBox374.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox374.TabIndex = 374;
this.solvencyCurrencyTextBox374.ColName = "R3490C1210";
this.solvencyCurrencyTextBox374.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox375
//
this.solvencyCurrencyTextBox375.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox375.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox375.Location = new System.Drawing.Point(545,429);
this.solvencyCurrencyTextBox375.Name = "solvencyCurrencyTextBox375";
this.solvencyCurrencyTextBox375.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox375.TabIndex = 375;
this.solvencyCurrencyTextBox375.ColName = "R3490C1220";
this.solvencyCurrencyTextBox375.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox376
//
this.solvencyCurrencyTextBox376.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox376.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox376.Location = new System.Drawing.Point(652,429);
this.solvencyCurrencyTextBox376.Name = "solvencyCurrencyTextBox376";
this.solvencyCurrencyTextBox376.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox376.TabIndex = 376;
this.solvencyCurrencyTextBox376.ColName = "R3490C1230";
this.solvencyCurrencyTextBox376.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox377
//
this.solvencyCurrencyTextBox377.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox377.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox377.Location = new System.Drawing.Point(759,429);
this.solvencyCurrencyTextBox377.Name = "solvencyCurrencyTextBox377";
this.solvencyCurrencyTextBox377.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox377.TabIndex = 377;
this.solvencyCurrencyTextBox377.ColName = "R3490C1240";
this.solvencyCurrencyTextBox377.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox378
//
this.solvencyCurrencyTextBox378.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox378.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox378.Location = new System.Drawing.Point(866,429);
this.solvencyCurrencyTextBox378.Name = "solvencyCurrencyTextBox378";
this.solvencyCurrencyTextBox378.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox378.TabIndex = 378;
this.solvencyCurrencyTextBox378.ColName = "R3490C1250";
this.solvencyCurrencyTextBox378.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox379
//
this.solvencyCurrencyTextBox379.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox379.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox379.Location = new System.Drawing.Point(973,429);
this.solvencyCurrencyTextBox379.Name = "solvencyCurrencyTextBox379";
this.solvencyCurrencyTextBox379.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox379.TabIndex = 379;
this.solvencyCurrencyTextBox379.ColName = "R3490C1260";
this.solvencyCurrencyTextBox379.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox380
//
this.solvencyCurrencyTextBox380.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox380.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox380.Location = new System.Drawing.Point(1080,429);
this.solvencyCurrencyTextBox380.Name = "solvencyCurrencyTextBox380";
this.solvencyCurrencyTextBox380.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox380.TabIndex = 380;
this.solvencyCurrencyTextBox380.ColName = "R3490C1270";
this.solvencyCurrencyTextBox380.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox381
//
this.solvencyCurrencyTextBox381.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox381.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox381.Location = new System.Drawing.Point(1187,429);
this.solvencyCurrencyTextBox381.Name = "solvencyCurrencyTextBox381";
this.solvencyCurrencyTextBox381.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox381.TabIndex = 381;
this.solvencyCurrencyTextBox381.ColName = "R3490C1280";
this.solvencyCurrencyTextBox381.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox382
//
this.solvencyCurrencyTextBox382.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox382.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox382.Location = new System.Drawing.Point(1294,429);
this.solvencyCurrencyTextBox382.Name = "solvencyCurrencyTextBox382";
this.solvencyCurrencyTextBox382.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox382.TabIndex = 382;
this.solvencyCurrencyTextBox382.ColName = "R3490C1290";
this.solvencyCurrencyTextBox382.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox383
//
this.solvencyCurrencyTextBox383.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox383.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox383.Location = new System.Drawing.Point(1401,429);
this.solvencyCurrencyTextBox383.Name = "solvencyCurrencyTextBox383";
this.solvencyCurrencyTextBox383.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox383.TabIndex = 383;
this.solvencyCurrencyTextBox383.ColName = "R3490C1300";
this.solvencyCurrencyTextBox383.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox384
//
this.solvencyCurrencyTextBox384.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox384.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox384.Location = new System.Drawing.Point(10,449);
this.solvencyCurrencyTextBox384.Name = "solvencyCurrencyTextBox384";
this.solvencyCurrencyTextBox384.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox384.TabIndex = 384;
this.solvencyCurrencyTextBox384.ColName = "R3500C1170";
this.solvencyCurrencyTextBox384.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox385
//
this.solvencyCurrencyTextBox385.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox385.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox385.Location = new System.Drawing.Point(117,449);
this.solvencyCurrencyTextBox385.Name = "solvencyCurrencyTextBox385";
this.solvencyCurrencyTextBox385.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox385.TabIndex = 385;
this.solvencyCurrencyTextBox385.ColName = "R3500C1180";
this.solvencyCurrencyTextBox385.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox386
//
this.solvencyCurrencyTextBox386.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox386.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox386.Location = new System.Drawing.Point(224,449);
this.solvencyCurrencyTextBox386.Name = "solvencyCurrencyTextBox386";
this.solvencyCurrencyTextBox386.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox386.TabIndex = 386;
this.solvencyCurrencyTextBox386.ColName = "R3500C1190";
this.solvencyCurrencyTextBox386.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox387
//
this.solvencyCurrencyTextBox387.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox387.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox387.Location = new System.Drawing.Point(331,449);
this.solvencyCurrencyTextBox387.Name = "solvencyCurrencyTextBox387";
this.solvencyCurrencyTextBox387.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox387.TabIndex = 387;
this.solvencyCurrencyTextBox387.ColName = "R3500C1200";
this.solvencyCurrencyTextBox387.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox388
//
this.solvencyCurrencyTextBox388.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox388.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox388.Location = new System.Drawing.Point(438,449);
this.solvencyCurrencyTextBox388.Name = "solvencyCurrencyTextBox388";
this.solvencyCurrencyTextBox388.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox388.TabIndex = 388;
this.solvencyCurrencyTextBox388.ColName = "R3500C1210";
this.solvencyCurrencyTextBox388.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox389
//
this.solvencyCurrencyTextBox389.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox389.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox389.Location = new System.Drawing.Point(545,449);
this.solvencyCurrencyTextBox389.Name = "solvencyCurrencyTextBox389";
this.solvencyCurrencyTextBox389.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox389.TabIndex = 389;
this.solvencyCurrencyTextBox389.ColName = "R3500C1220";
this.solvencyCurrencyTextBox389.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox390
//
this.solvencyCurrencyTextBox390.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox390.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox390.Location = new System.Drawing.Point(652,449);
this.solvencyCurrencyTextBox390.Name = "solvencyCurrencyTextBox390";
this.solvencyCurrencyTextBox390.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox390.TabIndex = 390;
this.solvencyCurrencyTextBox390.ColName = "R3500C1230";
this.solvencyCurrencyTextBox390.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox391
//
this.solvencyCurrencyTextBox391.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox391.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox391.Location = new System.Drawing.Point(759,449);
this.solvencyCurrencyTextBox391.Name = "solvencyCurrencyTextBox391";
this.solvencyCurrencyTextBox391.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox391.TabIndex = 391;
this.solvencyCurrencyTextBox391.ColName = "R3500C1240";
this.solvencyCurrencyTextBox391.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox392
//
this.solvencyCurrencyTextBox392.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox392.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox392.Location = new System.Drawing.Point(866,449);
this.solvencyCurrencyTextBox392.Name = "solvencyCurrencyTextBox392";
this.solvencyCurrencyTextBox392.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox392.TabIndex = 392;
this.solvencyCurrencyTextBox392.ColName = "R3500C1250";
this.solvencyCurrencyTextBox392.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox393
//
this.solvencyCurrencyTextBox393.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox393.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox393.Location = new System.Drawing.Point(973,449);
this.solvencyCurrencyTextBox393.Name = "solvencyCurrencyTextBox393";
this.solvencyCurrencyTextBox393.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox393.TabIndex = 393;
this.solvencyCurrencyTextBox393.ColName = "R3500C1260";
this.solvencyCurrencyTextBox393.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox394
//
this.solvencyCurrencyTextBox394.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox394.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox394.Location = new System.Drawing.Point(1080,449);
this.solvencyCurrencyTextBox394.Name = "solvencyCurrencyTextBox394";
this.solvencyCurrencyTextBox394.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox394.TabIndex = 394;
this.solvencyCurrencyTextBox394.ColName = "R3500C1270";
this.solvencyCurrencyTextBox394.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox395
//
this.solvencyCurrencyTextBox395.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox395.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox395.Location = new System.Drawing.Point(1187,449);
this.solvencyCurrencyTextBox395.Name = "solvencyCurrencyTextBox395";
this.solvencyCurrencyTextBox395.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox395.TabIndex = 395;
this.solvencyCurrencyTextBox395.ColName = "R3500C1280";
this.solvencyCurrencyTextBox395.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox396
//
this.solvencyCurrencyTextBox396.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox396.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox396.Location = new System.Drawing.Point(1294,449);
this.solvencyCurrencyTextBox396.Name = "solvencyCurrencyTextBox396";
this.solvencyCurrencyTextBox396.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox396.TabIndex = 396;
this.solvencyCurrencyTextBox396.ColName = "R3500C1290";
this.solvencyCurrencyTextBox396.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox397
//
this.solvencyCurrencyTextBox397.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox397.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox397.Location = new System.Drawing.Point(1401,449);
this.solvencyCurrencyTextBox397.Name = "solvencyCurrencyTextBox397";
this.solvencyCurrencyTextBox397.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox397.TabIndex = 397;
this.solvencyCurrencyTextBox397.ColName = "R3500C1300";
this.solvencyCurrencyTextBox397.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox398
//
this.solvencyCurrencyTextBox398.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox398.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox398.Location = new System.Drawing.Point(10,469);
this.solvencyCurrencyTextBox398.Name = "solvencyCurrencyTextBox398";
this.solvencyCurrencyTextBox398.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox398.TabIndex = 398;
this.solvencyCurrencyTextBox398.ColName = "R3510C1170";
this.solvencyCurrencyTextBox398.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox399
//
this.solvencyCurrencyTextBox399.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox399.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox399.Location = new System.Drawing.Point(117,469);
this.solvencyCurrencyTextBox399.Name = "solvencyCurrencyTextBox399";
this.solvencyCurrencyTextBox399.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox399.TabIndex = 399;
this.solvencyCurrencyTextBox399.ColName = "R3510C1180";
this.solvencyCurrencyTextBox399.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox400
//
this.solvencyCurrencyTextBox400.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox400.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox400.Location = new System.Drawing.Point(224,469);
this.solvencyCurrencyTextBox400.Name = "solvencyCurrencyTextBox400";
this.solvencyCurrencyTextBox400.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox400.TabIndex = 400;
this.solvencyCurrencyTextBox400.ColName = "R3510C1190";
this.solvencyCurrencyTextBox400.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox401
//
this.solvencyCurrencyTextBox401.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox401.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox401.Location = new System.Drawing.Point(331,469);
this.solvencyCurrencyTextBox401.Name = "solvencyCurrencyTextBox401";
this.solvencyCurrencyTextBox401.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox401.TabIndex = 401;
this.solvencyCurrencyTextBox401.ColName = "R3510C1200";
this.solvencyCurrencyTextBox401.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox402
//
this.solvencyCurrencyTextBox402.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox402.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox402.Location = new System.Drawing.Point(438,469);
this.solvencyCurrencyTextBox402.Name = "solvencyCurrencyTextBox402";
this.solvencyCurrencyTextBox402.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox402.TabIndex = 402;
this.solvencyCurrencyTextBox402.ColName = "R3510C1210";
this.solvencyCurrencyTextBox402.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox403
//
this.solvencyCurrencyTextBox403.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox403.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox403.Location = new System.Drawing.Point(545,469);
this.solvencyCurrencyTextBox403.Name = "solvencyCurrencyTextBox403";
this.solvencyCurrencyTextBox403.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox403.TabIndex = 403;
this.solvencyCurrencyTextBox403.ColName = "R3510C1220";
this.solvencyCurrencyTextBox403.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox404
//
this.solvencyCurrencyTextBox404.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox404.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox404.Location = new System.Drawing.Point(652,469);
this.solvencyCurrencyTextBox404.Name = "solvencyCurrencyTextBox404";
this.solvencyCurrencyTextBox404.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox404.TabIndex = 404;
this.solvencyCurrencyTextBox404.ColName = "R3510C1230";
this.solvencyCurrencyTextBox404.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox405
//
this.solvencyCurrencyTextBox405.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox405.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox405.Location = new System.Drawing.Point(759,469);
this.solvencyCurrencyTextBox405.Name = "solvencyCurrencyTextBox405";
this.solvencyCurrencyTextBox405.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox405.TabIndex = 405;
this.solvencyCurrencyTextBox405.ColName = "R3510C1240";
this.solvencyCurrencyTextBox405.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox406
//
this.solvencyCurrencyTextBox406.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox406.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox406.Location = new System.Drawing.Point(866,469);
this.solvencyCurrencyTextBox406.Name = "solvencyCurrencyTextBox406";
this.solvencyCurrencyTextBox406.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox406.TabIndex = 406;
this.solvencyCurrencyTextBox406.ColName = "R3510C1250";
this.solvencyCurrencyTextBox406.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox407
//
this.solvencyCurrencyTextBox407.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox407.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox407.Location = new System.Drawing.Point(973,469);
this.solvencyCurrencyTextBox407.Name = "solvencyCurrencyTextBox407";
this.solvencyCurrencyTextBox407.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox407.TabIndex = 407;
this.solvencyCurrencyTextBox407.ColName = "R3510C1260";
this.solvencyCurrencyTextBox407.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox408
//
this.solvencyCurrencyTextBox408.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox408.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox408.Location = new System.Drawing.Point(1080,469);
this.solvencyCurrencyTextBox408.Name = "solvencyCurrencyTextBox408";
this.solvencyCurrencyTextBox408.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox408.TabIndex = 408;
this.solvencyCurrencyTextBox408.ColName = "R3510C1270";
this.solvencyCurrencyTextBox408.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox409
//
this.solvencyCurrencyTextBox409.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox409.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox409.Location = new System.Drawing.Point(1187,469);
this.solvencyCurrencyTextBox409.Name = "solvencyCurrencyTextBox409";
this.solvencyCurrencyTextBox409.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox409.TabIndex = 409;
this.solvencyCurrencyTextBox409.ColName = "R3510C1280";
this.solvencyCurrencyTextBox409.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox410
//
this.solvencyCurrencyTextBox410.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox410.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox410.Location = new System.Drawing.Point(1294,469);
this.solvencyCurrencyTextBox410.Name = "solvencyCurrencyTextBox410";
this.solvencyCurrencyTextBox410.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox410.TabIndex = 410;
this.solvencyCurrencyTextBox410.ColName = "R3510C1290";
this.solvencyCurrencyTextBox410.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox411
//
this.solvencyCurrencyTextBox411.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox411.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox411.Location = new System.Drawing.Point(1401,469);
this.solvencyCurrencyTextBox411.Name = "solvencyCurrencyTextBox411";
this.solvencyCurrencyTextBox411.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox411.TabIndex = 411;
this.solvencyCurrencyTextBox411.ColName = "R3510C1300";
this.solvencyCurrencyTextBox411.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox412
//
this.solvencyCurrencyTextBox412.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox412.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox412.Location = new System.Drawing.Point(10,489);
this.solvencyCurrencyTextBox412.Name = "solvencyCurrencyTextBox412";
this.solvencyCurrencyTextBox412.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox412.TabIndex = 412;
this.solvencyCurrencyTextBox412.ColName = "R3520C1170";
this.solvencyCurrencyTextBox412.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox413
//
this.solvencyCurrencyTextBox413.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox413.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox413.Location = new System.Drawing.Point(117,489);
this.solvencyCurrencyTextBox413.Name = "solvencyCurrencyTextBox413";
this.solvencyCurrencyTextBox413.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox413.TabIndex = 413;
this.solvencyCurrencyTextBox413.ColName = "R3520C1180";
this.solvencyCurrencyTextBox413.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox414
//
this.solvencyCurrencyTextBox414.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox414.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox414.Location = new System.Drawing.Point(224,489);
this.solvencyCurrencyTextBox414.Name = "solvencyCurrencyTextBox414";
this.solvencyCurrencyTextBox414.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox414.TabIndex = 414;
this.solvencyCurrencyTextBox414.ColName = "R3520C1190";
this.solvencyCurrencyTextBox414.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox415
//
this.solvencyCurrencyTextBox415.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox415.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox415.Location = new System.Drawing.Point(331,489);
this.solvencyCurrencyTextBox415.Name = "solvencyCurrencyTextBox415";
this.solvencyCurrencyTextBox415.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox415.TabIndex = 415;
this.solvencyCurrencyTextBox415.ColName = "R3520C1200";
this.solvencyCurrencyTextBox415.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox416
//
this.solvencyCurrencyTextBox416.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox416.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox416.Location = new System.Drawing.Point(438,489);
this.solvencyCurrencyTextBox416.Name = "solvencyCurrencyTextBox416";
this.solvencyCurrencyTextBox416.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox416.TabIndex = 416;
this.solvencyCurrencyTextBox416.ColName = "R3520C1210";
this.solvencyCurrencyTextBox416.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox417
//
this.solvencyCurrencyTextBox417.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox417.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox417.Location = new System.Drawing.Point(545,489);
this.solvencyCurrencyTextBox417.Name = "solvencyCurrencyTextBox417";
this.solvencyCurrencyTextBox417.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox417.TabIndex = 417;
this.solvencyCurrencyTextBox417.ColName = "R3520C1220";
this.solvencyCurrencyTextBox417.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox418
//
this.solvencyCurrencyTextBox418.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox418.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox418.Location = new System.Drawing.Point(652,489);
this.solvencyCurrencyTextBox418.Name = "solvencyCurrencyTextBox418";
this.solvencyCurrencyTextBox418.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox418.TabIndex = 418;
this.solvencyCurrencyTextBox418.ColName = "R3520C1230";
this.solvencyCurrencyTextBox418.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox419
//
this.solvencyCurrencyTextBox419.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox419.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox419.Location = new System.Drawing.Point(759,489);
this.solvencyCurrencyTextBox419.Name = "solvencyCurrencyTextBox419";
this.solvencyCurrencyTextBox419.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox419.TabIndex = 419;
this.solvencyCurrencyTextBox419.ColName = "R3520C1240";
this.solvencyCurrencyTextBox419.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox420
//
this.solvencyCurrencyTextBox420.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox420.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox420.Location = new System.Drawing.Point(866,489);
this.solvencyCurrencyTextBox420.Name = "solvencyCurrencyTextBox420";
this.solvencyCurrencyTextBox420.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox420.TabIndex = 420;
this.solvencyCurrencyTextBox420.ColName = "R3520C1250";
this.solvencyCurrencyTextBox420.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox421
//
this.solvencyCurrencyTextBox421.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox421.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox421.Location = new System.Drawing.Point(973,489);
this.solvencyCurrencyTextBox421.Name = "solvencyCurrencyTextBox421";
this.solvencyCurrencyTextBox421.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox421.TabIndex = 421;
this.solvencyCurrencyTextBox421.ColName = "R3520C1260";
this.solvencyCurrencyTextBox421.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox422
//
this.solvencyCurrencyTextBox422.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox422.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox422.Location = new System.Drawing.Point(1080,489);
this.solvencyCurrencyTextBox422.Name = "solvencyCurrencyTextBox422";
this.solvencyCurrencyTextBox422.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox422.TabIndex = 422;
this.solvencyCurrencyTextBox422.ColName = "R3520C1270";
this.solvencyCurrencyTextBox422.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox423
//
this.solvencyCurrencyTextBox423.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox423.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox423.Location = new System.Drawing.Point(1187,489);
this.solvencyCurrencyTextBox423.Name = "solvencyCurrencyTextBox423";
this.solvencyCurrencyTextBox423.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox423.TabIndex = 423;
this.solvencyCurrencyTextBox423.ColName = "R3520C1280";
this.solvencyCurrencyTextBox423.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox424
//
this.solvencyCurrencyTextBox424.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox424.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox424.Location = new System.Drawing.Point(1294,489);
this.solvencyCurrencyTextBox424.Name = "solvencyCurrencyTextBox424";
this.solvencyCurrencyTextBox424.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox424.TabIndex = 424;
this.solvencyCurrencyTextBox424.ColName = "R3520C1290";
this.solvencyCurrencyTextBox424.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox425
//
this.solvencyCurrencyTextBox425.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox425.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox425.Location = new System.Drawing.Point(1401,489);
this.solvencyCurrencyTextBox425.Name = "solvencyCurrencyTextBox425";
this.solvencyCurrencyTextBox425.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox425.TabIndex = 425;
this.solvencyCurrencyTextBox425.ColName = "R3520C1300";
this.solvencyCurrencyTextBox425.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox426
//
this.solvencyCurrencyTextBox426.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox426.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox426.Location = new System.Drawing.Point(10,509);
this.solvencyCurrencyTextBox426.Name = "solvencyCurrencyTextBox426";
this.solvencyCurrencyTextBox426.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox426.TabIndex = 426;
this.solvencyCurrencyTextBox426.ColName = "R3530C1170";
this.solvencyCurrencyTextBox426.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox427
//
this.solvencyCurrencyTextBox427.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox427.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox427.Location = new System.Drawing.Point(117,509);
this.solvencyCurrencyTextBox427.Name = "solvencyCurrencyTextBox427";
this.solvencyCurrencyTextBox427.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox427.TabIndex = 427;
this.solvencyCurrencyTextBox427.ColName = "R3530C1180";
this.solvencyCurrencyTextBox427.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox428
//
this.solvencyCurrencyTextBox428.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox428.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox428.Location = new System.Drawing.Point(224,509);
this.solvencyCurrencyTextBox428.Name = "solvencyCurrencyTextBox428";
this.solvencyCurrencyTextBox428.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox428.TabIndex = 428;
this.solvencyCurrencyTextBox428.ColName = "R3530C1190";
this.solvencyCurrencyTextBox428.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox429
//
this.solvencyCurrencyTextBox429.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox429.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox429.Location = new System.Drawing.Point(331,509);
this.solvencyCurrencyTextBox429.Name = "solvencyCurrencyTextBox429";
this.solvencyCurrencyTextBox429.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox429.TabIndex = 429;
this.solvencyCurrencyTextBox429.ColName = "R3530C1200";
this.solvencyCurrencyTextBox429.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox430
//
this.solvencyCurrencyTextBox430.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox430.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox430.Location = new System.Drawing.Point(438,509);
this.solvencyCurrencyTextBox430.Name = "solvencyCurrencyTextBox430";
this.solvencyCurrencyTextBox430.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox430.TabIndex = 430;
this.solvencyCurrencyTextBox430.ColName = "R3530C1210";
this.solvencyCurrencyTextBox430.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox431
//
this.solvencyCurrencyTextBox431.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox431.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox431.Location = new System.Drawing.Point(545,509);
this.solvencyCurrencyTextBox431.Name = "solvencyCurrencyTextBox431";
this.solvencyCurrencyTextBox431.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox431.TabIndex = 431;
this.solvencyCurrencyTextBox431.ColName = "R3530C1220";
this.solvencyCurrencyTextBox431.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox432
//
this.solvencyCurrencyTextBox432.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox432.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox432.Location = new System.Drawing.Point(652,509);
this.solvencyCurrencyTextBox432.Name = "solvencyCurrencyTextBox432";
this.solvencyCurrencyTextBox432.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox432.TabIndex = 432;
this.solvencyCurrencyTextBox432.ColName = "R3530C1230";
this.solvencyCurrencyTextBox432.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox433
//
this.solvencyCurrencyTextBox433.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox433.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox433.Location = new System.Drawing.Point(759,509);
this.solvencyCurrencyTextBox433.Name = "solvencyCurrencyTextBox433";
this.solvencyCurrencyTextBox433.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox433.TabIndex = 433;
this.solvencyCurrencyTextBox433.ColName = "R3530C1240";
this.solvencyCurrencyTextBox433.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox434
//
this.solvencyCurrencyTextBox434.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox434.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox434.Location = new System.Drawing.Point(866,509);
this.solvencyCurrencyTextBox434.Name = "solvencyCurrencyTextBox434";
this.solvencyCurrencyTextBox434.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox434.TabIndex = 434;
this.solvencyCurrencyTextBox434.ColName = "R3530C1250";
this.solvencyCurrencyTextBox434.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox435
//
this.solvencyCurrencyTextBox435.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox435.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox435.Location = new System.Drawing.Point(973,509);
this.solvencyCurrencyTextBox435.Name = "solvencyCurrencyTextBox435";
this.solvencyCurrencyTextBox435.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox435.TabIndex = 435;
this.solvencyCurrencyTextBox435.ColName = "R3530C1260";
this.solvencyCurrencyTextBox435.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox436
//
this.solvencyCurrencyTextBox436.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox436.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox436.Location = new System.Drawing.Point(1080,509);
this.solvencyCurrencyTextBox436.Name = "solvencyCurrencyTextBox436";
this.solvencyCurrencyTextBox436.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox436.TabIndex = 436;
this.solvencyCurrencyTextBox436.ColName = "R3530C1270";
this.solvencyCurrencyTextBox436.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox437
//
this.solvencyCurrencyTextBox437.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox437.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox437.Location = new System.Drawing.Point(1187,509);
this.solvencyCurrencyTextBox437.Name = "solvencyCurrencyTextBox437";
this.solvencyCurrencyTextBox437.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox437.TabIndex = 437;
this.solvencyCurrencyTextBox437.ColName = "R3530C1280";
this.solvencyCurrencyTextBox437.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox438
//
this.solvencyCurrencyTextBox438.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox438.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox438.Location = new System.Drawing.Point(1294,509);
this.solvencyCurrencyTextBox438.Name = "solvencyCurrencyTextBox438";
this.solvencyCurrencyTextBox438.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox438.TabIndex = 438;
this.solvencyCurrencyTextBox438.ColName = "R3530C1290";
this.solvencyCurrencyTextBox438.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox439
//
this.solvencyCurrencyTextBox439.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox439.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox439.Location = new System.Drawing.Point(1401,509);
this.solvencyCurrencyTextBox439.Name = "solvencyCurrencyTextBox439";
this.solvencyCurrencyTextBox439.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox439.TabIndex = 439;
this.solvencyCurrencyTextBox439.ColName = "R3530C1300";
this.solvencyCurrencyTextBox439.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox440
//
this.solvencyCurrencyTextBox440.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox440.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox440.Location = new System.Drawing.Point(10,529);
this.solvencyCurrencyTextBox440.Name = "solvencyCurrencyTextBox440";
this.solvencyCurrencyTextBox440.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox440.TabIndex = 440;
this.solvencyCurrencyTextBox440.ColName = "R3540C1170";
this.solvencyCurrencyTextBox440.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox441
//
this.solvencyCurrencyTextBox441.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox441.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox441.Location = new System.Drawing.Point(117,529);
this.solvencyCurrencyTextBox441.Name = "solvencyCurrencyTextBox441";
this.solvencyCurrencyTextBox441.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox441.TabIndex = 441;
this.solvencyCurrencyTextBox441.ColName = "R3540C1180";
this.solvencyCurrencyTextBox441.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox442
//
this.solvencyCurrencyTextBox442.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox442.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox442.Location = new System.Drawing.Point(224,529);
this.solvencyCurrencyTextBox442.Name = "solvencyCurrencyTextBox442";
this.solvencyCurrencyTextBox442.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox442.TabIndex = 442;
this.solvencyCurrencyTextBox442.ColName = "R3540C1190";
this.solvencyCurrencyTextBox442.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox443
//
this.solvencyCurrencyTextBox443.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox443.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox443.Location = new System.Drawing.Point(331,529);
this.solvencyCurrencyTextBox443.Name = "solvencyCurrencyTextBox443";
this.solvencyCurrencyTextBox443.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox443.TabIndex = 443;
this.solvencyCurrencyTextBox443.ColName = "R3540C1200";
this.solvencyCurrencyTextBox443.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox444
//
this.solvencyCurrencyTextBox444.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox444.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox444.Location = new System.Drawing.Point(438,529);
this.solvencyCurrencyTextBox444.Name = "solvencyCurrencyTextBox444";
this.solvencyCurrencyTextBox444.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox444.TabIndex = 444;
this.solvencyCurrencyTextBox444.ColName = "R3540C1210";
this.solvencyCurrencyTextBox444.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox445
//
this.solvencyCurrencyTextBox445.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox445.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox445.Location = new System.Drawing.Point(545,529);
this.solvencyCurrencyTextBox445.Name = "solvencyCurrencyTextBox445";
this.solvencyCurrencyTextBox445.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox445.TabIndex = 445;
this.solvencyCurrencyTextBox445.ColName = "R3540C1220";
this.solvencyCurrencyTextBox445.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox446
//
this.solvencyCurrencyTextBox446.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox446.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox446.Location = new System.Drawing.Point(652,529);
this.solvencyCurrencyTextBox446.Name = "solvencyCurrencyTextBox446";
this.solvencyCurrencyTextBox446.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox446.TabIndex = 446;
this.solvencyCurrencyTextBox446.ColName = "R3540C1230";
this.solvencyCurrencyTextBox446.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox447
//
this.solvencyCurrencyTextBox447.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox447.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox447.Location = new System.Drawing.Point(759,529);
this.solvencyCurrencyTextBox447.Name = "solvencyCurrencyTextBox447";
this.solvencyCurrencyTextBox447.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox447.TabIndex = 447;
this.solvencyCurrencyTextBox447.ColName = "R3540C1240";
this.solvencyCurrencyTextBox447.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox448
//
this.solvencyCurrencyTextBox448.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox448.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox448.Location = new System.Drawing.Point(866,529);
this.solvencyCurrencyTextBox448.Name = "solvencyCurrencyTextBox448";
this.solvencyCurrencyTextBox448.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox448.TabIndex = 448;
this.solvencyCurrencyTextBox448.ColName = "R3540C1250";
this.solvencyCurrencyTextBox448.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox449
//
this.solvencyCurrencyTextBox449.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox449.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox449.Location = new System.Drawing.Point(973,529);
this.solvencyCurrencyTextBox449.Name = "solvencyCurrencyTextBox449";
this.solvencyCurrencyTextBox449.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox449.TabIndex = 449;
this.solvencyCurrencyTextBox449.ColName = "R3540C1260";
this.solvencyCurrencyTextBox449.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox450
//
this.solvencyCurrencyTextBox450.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox450.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox450.Location = new System.Drawing.Point(1080,529);
this.solvencyCurrencyTextBox450.Name = "solvencyCurrencyTextBox450";
this.solvencyCurrencyTextBox450.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox450.TabIndex = 450;
this.solvencyCurrencyTextBox450.ColName = "R3540C1270";
this.solvencyCurrencyTextBox450.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox451
//
this.solvencyCurrencyTextBox451.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox451.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox451.Location = new System.Drawing.Point(1187,529);
this.solvencyCurrencyTextBox451.Name = "solvencyCurrencyTextBox451";
this.solvencyCurrencyTextBox451.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox451.TabIndex = 451;
this.solvencyCurrencyTextBox451.ColName = "R3540C1280";
this.solvencyCurrencyTextBox451.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox452
//
this.solvencyCurrencyTextBox452.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox452.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox452.Location = new System.Drawing.Point(1294,529);
this.solvencyCurrencyTextBox452.Name = "solvencyCurrencyTextBox452";
this.solvencyCurrencyTextBox452.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox452.TabIndex = 452;
this.solvencyCurrencyTextBox452.ColName = "R3540C1290";
this.solvencyCurrencyTextBox452.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox453
//
this.solvencyCurrencyTextBox453.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox453.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox453.Location = new System.Drawing.Point(1401,529);
this.solvencyCurrencyTextBox453.Name = "solvencyCurrencyTextBox453";
this.solvencyCurrencyTextBox453.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox453.TabIndex = 453;
this.solvencyCurrencyTextBox453.ColName = "R3540C1300";
this.solvencyCurrencyTextBox453.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox454
//
this.solvencyCurrencyTextBox454.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox454.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox454.Location = new System.Drawing.Point(10,549);
this.solvencyCurrencyTextBox454.Name = "solvencyCurrencyTextBox454";
this.solvencyCurrencyTextBox454.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox454.TabIndex = 454;
this.solvencyCurrencyTextBox454.ColName = "R3550C1170";
this.solvencyCurrencyTextBox454.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox455
//
this.solvencyCurrencyTextBox455.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox455.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox455.Location = new System.Drawing.Point(117,549);
this.solvencyCurrencyTextBox455.Name = "solvencyCurrencyTextBox455";
this.solvencyCurrencyTextBox455.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox455.TabIndex = 455;
this.solvencyCurrencyTextBox455.ColName = "R3550C1180";
this.solvencyCurrencyTextBox455.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox456
//
this.solvencyCurrencyTextBox456.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox456.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox456.Location = new System.Drawing.Point(224,549);
this.solvencyCurrencyTextBox456.Name = "solvencyCurrencyTextBox456";
this.solvencyCurrencyTextBox456.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox456.TabIndex = 456;
this.solvencyCurrencyTextBox456.ColName = "R3550C1190";
this.solvencyCurrencyTextBox456.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox457
//
this.solvencyCurrencyTextBox457.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox457.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox457.Location = new System.Drawing.Point(331,549);
this.solvencyCurrencyTextBox457.Name = "solvencyCurrencyTextBox457";
this.solvencyCurrencyTextBox457.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox457.TabIndex = 457;
this.solvencyCurrencyTextBox457.ColName = "R3550C1200";
this.solvencyCurrencyTextBox457.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox458
//
this.solvencyCurrencyTextBox458.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox458.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox458.Location = new System.Drawing.Point(438,549);
this.solvencyCurrencyTextBox458.Name = "solvencyCurrencyTextBox458";
this.solvencyCurrencyTextBox458.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox458.TabIndex = 458;
this.solvencyCurrencyTextBox458.ColName = "R3550C1210";
this.solvencyCurrencyTextBox458.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox459
//
this.solvencyCurrencyTextBox459.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox459.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox459.Location = new System.Drawing.Point(545,549);
this.solvencyCurrencyTextBox459.Name = "solvencyCurrencyTextBox459";
this.solvencyCurrencyTextBox459.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox459.TabIndex = 459;
this.solvencyCurrencyTextBox459.ColName = "R3550C1220";
this.solvencyCurrencyTextBox459.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox460
//
this.solvencyCurrencyTextBox460.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox460.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox460.Location = new System.Drawing.Point(652,549);
this.solvencyCurrencyTextBox460.Name = "solvencyCurrencyTextBox460";
this.solvencyCurrencyTextBox460.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox460.TabIndex = 460;
this.solvencyCurrencyTextBox460.ColName = "R3550C1230";
this.solvencyCurrencyTextBox460.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox461
//
this.solvencyCurrencyTextBox461.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox461.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox461.Location = new System.Drawing.Point(759,549);
this.solvencyCurrencyTextBox461.Name = "solvencyCurrencyTextBox461";
this.solvencyCurrencyTextBox461.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox461.TabIndex = 461;
this.solvencyCurrencyTextBox461.ColName = "R3550C1240";
this.solvencyCurrencyTextBox461.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox462
//
this.solvencyCurrencyTextBox462.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox462.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox462.Location = new System.Drawing.Point(866,549);
this.solvencyCurrencyTextBox462.Name = "solvencyCurrencyTextBox462";
this.solvencyCurrencyTextBox462.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox462.TabIndex = 462;
this.solvencyCurrencyTextBox462.ColName = "R3550C1250";
this.solvencyCurrencyTextBox462.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox463
//
this.solvencyCurrencyTextBox463.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox463.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox463.Location = new System.Drawing.Point(973,549);
this.solvencyCurrencyTextBox463.Name = "solvencyCurrencyTextBox463";
this.solvencyCurrencyTextBox463.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox463.TabIndex = 463;
this.solvencyCurrencyTextBox463.ColName = "R3550C1260";
this.solvencyCurrencyTextBox463.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox464
//
this.solvencyCurrencyTextBox464.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox464.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox464.Location = new System.Drawing.Point(1080,549);
this.solvencyCurrencyTextBox464.Name = "solvencyCurrencyTextBox464";
this.solvencyCurrencyTextBox464.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox464.TabIndex = 464;
this.solvencyCurrencyTextBox464.ColName = "R3550C1270";
this.solvencyCurrencyTextBox464.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox465
//
this.solvencyCurrencyTextBox465.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox465.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox465.Location = new System.Drawing.Point(1187,549);
this.solvencyCurrencyTextBox465.Name = "solvencyCurrencyTextBox465";
this.solvencyCurrencyTextBox465.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox465.TabIndex = 465;
this.solvencyCurrencyTextBox465.ColName = "R3550C1280";
this.solvencyCurrencyTextBox465.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox466
//
this.solvencyCurrencyTextBox466.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox466.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox466.Location = new System.Drawing.Point(1294,549);
this.solvencyCurrencyTextBox466.Name = "solvencyCurrencyTextBox466";
this.solvencyCurrencyTextBox466.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox466.TabIndex = 466;
this.solvencyCurrencyTextBox466.ColName = "R3550C1290";
this.solvencyCurrencyTextBox466.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox467
//
this.solvencyCurrencyTextBox467.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox467.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox467.Location = new System.Drawing.Point(1401,549);
this.solvencyCurrencyTextBox467.Name = "solvencyCurrencyTextBox467";
this.solvencyCurrencyTextBox467.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox467.TabIndex = 467;
this.solvencyCurrencyTextBox467.ColName = "R3550C1300";
this.solvencyCurrencyTextBox467.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox468
//
this.solvencyCurrencyTextBox468.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox468.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox468.Location = new System.Drawing.Point(10,569);
this.solvencyCurrencyTextBox468.Name = "solvencyCurrencyTextBox468";
this.solvencyCurrencyTextBox468.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox468.TabIndex = 468;
this.solvencyCurrencyTextBox468.ColName = "R3560C1170";
this.solvencyCurrencyTextBox468.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox469
//
this.solvencyCurrencyTextBox469.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox469.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox469.Location = new System.Drawing.Point(117,569);
this.solvencyCurrencyTextBox469.Name = "solvencyCurrencyTextBox469";
this.solvencyCurrencyTextBox469.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox469.TabIndex = 469;
this.solvencyCurrencyTextBox469.ColName = "R3560C1180";
this.solvencyCurrencyTextBox469.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox470
//
this.solvencyCurrencyTextBox470.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox470.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox470.Location = new System.Drawing.Point(224,569);
this.solvencyCurrencyTextBox470.Name = "solvencyCurrencyTextBox470";
this.solvencyCurrencyTextBox470.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox470.TabIndex = 470;
this.solvencyCurrencyTextBox470.ColName = "R3560C1190";
this.solvencyCurrencyTextBox470.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox471
//
this.solvencyCurrencyTextBox471.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox471.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox471.Location = new System.Drawing.Point(331,569);
this.solvencyCurrencyTextBox471.Name = "solvencyCurrencyTextBox471";
this.solvencyCurrencyTextBox471.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox471.TabIndex = 471;
this.solvencyCurrencyTextBox471.ColName = "R3560C1200";
this.solvencyCurrencyTextBox471.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox472
//
this.solvencyCurrencyTextBox472.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox472.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox472.Location = new System.Drawing.Point(438,569);
this.solvencyCurrencyTextBox472.Name = "solvencyCurrencyTextBox472";
this.solvencyCurrencyTextBox472.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox472.TabIndex = 472;
this.solvencyCurrencyTextBox472.ColName = "R3560C1210";
this.solvencyCurrencyTextBox472.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox473
//
this.solvencyCurrencyTextBox473.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox473.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox473.Location = new System.Drawing.Point(545,569);
this.solvencyCurrencyTextBox473.Name = "solvencyCurrencyTextBox473";
this.solvencyCurrencyTextBox473.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox473.TabIndex = 473;
this.solvencyCurrencyTextBox473.ColName = "R3560C1220";
this.solvencyCurrencyTextBox473.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox474
//
this.solvencyCurrencyTextBox474.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox474.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox474.Location = new System.Drawing.Point(652,569);
this.solvencyCurrencyTextBox474.Name = "solvencyCurrencyTextBox474";
this.solvencyCurrencyTextBox474.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox474.TabIndex = 474;
this.solvencyCurrencyTextBox474.ColName = "R3560C1230";
this.solvencyCurrencyTextBox474.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox475
//
this.solvencyCurrencyTextBox475.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox475.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox475.Location = new System.Drawing.Point(759,569);
this.solvencyCurrencyTextBox475.Name = "solvencyCurrencyTextBox475";
this.solvencyCurrencyTextBox475.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox475.TabIndex = 475;
this.solvencyCurrencyTextBox475.ColName = "R3560C1240";
this.solvencyCurrencyTextBox475.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox476
//
this.solvencyCurrencyTextBox476.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox476.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox476.Location = new System.Drawing.Point(866,569);
this.solvencyCurrencyTextBox476.Name = "solvencyCurrencyTextBox476";
this.solvencyCurrencyTextBox476.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox476.TabIndex = 476;
this.solvencyCurrencyTextBox476.ColName = "R3560C1250";
this.solvencyCurrencyTextBox476.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox477
//
this.solvencyCurrencyTextBox477.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox477.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox477.Location = new System.Drawing.Point(973,569);
this.solvencyCurrencyTextBox477.Name = "solvencyCurrencyTextBox477";
this.solvencyCurrencyTextBox477.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox477.TabIndex = 477;
this.solvencyCurrencyTextBox477.ColName = "R3560C1260";
this.solvencyCurrencyTextBox477.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox478
//
this.solvencyCurrencyTextBox478.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox478.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox478.Location = new System.Drawing.Point(1080,569);
this.solvencyCurrencyTextBox478.Name = "solvencyCurrencyTextBox478";
this.solvencyCurrencyTextBox478.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox478.TabIndex = 478;
this.solvencyCurrencyTextBox478.ColName = "R3560C1270";
this.solvencyCurrencyTextBox478.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox479
//
this.solvencyCurrencyTextBox479.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox479.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox479.Location = new System.Drawing.Point(1187,569);
this.solvencyCurrencyTextBox479.Name = "solvencyCurrencyTextBox479";
this.solvencyCurrencyTextBox479.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox479.TabIndex = 479;
this.solvencyCurrencyTextBox479.ColName = "R3560C1280";
this.solvencyCurrencyTextBox479.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox480
//
this.solvencyCurrencyTextBox480.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox480.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox480.Location = new System.Drawing.Point(1294,569);
this.solvencyCurrencyTextBox480.Name = "solvencyCurrencyTextBox480";
this.solvencyCurrencyTextBox480.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox480.TabIndex = 480;
this.solvencyCurrencyTextBox480.ColName = "R3560C1290";
this.solvencyCurrencyTextBox480.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox481
//
this.solvencyCurrencyTextBox481.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox481.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox481.Location = new System.Drawing.Point(1401,569);
this.solvencyCurrencyTextBox481.Name = "solvencyCurrencyTextBox481";
this.solvencyCurrencyTextBox481.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox481.TabIndex = 481;
this.solvencyCurrencyTextBox481.ColName = "R3560C1300";
this.solvencyCurrencyTextBox481.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox482
//
this.solvencyCurrencyTextBox482.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox482.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox482.Location = new System.Drawing.Point(10,589);
this.solvencyCurrencyTextBox482.Name = "solvencyCurrencyTextBox482";
this.solvencyCurrencyTextBox482.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox482.TabIndex = 482;
this.solvencyCurrencyTextBox482.ColName = "R3570C1170";
this.solvencyCurrencyTextBox482.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox483
//
this.solvencyCurrencyTextBox483.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox483.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox483.Location = new System.Drawing.Point(117,589);
this.solvencyCurrencyTextBox483.Name = "solvencyCurrencyTextBox483";
this.solvencyCurrencyTextBox483.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox483.TabIndex = 483;
this.solvencyCurrencyTextBox483.ColName = "R3570C1180";
this.solvencyCurrencyTextBox483.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox484
//
this.solvencyCurrencyTextBox484.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox484.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox484.Location = new System.Drawing.Point(224,589);
this.solvencyCurrencyTextBox484.Name = "solvencyCurrencyTextBox484";
this.solvencyCurrencyTextBox484.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox484.TabIndex = 484;
this.solvencyCurrencyTextBox484.ColName = "R3570C1190";
this.solvencyCurrencyTextBox484.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox485
//
this.solvencyCurrencyTextBox485.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox485.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox485.Location = new System.Drawing.Point(331,589);
this.solvencyCurrencyTextBox485.Name = "solvencyCurrencyTextBox485";
this.solvencyCurrencyTextBox485.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox485.TabIndex = 485;
this.solvencyCurrencyTextBox485.ColName = "R3570C1200";
this.solvencyCurrencyTextBox485.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox486
//
this.solvencyCurrencyTextBox486.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox486.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox486.Location = new System.Drawing.Point(438,589);
this.solvencyCurrencyTextBox486.Name = "solvencyCurrencyTextBox486";
this.solvencyCurrencyTextBox486.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox486.TabIndex = 486;
this.solvencyCurrencyTextBox486.ColName = "R3570C1210";
this.solvencyCurrencyTextBox486.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox487
//
this.solvencyCurrencyTextBox487.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox487.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox487.Location = new System.Drawing.Point(545,589);
this.solvencyCurrencyTextBox487.Name = "solvencyCurrencyTextBox487";
this.solvencyCurrencyTextBox487.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox487.TabIndex = 487;
this.solvencyCurrencyTextBox487.ColName = "R3570C1220";
this.solvencyCurrencyTextBox487.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox488
//
this.solvencyCurrencyTextBox488.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox488.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox488.Location = new System.Drawing.Point(652,589);
this.solvencyCurrencyTextBox488.Name = "solvencyCurrencyTextBox488";
this.solvencyCurrencyTextBox488.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox488.TabIndex = 488;
this.solvencyCurrencyTextBox488.ColName = "R3570C1230";
this.solvencyCurrencyTextBox488.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox489
//
this.solvencyCurrencyTextBox489.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox489.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox489.Location = new System.Drawing.Point(759,589);
this.solvencyCurrencyTextBox489.Name = "solvencyCurrencyTextBox489";
this.solvencyCurrencyTextBox489.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox489.TabIndex = 489;
this.solvencyCurrencyTextBox489.ColName = "R3570C1240";
this.solvencyCurrencyTextBox489.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox490
//
this.solvencyCurrencyTextBox490.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox490.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox490.Location = new System.Drawing.Point(866,589);
this.solvencyCurrencyTextBox490.Name = "solvencyCurrencyTextBox490";
this.solvencyCurrencyTextBox490.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox490.TabIndex = 490;
this.solvencyCurrencyTextBox490.ColName = "R3570C1250";
this.solvencyCurrencyTextBox490.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox491
//
this.solvencyCurrencyTextBox491.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox491.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox491.Location = new System.Drawing.Point(973,589);
this.solvencyCurrencyTextBox491.Name = "solvencyCurrencyTextBox491";
this.solvencyCurrencyTextBox491.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox491.TabIndex = 491;
this.solvencyCurrencyTextBox491.ColName = "R3570C1260";
this.solvencyCurrencyTextBox491.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox492
//
this.solvencyCurrencyTextBox492.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox492.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox492.Location = new System.Drawing.Point(1080,589);
this.solvencyCurrencyTextBox492.Name = "solvencyCurrencyTextBox492";
this.solvencyCurrencyTextBox492.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox492.TabIndex = 492;
this.solvencyCurrencyTextBox492.ColName = "R3570C1270";
this.solvencyCurrencyTextBox492.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox493
//
this.solvencyCurrencyTextBox493.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox493.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox493.Location = new System.Drawing.Point(1187,589);
this.solvencyCurrencyTextBox493.Name = "solvencyCurrencyTextBox493";
this.solvencyCurrencyTextBox493.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox493.TabIndex = 493;
this.solvencyCurrencyTextBox493.ColName = "R3570C1280";
this.solvencyCurrencyTextBox493.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox494
//
this.solvencyCurrencyTextBox494.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox494.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox494.Location = new System.Drawing.Point(1294,589);
this.solvencyCurrencyTextBox494.Name = "solvencyCurrencyTextBox494";
this.solvencyCurrencyTextBox494.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox494.TabIndex = 494;
this.solvencyCurrencyTextBox494.ColName = "R3570C1290";
this.solvencyCurrencyTextBox494.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox495
//
this.solvencyCurrencyTextBox495.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox495.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox495.Location = new System.Drawing.Point(1401,589);
this.solvencyCurrencyTextBox495.Name = "solvencyCurrencyTextBox495";
this.solvencyCurrencyTextBox495.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox495.TabIndex = 495;
this.solvencyCurrencyTextBox495.ColName = "R3570C1300";
this.solvencyCurrencyTextBox495.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox496
//
this.solvencyCurrencyTextBox496.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox496.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox496.Location = new System.Drawing.Point(10,609);
this.solvencyCurrencyTextBox496.Name = "solvencyCurrencyTextBox496";
this.solvencyCurrencyTextBox496.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox496.TabIndex = 496;
this.solvencyCurrencyTextBox496.ColName = "R3580C1170";
this.solvencyCurrencyTextBox496.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox497
//
this.solvencyCurrencyTextBox497.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox497.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox497.Location = new System.Drawing.Point(117,609);
this.solvencyCurrencyTextBox497.Name = "solvencyCurrencyTextBox497";
this.solvencyCurrencyTextBox497.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox497.TabIndex = 497;
this.solvencyCurrencyTextBox497.ColName = "R3580C1180";
this.solvencyCurrencyTextBox497.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox498
//
this.solvencyCurrencyTextBox498.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox498.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox498.Location = new System.Drawing.Point(224,609);
this.solvencyCurrencyTextBox498.Name = "solvencyCurrencyTextBox498";
this.solvencyCurrencyTextBox498.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox498.TabIndex = 498;
this.solvencyCurrencyTextBox498.ColName = "R3580C1190";
this.solvencyCurrencyTextBox498.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox499
//
this.solvencyCurrencyTextBox499.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox499.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox499.Location = new System.Drawing.Point(331,609);
this.solvencyCurrencyTextBox499.Name = "solvencyCurrencyTextBox499";
this.solvencyCurrencyTextBox499.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox499.TabIndex = 499;
this.solvencyCurrencyTextBox499.ColName = "R3580C1200";
this.solvencyCurrencyTextBox499.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox500
//
this.solvencyCurrencyTextBox500.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox500.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox500.Location = new System.Drawing.Point(438,609);
this.solvencyCurrencyTextBox500.Name = "solvencyCurrencyTextBox500";
this.solvencyCurrencyTextBox500.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox500.TabIndex = 500;
this.solvencyCurrencyTextBox500.ColName = "R3580C1210";
this.solvencyCurrencyTextBox500.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox501
//
this.solvencyCurrencyTextBox501.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox501.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox501.Location = new System.Drawing.Point(545,609);
this.solvencyCurrencyTextBox501.Name = "solvencyCurrencyTextBox501";
this.solvencyCurrencyTextBox501.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox501.TabIndex = 501;
this.solvencyCurrencyTextBox501.ColName = "R3580C1220";
this.solvencyCurrencyTextBox501.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox502
//
this.solvencyCurrencyTextBox502.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox502.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox502.Location = new System.Drawing.Point(652,609);
this.solvencyCurrencyTextBox502.Name = "solvencyCurrencyTextBox502";
this.solvencyCurrencyTextBox502.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox502.TabIndex = 502;
this.solvencyCurrencyTextBox502.ColName = "R3580C1230";
this.solvencyCurrencyTextBox502.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox503
//
this.solvencyCurrencyTextBox503.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox503.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox503.Location = new System.Drawing.Point(759,609);
this.solvencyCurrencyTextBox503.Name = "solvencyCurrencyTextBox503";
this.solvencyCurrencyTextBox503.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox503.TabIndex = 503;
this.solvencyCurrencyTextBox503.ColName = "R3580C1240";
this.solvencyCurrencyTextBox503.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox504
//
this.solvencyCurrencyTextBox504.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox504.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox504.Location = new System.Drawing.Point(866,609);
this.solvencyCurrencyTextBox504.Name = "solvencyCurrencyTextBox504";
this.solvencyCurrencyTextBox504.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox504.TabIndex = 504;
this.solvencyCurrencyTextBox504.ColName = "R3580C1250";
this.solvencyCurrencyTextBox504.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox505
//
this.solvencyCurrencyTextBox505.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox505.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox505.Location = new System.Drawing.Point(973,609);
this.solvencyCurrencyTextBox505.Name = "solvencyCurrencyTextBox505";
this.solvencyCurrencyTextBox505.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox505.TabIndex = 505;
this.solvencyCurrencyTextBox505.ColName = "R3580C1260";
this.solvencyCurrencyTextBox505.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox506
//
this.solvencyCurrencyTextBox506.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox506.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox506.Location = new System.Drawing.Point(1080,609);
this.solvencyCurrencyTextBox506.Name = "solvencyCurrencyTextBox506";
this.solvencyCurrencyTextBox506.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox506.TabIndex = 506;
this.solvencyCurrencyTextBox506.ColName = "R3580C1270";
this.solvencyCurrencyTextBox506.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox507
//
this.solvencyCurrencyTextBox507.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox507.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox507.Location = new System.Drawing.Point(1187,609);
this.solvencyCurrencyTextBox507.Name = "solvencyCurrencyTextBox507";
this.solvencyCurrencyTextBox507.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox507.TabIndex = 507;
this.solvencyCurrencyTextBox507.ColName = "R3580C1280";
this.solvencyCurrencyTextBox507.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox508
//
this.solvencyCurrencyTextBox508.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox508.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox508.Location = new System.Drawing.Point(1294,609);
this.solvencyCurrencyTextBox508.Name = "solvencyCurrencyTextBox508";
this.solvencyCurrencyTextBox508.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox508.TabIndex = 508;
this.solvencyCurrencyTextBox508.ColName = "R3580C1290";
this.solvencyCurrencyTextBox508.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox509
//
this.solvencyCurrencyTextBox509.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox509.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox509.Location = new System.Drawing.Point(1401,609);
this.solvencyCurrencyTextBox509.Name = "solvencyCurrencyTextBox509";
this.solvencyCurrencyTextBox509.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox509.TabIndex = 509;
this.solvencyCurrencyTextBox509.ColName = "R3580C1300";
this.solvencyCurrencyTextBox509.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox510
//
this.solvencyCurrencyTextBox510.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox510.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox510.Location = new System.Drawing.Point(10,629);
this.solvencyCurrencyTextBox510.Name = "solvencyCurrencyTextBox510";
this.solvencyCurrencyTextBox510.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox510.TabIndex = 510;
this.solvencyCurrencyTextBox510.ColName = "R3590C1170";
this.solvencyCurrencyTextBox510.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox511
//
this.solvencyCurrencyTextBox511.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox511.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox511.Location = new System.Drawing.Point(117,629);
this.solvencyCurrencyTextBox511.Name = "solvencyCurrencyTextBox511";
this.solvencyCurrencyTextBox511.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox511.TabIndex = 511;
this.solvencyCurrencyTextBox511.ColName = "R3590C1180";
this.solvencyCurrencyTextBox511.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox512
//
this.solvencyCurrencyTextBox512.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox512.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox512.Location = new System.Drawing.Point(224,629);
this.solvencyCurrencyTextBox512.Name = "solvencyCurrencyTextBox512";
this.solvencyCurrencyTextBox512.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox512.TabIndex = 512;
this.solvencyCurrencyTextBox512.ColName = "R3590C1190";
this.solvencyCurrencyTextBox512.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox513
//
this.solvencyCurrencyTextBox513.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox513.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox513.Location = new System.Drawing.Point(331,629);
this.solvencyCurrencyTextBox513.Name = "solvencyCurrencyTextBox513";
this.solvencyCurrencyTextBox513.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox513.TabIndex = 513;
this.solvencyCurrencyTextBox513.ColName = "R3590C1200";
this.solvencyCurrencyTextBox513.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox514
//
this.solvencyCurrencyTextBox514.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox514.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox514.Location = new System.Drawing.Point(438,629);
this.solvencyCurrencyTextBox514.Name = "solvencyCurrencyTextBox514";
this.solvencyCurrencyTextBox514.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox514.TabIndex = 514;
this.solvencyCurrencyTextBox514.ColName = "R3590C1210";
this.solvencyCurrencyTextBox514.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox515
//
this.solvencyCurrencyTextBox515.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox515.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox515.Location = new System.Drawing.Point(545,629);
this.solvencyCurrencyTextBox515.Name = "solvencyCurrencyTextBox515";
this.solvencyCurrencyTextBox515.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox515.TabIndex = 515;
this.solvencyCurrencyTextBox515.ColName = "R3590C1220";
this.solvencyCurrencyTextBox515.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox516
//
this.solvencyCurrencyTextBox516.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox516.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox516.Location = new System.Drawing.Point(652,629);
this.solvencyCurrencyTextBox516.Name = "solvencyCurrencyTextBox516";
this.solvencyCurrencyTextBox516.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox516.TabIndex = 516;
this.solvencyCurrencyTextBox516.ColName = "R3590C1230";
this.solvencyCurrencyTextBox516.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox517
//
this.solvencyCurrencyTextBox517.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox517.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox517.Location = new System.Drawing.Point(759,629);
this.solvencyCurrencyTextBox517.Name = "solvencyCurrencyTextBox517";
this.solvencyCurrencyTextBox517.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox517.TabIndex = 517;
this.solvencyCurrencyTextBox517.ColName = "R3590C1240";
this.solvencyCurrencyTextBox517.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox518
//
this.solvencyCurrencyTextBox518.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox518.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox518.Location = new System.Drawing.Point(866,629);
this.solvencyCurrencyTextBox518.Name = "solvencyCurrencyTextBox518";
this.solvencyCurrencyTextBox518.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox518.TabIndex = 518;
this.solvencyCurrencyTextBox518.ColName = "R3590C1250";
this.solvencyCurrencyTextBox518.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox519
//
this.solvencyCurrencyTextBox519.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox519.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox519.Location = new System.Drawing.Point(973,629);
this.solvencyCurrencyTextBox519.Name = "solvencyCurrencyTextBox519";
this.solvencyCurrencyTextBox519.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox519.TabIndex = 519;
this.solvencyCurrencyTextBox519.ColName = "R3590C1260";
this.solvencyCurrencyTextBox519.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox520
//
this.solvencyCurrencyTextBox520.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox520.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox520.Location = new System.Drawing.Point(1080,629);
this.solvencyCurrencyTextBox520.Name = "solvencyCurrencyTextBox520";
this.solvencyCurrencyTextBox520.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox520.TabIndex = 520;
this.solvencyCurrencyTextBox520.ColName = "R3590C1270";
this.solvencyCurrencyTextBox520.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox521
//
this.solvencyCurrencyTextBox521.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox521.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox521.Location = new System.Drawing.Point(1187,629);
this.solvencyCurrencyTextBox521.Name = "solvencyCurrencyTextBox521";
this.solvencyCurrencyTextBox521.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox521.TabIndex = 521;
this.solvencyCurrencyTextBox521.ColName = "R3590C1280";
this.solvencyCurrencyTextBox521.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox522
//
this.solvencyCurrencyTextBox522.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox522.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox522.Location = new System.Drawing.Point(1294,629);
this.solvencyCurrencyTextBox522.Name = "solvencyCurrencyTextBox522";
this.solvencyCurrencyTextBox522.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox522.TabIndex = 522;
this.solvencyCurrencyTextBox522.ColName = "R3590C1290";
this.solvencyCurrencyTextBox522.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox523
//
this.solvencyCurrencyTextBox523.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox523.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox523.Location = new System.Drawing.Point(1401,629);
this.solvencyCurrencyTextBox523.Name = "solvencyCurrencyTextBox523";
this.solvencyCurrencyTextBox523.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox523.TabIndex = 523;
this.solvencyCurrencyTextBox523.ColName = "R3590C1300";
this.solvencyCurrencyTextBox523.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox524
//
this.solvencyCurrencyTextBox524.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox524.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox524.Location = new System.Drawing.Point(10,649);
this.solvencyCurrencyTextBox524.Name = "solvencyCurrencyTextBox524";
this.solvencyCurrencyTextBox524.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox524.TabIndex = 524;
this.solvencyCurrencyTextBox524.ColName = "R3600C1170";
this.solvencyCurrencyTextBox524.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox525
//
this.solvencyCurrencyTextBox525.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox525.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox525.Location = new System.Drawing.Point(117,649);
this.solvencyCurrencyTextBox525.Name = "solvencyCurrencyTextBox525";
this.solvencyCurrencyTextBox525.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox525.TabIndex = 525;
this.solvencyCurrencyTextBox525.ColName = "R3600C1180";
this.solvencyCurrencyTextBox525.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox526
//
this.solvencyCurrencyTextBox526.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox526.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox526.Location = new System.Drawing.Point(224,649);
this.solvencyCurrencyTextBox526.Name = "solvencyCurrencyTextBox526";
this.solvencyCurrencyTextBox526.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox526.TabIndex = 526;
this.solvencyCurrencyTextBox526.ColName = "R3600C1190";
this.solvencyCurrencyTextBox526.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox527
//
this.solvencyCurrencyTextBox527.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox527.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox527.Location = new System.Drawing.Point(331,649);
this.solvencyCurrencyTextBox527.Name = "solvencyCurrencyTextBox527";
this.solvencyCurrencyTextBox527.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox527.TabIndex = 527;
this.solvencyCurrencyTextBox527.ColName = "R3600C1200";
this.solvencyCurrencyTextBox527.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox528
//
this.solvencyCurrencyTextBox528.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox528.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox528.Location = new System.Drawing.Point(438,649);
this.solvencyCurrencyTextBox528.Name = "solvencyCurrencyTextBox528";
this.solvencyCurrencyTextBox528.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox528.TabIndex = 528;
this.solvencyCurrencyTextBox528.ColName = "R3600C1210";
this.solvencyCurrencyTextBox528.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox529
//
this.solvencyCurrencyTextBox529.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox529.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox529.Location = new System.Drawing.Point(545,649);
this.solvencyCurrencyTextBox529.Name = "solvencyCurrencyTextBox529";
this.solvencyCurrencyTextBox529.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox529.TabIndex = 529;
this.solvencyCurrencyTextBox529.ColName = "R3600C1220";
this.solvencyCurrencyTextBox529.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox530
//
this.solvencyCurrencyTextBox530.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox530.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox530.Location = new System.Drawing.Point(652,649);
this.solvencyCurrencyTextBox530.Name = "solvencyCurrencyTextBox530";
this.solvencyCurrencyTextBox530.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox530.TabIndex = 530;
this.solvencyCurrencyTextBox530.ColName = "R3600C1230";
this.solvencyCurrencyTextBox530.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox531
//
this.solvencyCurrencyTextBox531.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox531.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox531.Location = new System.Drawing.Point(759,649);
this.solvencyCurrencyTextBox531.Name = "solvencyCurrencyTextBox531";
this.solvencyCurrencyTextBox531.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox531.TabIndex = 531;
this.solvencyCurrencyTextBox531.ColName = "R3600C1240";
this.solvencyCurrencyTextBox531.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox532
//
this.solvencyCurrencyTextBox532.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox532.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox532.Location = new System.Drawing.Point(866,649);
this.solvencyCurrencyTextBox532.Name = "solvencyCurrencyTextBox532";
this.solvencyCurrencyTextBox532.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox532.TabIndex = 532;
this.solvencyCurrencyTextBox532.ColName = "R3600C1250";
this.solvencyCurrencyTextBox532.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox533
//
this.solvencyCurrencyTextBox533.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox533.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox533.Location = new System.Drawing.Point(973,649);
this.solvencyCurrencyTextBox533.Name = "solvencyCurrencyTextBox533";
this.solvencyCurrencyTextBox533.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox533.TabIndex = 533;
this.solvencyCurrencyTextBox533.ColName = "R3600C1260";
this.solvencyCurrencyTextBox533.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox534
//
this.solvencyCurrencyTextBox534.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox534.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox534.Location = new System.Drawing.Point(1080,649);
this.solvencyCurrencyTextBox534.Name = "solvencyCurrencyTextBox534";
this.solvencyCurrencyTextBox534.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox534.TabIndex = 534;
this.solvencyCurrencyTextBox534.ColName = "R3600C1270";
this.solvencyCurrencyTextBox534.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox535
//
this.solvencyCurrencyTextBox535.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox535.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox535.Location = new System.Drawing.Point(1187,649);
this.solvencyCurrencyTextBox535.Name = "solvencyCurrencyTextBox535";
this.solvencyCurrencyTextBox535.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox535.TabIndex = 535;
this.solvencyCurrencyTextBox535.ColName = "R3600C1280";
this.solvencyCurrencyTextBox535.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox536
//
this.solvencyCurrencyTextBox536.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox536.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox536.Location = new System.Drawing.Point(1294,649);
this.solvencyCurrencyTextBox536.Name = "solvencyCurrencyTextBox536";
this.solvencyCurrencyTextBox536.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox536.TabIndex = 536;
this.solvencyCurrencyTextBox536.ColName = "R3600C1290";
this.solvencyCurrencyTextBox536.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox537
//
this.solvencyCurrencyTextBox537.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox537.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox537.Location = new System.Drawing.Point(1401,649);
this.solvencyCurrencyTextBox537.Name = "solvencyCurrencyTextBox537";
this.solvencyCurrencyTextBox537.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox537.TabIndex = 537;
this.solvencyCurrencyTextBox537.ColName = "R3600C1300";
this.solvencyCurrencyTextBox537.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox538
//
this.solvencyCurrencyTextBox538.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox538.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox538.Location = new System.Drawing.Point(10,682);
this.solvencyCurrencyTextBox538.Name = "solvencyCurrencyTextBox538";
this.solvencyCurrencyTextBox538.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox538.TabIndex = 538;
this.solvencyCurrencyTextBox538.ColName = "R3610C1170";
this.solvencyCurrencyTextBox538.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox538.Enabled = false;
this.solvencyCurrencyTextBox538.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox539
//
this.solvencyCurrencyTextBox539.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox539.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox539.Location = new System.Drawing.Point(117,682);
this.solvencyCurrencyTextBox539.Name = "solvencyCurrencyTextBox539";
this.solvencyCurrencyTextBox539.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox539.TabIndex = 539;
this.solvencyCurrencyTextBox539.ColName = "R3610C1180";
this.solvencyCurrencyTextBox539.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox539.Enabled = false;
this.solvencyCurrencyTextBox539.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox540
//
this.solvencyCurrencyTextBox540.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox540.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox540.Location = new System.Drawing.Point(224,682);
this.solvencyCurrencyTextBox540.Name = "solvencyCurrencyTextBox540";
this.solvencyCurrencyTextBox540.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox540.TabIndex = 540;
this.solvencyCurrencyTextBox540.ColName = "R3610C1190";
this.solvencyCurrencyTextBox540.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox540.Enabled = false;
this.solvencyCurrencyTextBox540.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox541
//
this.solvencyCurrencyTextBox541.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox541.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox541.Location = new System.Drawing.Point(331,682);
this.solvencyCurrencyTextBox541.Name = "solvencyCurrencyTextBox541";
this.solvencyCurrencyTextBox541.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox541.TabIndex = 541;
this.solvencyCurrencyTextBox541.ColName = "R3610C1200";
this.solvencyCurrencyTextBox541.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox541.Enabled = false;
this.solvencyCurrencyTextBox541.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox542
//
this.solvencyCurrencyTextBox542.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox542.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox542.Location = new System.Drawing.Point(438,682);
this.solvencyCurrencyTextBox542.Name = "solvencyCurrencyTextBox542";
this.solvencyCurrencyTextBox542.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox542.TabIndex = 542;
this.solvencyCurrencyTextBox542.ColName = "R3610C1210";
this.solvencyCurrencyTextBox542.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox542.Enabled = false;
this.solvencyCurrencyTextBox542.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox543
//
this.solvencyCurrencyTextBox543.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox543.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox543.Location = new System.Drawing.Point(545,682);
this.solvencyCurrencyTextBox543.Name = "solvencyCurrencyTextBox543";
this.solvencyCurrencyTextBox543.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox543.TabIndex = 543;
this.solvencyCurrencyTextBox543.ColName = "R3610C1220";
this.solvencyCurrencyTextBox543.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox543.Enabled = false;
this.solvencyCurrencyTextBox543.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox544
//
this.solvencyCurrencyTextBox544.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox544.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox544.Location = new System.Drawing.Point(652,682);
this.solvencyCurrencyTextBox544.Name = "solvencyCurrencyTextBox544";
this.solvencyCurrencyTextBox544.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox544.TabIndex = 544;
this.solvencyCurrencyTextBox544.ColName = "R3610C1230";
this.solvencyCurrencyTextBox544.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox544.Enabled = false;
this.solvencyCurrencyTextBox544.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox545
//
this.solvencyCurrencyTextBox545.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox545.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox545.Location = new System.Drawing.Point(759,682);
this.solvencyCurrencyTextBox545.Name = "solvencyCurrencyTextBox545";
this.solvencyCurrencyTextBox545.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox545.TabIndex = 545;
this.solvencyCurrencyTextBox545.ColName = "R3610C1240";
this.solvencyCurrencyTextBox545.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox545.Enabled = false;
this.solvencyCurrencyTextBox545.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox546
//
this.solvencyCurrencyTextBox546.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox546.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox546.Location = new System.Drawing.Point(866,682);
this.solvencyCurrencyTextBox546.Name = "solvencyCurrencyTextBox546";
this.solvencyCurrencyTextBox546.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox546.TabIndex = 546;
this.solvencyCurrencyTextBox546.ColName = "R3610C1250";
this.solvencyCurrencyTextBox546.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox546.Enabled = false;
this.solvencyCurrencyTextBox546.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox547
//
this.solvencyCurrencyTextBox547.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox547.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox547.Location = new System.Drawing.Point(973,682);
this.solvencyCurrencyTextBox547.Name = "solvencyCurrencyTextBox547";
this.solvencyCurrencyTextBox547.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox547.TabIndex = 547;
this.solvencyCurrencyTextBox547.ColName = "R3610C1260";
this.solvencyCurrencyTextBox547.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox547.Enabled = false;
this.solvencyCurrencyTextBox547.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox548
//
this.solvencyCurrencyTextBox548.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox548.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox548.Location = new System.Drawing.Point(1080,682);
this.solvencyCurrencyTextBox548.Name = "solvencyCurrencyTextBox548";
this.solvencyCurrencyTextBox548.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox548.TabIndex = 548;
this.solvencyCurrencyTextBox548.ColName = "R3610C1270";
this.solvencyCurrencyTextBox548.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox549
//
this.solvencyCurrencyTextBox549.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox549.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox549.Location = new System.Drawing.Point(1187,682);
this.solvencyCurrencyTextBox549.Name = "solvencyCurrencyTextBox549";
this.solvencyCurrencyTextBox549.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox549.TabIndex = 549;
this.solvencyCurrencyTextBox549.ColName = "R3610C1280";
this.solvencyCurrencyTextBox549.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox550
//
this.solvencyCurrencyTextBox550.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox550.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox550.Location = new System.Drawing.Point(1294,682);
this.solvencyCurrencyTextBox550.Name = "solvencyCurrencyTextBox550";
this.solvencyCurrencyTextBox550.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox550.TabIndex = 550;
this.solvencyCurrencyTextBox550.ColName = "R3610C1290";
this.solvencyCurrencyTextBox550.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox551
//
this.solvencyCurrencyTextBox551.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox551.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox551.Location = new System.Drawing.Point(1401,682);
this.solvencyCurrencyTextBox551.Name = "solvencyCurrencyTextBox551";
this.solvencyCurrencyTextBox551.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox551.TabIndex = 551;
this.solvencyCurrencyTextBox551.ColName = "R3610C1300";
this.solvencyCurrencyTextBox551.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox552
//
this.solvencyCurrencyTextBox552.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox552.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox552.Location = new System.Drawing.Point(10,715);
this.solvencyCurrencyTextBox552.Name = "solvencyCurrencyTextBox552";
this.solvencyCurrencyTextBox552.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox552.TabIndex = 552;
this.solvencyCurrencyTextBox552.ColName = "R3620C1170";
this.solvencyCurrencyTextBox552.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox552.Enabled = false;
this.solvencyCurrencyTextBox552.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox553
//
this.solvencyCurrencyTextBox553.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox553.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox553.Location = new System.Drawing.Point(117,715);
this.solvencyCurrencyTextBox553.Name = "solvencyCurrencyTextBox553";
this.solvencyCurrencyTextBox553.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox553.TabIndex = 553;
this.solvencyCurrencyTextBox553.ColName = "R3620C1180";
this.solvencyCurrencyTextBox553.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox553.Enabled = false;
this.solvencyCurrencyTextBox553.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox554
//
this.solvencyCurrencyTextBox554.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox554.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox554.Location = new System.Drawing.Point(224,715);
this.solvencyCurrencyTextBox554.Name = "solvencyCurrencyTextBox554";
this.solvencyCurrencyTextBox554.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox554.TabIndex = 554;
this.solvencyCurrencyTextBox554.ColName = "R3620C1190";
this.solvencyCurrencyTextBox554.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox554.Enabled = false;
this.solvencyCurrencyTextBox554.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox555
//
this.solvencyCurrencyTextBox555.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox555.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox555.Location = new System.Drawing.Point(331,715);
this.solvencyCurrencyTextBox555.Name = "solvencyCurrencyTextBox555";
this.solvencyCurrencyTextBox555.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox555.TabIndex = 555;
this.solvencyCurrencyTextBox555.ColName = "R3620C1200";
this.solvencyCurrencyTextBox555.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox555.Enabled = false;
this.solvencyCurrencyTextBox555.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox556
//
this.solvencyCurrencyTextBox556.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox556.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox556.Location = new System.Drawing.Point(438,715);
this.solvencyCurrencyTextBox556.Name = "solvencyCurrencyTextBox556";
this.solvencyCurrencyTextBox556.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox556.TabIndex = 556;
this.solvencyCurrencyTextBox556.ColName = "R3620C1210";
this.solvencyCurrencyTextBox556.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox556.Enabled = false;
this.solvencyCurrencyTextBox556.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox557
//
this.solvencyCurrencyTextBox557.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox557.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox557.Location = new System.Drawing.Point(545,715);
this.solvencyCurrencyTextBox557.Name = "solvencyCurrencyTextBox557";
this.solvencyCurrencyTextBox557.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox557.TabIndex = 557;
this.solvencyCurrencyTextBox557.ColName = "R3620C1220";
this.solvencyCurrencyTextBox557.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox557.Enabled = false;
this.solvencyCurrencyTextBox557.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox558
//
this.solvencyCurrencyTextBox558.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox558.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox558.Location = new System.Drawing.Point(652,715);
this.solvencyCurrencyTextBox558.Name = "solvencyCurrencyTextBox558";
this.solvencyCurrencyTextBox558.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox558.TabIndex = 558;
this.solvencyCurrencyTextBox558.ColName = "R3620C1230";
this.solvencyCurrencyTextBox558.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox558.Enabled = false;
this.solvencyCurrencyTextBox558.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox559
//
this.solvencyCurrencyTextBox559.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox559.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox559.Location = new System.Drawing.Point(759,715);
this.solvencyCurrencyTextBox559.Name = "solvencyCurrencyTextBox559";
this.solvencyCurrencyTextBox559.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox559.TabIndex = 559;
this.solvencyCurrencyTextBox559.ColName = "R3620C1240";
this.solvencyCurrencyTextBox559.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox559.Enabled = false;
this.solvencyCurrencyTextBox559.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox560
//
this.solvencyCurrencyTextBox560.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox560.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox560.Location = new System.Drawing.Point(866,715);
this.solvencyCurrencyTextBox560.Name = "solvencyCurrencyTextBox560";
this.solvencyCurrencyTextBox560.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox560.TabIndex = 560;
this.solvencyCurrencyTextBox560.ColName = "R3620C1250";
this.solvencyCurrencyTextBox560.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox560.Enabled = false;
this.solvencyCurrencyTextBox560.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox561
//
this.solvencyCurrencyTextBox561.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox561.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox561.Location = new System.Drawing.Point(973,715);
this.solvencyCurrencyTextBox561.Name = "solvencyCurrencyTextBox561";
this.solvencyCurrencyTextBox561.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox561.TabIndex = 561;
this.solvencyCurrencyTextBox561.ColName = "R3620C1260";
this.solvencyCurrencyTextBox561.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox561.Enabled = false;
this.solvencyCurrencyTextBox561.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox562
//
this.solvencyCurrencyTextBox562.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox562.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox562.Location = new System.Drawing.Point(1080,715);
this.solvencyCurrencyTextBox562.Name = "solvencyCurrencyTextBox562";
this.solvencyCurrencyTextBox562.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox562.TabIndex = 562;
this.solvencyCurrencyTextBox562.ColName = "R3620C1270";
this.solvencyCurrencyTextBox562.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox563
//
this.solvencyCurrencyTextBox563.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox563.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox563.Location = new System.Drawing.Point(1187,715);
this.solvencyCurrencyTextBox563.Name = "solvencyCurrencyTextBox563";
this.solvencyCurrencyTextBox563.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox563.TabIndex = 563;
this.solvencyCurrencyTextBox563.ColName = "R3620C1280";
this.solvencyCurrencyTextBox563.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox563.Enabled = false;
this.solvencyCurrencyTextBox563.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox564
//
this.solvencyCurrencyTextBox564.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox564.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox564.Location = new System.Drawing.Point(1294,715);
this.solvencyCurrencyTextBox564.Name = "solvencyCurrencyTextBox564";
this.solvencyCurrencyTextBox564.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox564.TabIndex = 564;
this.solvencyCurrencyTextBox564.ColName = "R3620C1290";
this.solvencyCurrencyTextBox564.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox564.Enabled = false;
this.solvencyCurrencyTextBox564.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox565
//
this.solvencyCurrencyTextBox565.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox565.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox565.Location = new System.Drawing.Point(1401,715);
this.solvencyCurrencyTextBox565.Name = "solvencyCurrencyTextBox565";
this.solvencyCurrencyTextBox565.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox565.TabIndex = 565;
this.solvencyCurrencyTextBox565.ColName = "R3620C1300";
this.solvencyCurrencyTextBox565.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox566
//
this.solvencyCurrencyTextBox566.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox566.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox566.Location = new System.Drawing.Point(10,735);
this.solvencyCurrencyTextBox566.Name = "solvencyCurrencyTextBox566";
this.solvencyCurrencyTextBox566.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox566.TabIndex = 566;
this.solvencyCurrencyTextBox566.ColName = "R3630C1170";
this.solvencyCurrencyTextBox566.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox566.Enabled = false;
this.solvencyCurrencyTextBox566.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox567
//
this.solvencyCurrencyTextBox567.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox567.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox567.Location = new System.Drawing.Point(117,735);
this.solvencyCurrencyTextBox567.Name = "solvencyCurrencyTextBox567";
this.solvencyCurrencyTextBox567.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox567.TabIndex = 567;
this.solvencyCurrencyTextBox567.ColName = "R3630C1180";
this.solvencyCurrencyTextBox567.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox567.Enabled = false;
this.solvencyCurrencyTextBox567.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox568
//
this.solvencyCurrencyTextBox568.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox568.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox568.Location = new System.Drawing.Point(224,735);
this.solvencyCurrencyTextBox568.Name = "solvencyCurrencyTextBox568";
this.solvencyCurrencyTextBox568.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox568.TabIndex = 568;
this.solvencyCurrencyTextBox568.ColName = "R3630C1190";
this.solvencyCurrencyTextBox568.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox568.Enabled = false;
this.solvencyCurrencyTextBox568.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox569
//
this.solvencyCurrencyTextBox569.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox569.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox569.Location = new System.Drawing.Point(331,735);
this.solvencyCurrencyTextBox569.Name = "solvencyCurrencyTextBox569";
this.solvencyCurrencyTextBox569.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox569.TabIndex = 569;
this.solvencyCurrencyTextBox569.ColName = "R3630C1200";
this.solvencyCurrencyTextBox569.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox569.Enabled = false;
this.solvencyCurrencyTextBox569.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox570
//
this.solvencyCurrencyTextBox570.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox570.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox570.Location = new System.Drawing.Point(438,735);
this.solvencyCurrencyTextBox570.Name = "solvencyCurrencyTextBox570";
this.solvencyCurrencyTextBox570.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox570.TabIndex = 570;
this.solvencyCurrencyTextBox570.ColName = "R3630C1210";
this.solvencyCurrencyTextBox570.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox570.Enabled = false;
this.solvencyCurrencyTextBox570.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox571
//
this.solvencyCurrencyTextBox571.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox571.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox571.Location = new System.Drawing.Point(545,735);
this.solvencyCurrencyTextBox571.Name = "solvencyCurrencyTextBox571";
this.solvencyCurrencyTextBox571.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox571.TabIndex = 571;
this.solvencyCurrencyTextBox571.ColName = "R3630C1220";
this.solvencyCurrencyTextBox571.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox571.Enabled = false;
this.solvencyCurrencyTextBox571.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox572
//
this.solvencyCurrencyTextBox572.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox572.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox572.Location = new System.Drawing.Point(652,735);
this.solvencyCurrencyTextBox572.Name = "solvencyCurrencyTextBox572";
this.solvencyCurrencyTextBox572.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox572.TabIndex = 572;
this.solvencyCurrencyTextBox572.ColName = "R3630C1230";
this.solvencyCurrencyTextBox572.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox572.Enabled = false;
this.solvencyCurrencyTextBox572.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox573
//
this.solvencyCurrencyTextBox573.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox573.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox573.Location = new System.Drawing.Point(759,735);
this.solvencyCurrencyTextBox573.Name = "solvencyCurrencyTextBox573";
this.solvencyCurrencyTextBox573.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox573.TabIndex = 573;
this.solvencyCurrencyTextBox573.ColName = "R3630C1240";
this.solvencyCurrencyTextBox573.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox573.Enabled = false;
this.solvencyCurrencyTextBox573.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox574
//
this.solvencyCurrencyTextBox574.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox574.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox574.Location = new System.Drawing.Point(866,735);
this.solvencyCurrencyTextBox574.Name = "solvencyCurrencyTextBox574";
this.solvencyCurrencyTextBox574.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox574.TabIndex = 574;
this.solvencyCurrencyTextBox574.ColName = "R3630C1250";
this.solvencyCurrencyTextBox574.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox574.Enabled = false;
this.solvencyCurrencyTextBox574.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox575
//
this.solvencyCurrencyTextBox575.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox575.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox575.Location = new System.Drawing.Point(973,735);
this.solvencyCurrencyTextBox575.Name = "solvencyCurrencyTextBox575";
this.solvencyCurrencyTextBox575.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox575.TabIndex = 575;
this.solvencyCurrencyTextBox575.ColName = "R3630C1260";
this.solvencyCurrencyTextBox575.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox575.Enabled = false;
this.solvencyCurrencyTextBox575.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox576
//
this.solvencyCurrencyTextBox576.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox576.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox576.Location = new System.Drawing.Point(1080,735);
this.solvencyCurrencyTextBox576.Name = "solvencyCurrencyTextBox576";
this.solvencyCurrencyTextBox576.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox576.TabIndex = 576;
this.solvencyCurrencyTextBox576.ColName = "R3630C1270";
this.solvencyCurrencyTextBox576.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox577
//
this.solvencyCurrencyTextBox577.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox577.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox577.Location = new System.Drawing.Point(1187,735);
this.solvencyCurrencyTextBox577.Name = "solvencyCurrencyTextBox577";
this.solvencyCurrencyTextBox577.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox577.TabIndex = 577;
this.solvencyCurrencyTextBox577.ColName = "R3630C1280";
this.solvencyCurrencyTextBox577.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox577.Enabled = false;
this.solvencyCurrencyTextBox577.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox578
//
this.solvencyCurrencyTextBox578.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox578.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox578.Location = new System.Drawing.Point(1294,735);
this.solvencyCurrencyTextBox578.Name = "solvencyCurrencyTextBox578";
this.solvencyCurrencyTextBox578.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox578.TabIndex = 578;
this.solvencyCurrencyTextBox578.ColName = "R3630C1290";
this.solvencyCurrencyTextBox578.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox578.Enabled = false;
this.solvencyCurrencyTextBox578.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox579
//
this.solvencyCurrencyTextBox579.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox579.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox579.Location = new System.Drawing.Point(1401,735);
this.solvencyCurrencyTextBox579.Name = "solvencyCurrencyTextBox579";
this.solvencyCurrencyTextBox579.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox579.TabIndex = 579;
this.solvencyCurrencyTextBox579.ColName = "R3630C1300";
this.solvencyCurrencyTextBox579.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// splitContainerColTitles
//
this.splitContainerColTitles.Dock = System.Windows.Forms.DockStyle.Fill;
this.splitContainerColTitles.Location = new System.Drawing.Point(0,0);
this.splitContainerColTitles.Name = "splitContainerColTitles";
this.splitContainerColTitles.Orientation = System.Windows.Forms.Orientation.Vertical;
this.splitContainerColTitles.Panel1MinSize = 0;
//
// splitContainerColTitles.Panel1
//
//
// splitContainerColTitles.Panel2
//
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel0);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel1);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel2);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel3);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel4);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel5);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel6);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel7);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel8);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel9);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel10);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel11);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel12);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel13);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel14);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel15);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel16);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel17);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel18);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel19);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel20);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel21);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel22);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel23);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel24);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel25);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel26);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel27);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel28);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel29);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel30);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel31);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel32);
this.splitContainerColTitles.Size = new System.Drawing.Size(1947, 412);
this.splitContainerColTitles.SplitterDistance = 332;
//
// splitContainerRowTitles
//
this.splitContainerRowTitles.Dock = System.Windows.Forms.DockStyle.Fill;
this.splitContainerRowTitles.Location = new System.Drawing.Point(0,0);
this.splitContainerRowTitles.Name = "splitContainerRowTitles";
this.splitContainerRowTitles.Orientation = System.Windows.Forms.Orientation.Vertical;
this.splitContainerRowTitles.Panel1MinSize = 0;
//
// splitContainerRowTitles.Panel1
//
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel33);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel34);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel35);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel36);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel37);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel38);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel39);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel40);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel41);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel42);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel43);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel44);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel45);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel46);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel47);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel48);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel49);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel50);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel51);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel52);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel53);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel54);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel55);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel56);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel57);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel58);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel59);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel60);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel61);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel62);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel63);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel64);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel65);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel66);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel67);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel68);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel69);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel70);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel71);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel72);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel73);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel74);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel75);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel76);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel77);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel78);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel79);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel80);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel81);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel82);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel83);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel84);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel85);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel86);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel87);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel88);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel89);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel90);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel91);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel92);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel93);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel94);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel95);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel96);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel97);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel98);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel99);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel100);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel101);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel102);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel103);
//
// splitContainerRowTitles.Panel2
//
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox104);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox105);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox106);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox107);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox108);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox109);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox110);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox111);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox112);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox113);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox114);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox115);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox116);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox117);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox118);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox119);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox120);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox121);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox122);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox123);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox124);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox125);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox126);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox127);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox128);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox129);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox130);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox131);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox132);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox133);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox134);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox135);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox136);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox137);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox138);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox139);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox140);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox141);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox142);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox143);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox144);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox145);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox146);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox147);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox148);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox149);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox150);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox151);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox152);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox153);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox154);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox155);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox156);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox157);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox158);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox159);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox160);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox161);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox162);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox163);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox164);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox165);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox166);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox167);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox168);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox169);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox170);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox171);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox172);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox173);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox174);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox175);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox176);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox177);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox178);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox179);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox180);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox181);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox182);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox183);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox184);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox185);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox186);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox187);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox188);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox189);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox190);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox191);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox192);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox193);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox194);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox195);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox196);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox197);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox198);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox199);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox200);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox201);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox202);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox203);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox204);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox205);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox206);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox207);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox208);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox209);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox210);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox211);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox212);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox213);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox214);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox215);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox216);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox217);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox218);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox219);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox220);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox221);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox222);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox223);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox224);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox225);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox226);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox227);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox228);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox229);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox230);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox231);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox232);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox233);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox234);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox235);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox236);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox237);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox238);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox239);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox240);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox241);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox242);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox243);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox244);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox245);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox246);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox247);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox248);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox249);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox250);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox251);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox252);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox253);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox254);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox255);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox256);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox257);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox258);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox259);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox260);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox261);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox262);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox263);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox264);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox265);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox266);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox267);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox268);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox269);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox270);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox271);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox272);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox273);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox274);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox275);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox276);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox277);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox278);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox279);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox280);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox281);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox282);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox283);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox284);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox285);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox286);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox287);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox288);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox289);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox290);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox291);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox292);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox293);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox294);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox295);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox296);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox297);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox298);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox299);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox300);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox301);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox302);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox303);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox304);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox305);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox306);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox307);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox308);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox309);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox310);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox311);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox312);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox313);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox314);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox315);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox316);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox317);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox318);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox319);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox320);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox321);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox322);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox323);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox324);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox325);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox326);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox327);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox328);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox329);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox330);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox331);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox332);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox333);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox334);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox335);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox336);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox337);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox338);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox339);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox340);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox341);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox342);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox343);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox344);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox345);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox346);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox347);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox348);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox349);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox350);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox351);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox352);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox353);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox354);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox355);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox356);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox357);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox358);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox359);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox360);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox361);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox362);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox363);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox364);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox365);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox366);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox367);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox368);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox369);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox370);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox371);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox372);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox373);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox374);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox375);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox376);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox377);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox378);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox379);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox380);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox381);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox382);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox383);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox384);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox385);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox386);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox387);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox388);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox389);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox390);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox391);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox392);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox393);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox394);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox395);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox396);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox397);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox398);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox399);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox400);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox401);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox402);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox403);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox404);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox405);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox406);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox407);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox408);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox409);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox410);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox411);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox412);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox413);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox414);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox415);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox416);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox417);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox418);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox419);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox420);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox421);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox422);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox423);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox424);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox425);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox426);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox427);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox428);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox429);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox430);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox431);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox432);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox433);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox434);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox435);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox436);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox437);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox438);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox439);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox440);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox441);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox442);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox443);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox444);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox445);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox446);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox447);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox448);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox449);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox450);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox451);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox452);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox453);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox454);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox455);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox456);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox457);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox458);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox459);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox460);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox461);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox462);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox463);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox464);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox465);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox466);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox467);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox468);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox469);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox470);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox471);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox472);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox473);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox474);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox475);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox476);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox477);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox478);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox479);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox480);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox481);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox482);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox483);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox484);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox485);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox486);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox487);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox488);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox489);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox490);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox491);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox492);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox493);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox494);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox495);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox496);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox497);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox498);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox499);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox500);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox501);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox502);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox503);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox504);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox505);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox506);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox507);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox508);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox509);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox510);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox511);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox512);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox513);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox514);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox515);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox516);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox517);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox518);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox519);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox520);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox521);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox522);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox523);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox524);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox525);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox526);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox527);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox528);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox529);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox530);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox531);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox532);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox533);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox534);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox535);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox536);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox537);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox538);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox539);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox540);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox541);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox542);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox543);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox544);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox545);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox546);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox547);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox548);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox549);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox550);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox551);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox552);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox553);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox554);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox555);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox556);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox557);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox558);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox559);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox560);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox561);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox562);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox563);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox564);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox565);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox566);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox567);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox568);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox569);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox570);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox571);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox572);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox573);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox574);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox575);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox576);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox577);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox578);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox579);
this.splitContainerRowTitles.Panel2.AutoScroll = true;
this.splitContainerRowTitles.Size = new System.Drawing.Size(1947, 412);
this.splitContainerRowTitles.SplitterDistance = 332;
//
// spltMain
//
this.spltMain.Dock = System.Windows.Forms.DockStyle.Fill;
this.spltMain.Location = new System.Drawing.Point(0,0);
this.spltMain.Name = "spltMain";
this.spltMain.Orientation = System.Windows.Forms.Orientation.Horizontal;
this.spltMain.Panel1MinSize = 0;
//
// spltMain.Panel1
//
this.spltMain.Panel1.Controls.Add(this.splitContainerColTitles);
//
// spltMain.Panel2
//
this.spltMain.Panel2.Controls.Add(this.splitContainerRowTitles);
this.spltMain.Panel2.AutoScroll = true;
this.spltMain.Size = new System.Drawing.Size(1947, 918);
this.spltMain.SplitterDistance = 80;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F); 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font; 
this.Controls.Add(this.spltMain);
            this.Name = "S_27_01_01_20__sol2__2_0_1_ctrl"; 
            this.Size = new System.Drawing.Size(1947, 838); 
            this.Load += new System.EventHandler(this.BoundControl_Load);
            this.ResumeLayout(false); 
            this.PerformLayout(); 

      } 
private SolvencyLabel solvencyLabel0;
private SolvencyLabel solvencyLabel1;
private SolvencyLabel solvencyLabel2;
private SolvencyLabel solvencyLabel3;
private SolvencyLabel solvencyLabel4;
private SolvencyLabel solvencyLabel5;
private SolvencyLabel solvencyLabel6;
private SolvencyLabel solvencyLabel7;
private SolvencyLabel solvencyLabel8;
private SolvencyLabel solvencyLabel9;
private SolvencyLabel solvencyLabel10;
private SolvencyLabel solvencyLabel11;
private SolvencyLabel solvencyLabel12;
private SolvencyLabel solvencyLabel13;
private SolvencyLabel solvencyLabel14;
private SolvencyLabel solvencyLabel15;
private SolvencyLabel solvencyLabel16;
private SolvencyLabel solvencyLabel17;
private SolvencyLabel solvencyLabel18;
private SolvencyLabel solvencyLabel19;
private SolvencyLabel solvencyLabel20;
private SolvencyLabel solvencyLabel21;
private SolvencyLabel solvencyLabel22;
private SolvencyLabel solvencyLabel23;
private SolvencyLabel solvencyLabel24;
private SolvencyLabel solvencyLabel25;
private SolvencyLabel solvencyLabel26;
private SolvencyLabel solvencyLabel27;
private SolvencyLabel solvencyLabel28;
private SolvencyLabel solvencyLabel29;
private SolvencyLabel solvencyLabel30;
private SolvencyLabel solvencyLabel31;
private SolvencyLabel solvencyLabel32;
private SolvencyLabel solvencyLabel33;
private SolvencyLabel solvencyLabel34;
private SolvencyLabel solvencyLabel35;
private SolvencyLabel solvencyLabel36;
private SolvencyLabel solvencyLabel37;
private SolvencyLabel solvencyLabel38;
private SolvencyLabel solvencyLabel39;
private SolvencyLabel solvencyLabel40;
private SolvencyLabel solvencyLabel41;
private SolvencyLabel solvencyLabel42;
private SolvencyLabel solvencyLabel43;
private SolvencyLabel solvencyLabel44;
private SolvencyLabel solvencyLabel45;
private SolvencyLabel solvencyLabel46;
private SolvencyLabel solvencyLabel47;
private SolvencyLabel solvencyLabel48;
private SolvencyLabel solvencyLabel49;
private SolvencyLabel solvencyLabel50;
private SolvencyLabel solvencyLabel51;
private SolvencyLabel solvencyLabel52;
private SolvencyLabel solvencyLabel53;
private SolvencyLabel solvencyLabel54;
private SolvencyLabel solvencyLabel55;
private SolvencyLabel solvencyLabel56;
private SolvencyLabel solvencyLabel57;
private SolvencyLabel solvencyLabel58;
private SolvencyLabel solvencyLabel59;
private SolvencyLabel solvencyLabel60;
private SolvencyLabel solvencyLabel61;
private SolvencyLabel solvencyLabel62;
private SolvencyLabel solvencyLabel63;
private SolvencyLabel solvencyLabel64;
private SolvencyLabel solvencyLabel65;
private SolvencyLabel solvencyLabel66;
private SolvencyLabel solvencyLabel67;
private SolvencyLabel solvencyLabel68;
private SolvencyLabel solvencyLabel69;
private SolvencyLabel solvencyLabel70;
private SolvencyLabel solvencyLabel71;
private SolvencyLabel solvencyLabel72;
private SolvencyLabel solvencyLabel73;
private SolvencyLabel solvencyLabel74;
private SolvencyLabel solvencyLabel75;
private SolvencyLabel solvencyLabel76;
private SolvencyLabel solvencyLabel77;
private SolvencyLabel solvencyLabel78;
private SolvencyLabel solvencyLabel79;
private SolvencyLabel solvencyLabel80;
private SolvencyLabel solvencyLabel81;
private SolvencyLabel solvencyLabel82;
private SolvencyLabel solvencyLabel83;
private SolvencyLabel solvencyLabel84;
private SolvencyLabel solvencyLabel85;
private SolvencyLabel solvencyLabel86;
private SolvencyLabel solvencyLabel87;
private SolvencyLabel solvencyLabel88;
private SolvencyLabel solvencyLabel89;
private SolvencyLabel solvencyLabel90;
private SolvencyLabel solvencyLabel91;
private SolvencyLabel solvencyLabel92;
private SolvencyLabel solvencyLabel93;
private SolvencyLabel solvencyLabel94;
private SolvencyLabel solvencyLabel95;
private SolvencyLabel solvencyLabel96;
private SolvencyLabel solvencyLabel97;
private SolvencyLabel solvencyLabel98;
private SolvencyLabel solvencyLabel99;
private SolvencyLabel solvencyLabel100;
private SolvencyLabel solvencyLabel101;
private SolvencyLabel solvencyLabel102;
private SolvencyLabel solvencyLabel103;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox104;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox105;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox106;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox107;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox108;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox109;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox110;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox111;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox112;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox113;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox114;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox115;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox116;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox117;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox118;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox119;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox120;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox121;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox122;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox123;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox124;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox125;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox126;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox127;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox128;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox129;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox130;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox131;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox132;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox133;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox134;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox135;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox136;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox137;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox138;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox139;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox140;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox141;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox142;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox143;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox144;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox145;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox146;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox147;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox148;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox149;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox150;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox151;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox152;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox153;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox154;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox155;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox156;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox157;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox158;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox159;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox160;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox161;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox162;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox163;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox164;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox165;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox166;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox167;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox168;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox169;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox170;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox171;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox172;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox173;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox174;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox175;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox176;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox177;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox178;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox179;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox180;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox181;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox182;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox183;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox184;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox185;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox186;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox187;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox188;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox189;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox190;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox191;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox192;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox193;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox194;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox195;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox196;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox197;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox198;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox199;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox200;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox201;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox202;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox203;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox204;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox205;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox206;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox207;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox208;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox209;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox210;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox211;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox212;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox213;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox214;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox215;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox216;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox217;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox218;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox219;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox220;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox221;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox222;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox223;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox224;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox225;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox226;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox227;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox228;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox229;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox230;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox231;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox232;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox233;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox234;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox235;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox236;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox237;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox238;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox239;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox240;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox241;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox242;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox243;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox244;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox245;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox246;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox247;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox248;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox249;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox250;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox251;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox252;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox253;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox254;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox255;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox256;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox257;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox258;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox259;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox260;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox261;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox262;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox263;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox264;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox265;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox266;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox267;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox268;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox269;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox270;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox271;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox272;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox273;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox274;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox275;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox276;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox277;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox278;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox279;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox280;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox281;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox282;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox283;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox284;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox285;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox286;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox287;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox288;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox289;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox290;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox291;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox292;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox293;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox294;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox295;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox296;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox297;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox298;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox299;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox300;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox301;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox302;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox303;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox304;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox305;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox306;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox307;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox308;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox309;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox310;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox311;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox312;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox313;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox314;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox315;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox316;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox317;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox318;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox319;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox320;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox321;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox322;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox323;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox324;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox325;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox326;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox327;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox328;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox329;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox330;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox331;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox332;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox333;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox334;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox335;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox336;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox337;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox338;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox339;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox340;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox341;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox342;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox343;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox344;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox345;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox346;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox347;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox348;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox349;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox350;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox351;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox352;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox353;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox354;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox355;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox356;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox357;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox358;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox359;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox360;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox361;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox362;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox363;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox364;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox365;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox366;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox367;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox368;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox369;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox370;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox371;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox372;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox373;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox374;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox375;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox376;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox377;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox378;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox379;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox380;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox381;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox382;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox383;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox384;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox385;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox386;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox387;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox388;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox389;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox390;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox391;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox392;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox393;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox394;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox395;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox396;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox397;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox398;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox399;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox400;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox401;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox402;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox403;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox404;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox405;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox406;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox407;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox408;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox409;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox410;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox411;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox412;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox413;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox414;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox415;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox416;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox417;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox418;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox419;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox420;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox421;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox422;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox423;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox424;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox425;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox426;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox427;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox428;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox429;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox430;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox431;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox432;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox433;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox434;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox435;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox436;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox437;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox438;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox439;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox440;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox441;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox442;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox443;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox444;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox445;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox446;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox447;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox448;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox449;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox450;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox451;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox452;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox453;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox454;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox455;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox456;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox457;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox458;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox459;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox460;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox461;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox462;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox463;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox464;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox465;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox466;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox467;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox468;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox469;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox470;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox471;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox472;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox473;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox474;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox475;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox476;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox477;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox478;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox479;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox480;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox481;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox482;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox483;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox484;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox485;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox486;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox487;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox488;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox489;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox490;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox491;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox492;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox493;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox494;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox495;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox496;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox497;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox498;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox499;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox500;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox501;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox502;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox503;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox504;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox505;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox506;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox507;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox508;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox509;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox510;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox511;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox512;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox513;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox514;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox515;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox516;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox517;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox518;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox519;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox520;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox521;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox522;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox523;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox524;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox525;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox526;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox527;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox528;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox529;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox530;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox531;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox532;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox533;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox534;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox535;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox536;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox537;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox538;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox539;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox540;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox541;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox542;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox543;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox544;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox545;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox546;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox547;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox548;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox549;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox550;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox551;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox552;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox553;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox554;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox555;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox556;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox557;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox558;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox559;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox560;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox561;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox562;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox563;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox564;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox565;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox566;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox567;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox568;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox569;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox570;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox571;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox572;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox573;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox574;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox575;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox576;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox577;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox578;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox579;
private SolvencySplitContainer splitContainerColTitles;
private SolvencySplitContainer splitContainerRowTitles;
private SolvencySplitContainer spltMain;

   }
}

