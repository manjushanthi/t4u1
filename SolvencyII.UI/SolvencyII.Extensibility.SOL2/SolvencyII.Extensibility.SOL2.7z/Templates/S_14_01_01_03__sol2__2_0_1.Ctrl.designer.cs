using SolvencyII.Domain.ENumerators; 
using SolvencyII.UI.Shared.Controls; 

namespace SolvencyII.UI.UserControls 
{ 
   partial class S_14_01_01_03__sol2__2_0_1_ctrl 
   { 
      private void InitializeComponent() 
      { 
this.solvencyLabel0 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel1 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel2 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel3 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel4 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel5 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel6 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel7 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel8 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel9 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel10 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel12 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyTextBox13 = new SolvencyII.UI.Shared.Controls.SolvencyTextBox();
this.solvencyCurrencyTextBox14 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox15 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox16 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyTextBox17 = new SolvencyII.UI.Shared.Controls.SolvencyTextBox();
this.splitContainerColTitles = new SolvencyII.UI.Shared.Controls.SolvencySplitContainer();
this.splitContainerRowTitles = new SolvencyII.UI.Shared.Controls.SolvencySplitContainer();
this.spltMain = new SolvencyII.UI.Shared.Controls.SolvencySplitContainer();
            this.SuspendLayout(); 

//
// solvencyLabel0
//
this.solvencyLabel0.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel0.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel0.Location = new System.Drawing.Point(438,10);
this.solvencyLabel0.Name = "solvencyLabel0";
this.solvencyLabel0.OrdinateID_Label = 2905;
this.solvencyLabel0.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel0.TabIndex = 0;
this.solvencyLabel0.Text = "Annualised guaranteed rate (over average duration of guarantee)" ;
this.solvencyLabel0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel0.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel1
//
this.solvencyLabel1.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel1.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel1.Location = new System.Drawing.Point(438,55);
this.solvencyLabel1.Name = "solvencyLabel1";
this.solvencyLabel1.OrdinateID_Label = 0;
this.solvencyLabel1.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel1.TabIndex = 1;
this.solvencyLabel1.Text = "C0210" ;
this.solvencyLabel1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel2
//
this.solvencyLabel2.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel2.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel2.Location = new System.Drawing.Point(331,10);
this.solvencyLabel2.Name = "solvencyLabel2";
this.solvencyLabel2.OrdinateID_Label = 2904;
this.solvencyLabel2.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel2.TabIndex = 2;
this.solvencyLabel2.Text = "Surrender value" ;
this.solvencyLabel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel3
//
this.solvencyLabel3.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel3.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel3.Location = new System.Drawing.Point(331,55);
this.solvencyLabel3.Name = "solvencyLabel3";
this.solvencyLabel3.OrdinateID_Label = 0;
this.solvencyLabel3.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel3.TabIndex = 3;
this.solvencyLabel3.Text = "C0200" ;
this.solvencyLabel3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel4
//
this.solvencyLabel4.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel4.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel4.Location = new System.Drawing.Point(224,10);
this.solvencyLabel4.Name = "solvencyLabel4";
this.solvencyLabel4.OrdinateID_Label = 2903;
this.solvencyLabel4.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel4.TabIndex = 4;
this.solvencyLabel4.Text = "Capital-at-risk" ;
this.solvencyLabel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel5
//
this.solvencyLabel5.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel5.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel5.Location = new System.Drawing.Point(224,55);
this.solvencyLabel5.Name = "solvencyLabel5";
this.solvencyLabel5.OrdinateID_Label = 0;
this.solvencyLabel5.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel5.TabIndex = 5;
this.solvencyLabel5.Text = "C0190" ;
this.solvencyLabel5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel6
//
this.solvencyLabel6.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel6.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel6.Location = new System.Drawing.Point(117,10);
this.solvencyLabel6.Name = "solvencyLabel6";
this.solvencyLabel6.OrdinateID_Label = 2902;
this.solvencyLabel6.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel6.TabIndex = 6;
this.solvencyLabel6.Text = "Best Estimate" ;
this.solvencyLabel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel6.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel7
//
this.solvencyLabel7.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel7.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel7.Location = new System.Drawing.Point(117,55);
this.solvencyLabel7.Name = "solvencyLabel7";
this.solvencyLabel7.OrdinateID_Label = 0;
this.solvencyLabel7.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel7.TabIndex = 7;
this.solvencyLabel7.Text = "C0180" ;
this.solvencyLabel7.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel8
//
this.solvencyLabel8.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel8.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel8.Location = new System.Drawing.Point(10,10);
this.solvencyLabel8.Name = "solvencyLabel8";
this.solvencyLabel8.OrdinateID_Label = 2906;
this.solvencyLabel8.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel8.TabIndex = 8;
this.solvencyLabel8.Text = "HRG code" ;
this.solvencyLabel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel8.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel9
//
this.solvencyLabel9.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel9.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel9.Location = new System.Drawing.Point(10,55);
this.solvencyLabel9.Name = "solvencyLabel9";
this.solvencyLabel9.OrdinateID_Label = 0;
this.solvencyLabel9.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel9.TabIndex = 9;
this.solvencyLabel9.Text = "C0170" ;
this.solvencyLabel9.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel10
//
this.solvencyLabel10.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel10.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel10.Location = new System.Drawing.Point(3,3);
this.solvencyLabel10.Name = "solvencyLabel10";
this.solvencyLabel10.OrdinateID_Label = 0;
this.solvencyLabel10.Size = new System.Drawing.Size(21, 0);
this.solvencyLabel10.TabIndex = 10;
this.solvencyLabel10.Text = "" ;
this.solvencyLabel10.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel12
//
this.solvencyLabel12.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel12.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel12.Location = new System.Drawing.Point(38,23);
this.solvencyLabel12.Name = "solvencyLabel12";
this.solvencyLabel12.OrdinateID_Label = 0;
this.solvencyLabel12.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel12.TabIndex = 12;
this.solvencyLabel12.Text = "." ;
this.solvencyLabel12.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyTextBox13
//
this.solvencyTextBox13.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyTextBox13.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyTextBox13.Location = new System.Drawing.Point(10,3);
this.solvencyTextBox13.Name = "solvencyTextBox13";
this.solvencyTextBox13.Size = new System.Drawing.Size(100, 13);
this.solvencyTextBox13.TabIndex = 13;
this.solvencyTextBox13.ColName = "C0170";
this.solvencyTextBox13.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
//
// solvencyCurrencyTextBox14
//
this.solvencyCurrencyTextBox14.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox14.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox14.Location = new System.Drawing.Point(117,3);
this.solvencyCurrencyTextBox14.Name = "solvencyCurrencyTextBox14";
this.solvencyCurrencyTextBox14.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox14.TabIndex = 14;
this.solvencyCurrencyTextBox14.ColName = "C0180";
this.solvencyCurrencyTextBox14.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox15
//
this.solvencyCurrencyTextBox15.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox15.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox15.Location = new System.Drawing.Point(224,3);
this.solvencyCurrencyTextBox15.Name = "solvencyCurrencyTextBox15";
this.solvencyCurrencyTextBox15.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox15.TabIndex = 15;
this.solvencyCurrencyTextBox15.ColName = "C0190";
this.solvencyCurrencyTextBox15.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox16
//
this.solvencyCurrencyTextBox16.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox16.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox16.Location = new System.Drawing.Point(331,3);
this.solvencyCurrencyTextBox16.Name = "solvencyCurrencyTextBox16";
this.solvencyCurrencyTextBox16.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox16.TabIndex = 16;
this.solvencyCurrencyTextBox16.ColName = "C0200";
this.solvencyCurrencyTextBox16.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyTextBox17
//
this.solvencyTextBox17.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyTextBox17.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyTextBox17.Location = new System.Drawing.Point(438,3);
this.solvencyTextBox17.Name = "solvencyTextBox17";
this.solvencyTextBox17.Size = new System.Drawing.Size(100, 13);
this.solvencyTextBox17.TabIndex = 17;
this.solvencyTextBox17.ColName = "C0210";
this.solvencyTextBox17.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
//
// splitContainerColTitles
//
this.splitContainerColTitles.Dock = System.Windows.Forms.DockStyle.Fill;
this.splitContainerColTitles.Location = new System.Drawing.Point(0,0);
this.splitContainerColTitles.Name = "splitContainerColTitles";
this.splitContainerColTitles.Orientation = System.Windows.Forms.Orientation.Vertical;
this.splitContainerColTitles.Panel1MinSize = 0;
//
// splitContainerColTitles.Panel1
//
//
// splitContainerColTitles.Panel2
//
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel0);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel1);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel2);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel3);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel4);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel5);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel6);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel7);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel8);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel9);
this.splitContainerColTitles.Size = new System.Drawing.Size(737, 160);
this.splitContainerColTitles.SplitterDistance = 85;
//
// splitContainerRowTitles
//
this.splitContainerRowTitles.Dock = System.Windows.Forms.DockStyle.Fill;
this.splitContainerRowTitles.Location = new System.Drawing.Point(0,0);
this.splitContainerRowTitles.Name = "splitContainerRowTitles";
this.splitContainerRowTitles.Orientation = System.Windows.Forms.Orientation.Vertical;
this.splitContainerRowTitles.Panel1MinSize = 0;
//
// splitContainerRowTitles.Panel1
//
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel10);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel12);
//
// splitContainerRowTitles.Panel2
//
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyTextBox13);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox14);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox15);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox16);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyTextBox17);
this.splitContainerRowTitles.Panel2.AutoScroll = true;
this.splitContainerRowTitles.Size = new System.Drawing.Size(737, 160);
this.splitContainerRowTitles.SplitterDistance = 85;
//
// spltMain
//
this.spltMain.Dock = System.Windows.Forms.DockStyle.Fill;
this.spltMain.Location = new System.Drawing.Point(0,0);
this.spltMain.Name = "spltMain";
this.spltMain.Orientation = System.Windows.Forms.Orientation.Horizontal;
this.spltMain.Panel1MinSize = 0;
//
// spltMain.Panel1
//
this.spltMain.Panel1.Controls.Add(this.splitContainerColTitles);
//
// spltMain.Panel2
//
this.spltMain.Panel2.Controls.Add(this.splitContainerRowTitles);
this.spltMain.Panel2.AutoScroll = true;
this.spltMain.Size = new System.Drawing.Size(737, 176);
this.spltMain.SplitterDistance = 75;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F); 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font; 
this.Controls.Add(this.spltMain);
            this.Name = "S_14_01_01_03__sol2__2_0_1_ctrl"; 
            this.Size = new System.Drawing.Size(737, 101); 
            this.Load += new System.EventHandler(this.BoundControl_Load);
            this.ResumeLayout(false); 
            this.PerformLayout(); 

      } 
private SolvencyLabel solvencyLabel0;
private SolvencyLabel solvencyLabel1;
private SolvencyLabel solvencyLabel2;
private SolvencyLabel solvencyLabel3;
private SolvencyLabel solvencyLabel4;
private SolvencyLabel solvencyLabel5;
private SolvencyLabel solvencyLabel6;
private SolvencyLabel solvencyLabel7;
private SolvencyLabel solvencyLabel8;
private SolvencyLabel solvencyLabel9;
private SolvencyLabel solvencyLabel10;
private SolvencyLabel solvencyLabel12;
private SolvencyTextBox solvencyTextBox13;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox14;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox15;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox16;
private SolvencyTextBox solvencyTextBox17;
private SolvencySplitContainer splitContainerColTitles;
private SolvencySplitContainer splitContainerRowTitles;
private SolvencySplitContainer spltMain;

   }
}

