using SolvencyII.Domain.ENumerators; 
using SolvencyII.UI.Shared.Controls; 

namespace SolvencyII.UI.UserControls 
{ 
   partial class S_27_01_04_05__sol2__2_0_1_ctrl 
   { 
      private void InitializeComponent() 
      { 
this.solvencyLabel0 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel1 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel2 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel3 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel4 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel5 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel6 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel7 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel8 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel9 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel10 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel11 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel12 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel13 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel14 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel15 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel16 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel17 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel18 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel19 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel20 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel21 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel22 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel23 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel24 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel25 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel26 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel27 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel28 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel29 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel30 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel31 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel32 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel33 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel34 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel35 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel36 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel37 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel38 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel39 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel40 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel41 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel42 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel43 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel44 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel45 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel46 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel47 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel48 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel49 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel50 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel51 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel52 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel53 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel54 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel55 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel56 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel57 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel58 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel59 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel60 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel61 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel62 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel63 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel64 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel65 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel66 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel67 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel68 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel69 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel70 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel71 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel72 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel73 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel74 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel75 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel76 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel77 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel78 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel79 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel80 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel81 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel82 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel83 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel84 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyCurrencyTextBox85 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox86 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox87 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox88 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox89 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox90 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox91 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox92 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox93 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox94 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox95 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox96 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox97 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox98 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox99 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox100 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox101 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox102 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox103 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox104 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox105 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox106 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox107 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox108 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox109 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox110 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox111 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox112 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox113 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox114 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox115 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox116 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox117 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox118 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox119 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox120 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox121 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox122 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox123 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox124 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox125 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox126 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox127 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox128 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox129 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox130 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox131 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox132 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox133 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox134 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox135 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox136 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox137 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox138 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox139 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox140 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox141 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox142 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox143 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox144 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox145 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox146 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox147 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox148 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox149 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox150 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox151 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox152 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox153 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox154 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox155 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox156 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox157 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox158 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox159 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox160 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox161 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox162 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox163 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox164 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox165 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox166 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox167 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox168 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox169 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox170 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox171 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox172 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox173 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox174 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox175 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox176 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox177 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox178 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox179 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox180 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox181 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox182 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox183 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox184 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox185 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox186 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox187 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox188 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox189 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox190 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox191 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox192 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox193 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox194 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox195 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox196 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox197 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox198 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox199 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox200 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox201 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox202 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox203 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox204 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox205 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox206 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox207 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox208 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox209 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox210 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox211 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox212 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox213 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox214 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox215 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox216 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox217 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox218 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox219 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox220 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox221 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox222 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox223 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox224 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox225 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox226 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox227 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox228 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox229 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox230 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox231 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox232 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox233 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox234 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox235 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox236 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox237 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox238 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox239 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox240 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox241 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox242 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox243 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox244 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox245 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox246 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox247 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox248 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox249 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox250 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox251 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox252 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox253 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox254 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox255 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox256 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox257 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox258 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox259 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox260 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox261 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox262 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox263 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox264 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox265 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox266 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox267 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox268 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox269 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox270 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox271 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox272 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox273 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox274 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox275 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox276 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox277 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox278 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox279 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox280 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox281 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox282 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox283 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox284 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox285 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox286 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox287 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox288 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox289 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox290 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox291 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox292 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox293 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox294 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox295 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox296 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox297 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox298 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox299 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox300 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox301 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox302 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox303 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox304 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox305 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox306 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox307 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox308 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox309 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox310 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox311 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox312 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox313 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox314 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox315 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox316 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox317 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox318 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox319 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox320 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox321 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox322 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox323 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox324 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox325 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox326 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox327 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox328 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox329 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox330 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox331 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox332 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox333 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox334 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox335 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox336 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox337 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox338 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox339 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox340 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox341 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox342 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox343 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox344 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox345 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox346 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox347 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox348 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox349 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox350 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox351 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox352 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox353 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox354 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox355 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox356 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox357 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox358 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox359 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox360 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox361 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox362 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox363 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox364 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox365 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox366 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox367 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox368 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox369 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox370 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox371 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox372 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.splitContainerColTitles = new SolvencyII.UI.Shared.Controls.SolvencySplitContainer();
this.splitContainerRowTitles = new SolvencyII.UI.Shared.Controls.SolvencySplitContainer();
this.spltMain = new SolvencyII.UI.Shared.Controls.SolvencySplitContainer();
            this.SuspendLayout(); 

//
// solvencyLabel0
//
this.solvencyLabel0.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel0.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel0.Location = new System.Drawing.Point(966,10);
this.solvencyLabel0.Name = "solvencyLabel0";
this.solvencyLabel0.OrdinateID_Label = 7081;
this.solvencyLabel0.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel0.TabIndex = 0;
this.solvencyLabel0.Text = "Catastrophe Risk Charge after risk mitigation" ;
this.solvencyLabel0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel0.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel1
//
this.solvencyLabel1.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel1.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel1.Location = new System.Drawing.Point(966,55);
this.solvencyLabel1.Name = "solvencyLabel1";
this.solvencyLabel1.OrdinateID_Label = 0;
this.solvencyLabel1.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel1.TabIndex = 1;
this.solvencyLabel1.Text = "C0380" ;
this.solvencyLabel1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel2
//
this.solvencyLabel2.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel2.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel2.Location = new System.Drawing.Point(859,10);
this.solvencyLabel2.Name = "solvencyLabel2";
this.solvencyLabel2.OrdinateID_Label = 7080;
this.solvencyLabel2.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel2.TabIndex = 2;
this.solvencyLabel2.Text = "Estimated Reinstatement Premiums" ;
this.solvencyLabel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel3
//
this.solvencyLabel3.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel3.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel3.Location = new System.Drawing.Point(859,55);
this.solvencyLabel3.Name = "solvencyLabel3";
this.solvencyLabel3.OrdinateID_Label = 0;
this.solvencyLabel3.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel3.TabIndex = 3;
this.solvencyLabel3.Text = "C0370" ;
this.solvencyLabel3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel4
//
this.solvencyLabel4.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel4.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel4.Location = new System.Drawing.Point(752,10);
this.solvencyLabel4.Name = "solvencyLabel4";
this.solvencyLabel4.OrdinateID_Label = 7079;
this.solvencyLabel4.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel4.TabIndex = 4;
this.solvencyLabel4.Text = "Estimated Risk Mitigation" ;
this.solvencyLabel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel5
//
this.solvencyLabel5.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel5.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel5.Location = new System.Drawing.Point(752,55);
this.solvencyLabel5.Name = "solvencyLabel5";
this.solvencyLabel5.OrdinateID_Label = 0;
this.solvencyLabel5.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel5.TabIndex = 5;
this.solvencyLabel5.Text = "C0360" ;
this.solvencyLabel5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel6
//
this.solvencyLabel6.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel6.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel6.Location = new System.Drawing.Point(645,10);
this.solvencyLabel6.Name = "solvencyLabel6";
this.solvencyLabel6.OrdinateID_Label = 7078;
this.solvencyLabel6.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel6.TabIndex = 6;
this.solvencyLabel6.Text = "Catastrophe Risk Charge before risk mitigation" ;
this.solvencyLabel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel6.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel7
//
this.solvencyLabel7.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel7.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel7.Location = new System.Drawing.Point(645,55);
this.solvencyLabel7.Name = "solvencyLabel7";
this.solvencyLabel7.OrdinateID_Label = 0;
this.solvencyLabel7.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel7.TabIndex = 7;
this.solvencyLabel7.Text = "C0350" ;
this.solvencyLabel7.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel8
//
this.solvencyLabel8.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel8.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel8.Location = new System.Drawing.Point(438,10);
this.solvencyLabel8.Name = "solvencyLabel8";
this.solvencyLabel8.OrdinateID_Label = 7077;
this.solvencyLabel8.Size = new System.Drawing.Size(208, 45);
this.solvencyLabel8.TabIndex = 8;
this.solvencyLabel8.Text = "Scenario A or B" ;
this.solvencyLabel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel8.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel9
//
this.solvencyLabel9.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel9.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel9.Location = new System.Drawing.Point(438,55);
this.solvencyLabel9.Name = "solvencyLabel9";
this.solvencyLabel9.OrdinateID_Label = 0;
this.solvencyLabel9.Size = new System.Drawing.Size(208, 13);
this.solvencyLabel9.TabIndex = 9;
this.solvencyLabel9.Text = "C0340" ;
this.solvencyLabel9.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel10
//
this.solvencyLabel10.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel10.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel10.Location = new System.Drawing.Point(331,10);
this.solvencyLabel10.Name = "solvencyLabel10";
this.solvencyLabel10.OrdinateID_Label = 7076;
this.solvencyLabel10.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel10.TabIndex = 10;
this.solvencyLabel10.Text = "Catastrophe Risk Charge Factor before risk mitigation" ;
this.solvencyLabel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel10.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel11
//
this.solvencyLabel11.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel11.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel11.Location = new System.Drawing.Point(331,55);
this.solvencyLabel11.Name = "solvencyLabel11";
this.solvencyLabel11.OrdinateID_Label = 0;
this.solvencyLabel11.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel11.TabIndex = 11;
this.solvencyLabel11.Text = "C0330" ;
this.solvencyLabel11.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel12
//
this.solvencyLabel12.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel12.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel12.Location = new System.Drawing.Point(224,10);
this.solvencyLabel12.Name = "solvencyLabel12";
this.solvencyLabel12.OrdinateID_Label = 7075;
this.solvencyLabel12.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel12.TabIndex = 12;
this.solvencyLabel12.Text = "Specified Gross Loss" ;
this.solvencyLabel12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel12.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel13
//
this.solvencyLabel13.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel13.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel13.Location = new System.Drawing.Point(224,55);
this.solvencyLabel13.Name = "solvencyLabel13";
this.solvencyLabel13.OrdinateID_Label = 0;
this.solvencyLabel13.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel13.TabIndex = 13;
this.solvencyLabel13.Text = "C0320" ;
this.solvencyLabel13.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel14
//
this.solvencyLabel14.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel14.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel14.Location = new System.Drawing.Point(117,10);
this.solvencyLabel14.Name = "solvencyLabel14";
this.solvencyLabel14.OrdinateID_Label = 7074;
this.solvencyLabel14.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel14.TabIndex = 14;
this.solvencyLabel14.Text = "Exposure" ;
this.solvencyLabel14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel14.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel15
//
this.solvencyLabel15.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel15.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel15.Location = new System.Drawing.Point(117,55);
this.solvencyLabel15.Name = "solvencyLabel15";
this.solvencyLabel15.OrdinateID_Label = 0;
this.solvencyLabel15.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel15.TabIndex = 15;
this.solvencyLabel15.Text = "C0310" ;
this.solvencyLabel15.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel16
//
this.solvencyLabel16.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel16.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel16.Location = new System.Drawing.Point(10,10);
this.solvencyLabel16.Name = "solvencyLabel16";
this.solvencyLabel16.OrdinateID_Label = 7073;
this.solvencyLabel16.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel16.TabIndex = 16;
this.solvencyLabel16.Text = "Estimation of the gross premiums to be earned" ;
this.solvencyLabel16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel16.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel17
//
this.solvencyLabel17.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel17.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel17.Location = new System.Drawing.Point(10,55);
this.solvencyLabel17.Name = "solvencyLabel17";
this.solvencyLabel17.OrdinateID_Label = 0;
this.solvencyLabel17.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel17.TabIndex = 17;
this.solvencyLabel17.Text = "C0300" ;
this.solvencyLabel17.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel18
//
this.solvencyLabel18.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel18.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel18.Location = new System.Drawing.Point(10,3);
this.solvencyLabel18.Name = "solvencyLabel18";
this.solvencyLabel18.OrdinateID_Label = 7082;
this.solvencyLabel18.Size = new System.Drawing.Size(261, 15);
this.solvencyLabel18.TabIndex = 18;
this.solvencyLabel18.Text = "Natural Catastrophe risk - Hail" ;
this.solvencyLabel18.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel19
//
this.solvencyLabel19.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel19.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel19.Location = new System.Drawing.Point(285,3);
this.solvencyLabel19.Name = "solvencyLabel19";
this.solvencyLabel19.OrdinateID_Label = 0;
this.solvencyLabel19.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel19.TabIndex = 19;
this.solvencyLabel19.Text = "" ;
this.solvencyLabel19.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel20
//
this.solvencyLabel20.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel20.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel20.Location = new System.Drawing.Point(17,23);
this.solvencyLabel20.Name = "solvencyLabel20";
this.solvencyLabel20.OrdinateID_Label = 7083;
this.solvencyLabel20.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel20.TabIndex = 20;
this.solvencyLabel20.Text = "Republic of Austria" ;
this.solvencyLabel20.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel21
//
this.solvencyLabel21.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel21.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel21.Location = new System.Drawing.Point(285,23);
this.solvencyLabel21.Name = "solvencyLabel21";
this.solvencyLabel21.OrdinateID_Label = 0;
this.solvencyLabel21.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel21.TabIndex = 21;
this.solvencyLabel21.Text = "R1630" ;
this.solvencyLabel21.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel22
//
this.solvencyLabel22.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel22.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel22.Location = new System.Drawing.Point(17,43);
this.solvencyLabel22.Name = "solvencyLabel22";
this.solvencyLabel22.OrdinateID_Label = 7084;
this.solvencyLabel22.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel22.TabIndex = 22;
this.solvencyLabel22.Text = "Kingdom of Belgium" ;
this.solvencyLabel22.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel23
//
this.solvencyLabel23.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel23.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel23.Location = new System.Drawing.Point(285,43);
this.solvencyLabel23.Name = "solvencyLabel23";
this.solvencyLabel23.OrdinateID_Label = 0;
this.solvencyLabel23.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel23.TabIndex = 23;
this.solvencyLabel23.Text = "R1640" ;
this.solvencyLabel23.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel24
//
this.solvencyLabel24.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel24.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel24.Location = new System.Drawing.Point(17,63);
this.solvencyLabel24.Name = "solvencyLabel24";
this.solvencyLabel24.OrdinateID_Label = 7085;
this.solvencyLabel24.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel24.TabIndex = 24;
this.solvencyLabel24.Text = "Swiss Confederation; Principality of Lichtenstein" ;
this.solvencyLabel24.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel25
//
this.solvencyLabel25.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel25.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel25.Location = new System.Drawing.Point(285,63);
this.solvencyLabel25.Name = "solvencyLabel25";
this.solvencyLabel25.OrdinateID_Label = 0;
this.solvencyLabel25.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel25.TabIndex = 25;
this.solvencyLabel25.Text = "R1650" ;
this.solvencyLabel25.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel26
//
this.solvencyLabel26.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel26.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel26.Location = new System.Drawing.Point(17,83);
this.solvencyLabel26.Name = "solvencyLabel26";
this.solvencyLabel26.OrdinateID_Label = 7086;
this.solvencyLabel26.Size = new System.Drawing.Size(254, 45);
this.solvencyLabel26.TabIndex = 26;
this.solvencyLabel26.Text = "French Republic [except Guadeloupe, Martinique, the Collectivity of Saint Martin and Réunion]; Principality of Monaco; Principality of Andorra" ;
this.solvencyLabel26.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel27
//
this.solvencyLabel27.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel27.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel27.Location = new System.Drawing.Point(285,83);
this.solvencyLabel27.Name = "solvencyLabel27";
this.solvencyLabel27.OrdinateID_Label = 0;
this.solvencyLabel27.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel27.TabIndex = 27;
this.solvencyLabel27.Text = "R1660" ;
this.solvencyLabel27.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel28
//
this.solvencyLabel28.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel28.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel28.Location = new System.Drawing.Point(17,131);
this.solvencyLabel28.Name = "solvencyLabel28";
this.solvencyLabel28.OrdinateID_Label = 7087;
this.solvencyLabel28.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel28.TabIndex = 28;
this.solvencyLabel28.Text = "Federal Republic of Germany" ;
this.solvencyLabel28.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel29
//
this.solvencyLabel29.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel29.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel29.Location = new System.Drawing.Point(285,131);
this.solvencyLabel29.Name = "solvencyLabel29";
this.solvencyLabel29.OrdinateID_Label = 0;
this.solvencyLabel29.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel29.TabIndex = 29;
this.solvencyLabel29.Text = "R1670" ;
this.solvencyLabel29.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel30
//
this.solvencyLabel30.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel30.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel30.Location = new System.Drawing.Point(17,151);
this.solvencyLabel30.Name = "solvencyLabel30";
this.solvencyLabel30.OrdinateID_Label = 7088;
this.solvencyLabel30.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel30.TabIndex = 30;
this.solvencyLabel30.Text = "Italian Republic; Republic of San Marino; Vatican City State" ;
this.solvencyLabel30.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel31
//
this.solvencyLabel31.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel31.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel31.Location = new System.Drawing.Point(285,151);
this.solvencyLabel31.Name = "solvencyLabel31";
this.solvencyLabel31.OrdinateID_Label = 0;
this.solvencyLabel31.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel31.TabIndex = 31;
this.solvencyLabel31.Text = "R1680" ;
this.solvencyLabel31.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel32
//
this.solvencyLabel32.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel32.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel32.Location = new System.Drawing.Point(17,184);
this.solvencyLabel32.Name = "solvencyLabel32";
this.solvencyLabel32.OrdinateID_Label = 7089;
this.solvencyLabel32.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel32.TabIndex = 32;
this.solvencyLabel32.Text = "Grand Duchy of Luxemburg" ;
this.solvencyLabel32.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel33
//
this.solvencyLabel33.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel33.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel33.Location = new System.Drawing.Point(285,184);
this.solvencyLabel33.Name = "solvencyLabel33";
this.solvencyLabel33.OrdinateID_Label = 0;
this.solvencyLabel33.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel33.TabIndex = 33;
this.solvencyLabel33.Text = "R1690" ;
this.solvencyLabel33.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel34
//
this.solvencyLabel34.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel34.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel34.Location = new System.Drawing.Point(17,204);
this.solvencyLabel34.Name = "solvencyLabel34";
this.solvencyLabel34.OrdinateID_Label = 7090;
this.solvencyLabel34.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel34.TabIndex = 34;
this.solvencyLabel34.Text = "Kingdom of the Netherlands" ;
this.solvencyLabel34.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel35
//
this.solvencyLabel35.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel35.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel35.Location = new System.Drawing.Point(285,204);
this.solvencyLabel35.Name = "solvencyLabel35";
this.solvencyLabel35.OrdinateID_Label = 0;
this.solvencyLabel35.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel35.TabIndex = 35;
this.solvencyLabel35.Text = "R1700" ;
this.solvencyLabel35.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel36
//
this.solvencyLabel36.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel36.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel36.Location = new System.Drawing.Point(17,224);
this.solvencyLabel36.Name = "solvencyLabel36";
this.solvencyLabel36.OrdinateID_Label = 7091;
this.solvencyLabel36.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel36.TabIndex = 36;
this.solvencyLabel36.Text = "Kingdom of Spain" ;
this.solvencyLabel36.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel37
//
this.solvencyLabel37.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel37.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel37.Location = new System.Drawing.Point(285,224);
this.solvencyLabel37.Name = "solvencyLabel37";
this.solvencyLabel37.OrdinateID_Label = 0;
this.solvencyLabel37.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel37.TabIndex = 37;
this.solvencyLabel37.Text = "R1710" ;
this.solvencyLabel37.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel38
//
this.solvencyLabel38.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel38.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel38.Location = new System.Drawing.Point(17,244);
this.solvencyLabel38.Name = "solvencyLabel38";
this.solvencyLabel38.OrdinateID_Label = 7092;
this.solvencyLabel38.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel38.TabIndex = 38;
this.solvencyLabel38.Text = "Total Hail EEA Regions before diversification" ;
this.solvencyLabel38.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel39
//
this.solvencyLabel39.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel39.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel39.Location = new System.Drawing.Point(285,244);
this.solvencyLabel39.Name = "solvencyLabel39";
this.solvencyLabel39.OrdinateID_Label = 0;
this.solvencyLabel39.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel39.TabIndex = 39;
this.solvencyLabel39.Text = "R1720" ;
this.solvencyLabel39.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel40
//
this.solvencyLabel40.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel40.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel40.Location = new System.Drawing.Point(17,264);
this.solvencyLabel40.Name = "solvencyLabel40";
this.solvencyLabel40.OrdinateID_Label = 7093;
this.solvencyLabel40.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel40.TabIndex = 40;
this.solvencyLabel40.Text = "Northern Europe" ;
this.solvencyLabel40.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel41
//
this.solvencyLabel41.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel41.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel41.Location = new System.Drawing.Point(285,264);
this.solvencyLabel41.Name = "solvencyLabel41";
this.solvencyLabel41.OrdinateID_Label = 0;
this.solvencyLabel41.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel41.TabIndex = 41;
this.solvencyLabel41.Text = "R1730" ;
this.solvencyLabel41.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel42
//
this.solvencyLabel42.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel42.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel42.Location = new System.Drawing.Point(17,284);
this.solvencyLabel42.Name = "solvencyLabel42";
this.solvencyLabel42.OrdinateID_Label = 7094;
this.solvencyLabel42.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel42.TabIndex = 42;
this.solvencyLabel42.Text = "Western Europe" ;
this.solvencyLabel42.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel43
//
this.solvencyLabel43.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel43.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel43.Location = new System.Drawing.Point(285,284);
this.solvencyLabel43.Name = "solvencyLabel43";
this.solvencyLabel43.OrdinateID_Label = 0;
this.solvencyLabel43.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel43.TabIndex = 43;
this.solvencyLabel43.Text = "R1740" ;
this.solvencyLabel43.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel44
//
this.solvencyLabel44.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel44.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel44.Location = new System.Drawing.Point(17,304);
this.solvencyLabel44.Name = "solvencyLabel44";
this.solvencyLabel44.OrdinateID_Label = 7095;
this.solvencyLabel44.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel44.TabIndex = 44;
this.solvencyLabel44.Text = "Eastern Europe" ;
this.solvencyLabel44.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel45
//
this.solvencyLabel45.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel45.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel45.Location = new System.Drawing.Point(285,304);
this.solvencyLabel45.Name = "solvencyLabel45";
this.solvencyLabel45.OrdinateID_Label = 0;
this.solvencyLabel45.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel45.TabIndex = 45;
this.solvencyLabel45.Text = "R1750" ;
this.solvencyLabel45.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel46
//
this.solvencyLabel46.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel46.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel46.Location = new System.Drawing.Point(17,324);
this.solvencyLabel46.Name = "solvencyLabel46";
this.solvencyLabel46.OrdinateID_Label = 7096;
this.solvencyLabel46.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel46.TabIndex = 46;
this.solvencyLabel46.Text = "Southern Europe" ;
this.solvencyLabel46.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel47
//
this.solvencyLabel47.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel47.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel47.Location = new System.Drawing.Point(285,324);
this.solvencyLabel47.Name = "solvencyLabel47";
this.solvencyLabel47.OrdinateID_Label = 0;
this.solvencyLabel47.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel47.TabIndex = 47;
this.solvencyLabel47.Text = "R1760" ;
this.solvencyLabel47.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel48
//
this.solvencyLabel48.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel48.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel48.Location = new System.Drawing.Point(17,344);
this.solvencyLabel48.Name = "solvencyLabel48";
this.solvencyLabel48.OrdinateID_Label = 7097;
this.solvencyLabel48.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel48.TabIndex = 48;
this.solvencyLabel48.Text = "Central and Western Asia" ;
this.solvencyLabel48.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel49
//
this.solvencyLabel49.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel49.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel49.Location = new System.Drawing.Point(285,344);
this.solvencyLabel49.Name = "solvencyLabel49";
this.solvencyLabel49.OrdinateID_Label = 0;
this.solvencyLabel49.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel49.TabIndex = 49;
this.solvencyLabel49.Text = "R1770" ;
this.solvencyLabel49.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel50
//
this.solvencyLabel50.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel50.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel50.Location = new System.Drawing.Point(17,364);
this.solvencyLabel50.Name = "solvencyLabel50";
this.solvencyLabel50.OrdinateID_Label = 7098;
this.solvencyLabel50.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel50.TabIndex = 50;
this.solvencyLabel50.Text = "Eastern Asia" ;
this.solvencyLabel50.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel51
//
this.solvencyLabel51.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel51.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel51.Location = new System.Drawing.Point(285,364);
this.solvencyLabel51.Name = "solvencyLabel51";
this.solvencyLabel51.OrdinateID_Label = 0;
this.solvencyLabel51.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel51.TabIndex = 51;
this.solvencyLabel51.Text = "R1780" ;
this.solvencyLabel51.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel52
//
this.solvencyLabel52.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel52.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel52.Location = new System.Drawing.Point(17,384);
this.solvencyLabel52.Name = "solvencyLabel52";
this.solvencyLabel52.OrdinateID_Label = 7099;
this.solvencyLabel52.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel52.TabIndex = 52;
this.solvencyLabel52.Text = "South and South-Eastern Asia" ;
this.solvencyLabel52.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel53
//
this.solvencyLabel53.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel53.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel53.Location = new System.Drawing.Point(285,384);
this.solvencyLabel53.Name = "solvencyLabel53";
this.solvencyLabel53.OrdinateID_Label = 0;
this.solvencyLabel53.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel53.TabIndex = 53;
this.solvencyLabel53.Text = "R1790" ;
this.solvencyLabel53.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel54
//
this.solvencyLabel54.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel54.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel54.Location = new System.Drawing.Point(17,404);
this.solvencyLabel54.Name = "solvencyLabel54";
this.solvencyLabel54.OrdinateID_Label = 7100;
this.solvencyLabel54.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel54.TabIndex = 54;
this.solvencyLabel54.Text = "Oceania" ;
this.solvencyLabel54.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel55
//
this.solvencyLabel55.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel55.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel55.Location = new System.Drawing.Point(285,404);
this.solvencyLabel55.Name = "solvencyLabel55";
this.solvencyLabel55.OrdinateID_Label = 0;
this.solvencyLabel55.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel55.TabIndex = 55;
this.solvencyLabel55.Text = "R1800" ;
this.solvencyLabel55.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel56
//
this.solvencyLabel56.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel56.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel56.Location = new System.Drawing.Point(17,424);
this.solvencyLabel56.Name = "solvencyLabel56";
this.solvencyLabel56.OrdinateID_Label = 7101;
this.solvencyLabel56.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel56.TabIndex = 56;
this.solvencyLabel56.Text = "Northern Africa" ;
this.solvencyLabel56.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel57
//
this.solvencyLabel57.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel57.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel57.Location = new System.Drawing.Point(285,424);
this.solvencyLabel57.Name = "solvencyLabel57";
this.solvencyLabel57.OrdinateID_Label = 0;
this.solvencyLabel57.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel57.TabIndex = 57;
this.solvencyLabel57.Text = "R1810" ;
this.solvencyLabel57.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel58
//
this.solvencyLabel58.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel58.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel58.Location = new System.Drawing.Point(17,444);
this.solvencyLabel58.Name = "solvencyLabel58";
this.solvencyLabel58.OrdinateID_Label = 7102;
this.solvencyLabel58.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel58.TabIndex = 58;
this.solvencyLabel58.Text = "Southern Africa" ;
this.solvencyLabel58.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel59
//
this.solvencyLabel59.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel59.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel59.Location = new System.Drawing.Point(285,444);
this.solvencyLabel59.Name = "solvencyLabel59";
this.solvencyLabel59.OrdinateID_Label = 0;
this.solvencyLabel59.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel59.TabIndex = 59;
this.solvencyLabel59.Text = "R1820" ;
this.solvencyLabel59.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel60
//
this.solvencyLabel60.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel60.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel60.Location = new System.Drawing.Point(17,464);
this.solvencyLabel60.Name = "solvencyLabel60";
this.solvencyLabel60.OrdinateID_Label = 7103;
this.solvencyLabel60.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel60.TabIndex = 60;
this.solvencyLabel60.Text = "Northern America excluding the United States of America" ;
this.solvencyLabel60.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel61
//
this.solvencyLabel61.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel61.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel61.Location = new System.Drawing.Point(285,464);
this.solvencyLabel61.Name = "solvencyLabel61";
this.solvencyLabel61.OrdinateID_Label = 0;
this.solvencyLabel61.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel61.TabIndex = 61;
this.solvencyLabel61.Text = "R1830" ;
this.solvencyLabel61.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel62
//
this.solvencyLabel62.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel62.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel62.Location = new System.Drawing.Point(17,497);
this.solvencyLabel62.Name = "solvencyLabel62";
this.solvencyLabel62.OrdinateID_Label = 7104;
this.solvencyLabel62.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel62.TabIndex = 62;
this.solvencyLabel62.Text = "Caribbean and Central America" ;
this.solvencyLabel62.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel63
//
this.solvencyLabel63.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel63.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel63.Location = new System.Drawing.Point(285,497);
this.solvencyLabel63.Name = "solvencyLabel63";
this.solvencyLabel63.OrdinateID_Label = 0;
this.solvencyLabel63.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel63.TabIndex = 63;
this.solvencyLabel63.Text = "R1840" ;
this.solvencyLabel63.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel64
//
this.solvencyLabel64.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel64.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel64.Location = new System.Drawing.Point(17,517);
this.solvencyLabel64.Name = "solvencyLabel64";
this.solvencyLabel64.OrdinateID_Label = 7105;
this.solvencyLabel64.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel64.TabIndex = 64;
this.solvencyLabel64.Text = "Eastern South America" ;
this.solvencyLabel64.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel65
//
this.solvencyLabel65.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel65.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel65.Location = new System.Drawing.Point(285,517);
this.solvencyLabel65.Name = "solvencyLabel65";
this.solvencyLabel65.OrdinateID_Label = 0;
this.solvencyLabel65.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel65.TabIndex = 65;
this.solvencyLabel65.Text = "R1850" ;
this.solvencyLabel65.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel66
//
this.solvencyLabel66.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel66.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel66.Location = new System.Drawing.Point(17,537);
this.solvencyLabel66.Name = "solvencyLabel66";
this.solvencyLabel66.OrdinateID_Label = 7106;
this.solvencyLabel66.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel66.TabIndex = 66;
this.solvencyLabel66.Text = "Northern, southern and western South America" ;
this.solvencyLabel66.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel67
//
this.solvencyLabel67.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel67.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel67.Location = new System.Drawing.Point(285,537);
this.solvencyLabel67.Name = "solvencyLabel67";
this.solvencyLabel67.OrdinateID_Label = 0;
this.solvencyLabel67.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel67.TabIndex = 67;
this.solvencyLabel67.Text = "R1860" ;
this.solvencyLabel67.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel68
//
this.solvencyLabel68.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel68.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel68.Location = new System.Drawing.Point(17,557);
this.solvencyLabel68.Name = "solvencyLabel68";
this.solvencyLabel68.OrdinateID_Label = 7107;
this.solvencyLabel68.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel68.TabIndex = 68;
this.solvencyLabel68.Text = "North-east United States of America" ;
this.solvencyLabel68.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel69
//
this.solvencyLabel69.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel69.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel69.Location = new System.Drawing.Point(285,557);
this.solvencyLabel69.Name = "solvencyLabel69";
this.solvencyLabel69.OrdinateID_Label = 0;
this.solvencyLabel69.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel69.TabIndex = 69;
this.solvencyLabel69.Text = "R1870" ;
this.solvencyLabel69.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel70
//
this.solvencyLabel70.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel70.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel70.Location = new System.Drawing.Point(17,577);
this.solvencyLabel70.Name = "solvencyLabel70";
this.solvencyLabel70.OrdinateID_Label = 7108;
this.solvencyLabel70.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel70.TabIndex = 70;
this.solvencyLabel70.Text = "South-east United States of America" ;
this.solvencyLabel70.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel71
//
this.solvencyLabel71.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel71.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel71.Location = new System.Drawing.Point(285,577);
this.solvencyLabel71.Name = "solvencyLabel71";
this.solvencyLabel71.OrdinateID_Label = 0;
this.solvencyLabel71.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel71.TabIndex = 71;
this.solvencyLabel71.Text = "R1880" ;
this.solvencyLabel71.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel72
//
this.solvencyLabel72.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel72.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel72.Location = new System.Drawing.Point(17,597);
this.solvencyLabel72.Name = "solvencyLabel72";
this.solvencyLabel72.OrdinateID_Label = 7109;
this.solvencyLabel72.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel72.TabIndex = 72;
this.solvencyLabel72.Text = "Mid-west United States of America" ;
this.solvencyLabel72.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel73
//
this.solvencyLabel73.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel73.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel73.Location = new System.Drawing.Point(285,597);
this.solvencyLabel73.Name = "solvencyLabel73";
this.solvencyLabel73.OrdinateID_Label = 0;
this.solvencyLabel73.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel73.TabIndex = 73;
this.solvencyLabel73.Text = "R1890" ;
this.solvencyLabel73.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel74
//
this.solvencyLabel74.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel74.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel74.Location = new System.Drawing.Point(17,617);
this.solvencyLabel74.Name = "solvencyLabel74";
this.solvencyLabel74.OrdinateID_Label = 7110;
this.solvencyLabel74.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel74.TabIndex = 74;
this.solvencyLabel74.Text = "Western United States of America" ;
this.solvencyLabel74.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel75
//
this.solvencyLabel75.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel75.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel75.Location = new System.Drawing.Point(285,617);
this.solvencyLabel75.Name = "solvencyLabel75";
this.solvencyLabel75.OrdinateID_Label = 0;
this.solvencyLabel75.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel75.TabIndex = 75;
this.solvencyLabel75.Text = "R1900" ;
this.solvencyLabel75.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel76
//
this.solvencyLabel76.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel76.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel76.Location = new System.Drawing.Point(17,637);
this.solvencyLabel76.Name = "solvencyLabel76";
this.solvencyLabel76.OrdinateID_Label = 7111;
this.solvencyLabel76.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel76.TabIndex = 76;
this.solvencyLabel76.Text = "Total Hail Other Regions before diversifications" ;
this.solvencyLabel76.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel77
//
this.solvencyLabel77.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel77.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel77.Location = new System.Drawing.Point(285,637);
this.solvencyLabel77.Name = "solvencyLabel77";
this.solvencyLabel77.OrdinateID_Label = 0;
this.solvencyLabel77.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel77.TabIndex = 77;
this.solvencyLabel77.Text = "R1910" ;
this.solvencyLabel77.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel78
//
this.solvencyLabel78.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel78.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel78.Location = new System.Drawing.Point(17,657);
this.solvencyLabel78.Name = "solvencyLabel78";
this.solvencyLabel78.OrdinateID_Label = 7112;
this.solvencyLabel78.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel78.TabIndex = 78;
this.solvencyLabel78.Text = "Total Hail all Regions before diversification" ;
this.solvencyLabel78.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel79
//
this.solvencyLabel79.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel79.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel79.Location = new System.Drawing.Point(285,657);
this.solvencyLabel79.Name = "solvencyLabel79";
this.solvencyLabel79.OrdinateID_Label = 0;
this.solvencyLabel79.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel79.TabIndex = 79;
this.solvencyLabel79.Text = "R1920" ;
this.solvencyLabel79.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel80
//
this.solvencyLabel80.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel80.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel80.Location = new System.Drawing.Point(17,677);
this.solvencyLabel80.Name = "solvencyLabel80";
this.solvencyLabel80.OrdinateID_Label = 7113;
this.solvencyLabel80.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel80.TabIndex = 80;
this.solvencyLabel80.Text = "Diversification effect between regions" ;
this.solvencyLabel80.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel81
//
this.solvencyLabel81.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel81.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel81.Location = new System.Drawing.Point(285,677);
this.solvencyLabel81.Name = "solvencyLabel81";
this.solvencyLabel81.OrdinateID_Label = 0;
this.solvencyLabel81.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel81.TabIndex = 81;
this.solvencyLabel81.Text = "R1930" ;
this.solvencyLabel81.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel82
//
this.solvencyLabel82.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel82.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel82.Location = new System.Drawing.Point(17,697);
this.solvencyLabel82.Name = "solvencyLabel82";
this.solvencyLabel82.OrdinateID_Label = 7114;
this.solvencyLabel82.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel82.TabIndex = 82;
this.solvencyLabel82.Text = "Total Hail after diversification" ;
this.solvencyLabel82.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel83
//
this.solvencyLabel83.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel83.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel83.Location = new System.Drawing.Point(285,697);
this.solvencyLabel83.Name = "solvencyLabel83";
this.solvencyLabel83.OrdinateID_Label = 0;
this.solvencyLabel83.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel83.TabIndex = 83;
this.solvencyLabel83.Text = "R1940" ;
this.solvencyLabel83.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel84
//
this.solvencyLabel84.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel84.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel84.Location = new System.Drawing.Point(285,717);
this.solvencyLabel84.Name = "solvencyLabel84";
this.solvencyLabel84.OrdinateID_Label = 0;
this.solvencyLabel84.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel84.TabIndex = 84;
this.solvencyLabel84.Text = "." ;
this.solvencyLabel84.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyCurrencyTextBox85
//
this.solvencyCurrencyTextBox85.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox85.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox85.Location = new System.Drawing.Point(10,23);
this.solvencyCurrencyTextBox85.Name = "solvencyCurrencyTextBox85";
this.solvencyCurrencyTextBox85.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox85.TabIndex = 85;
this.solvencyCurrencyTextBox85.ColName = "R1630C0300";
this.solvencyCurrencyTextBox85.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox85.Enabled = false;
this.solvencyCurrencyTextBox85.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox86
//
this.solvencyCurrencyTextBox86.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox86.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox86.Location = new System.Drawing.Point(117,23);
this.solvencyCurrencyTextBox86.Name = "solvencyCurrencyTextBox86";
this.solvencyCurrencyTextBox86.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox86.TabIndex = 86;
this.solvencyCurrencyTextBox86.ColName = "R1630C0310";
this.solvencyCurrencyTextBox86.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox87
//
this.solvencyCurrencyTextBox87.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox87.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox87.Location = new System.Drawing.Point(224,23);
this.solvencyCurrencyTextBox87.Name = "solvencyCurrencyTextBox87";
this.solvencyCurrencyTextBox87.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox87.TabIndex = 87;
this.solvencyCurrencyTextBox87.ColName = "R1630C0320";
this.solvencyCurrencyTextBox87.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox88
//
this.solvencyCurrencyTextBox88.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox88.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox88.Location = new System.Drawing.Point(331,23);
this.solvencyCurrencyTextBox88.Name = "solvencyCurrencyTextBox88";
this.solvencyCurrencyTextBox88.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox88.TabIndex = 88;
this.solvencyCurrencyTextBox88.ColName = "R1630C0330";
this.solvencyCurrencyTextBox88.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// SolvencyDataComboBox89
//
this.SolvencyDataComboBox89.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox89.Location = new System.Drawing.Point(438,23);
this.SolvencyDataComboBox89.Name = "SolvencyDataComboBox89";
this.SolvencyDataComboBox89.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox89.TabIndex = 89;
this.SolvencyDataComboBox89.ColName = "R1630C0340";
this.SolvencyDataComboBox89.AxisID = 1321;
this.SolvencyDataComboBox89.OrdinateID = 7077;
this.SolvencyDataComboBox89.StartOrder = 0;
this.SolvencyDataComboBox89.NextOrder = 0;
//
// solvencyCurrencyTextBox90
//
this.solvencyCurrencyTextBox90.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox90.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox90.Location = new System.Drawing.Point(645,23);
this.solvencyCurrencyTextBox90.Name = "solvencyCurrencyTextBox90";
this.solvencyCurrencyTextBox90.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox90.TabIndex = 90;
this.solvencyCurrencyTextBox90.ColName = "R1630C0350";
this.solvencyCurrencyTextBox90.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox91
//
this.solvencyCurrencyTextBox91.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox91.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox91.Location = new System.Drawing.Point(752,23);
this.solvencyCurrencyTextBox91.Name = "solvencyCurrencyTextBox91";
this.solvencyCurrencyTextBox91.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox91.TabIndex = 91;
this.solvencyCurrencyTextBox91.ColName = "R1630C0360";
this.solvencyCurrencyTextBox91.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox92
//
this.solvencyCurrencyTextBox92.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox92.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox92.Location = new System.Drawing.Point(859,23);
this.solvencyCurrencyTextBox92.Name = "solvencyCurrencyTextBox92";
this.solvencyCurrencyTextBox92.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox92.TabIndex = 92;
this.solvencyCurrencyTextBox92.ColName = "R1630C0370";
this.solvencyCurrencyTextBox92.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox93
//
this.solvencyCurrencyTextBox93.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox93.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox93.Location = new System.Drawing.Point(966,23);
this.solvencyCurrencyTextBox93.Name = "solvencyCurrencyTextBox93";
this.solvencyCurrencyTextBox93.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox93.TabIndex = 93;
this.solvencyCurrencyTextBox93.ColName = "R1630C0380";
this.solvencyCurrencyTextBox93.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox94
//
this.solvencyCurrencyTextBox94.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox94.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox94.Location = new System.Drawing.Point(10,43);
this.solvencyCurrencyTextBox94.Name = "solvencyCurrencyTextBox94";
this.solvencyCurrencyTextBox94.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox94.TabIndex = 94;
this.solvencyCurrencyTextBox94.ColName = "R1640C0300";
this.solvencyCurrencyTextBox94.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox94.Enabled = false;
this.solvencyCurrencyTextBox94.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox95
//
this.solvencyCurrencyTextBox95.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox95.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox95.Location = new System.Drawing.Point(117,43);
this.solvencyCurrencyTextBox95.Name = "solvencyCurrencyTextBox95";
this.solvencyCurrencyTextBox95.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox95.TabIndex = 95;
this.solvencyCurrencyTextBox95.ColName = "R1640C0310";
this.solvencyCurrencyTextBox95.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox96
//
this.solvencyCurrencyTextBox96.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox96.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox96.Location = new System.Drawing.Point(224,43);
this.solvencyCurrencyTextBox96.Name = "solvencyCurrencyTextBox96";
this.solvencyCurrencyTextBox96.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox96.TabIndex = 96;
this.solvencyCurrencyTextBox96.ColName = "R1640C0320";
this.solvencyCurrencyTextBox96.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox97
//
this.solvencyCurrencyTextBox97.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox97.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox97.Location = new System.Drawing.Point(331,43);
this.solvencyCurrencyTextBox97.Name = "solvencyCurrencyTextBox97";
this.solvencyCurrencyTextBox97.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox97.TabIndex = 97;
this.solvencyCurrencyTextBox97.ColName = "R1640C0330";
this.solvencyCurrencyTextBox97.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// SolvencyDataComboBox98
//
this.SolvencyDataComboBox98.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox98.Location = new System.Drawing.Point(438,43);
this.SolvencyDataComboBox98.Name = "SolvencyDataComboBox98";
this.SolvencyDataComboBox98.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox98.TabIndex = 98;
this.SolvencyDataComboBox98.ColName = "R1640C0340";
this.SolvencyDataComboBox98.AxisID = 1321;
this.SolvencyDataComboBox98.OrdinateID = 7077;
this.SolvencyDataComboBox98.StartOrder = 0;
this.SolvencyDataComboBox98.NextOrder = 0;
//
// solvencyCurrencyTextBox99
//
this.solvencyCurrencyTextBox99.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox99.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox99.Location = new System.Drawing.Point(645,43);
this.solvencyCurrencyTextBox99.Name = "solvencyCurrencyTextBox99";
this.solvencyCurrencyTextBox99.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox99.TabIndex = 99;
this.solvencyCurrencyTextBox99.ColName = "R1640C0350";
this.solvencyCurrencyTextBox99.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox100
//
this.solvencyCurrencyTextBox100.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox100.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox100.Location = new System.Drawing.Point(752,43);
this.solvencyCurrencyTextBox100.Name = "solvencyCurrencyTextBox100";
this.solvencyCurrencyTextBox100.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox100.TabIndex = 100;
this.solvencyCurrencyTextBox100.ColName = "R1640C0360";
this.solvencyCurrencyTextBox100.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox101
//
this.solvencyCurrencyTextBox101.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox101.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox101.Location = new System.Drawing.Point(859,43);
this.solvencyCurrencyTextBox101.Name = "solvencyCurrencyTextBox101";
this.solvencyCurrencyTextBox101.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox101.TabIndex = 101;
this.solvencyCurrencyTextBox101.ColName = "R1640C0370";
this.solvencyCurrencyTextBox101.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox102
//
this.solvencyCurrencyTextBox102.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox102.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox102.Location = new System.Drawing.Point(966,43);
this.solvencyCurrencyTextBox102.Name = "solvencyCurrencyTextBox102";
this.solvencyCurrencyTextBox102.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox102.TabIndex = 102;
this.solvencyCurrencyTextBox102.ColName = "R1640C0380";
this.solvencyCurrencyTextBox102.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox103
//
this.solvencyCurrencyTextBox103.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox103.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox103.Location = new System.Drawing.Point(10,63);
this.solvencyCurrencyTextBox103.Name = "solvencyCurrencyTextBox103";
this.solvencyCurrencyTextBox103.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox103.TabIndex = 103;
this.solvencyCurrencyTextBox103.ColName = "R1650C0300";
this.solvencyCurrencyTextBox103.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox103.Enabled = false;
this.solvencyCurrencyTextBox103.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox104
//
this.solvencyCurrencyTextBox104.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox104.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox104.Location = new System.Drawing.Point(117,63);
this.solvencyCurrencyTextBox104.Name = "solvencyCurrencyTextBox104";
this.solvencyCurrencyTextBox104.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox104.TabIndex = 104;
this.solvencyCurrencyTextBox104.ColName = "R1650C0310";
this.solvencyCurrencyTextBox104.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox105
//
this.solvencyCurrencyTextBox105.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox105.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox105.Location = new System.Drawing.Point(224,63);
this.solvencyCurrencyTextBox105.Name = "solvencyCurrencyTextBox105";
this.solvencyCurrencyTextBox105.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox105.TabIndex = 105;
this.solvencyCurrencyTextBox105.ColName = "R1650C0320";
this.solvencyCurrencyTextBox105.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox106
//
this.solvencyCurrencyTextBox106.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox106.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox106.Location = new System.Drawing.Point(331,63);
this.solvencyCurrencyTextBox106.Name = "solvencyCurrencyTextBox106";
this.solvencyCurrencyTextBox106.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox106.TabIndex = 106;
this.solvencyCurrencyTextBox106.ColName = "R1650C0330";
this.solvencyCurrencyTextBox106.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// SolvencyDataComboBox107
//
this.SolvencyDataComboBox107.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox107.Location = new System.Drawing.Point(438,63);
this.SolvencyDataComboBox107.Name = "SolvencyDataComboBox107";
this.SolvencyDataComboBox107.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox107.TabIndex = 107;
this.SolvencyDataComboBox107.ColName = "R1650C0340";
this.SolvencyDataComboBox107.AxisID = 1321;
this.SolvencyDataComboBox107.OrdinateID = 7077;
this.SolvencyDataComboBox107.StartOrder = 0;
this.SolvencyDataComboBox107.NextOrder = 0;
//
// solvencyCurrencyTextBox108
//
this.solvencyCurrencyTextBox108.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox108.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox108.Location = new System.Drawing.Point(645,63);
this.solvencyCurrencyTextBox108.Name = "solvencyCurrencyTextBox108";
this.solvencyCurrencyTextBox108.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox108.TabIndex = 108;
this.solvencyCurrencyTextBox108.ColName = "R1650C0350";
this.solvencyCurrencyTextBox108.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox109
//
this.solvencyCurrencyTextBox109.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox109.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox109.Location = new System.Drawing.Point(752,63);
this.solvencyCurrencyTextBox109.Name = "solvencyCurrencyTextBox109";
this.solvencyCurrencyTextBox109.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox109.TabIndex = 109;
this.solvencyCurrencyTextBox109.ColName = "R1650C0360";
this.solvencyCurrencyTextBox109.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox110
//
this.solvencyCurrencyTextBox110.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox110.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox110.Location = new System.Drawing.Point(859,63);
this.solvencyCurrencyTextBox110.Name = "solvencyCurrencyTextBox110";
this.solvencyCurrencyTextBox110.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox110.TabIndex = 110;
this.solvencyCurrencyTextBox110.ColName = "R1650C0370";
this.solvencyCurrencyTextBox110.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox111
//
this.solvencyCurrencyTextBox111.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox111.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox111.Location = new System.Drawing.Point(966,63);
this.solvencyCurrencyTextBox111.Name = "solvencyCurrencyTextBox111";
this.solvencyCurrencyTextBox111.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox111.TabIndex = 111;
this.solvencyCurrencyTextBox111.ColName = "R1650C0380";
this.solvencyCurrencyTextBox111.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox112
//
this.solvencyCurrencyTextBox112.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox112.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox112.Location = new System.Drawing.Point(10,83);
this.solvencyCurrencyTextBox112.Name = "solvencyCurrencyTextBox112";
this.solvencyCurrencyTextBox112.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox112.TabIndex = 112;
this.solvencyCurrencyTextBox112.ColName = "R1660C0300";
this.solvencyCurrencyTextBox112.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox112.Enabled = false;
this.solvencyCurrencyTextBox112.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox113
//
this.solvencyCurrencyTextBox113.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox113.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox113.Location = new System.Drawing.Point(117,83);
this.solvencyCurrencyTextBox113.Name = "solvencyCurrencyTextBox113";
this.solvencyCurrencyTextBox113.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox113.TabIndex = 113;
this.solvencyCurrencyTextBox113.ColName = "R1660C0310";
this.solvencyCurrencyTextBox113.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox114
//
this.solvencyCurrencyTextBox114.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox114.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox114.Location = new System.Drawing.Point(224,83);
this.solvencyCurrencyTextBox114.Name = "solvencyCurrencyTextBox114";
this.solvencyCurrencyTextBox114.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox114.TabIndex = 114;
this.solvencyCurrencyTextBox114.ColName = "R1660C0320";
this.solvencyCurrencyTextBox114.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox115
//
this.solvencyCurrencyTextBox115.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox115.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox115.Location = new System.Drawing.Point(331,83);
this.solvencyCurrencyTextBox115.Name = "solvencyCurrencyTextBox115";
this.solvencyCurrencyTextBox115.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox115.TabIndex = 115;
this.solvencyCurrencyTextBox115.ColName = "R1660C0330";
this.solvencyCurrencyTextBox115.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// SolvencyDataComboBox116
//
this.SolvencyDataComboBox116.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox116.Location = new System.Drawing.Point(438,83);
this.SolvencyDataComboBox116.Name = "SolvencyDataComboBox116";
this.SolvencyDataComboBox116.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox116.TabIndex = 116;
this.SolvencyDataComboBox116.ColName = "R1660C0340";
this.SolvencyDataComboBox116.AxisID = 1321;
this.SolvencyDataComboBox116.OrdinateID = 7077;
this.SolvencyDataComboBox116.StartOrder = 0;
this.SolvencyDataComboBox116.NextOrder = 0;
//
// solvencyCurrencyTextBox117
//
this.solvencyCurrencyTextBox117.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox117.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox117.Location = new System.Drawing.Point(645,83);
this.solvencyCurrencyTextBox117.Name = "solvencyCurrencyTextBox117";
this.solvencyCurrencyTextBox117.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox117.TabIndex = 117;
this.solvencyCurrencyTextBox117.ColName = "R1660C0350";
this.solvencyCurrencyTextBox117.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox118
//
this.solvencyCurrencyTextBox118.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox118.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox118.Location = new System.Drawing.Point(752,83);
this.solvencyCurrencyTextBox118.Name = "solvencyCurrencyTextBox118";
this.solvencyCurrencyTextBox118.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox118.TabIndex = 118;
this.solvencyCurrencyTextBox118.ColName = "R1660C0360";
this.solvencyCurrencyTextBox118.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox119
//
this.solvencyCurrencyTextBox119.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox119.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox119.Location = new System.Drawing.Point(859,83);
this.solvencyCurrencyTextBox119.Name = "solvencyCurrencyTextBox119";
this.solvencyCurrencyTextBox119.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox119.TabIndex = 119;
this.solvencyCurrencyTextBox119.ColName = "R1660C0370";
this.solvencyCurrencyTextBox119.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox120
//
this.solvencyCurrencyTextBox120.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox120.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox120.Location = new System.Drawing.Point(966,83);
this.solvencyCurrencyTextBox120.Name = "solvencyCurrencyTextBox120";
this.solvencyCurrencyTextBox120.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox120.TabIndex = 120;
this.solvencyCurrencyTextBox120.ColName = "R1660C0380";
this.solvencyCurrencyTextBox120.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox121
//
this.solvencyCurrencyTextBox121.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox121.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox121.Location = new System.Drawing.Point(10,131);
this.solvencyCurrencyTextBox121.Name = "solvencyCurrencyTextBox121";
this.solvencyCurrencyTextBox121.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox121.TabIndex = 121;
this.solvencyCurrencyTextBox121.ColName = "R1670C0300";
this.solvencyCurrencyTextBox121.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox121.Enabled = false;
this.solvencyCurrencyTextBox121.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox122
//
this.solvencyCurrencyTextBox122.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox122.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox122.Location = new System.Drawing.Point(117,131);
this.solvencyCurrencyTextBox122.Name = "solvencyCurrencyTextBox122";
this.solvencyCurrencyTextBox122.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox122.TabIndex = 122;
this.solvencyCurrencyTextBox122.ColName = "R1670C0310";
this.solvencyCurrencyTextBox122.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox123
//
this.solvencyCurrencyTextBox123.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox123.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox123.Location = new System.Drawing.Point(224,131);
this.solvencyCurrencyTextBox123.Name = "solvencyCurrencyTextBox123";
this.solvencyCurrencyTextBox123.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox123.TabIndex = 123;
this.solvencyCurrencyTextBox123.ColName = "R1670C0320";
this.solvencyCurrencyTextBox123.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox124
//
this.solvencyCurrencyTextBox124.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox124.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox124.Location = new System.Drawing.Point(331,131);
this.solvencyCurrencyTextBox124.Name = "solvencyCurrencyTextBox124";
this.solvencyCurrencyTextBox124.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox124.TabIndex = 124;
this.solvencyCurrencyTextBox124.ColName = "R1670C0330";
this.solvencyCurrencyTextBox124.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// SolvencyDataComboBox125
//
this.SolvencyDataComboBox125.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox125.Location = new System.Drawing.Point(438,131);
this.SolvencyDataComboBox125.Name = "SolvencyDataComboBox125";
this.SolvencyDataComboBox125.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox125.TabIndex = 125;
this.SolvencyDataComboBox125.ColName = "R1670C0340";
this.SolvencyDataComboBox125.AxisID = 1321;
this.SolvencyDataComboBox125.OrdinateID = 7077;
this.SolvencyDataComboBox125.StartOrder = 0;
this.SolvencyDataComboBox125.NextOrder = 0;
//
// solvencyCurrencyTextBox126
//
this.solvencyCurrencyTextBox126.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox126.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox126.Location = new System.Drawing.Point(645,131);
this.solvencyCurrencyTextBox126.Name = "solvencyCurrencyTextBox126";
this.solvencyCurrencyTextBox126.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox126.TabIndex = 126;
this.solvencyCurrencyTextBox126.ColName = "R1670C0350";
this.solvencyCurrencyTextBox126.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox127
//
this.solvencyCurrencyTextBox127.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox127.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox127.Location = new System.Drawing.Point(752,131);
this.solvencyCurrencyTextBox127.Name = "solvencyCurrencyTextBox127";
this.solvencyCurrencyTextBox127.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox127.TabIndex = 127;
this.solvencyCurrencyTextBox127.ColName = "R1670C0360";
this.solvencyCurrencyTextBox127.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox128
//
this.solvencyCurrencyTextBox128.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox128.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox128.Location = new System.Drawing.Point(859,131);
this.solvencyCurrencyTextBox128.Name = "solvencyCurrencyTextBox128";
this.solvencyCurrencyTextBox128.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox128.TabIndex = 128;
this.solvencyCurrencyTextBox128.ColName = "R1670C0370";
this.solvencyCurrencyTextBox128.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox129
//
this.solvencyCurrencyTextBox129.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox129.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox129.Location = new System.Drawing.Point(966,131);
this.solvencyCurrencyTextBox129.Name = "solvencyCurrencyTextBox129";
this.solvencyCurrencyTextBox129.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox129.TabIndex = 129;
this.solvencyCurrencyTextBox129.ColName = "R1670C0380";
this.solvencyCurrencyTextBox129.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox130
//
this.solvencyCurrencyTextBox130.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox130.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox130.Location = new System.Drawing.Point(10,151);
this.solvencyCurrencyTextBox130.Name = "solvencyCurrencyTextBox130";
this.solvencyCurrencyTextBox130.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox130.TabIndex = 130;
this.solvencyCurrencyTextBox130.ColName = "R1680C0300";
this.solvencyCurrencyTextBox130.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox130.Enabled = false;
this.solvencyCurrencyTextBox130.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox131
//
this.solvencyCurrencyTextBox131.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox131.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox131.Location = new System.Drawing.Point(117,151);
this.solvencyCurrencyTextBox131.Name = "solvencyCurrencyTextBox131";
this.solvencyCurrencyTextBox131.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox131.TabIndex = 131;
this.solvencyCurrencyTextBox131.ColName = "R1680C0310";
this.solvencyCurrencyTextBox131.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox132
//
this.solvencyCurrencyTextBox132.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox132.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox132.Location = new System.Drawing.Point(224,151);
this.solvencyCurrencyTextBox132.Name = "solvencyCurrencyTextBox132";
this.solvencyCurrencyTextBox132.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox132.TabIndex = 132;
this.solvencyCurrencyTextBox132.ColName = "R1680C0320";
this.solvencyCurrencyTextBox132.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox133
//
this.solvencyCurrencyTextBox133.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox133.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox133.Location = new System.Drawing.Point(331,151);
this.solvencyCurrencyTextBox133.Name = "solvencyCurrencyTextBox133";
this.solvencyCurrencyTextBox133.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox133.TabIndex = 133;
this.solvencyCurrencyTextBox133.ColName = "R1680C0330";
this.solvencyCurrencyTextBox133.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// SolvencyDataComboBox134
//
this.SolvencyDataComboBox134.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox134.Location = new System.Drawing.Point(438,151);
this.SolvencyDataComboBox134.Name = "SolvencyDataComboBox134";
this.SolvencyDataComboBox134.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox134.TabIndex = 134;
this.SolvencyDataComboBox134.ColName = "R1680C0340";
this.SolvencyDataComboBox134.AxisID = 1321;
this.SolvencyDataComboBox134.OrdinateID = 7077;
this.SolvencyDataComboBox134.StartOrder = 0;
this.SolvencyDataComboBox134.NextOrder = 0;
//
// solvencyCurrencyTextBox135
//
this.solvencyCurrencyTextBox135.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox135.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox135.Location = new System.Drawing.Point(645,151);
this.solvencyCurrencyTextBox135.Name = "solvencyCurrencyTextBox135";
this.solvencyCurrencyTextBox135.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox135.TabIndex = 135;
this.solvencyCurrencyTextBox135.ColName = "R1680C0350";
this.solvencyCurrencyTextBox135.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox136
//
this.solvencyCurrencyTextBox136.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox136.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox136.Location = new System.Drawing.Point(752,151);
this.solvencyCurrencyTextBox136.Name = "solvencyCurrencyTextBox136";
this.solvencyCurrencyTextBox136.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox136.TabIndex = 136;
this.solvencyCurrencyTextBox136.ColName = "R1680C0360";
this.solvencyCurrencyTextBox136.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox137
//
this.solvencyCurrencyTextBox137.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox137.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox137.Location = new System.Drawing.Point(859,151);
this.solvencyCurrencyTextBox137.Name = "solvencyCurrencyTextBox137";
this.solvencyCurrencyTextBox137.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox137.TabIndex = 137;
this.solvencyCurrencyTextBox137.ColName = "R1680C0370";
this.solvencyCurrencyTextBox137.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox138
//
this.solvencyCurrencyTextBox138.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox138.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox138.Location = new System.Drawing.Point(966,151);
this.solvencyCurrencyTextBox138.Name = "solvencyCurrencyTextBox138";
this.solvencyCurrencyTextBox138.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox138.TabIndex = 138;
this.solvencyCurrencyTextBox138.ColName = "R1680C0380";
this.solvencyCurrencyTextBox138.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox139
//
this.solvencyCurrencyTextBox139.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox139.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox139.Location = new System.Drawing.Point(10,184);
this.solvencyCurrencyTextBox139.Name = "solvencyCurrencyTextBox139";
this.solvencyCurrencyTextBox139.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox139.TabIndex = 139;
this.solvencyCurrencyTextBox139.ColName = "R1690C0300";
this.solvencyCurrencyTextBox139.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox139.Enabled = false;
this.solvencyCurrencyTextBox139.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox140
//
this.solvencyCurrencyTextBox140.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox140.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox140.Location = new System.Drawing.Point(117,184);
this.solvencyCurrencyTextBox140.Name = "solvencyCurrencyTextBox140";
this.solvencyCurrencyTextBox140.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox140.TabIndex = 140;
this.solvencyCurrencyTextBox140.ColName = "R1690C0310";
this.solvencyCurrencyTextBox140.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox141
//
this.solvencyCurrencyTextBox141.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox141.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox141.Location = new System.Drawing.Point(224,184);
this.solvencyCurrencyTextBox141.Name = "solvencyCurrencyTextBox141";
this.solvencyCurrencyTextBox141.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox141.TabIndex = 141;
this.solvencyCurrencyTextBox141.ColName = "R1690C0320";
this.solvencyCurrencyTextBox141.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox142
//
this.solvencyCurrencyTextBox142.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox142.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox142.Location = new System.Drawing.Point(331,184);
this.solvencyCurrencyTextBox142.Name = "solvencyCurrencyTextBox142";
this.solvencyCurrencyTextBox142.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox142.TabIndex = 142;
this.solvencyCurrencyTextBox142.ColName = "R1690C0330";
this.solvencyCurrencyTextBox142.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// SolvencyDataComboBox143
//
this.SolvencyDataComboBox143.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox143.Location = new System.Drawing.Point(438,184);
this.SolvencyDataComboBox143.Name = "SolvencyDataComboBox143";
this.SolvencyDataComboBox143.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox143.TabIndex = 143;
this.SolvencyDataComboBox143.ColName = "R1690C0340";
this.SolvencyDataComboBox143.AxisID = 1321;
this.SolvencyDataComboBox143.OrdinateID = 7077;
this.SolvencyDataComboBox143.StartOrder = 0;
this.SolvencyDataComboBox143.NextOrder = 0;
//
// solvencyCurrencyTextBox144
//
this.solvencyCurrencyTextBox144.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox144.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox144.Location = new System.Drawing.Point(645,184);
this.solvencyCurrencyTextBox144.Name = "solvencyCurrencyTextBox144";
this.solvencyCurrencyTextBox144.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox144.TabIndex = 144;
this.solvencyCurrencyTextBox144.ColName = "R1690C0350";
this.solvencyCurrencyTextBox144.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox145
//
this.solvencyCurrencyTextBox145.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox145.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox145.Location = new System.Drawing.Point(752,184);
this.solvencyCurrencyTextBox145.Name = "solvencyCurrencyTextBox145";
this.solvencyCurrencyTextBox145.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox145.TabIndex = 145;
this.solvencyCurrencyTextBox145.ColName = "R1690C0360";
this.solvencyCurrencyTextBox145.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox146
//
this.solvencyCurrencyTextBox146.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox146.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox146.Location = new System.Drawing.Point(859,184);
this.solvencyCurrencyTextBox146.Name = "solvencyCurrencyTextBox146";
this.solvencyCurrencyTextBox146.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox146.TabIndex = 146;
this.solvencyCurrencyTextBox146.ColName = "R1690C0370";
this.solvencyCurrencyTextBox146.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox147
//
this.solvencyCurrencyTextBox147.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox147.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox147.Location = new System.Drawing.Point(966,184);
this.solvencyCurrencyTextBox147.Name = "solvencyCurrencyTextBox147";
this.solvencyCurrencyTextBox147.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox147.TabIndex = 147;
this.solvencyCurrencyTextBox147.ColName = "R1690C0380";
this.solvencyCurrencyTextBox147.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox148
//
this.solvencyCurrencyTextBox148.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox148.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox148.Location = new System.Drawing.Point(10,204);
this.solvencyCurrencyTextBox148.Name = "solvencyCurrencyTextBox148";
this.solvencyCurrencyTextBox148.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox148.TabIndex = 148;
this.solvencyCurrencyTextBox148.ColName = "R1700C0300";
this.solvencyCurrencyTextBox148.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox148.Enabled = false;
this.solvencyCurrencyTextBox148.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox149
//
this.solvencyCurrencyTextBox149.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox149.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox149.Location = new System.Drawing.Point(117,204);
this.solvencyCurrencyTextBox149.Name = "solvencyCurrencyTextBox149";
this.solvencyCurrencyTextBox149.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox149.TabIndex = 149;
this.solvencyCurrencyTextBox149.ColName = "R1700C0310";
this.solvencyCurrencyTextBox149.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox150
//
this.solvencyCurrencyTextBox150.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox150.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox150.Location = new System.Drawing.Point(224,204);
this.solvencyCurrencyTextBox150.Name = "solvencyCurrencyTextBox150";
this.solvencyCurrencyTextBox150.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox150.TabIndex = 150;
this.solvencyCurrencyTextBox150.ColName = "R1700C0320";
this.solvencyCurrencyTextBox150.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox151
//
this.solvencyCurrencyTextBox151.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox151.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox151.Location = new System.Drawing.Point(331,204);
this.solvencyCurrencyTextBox151.Name = "solvencyCurrencyTextBox151";
this.solvencyCurrencyTextBox151.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox151.TabIndex = 151;
this.solvencyCurrencyTextBox151.ColName = "R1700C0330";
this.solvencyCurrencyTextBox151.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// SolvencyDataComboBox152
//
this.SolvencyDataComboBox152.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox152.Location = new System.Drawing.Point(438,204);
this.SolvencyDataComboBox152.Name = "SolvencyDataComboBox152";
this.SolvencyDataComboBox152.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox152.TabIndex = 152;
this.SolvencyDataComboBox152.ColName = "R1700C0340";
this.SolvencyDataComboBox152.AxisID = 1321;
this.SolvencyDataComboBox152.OrdinateID = 7077;
this.SolvencyDataComboBox152.StartOrder = 0;
this.SolvencyDataComboBox152.NextOrder = 0;
//
// solvencyCurrencyTextBox153
//
this.solvencyCurrencyTextBox153.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox153.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox153.Location = new System.Drawing.Point(645,204);
this.solvencyCurrencyTextBox153.Name = "solvencyCurrencyTextBox153";
this.solvencyCurrencyTextBox153.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox153.TabIndex = 153;
this.solvencyCurrencyTextBox153.ColName = "R1700C0350";
this.solvencyCurrencyTextBox153.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox154
//
this.solvencyCurrencyTextBox154.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox154.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox154.Location = new System.Drawing.Point(752,204);
this.solvencyCurrencyTextBox154.Name = "solvencyCurrencyTextBox154";
this.solvencyCurrencyTextBox154.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox154.TabIndex = 154;
this.solvencyCurrencyTextBox154.ColName = "R1700C0360";
this.solvencyCurrencyTextBox154.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox155
//
this.solvencyCurrencyTextBox155.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox155.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox155.Location = new System.Drawing.Point(859,204);
this.solvencyCurrencyTextBox155.Name = "solvencyCurrencyTextBox155";
this.solvencyCurrencyTextBox155.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox155.TabIndex = 155;
this.solvencyCurrencyTextBox155.ColName = "R1700C0370";
this.solvencyCurrencyTextBox155.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox156
//
this.solvencyCurrencyTextBox156.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox156.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox156.Location = new System.Drawing.Point(966,204);
this.solvencyCurrencyTextBox156.Name = "solvencyCurrencyTextBox156";
this.solvencyCurrencyTextBox156.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox156.TabIndex = 156;
this.solvencyCurrencyTextBox156.ColName = "R1700C0380";
this.solvencyCurrencyTextBox156.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox157
//
this.solvencyCurrencyTextBox157.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox157.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox157.Location = new System.Drawing.Point(10,224);
this.solvencyCurrencyTextBox157.Name = "solvencyCurrencyTextBox157";
this.solvencyCurrencyTextBox157.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox157.TabIndex = 157;
this.solvencyCurrencyTextBox157.ColName = "R1710C0300";
this.solvencyCurrencyTextBox157.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox157.Enabled = false;
this.solvencyCurrencyTextBox157.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox158
//
this.solvencyCurrencyTextBox158.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox158.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox158.Location = new System.Drawing.Point(117,224);
this.solvencyCurrencyTextBox158.Name = "solvencyCurrencyTextBox158";
this.solvencyCurrencyTextBox158.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox158.TabIndex = 158;
this.solvencyCurrencyTextBox158.ColName = "R1710C0310";
this.solvencyCurrencyTextBox158.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox159
//
this.solvencyCurrencyTextBox159.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox159.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox159.Location = new System.Drawing.Point(224,224);
this.solvencyCurrencyTextBox159.Name = "solvencyCurrencyTextBox159";
this.solvencyCurrencyTextBox159.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox159.TabIndex = 159;
this.solvencyCurrencyTextBox159.ColName = "R1710C0320";
this.solvencyCurrencyTextBox159.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox160
//
this.solvencyCurrencyTextBox160.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox160.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox160.Location = new System.Drawing.Point(331,224);
this.solvencyCurrencyTextBox160.Name = "solvencyCurrencyTextBox160";
this.solvencyCurrencyTextBox160.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox160.TabIndex = 160;
this.solvencyCurrencyTextBox160.ColName = "R1710C0330";
this.solvencyCurrencyTextBox160.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// SolvencyDataComboBox161
//
this.SolvencyDataComboBox161.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox161.Location = new System.Drawing.Point(438,224);
this.SolvencyDataComboBox161.Name = "SolvencyDataComboBox161";
this.SolvencyDataComboBox161.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox161.TabIndex = 161;
this.SolvencyDataComboBox161.ColName = "R1710C0340";
this.SolvencyDataComboBox161.AxisID = 1321;
this.SolvencyDataComboBox161.OrdinateID = 7077;
this.SolvencyDataComboBox161.StartOrder = 0;
this.SolvencyDataComboBox161.NextOrder = 0;
//
// solvencyCurrencyTextBox162
//
this.solvencyCurrencyTextBox162.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox162.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox162.Location = new System.Drawing.Point(645,224);
this.solvencyCurrencyTextBox162.Name = "solvencyCurrencyTextBox162";
this.solvencyCurrencyTextBox162.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox162.TabIndex = 162;
this.solvencyCurrencyTextBox162.ColName = "R1710C0350";
this.solvencyCurrencyTextBox162.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox163
//
this.solvencyCurrencyTextBox163.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox163.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox163.Location = new System.Drawing.Point(752,224);
this.solvencyCurrencyTextBox163.Name = "solvencyCurrencyTextBox163";
this.solvencyCurrencyTextBox163.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox163.TabIndex = 163;
this.solvencyCurrencyTextBox163.ColName = "R1710C0360";
this.solvencyCurrencyTextBox163.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox164
//
this.solvencyCurrencyTextBox164.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox164.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox164.Location = new System.Drawing.Point(859,224);
this.solvencyCurrencyTextBox164.Name = "solvencyCurrencyTextBox164";
this.solvencyCurrencyTextBox164.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox164.TabIndex = 164;
this.solvencyCurrencyTextBox164.ColName = "R1710C0370";
this.solvencyCurrencyTextBox164.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox165
//
this.solvencyCurrencyTextBox165.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox165.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox165.Location = new System.Drawing.Point(966,224);
this.solvencyCurrencyTextBox165.Name = "solvencyCurrencyTextBox165";
this.solvencyCurrencyTextBox165.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox165.TabIndex = 165;
this.solvencyCurrencyTextBox165.ColName = "R1710C0380";
this.solvencyCurrencyTextBox165.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox166
//
this.solvencyCurrencyTextBox166.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox166.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox166.Location = new System.Drawing.Point(10,244);
this.solvencyCurrencyTextBox166.Name = "solvencyCurrencyTextBox166";
this.solvencyCurrencyTextBox166.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox166.TabIndex = 166;
this.solvencyCurrencyTextBox166.ColName = "R1720C0300";
this.solvencyCurrencyTextBox166.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox166.Enabled = false;
this.solvencyCurrencyTextBox166.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox167
//
this.solvencyCurrencyTextBox167.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox167.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox167.Location = new System.Drawing.Point(117,244);
this.solvencyCurrencyTextBox167.Name = "solvencyCurrencyTextBox167";
this.solvencyCurrencyTextBox167.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox167.TabIndex = 167;
this.solvencyCurrencyTextBox167.ColName = "R1720C0310";
this.solvencyCurrencyTextBox167.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox168
//
this.solvencyCurrencyTextBox168.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox168.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox168.Location = new System.Drawing.Point(224,244);
this.solvencyCurrencyTextBox168.Name = "solvencyCurrencyTextBox168";
this.solvencyCurrencyTextBox168.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox168.TabIndex = 168;
this.solvencyCurrencyTextBox168.ColName = "R1720C0320";
this.solvencyCurrencyTextBox168.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox169
//
this.solvencyCurrencyTextBox169.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox169.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox169.Location = new System.Drawing.Point(331,244);
this.solvencyCurrencyTextBox169.Name = "solvencyCurrencyTextBox169";
this.solvencyCurrencyTextBox169.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox169.TabIndex = 169;
this.solvencyCurrencyTextBox169.ColName = "R1720C0330";
this.solvencyCurrencyTextBox169.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// SolvencyDataComboBox170
//
this.SolvencyDataComboBox170.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox170.Location = new System.Drawing.Point(438,244);
this.SolvencyDataComboBox170.Name = "SolvencyDataComboBox170";
this.SolvencyDataComboBox170.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox170.TabIndex = 170;
this.SolvencyDataComboBox170.ColName = "R1720C0340";
this.SolvencyDataComboBox170.AxisID = 1321;
this.SolvencyDataComboBox170.OrdinateID = 7077;
this.SolvencyDataComboBox170.StartOrder = 0;
this.SolvencyDataComboBox170.NextOrder = 0;
this.SolvencyDataComboBox170.Enabled = false;
this.SolvencyDataComboBox170.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox171
//
this.solvencyCurrencyTextBox171.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox171.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox171.Location = new System.Drawing.Point(645,244);
this.solvencyCurrencyTextBox171.Name = "solvencyCurrencyTextBox171";
this.solvencyCurrencyTextBox171.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox171.TabIndex = 171;
this.solvencyCurrencyTextBox171.ColName = "R1720C0350";
this.solvencyCurrencyTextBox171.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox172
//
this.solvencyCurrencyTextBox172.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox172.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox172.Location = new System.Drawing.Point(752,244);
this.solvencyCurrencyTextBox172.Name = "solvencyCurrencyTextBox172";
this.solvencyCurrencyTextBox172.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox172.TabIndex = 172;
this.solvencyCurrencyTextBox172.ColName = "R1720C0360";
this.solvencyCurrencyTextBox172.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox173
//
this.solvencyCurrencyTextBox173.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox173.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox173.Location = new System.Drawing.Point(859,244);
this.solvencyCurrencyTextBox173.Name = "solvencyCurrencyTextBox173";
this.solvencyCurrencyTextBox173.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox173.TabIndex = 173;
this.solvencyCurrencyTextBox173.ColName = "R1720C0370";
this.solvencyCurrencyTextBox173.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox174
//
this.solvencyCurrencyTextBox174.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox174.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox174.Location = new System.Drawing.Point(966,244);
this.solvencyCurrencyTextBox174.Name = "solvencyCurrencyTextBox174";
this.solvencyCurrencyTextBox174.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox174.TabIndex = 174;
this.solvencyCurrencyTextBox174.ColName = "R1720C0380";
this.solvencyCurrencyTextBox174.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox175
//
this.solvencyCurrencyTextBox175.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox175.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox175.Location = new System.Drawing.Point(10,264);
this.solvencyCurrencyTextBox175.Name = "solvencyCurrencyTextBox175";
this.solvencyCurrencyTextBox175.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox175.TabIndex = 175;
this.solvencyCurrencyTextBox175.ColName = "R1730C0300";
this.solvencyCurrencyTextBox175.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox176
//
this.solvencyCurrencyTextBox176.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox176.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox176.Location = new System.Drawing.Point(117,264);
this.solvencyCurrencyTextBox176.Name = "solvencyCurrencyTextBox176";
this.solvencyCurrencyTextBox176.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox176.TabIndex = 176;
this.solvencyCurrencyTextBox176.ColName = "R1730C0310";
this.solvencyCurrencyTextBox176.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox176.Enabled = false;
this.solvencyCurrencyTextBox176.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox177
//
this.solvencyCurrencyTextBox177.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox177.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox177.Location = new System.Drawing.Point(224,264);
this.solvencyCurrencyTextBox177.Name = "solvencyCurrencyTextBox177";
this.solvencyCurrencyTextBox177.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox177.TabIndex = 177;
this.solvencyCurrencyTextBox177.ColName = "R1730C0320";
this.solvencyCurrencyTextBox177.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox177.Enabled = false;
this.solvencyCurrencyTextBox177.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox178
//
this.solvencyCurrencyTextBox178.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox178.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox178.Location = new System.Drawing.Point(331,264);
this.solvencyCurrencyTextBox178.Name = "solvencyCurrencyTextBox178";
this.solvencyCurrencyTextBox178.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox178.TabIndex = 178;
this.solvencyCurrencyTextBox178.ColName = "R1730C0330";
this.solvencyCurrencyTextBox178.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox178.Enabled = false;
this.solvencyCurrencyTextBox178.BackColor = System.Drawing.Color.Gray;
//
// SolvencyDataComboBox179
//
this.SolvencyDataComboBox179.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox179.Location = new System.Drawing.Point(438,264);
this.SolvencyDataComboBox179.Name = "SolvencyDataComboBox179";
this.SolvencyDataComboBox179.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox179.TabIndex = 179;
this.SolvencyDataComboBox179.ColName = "R1730C0340";
this.SolvencyDataComboBox179.AxisID = 1321;
this.SolvencyDataComboBox179.OrdinateID = 7077;
this.SolvencyDataComboBox179.StartOrder = 0;
this.SolvencyDataComboBox179.NextOrder = 0;
this.SolvencyDataComboBox179.Enabled = false;
this.SolvencyDataComboBox179.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox180
//
this.solvencyCurrencyTextBox180.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox180.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox180.Location = new System.Drawing.Point(645,264);
this.solvencyCurrencyTextBox180.Name = "solvencyCurrencyTextBox180";
this.solvencyCurrencyTextBox180.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox180.TabIndex = 180;
this.solvencyCurrencyTextBox180.ColName = "R1730C0350";
this.solvencyCurrencyTextBox180.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox180.Enabled = false;
this.solvencyCurrencyTextBox180.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox181
//
this.solvencyCurrencyTextBox181.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox181.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox181.Location = new System.Drawing.Point(752,264);
this.solvencyCurrencyTextBox181.Name = "solvencyCurrencyTextBox181";
this.solvencyCurrencyTextBox181.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox181.TabIndex = 181;
this.solvencyCurrencyTextBox181.ColName = "R1730C0360";
this.solvencyCurrencyTextBox181.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox181.Enabled = false;
this.solvencyCurrencyTextBox181.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox182
//
this.solvencyCurrencyTextBox182.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox182.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox182.Location = new System.Drawing.Point(859,264);
this.solvencyCurrencyTextBox182.Name = "solvencyCurrencyTextBox182";
this.solvencyCurrencyTextBox182.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox182.TabIndex = 182;
this.solvencyCurrencyTextBox182.ColName = "R1730C0370";
this.solvencyCurrencyTextBox182.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox182.Enabled = false;
this.solvencyCurrencyTextBox182.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox183
//
this.solvencyCurrencyTextBox183.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox183.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox183.Location = new System.Drawing.Point(966,264);
this.solvencyCurrencyTextBox183.Name = "solvencyCurrencyTextBox183";
this.solvencyCurrencyTextBox183.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox183.TabIndex = 183;
this.solvencyCurrencyTextBox183.ColName = "R1730C0380";
this.solvencyCurrencyTextBox183.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox183.Enabled = false;
this.solvencyCurrencyTextBox183.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox184
//
this.solvencyCurrencyTextBox184.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox184.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox184.Location = new System.Drawing.Point(10,284);
this.solvencyCurrencyTextBox184.Name = "solvencyCurrencyTextBox184";
this.solvencyCurrencyTextBox184.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox184.TabIndex = 184;
this.solvencyCurrencyTextBox184.ColName = "R1740C0300";
this.solvencyCurrencyTextBox184.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox185
//
this.solvencyCurrencyTextBox185.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox185.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox185.Location = new System.Drawing.Point(117,284);
this.solvencyCurrencyTextBox185.Name = "solvencyCurrencyTextBox185";
this.solvencyCurrencyTextBox185.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox185.TabIndex = 185;
this.solvencyCurrencyTextBox185.ColName = "R1740C0310";
this.solvencyCurrencyTextBox185.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox185.Enabled = false;
this.solvencyCurrencyTextBox185.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox186
//
this.solvencyCurrencyTextBox186.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox186.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox186.Location = new System.Drawing.Point(224,284);
this.solvencyCurrencyTextBox186.Name = "solvencyCurrencyTextBox186";
this.solvencyCurrencyTextBox186.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox186.TabIndex = 186;
this.solvencyCurrencyTextBox186.ColName = "R1740C0320";
this.solvencyCurrencyTextBox186.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox186.Enabled = false;
this.solvencyCurrencyTextBox186.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox187
//
this.solvencyCurrencyTextBox187.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox187.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox187.Location = new System.Drawing.Point(331,284);
this.solvencyCurrencyTextBox187.Name = "solvencyCurrencyTextBox187";
this.solvencyCurrencyTextBox187.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox187.TabIndex = 187;
this.solvencyCurrencyTextBox187.ColName = "R1740C0330";
this.solvencyCurrencyTextBox187.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox187.Enabled = false;
this.solvencyCurrencyTextBox187.BackColor = System.Drawing.Color.Gray;
//
// SolvencyDataComboBox188
//
this.SolvencyDataComboBox188.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox188.Location = new System.Drawing.Point(438,284);
this.SolvencyDataComboBox188.Name = "SolvencyDataComboBox188";
this.SolvencyDataComboBox188.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox188.TabIndex = 188;
this.SolvencyDataComboBox188.ColName = "R1740C0340";
this.SolvencyDataComboBox188.AxisID = 1321;
this.SolvencyDataComboBox188.OrdinateID = 7077;
this.SolvencyDataComboBox188.StartOrder = 0;
this.SolvencyDataComboBox188.NextOrder = 0;
this.SolvencyDataComboBox188.Enabled = false;
this.SolvencyDataComboBox188.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox189
//
this.solvencyCurrencyTextBox189.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox189.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox189.Location = new System.Drawing.Point(645,284);
this.solvencyCurrencyTextBox189.Name = "solvencyCurrencyTextBox189";
this.solvencyCurrencyTextBox189.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox189.TabIndex = 189;
this.solvencyCurrencyTextBox189.ColName = "R1740C0350";
this.solvencyCurrencyTextBox189.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox189.Enabled = false;
this.solvencyCurrencyTextBox189.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox190
//
this.solvencyCurrencyTextBox190.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox190.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox190.Location = new System.Drawing.Point(752,284);
this.solvencyCurrencyTextBox190.Name = "solvencyCurrencyTextBox190";
this.solvencyCurrencyTextBox190.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox190.TabIndex = 190;
this.solvencyCurrencyTextBox190.ColName = "R1740C0360";
this.solvencyCurrencyTextBox190.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox190.Enabled = false;
this.solvencyCurrencyTextBox190.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox191
//
this.solvencyCurrencyTextBox191.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox191.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox191.Location = new System.Drawing.Point(859,284);
this.solvencyCurrencyTextBox191.Name = "solvencyCurrencyTextBox191";
this.solvencyCurrencyTextBox191.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox191.TabIndex = 191;
this.solvencyCurrencyTextBox191.ColName = "R1740C0370";
this.solvencyCurrencyTextBox191.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox191.Enabled = false;
this.solvencyCurrencyTextBox191.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox192
//
this.solvencyCurrencyTextBox192.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox192.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox192.Location = new System.Drawing.Point(966,284);
this.solvencyCurrencyTextBox192.Name = "solvencyCurrencyTextBox192";
this.solvencyCurrencyTextBox192.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox192.TabIndex = 192;
this.solvencyCurrencyTextBox192.ColName = "R1740C0380";
this.solvencyCurrencyTextBox192.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox192.Enabled = false;
this.solvencyCurrencyTextBox192.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox193
//
this.solvencyCurrencyTextBox193.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox193.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox193.Location = new System.Drawing.Point(10,304);
this.solvencyCurrencyTextBox193.Name = "solvencyCurrencyTextBox193";
this.solvencyCurrencyTextBox193.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox193.TabIndex = 193;
this.solvencyCurrencyTextBox193.ColName = "R1750C0300";
this.solvencyCurrencyTextBox193.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox194
//
this.solvencyCurrencyTextBox194.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox194.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox194.Location = new System.Drawing.Point(117,304);
this.solvencyCurrencyTextBox194.Name = "solvencyCurrencyTextBox194";
this.solvencyCurrencyTextBox194.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox194.TabIndex = 194;
this.solvencyCurrencyTextBox194.ColName = "R1750C0310";
this.solvencyCurrencyTextBox194.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox194.Enabled = false;
this.solvencyCurrencyTextBox194.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox195
//
this.solvencyCurrencyTextBox195.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox195.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox195.Location = new System.Drawing.Point(224,304);
this.solvencyCurrencyTextBox195.Name = "solvencyCurrencyTextBox195";
this.solvencyCurrencyTextBox195.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox195.TabIndex = 195;
this.solvencyCurrencyTextBox195.ColName = "R1750C0320";
this.solvencyCurrencyTextBox195.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox195.Enabled = false;
this.solvencyCurrencyTextBox195.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox196
//
this.solvencyCurrencyTextBox196.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox196.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox196.Location = new System.Drawing.Point(331,304);
this.solvencyCurrencyTextBox196.Name = "solvencyCurrencyTextBox196";
this.solvencyCurrencyTextBox196.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox196.TabIndex = 196;
this.solvencyCurrencyTextBox196.ColName = "R1750C0330";
this.solvencyCurrencyTextBox196.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox196.Enabled = false;
this.solvencyCurrencyTextBox196.BackColor = System.Drawing.Color.Gray;
//
// SolvencyDataComboBox197
//
this.SolvencyDataComboBox197.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox197.Location = new System.Drawing.Point(438,304);
this.SolvencyDataComboBox197.Name = "SolvencyDataComboBox197";
this.SolvencyDataComboBox197.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox197.TabIndex = 197;
this.SolvencyDataComboBox197.ColName = "R1750C0340";
this.SolvencyDataComboBox197.AxisID = 1321;
this.SolvencyDataComboBox197.OrdinateID = 7077;
this.SolvencyDataComboBox197.StartOrder = 0;
this.SolvencyDataComboBox197.NextOrder = 0;
this.SolvencyDataComboBox197.Enabled = false;
this.SolvencyDataComboBox197.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox198
//
this.solvencyCurrencyTextBox198.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox198.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox198.Location = new System.Drawing.Point(645,304);
this.solvencyCurrencyTextBox198.Name = "solvencyCurrencyTextBox198";
this.solvencyCurrencyTextBox198.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox198.TabIndex = 198;
this.solvencyCurrencyTextBox198.ColName = "R1750C0350";
this.solvencyCurrencyTextBox198.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox198.Enabled = false;
this.solvencyCurrencyTextBox198.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox199
//
this.solvencyCurrencyTextBox199.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox199.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox199.Location = new System.Drawing.Point(752,304);
this.solvencyCurrencyTextBox199.Name = "solvencyCurrencyTextBox199";
this.solvencyCurrencyTextBox199.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox199.TabIndex = 199;
this.solvencyCurrencyTextBox199.ColName = "R1750C0360";
this.solvencyCurrencyTextBox199.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox199.Enabled = false;
this.solvencyCurrencyTextBox199.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox200
//
this.solvencyCurrencyTextBox200.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox200.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox200.Location = new System.Drawing.Point(859,304);
this.solvencyCurrencyTextBox200.Name = "solvencyCurrencyTextBox200";
this.solvencyCurrencyTextBox200.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox200.TabIndex = 200;
this.solvencyCurrencyTextBox200.ColName = "R1750C0370";
this.solvencyCurrencyTextBox200.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox200.Enabled = false;
this.solvencyCurrencyTextBox200.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox201
//
this.solvencyCurrencyTextBox201.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox201.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox201.Location = new System.Drawing.Point(966,304);
this.solvencyCurrencyTextBox201.Name = "solvencyCurrencyTextBox201";
this.solvencyCurrencyTextBox201.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox201.TabIndex = 201;
this.solvencyCurrencyTextBox201.ColName = "R1750C0380";
this.solvencyCurrencyTextBox201.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox201.Enabled = false;
this.solvencyCurrencyTextBox201.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox202
//
this.solvencyCurrencyTextBox202.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox202.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox202.Location = new System.Drawing.Point(10,324);
this.solvencyCurrencyTextBox202.Name = "solvencyCurrencyTextBox202";
this.solvencyCurrencyTextBox202.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox202.TabIndex = 202;
this.solvencyCurrencyTextBox202.ColName = "R1760C0300";
this.solvencyCurrencyTextBox202.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox203
//
this.solvencyCurrencyTextBox203.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox203.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox203.Location = new System.Drawing.Point(117,324);
this.solvencyCurrencyTextBox203.Name = "solvencyCurrencyTextBox203";
this.solvencyCurrencyTextBox203.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox203.TabIndex = 203;
this.solvencyCurrencyTextBox203.ColName = "R1760C0310";
this.solvencyCurrencyTextBox203.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox203.Enabled = false;
this.solvencyCurrencyTextBox203.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox204
//
this.solvencyCurrencyTextBox204.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox204.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox204.Location = new System.Drawing.Point(224,324);
this.solvencyCurrencyTextBox204.Name = "solvencyCurrencyTextBox204";
this.solvencyCurrencyTextBox204.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox204.TabIndex = 204;
this.solvencyCurrencyTextBox204.ColName = "R1760C0320";
this.solvencyCurrencyTextBox204.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox204.Enabled = false;
this.solvencyCurrencyTextBox204.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox205
//
this.solvencyCurrencyTextBox205.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox205.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox205.Location = new System.Drawing.Point(331,324);
this.solvencyCurrencyTextBox205.Name = "solvencyCurrencyTextBox205";
this.solvencyCurrencyTextBox205.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox205.TabIndex = 205;
this.solvencyCurrencyTextBox205.ColName = "R1760C0330";
this.solvencyCurrencyTextBox205.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox205.Enabled = false;
this.solvencyCurrencyTextBox205.BackColor = System.Drawing.Color.Gray;
//
// SolvencyDataComboBox206
//
this.SolvencyDataComboBox206.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox206.Location = new System.Drawing.Point(438,324);
this.SolvencyDataComboBox206.Name = "SolvencyDataComboBox206";
this.SolvencyDataComboBox206.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox206.TabIndex = 206;
this.SolvencyDataComboBox206.ColName = "R1760C0340";
this.SolvencyDataComboBox206.AxisID = 1321;
this.SolvencyDataComboBox206.OrdinateID = 7077;
this.SolvencyDataComboBox206.StartOrder = 0;
this.SolvencyDataComboBox206.NextOrder = 0;
this.SolvencyDataComboBox206.Enabled = false;
this.SolvencyDataComboBox206.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox207
//
this.solvencyCurrencyTextBox207.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox207.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox207.Location = new System.Drawing.Point(645,324);
this.solvencyCurrencyTextBox207.Name = "solvencyCurrencyTextBox207";
this.solvencyCurrencyTextBox207.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox207.TabIndex = 207;
this.solvencyCurrencyTextBox207.ColName = "R1760C0350";
this.solvencyCurrencyTextBox207.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox207.Enabled = false;
this.solvencyCurrencyTextBox207.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox208
//
this.solvencyCurrencyTextBox208.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox208.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox208.Location = new System.Drawing.Point(752,324);
this.solvencyCurrencyTextBox208.Name = "solvencyCurrencyTextBox208";
this.solvencyCurrencyTextBox208.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox208.TabIndex = 208;
this.solvencyCurrencyTextBox208.ColName = "R1760C0360";
this.solvencyCurrencyTextBox208.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox208.Enabled = false;
this.solvencyCurrencyTextBox208.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox209
//
this.solvencyCurrencyTextBox209.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox209.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox209.Location = new System.Drawing.Point(859,324);
this.solvencyCurrencyTextBox209.Name = "solvencyCurrencyTextBox209";
this.solvencyCurrencyTextBox209.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox209.TabIndex = 209;
this.solvencyCurrencyTextBox209.ColName = "R1760C0370";
this.solvencyCurrencyTextBox209.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox209.Enabled = false;
this.solvencyCurrencyTextBox209.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox210
//
this.solvencyCurrencyTextBox210.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox210.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox210.Location = new System.Drawing.Point(966,324);
this.solvencyCurrencyTextBox210.Name = "solvencyCurrencyTextBox210";
this.solvencyCurrencyTextBox210.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox210.TabIndex = 210;
this.solvencyCurrencyTextBox210.ColName = "R1760C0380";
this.solvencyCurrencyTextBox210.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox210.Enabled = false;
this.solvencyCurrencyTextBox210.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox211
//
this.solvencyCurrencyTextBox211.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox211.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox211.Location = new System.Drawing.Point(10,344);
this.solvencyCurrencyTextBox211.Name = "solvencyCurrencyTextBox211";
this.solvencyCurrencyTextBox211.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox211.TabIndex = 211;
this.solvencyCurrencyTextBox211.ColName = "R1770C0300";
this.solvencyCurrencyTextBox211.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox212
//
this.solvencyCurrencyTextBox212.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox212.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox212.Location = new System.Drawing.Point(117,344);
this.solvencyCurrencyTextBox212.Name = "solvencyCurrencyTextBox212";
this.solvencyCurrencyTextBox212.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox212.TabIndex = 212;
this.solvencyCurrencyTextBox212.ColName = "R1770C0310";
this.solvencyCurrencyTextBox212.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox212.Enabled = false;
this.solvencyCurrencyTextBox212.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox213
//
this.solvencyCurrencyTextBox213.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox213.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox213.Location = new System.Drawing.Point(224,344);
this.solvencyCurrencyTextBox213.Name = "solvencyCurrencyTextBox213";
this.solvencyCurrencyTextBox213.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox213.TabIndex = 213;
this.solvencyCurrencyTextBox213.ColName = "R1770C0320";
this.solvencyCurrencyTextBox213.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox213.Enabled = false;
this.solvencyCurrencyTextBox213.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox214
//
this.solvencyCurrencyTextBox214.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox214.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox214.Location = new System.Drawing.Point(331,344);
this.solvencyCurrencyTextBox214.Name = "solvencyCurrencyTextBox214";
this.solvencyCurrencyTextBox214.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox214.TabIndex = 214;
this.solvencyCurrencyTextBox214.ColName = "R1770C0330";
this.solvencyCurrencyTextBox214.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox214.Enabled = false;
this.solvencyCurrencyTextBox214.BackColor = System.Drawing.Color.Gray;
//
// SolvencyDataComboBox215
//
this.SolvencyDataComboBox215.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox215.Location = new System.Drawing.Point(438,344);
this.SolvencyDataComboBox215.Name = "SolvencyDataComboBox215";
this.SolvencyDataComboBox215.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox215.TabIndex = 215;
this.SolvencyDataComboBox215.ColName = "R1770C0340";
this.SolvencyDataComboBox215.AxisID = 1321;
this.SolvencyDataComboBox215.OrdinateID = 7077;
this.SolvencyDataComboBox215.StartOrder = 0;
this.SolvencyDataComboBox215.NextOrder = 0;
this.SolvencyDataComboBox215.Enabled = false;
this.SolvencyDataComboBox215.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox216
//
this.solvencyCurrencyTextBox216.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox216.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox216.Location = new System.Drawing.Point(645,344);
this.solvencyCurrencyTextBox216.Name = "solvencyCurrencyTextBox216";
this.solvencyCurrencyTextBox216.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox216.TabIndex = 216;
this.solvencyCurrencyTextBox216.ColName = "R1770C0350";
this.solvencyCurrencyTextBox216.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox216.Enabled = false;
this.solvencyCurrencyTextBox216.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox217
//
this.solvencyCurrencyTextBox217.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox217.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox217.Location = new System.Drawing.Point(752,344);
this.solvencyCurrencyTextBox217.Name = "solvencyCurrencyTextBox217";
this.solvencyCurrencyTextBox217.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox217.TabIndex = 217;
this.solvencyCurrencyTextBox217.ColName = "R1770C0360";
this.solvencyCurrencyTextBox217.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox217.Enabled = false;
this.solvencyCurrencyTextBox217.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox218
//
this.solvencyCurrencyTextBox218.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox218.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox218.Location = new System.Drawing.Point(859,344);
this.solvencyCurrencyTextBox218.Name = "solvencyCurrencyTextBox218";
this.solvencyCurrencyTextBox218.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox218.TabIndex = 218;
this.solvencyCurrencyTextBox218.ColName = "R1770C0370";
this.solvencyCurrencyTextBox218.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox218.Enabled = false;
this.solvencyCurrencyTextBox218.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox219
//
this.solvencyCurrencyTextBox219.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox219.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox219.Location = new System.Drawing.Point(966,344);
this.solvencyCurrencyTextBox219.Name = "solvencyCurrencyTextBox219";
this.solvencyCurrencyTextBox219.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox219.TabIndex = 219;
this.solvencyCurrencyTextBox219.ColName = "R1770C0380";
this.solvencyCurrencyTextBox219.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox219.Enabled = false;
this.solvencyCurrencyTextBox219.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox220
//
this.solvencyCurrencyTextBox220.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox220.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox220.Location = new System.Drawing.Point(10,364);
this.solvencyCurrencyTextBox220.Name = "solvencyCurrencyTextBox220";
this.solvencyCurrencyTextBox220.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox220.TabIndex = 220;
this.solvencyCurrencyTextBox220.ColName = "R1780C0300";
this.solvencyCurrencyTextBox220.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox221
//
this.solvencyCurrencyTextBox221.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox221.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox221.Location = new System.Drawing.Point(117,364);
this.solvencyCurrencyTextBox221.Name = "solvencyCurrencyTextBox221";
this.solvencyCurrencyTextBox221.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox221.TabIndex = 221;
this.solvencyCurrencyTextBox221.ColName = "R1780C0310";
this.solvencyCurrencyTextBox221.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox221.Enabled = false;
this.solvencyCurrencyTextBox221.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox222
//
this.solvencyCurrencyTextBox222.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox222.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox222.Location = new System.Drawing.Point(224,364);
this.solvencyCurrencyTextBox222.Name = "solvencyCurrencyTextBox222";
this.solvencyCurrencyTextBox222.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox222.TabIndex = 222;
this.solvencyCurrencyTextBox222.ColName = "R1780C0320";
this.solvencyCurrencyTextBox222.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox222.Enabled = false;
this.solvencyCurrencyTextBox222.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox223
//
this.solvencyCurrencyTextBox223.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox223.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox223.Location = new System.Drawing.Point(331,364);
this.solvencyCurrencyTextBox223.Name = "solvencyCurrencyTextBox223";
this.solvencyCurrencyTextBox223.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox223.TabIndex = 223;
this.solvencyCurrencyTextBox223.ColName = "R1780C0330";
this.solvencyCurrencyTextBox223.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox223.Enabled = false;
this.solvencyCurrencyTextBox223.BackColor = System.Drawing.Color.Gray;
//
// SolvencyDataComboBox224
//
this.SolvencyDataComboBox224.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox224.Location = new System.Drawing.Point(438,364);
this.SolvencyDataComboBox224.Name = "SolvencyDataComboBox224";
this.SolvencyDataComboBox224.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox224.TabIndex = 224;
this.SolvencyDataComboBox224.ColName = "R1780C0340";
this.SolvencyDataComboBox224.AxisID = 1321;
this.SolvencyDataComboBox224.OrdinateID = 7077;
this.SolvencyDataComboBox224.StartOrder = 0;
this.SolvencyDataComboBox224.NextOrder = 0;
this.SolvencyDataComboBox224.Enabled = false;
this.SolvencyDataComboBox224.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox225
//
this.solvencyCurrencyTextBox225.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox225.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox225.Location = new System.Drawing.Point(645,364);
this.solvencyCurrencyTextBox225.Name = "solvencyCurrencyTextBox225";
this.solvencyCurrencyTextBox225.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox225.TabIndex = 225;
this.solvencyCurrencyTextBox225.ColName = "R1780C0350";
this.solvencyCurrencyTextBox225.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox225.Enabled = false;
this.solvencyCurrencyTextBox225.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox226
//
this.solvencyCurrencyTextBox226.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox226.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox226.Location = new System.Drawing.Point(752,364);
this.solvencyCurrencyTextBox226.Name = "solvencyCurrencyTextBox226";
this.solvencyCurrencyTextBox226.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox226.TabIndex = 226;
this.solvencyCurrencyTextBox226.ColName = "R1780C0360";
this.solvencyCurrencyTextBox226.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox226.Enabled = false;
this.solvencyCurrencyTextBox226.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox227
//
this.solvencyCurrencyTextBox227.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox227.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox227.Location = new System.Drawing.Point(859,364);
this.solvencyCurrencyTextBox227.Name = "solvencyCurrencyTextBox227";
this.solvencyCurrencyTextBox227.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox227.TabIndex = 227;
this.solvencyCurrencyTextBox227.ColName = "R1780C0370";
this.solvencyCurrencyTextBox227.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox227.Enabled = false;
this.solvencyCurrencyTextBox227.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox228
//
this.solvencyCurrencyTextBox228.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox228.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox228.Location = new System.Drawing.Point(966,364);
this.solvencyCurrencyTextBox228.Name = "solvencyCurrencyTextBox228";
this.solvencyCurrencyTextBox228.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox228.TabIndex = 228;
this.solvencyCurrencyTextBox228.ColName = "R1780C0380";
this.solvencyCurrencyTextBox228.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox228.Enabled = false;
this.solvencyCurrencyTextBox228.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox229
//
this.solvencyCurrencyTextBox229.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox229.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox229.Location = new System.Drawing.Point(10,384);
this.solvencyCurrencyTextBox229.Name = "solvencyCurrencyTextBox229";
this.solvencyCurrencyTextBox229.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox229.TabIndex = 229;
this.solvencyCurrencyTextBox229.ColName = "R1790C0300";
this.solvencyCurrencyTextBox229.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox230
//
this.solvencyCurrencyTextBox230.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox230.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox230.Location = new System.Drawing.Point(117,384);
this.solvencyCurrencyTextBox230.Name = "solvencyCurrencyTextBox230";
this.solvencyCurrencyTextBox230.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox230.TabIndex = 230;
this.solvencyCurrencyTextBox230.ColName = "R1790C0310";
this.solvencyCurrencyTextBox230.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox230.Enabled = false;
this.solvencyCurrencyTextBox230.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox231
//
this.solvencyCurrencyTextBox231.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox231.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox231.Location = new System.Drawing.Point(224,384);
this.solvencyCurrencyTextBox231.Name = "solvencyCurrencyTextBox231";
this.solvencyCurrencyTextBox231.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox231.TabIndex = 231;
this.solvencyCurrencyTextBox231.ColName = "R1790C0320";
this.solvencyCurrencyTextBox231.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox231.Enabled = false;
this.solvencyCurrencyTextBox231.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox232
//
this.solvencyCurrencyTextBox232.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox232.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox232.Location = new System.Drawing.Point(331,384);
this.solvencyCurrencyTextBox232.Name = "solvencyCurrencyTextBox232";
this.solvencyCurrencyTextBox232.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox232.TabIndex = 232;
this.solvencyCurrencyTextBox232.ColName = "R1790C0330";
this.solvencyCurrencyTextBox232.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox232.Enabled = false;
this.solvencyCurrencyTextBox232.BackColor = System.Drawing.Color.Gray;
//
// SolvencyDataComboBox233
//
this.SolvencyDataComboBox233.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox233.Location = new System.Drawing.Point(438,384);
this.SolvencyDataComboBox233.Name = "SolvencyDataComboBox233";
this.SolvencyDataComboBox233.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox233.TabIndex = 233;
this.SolvencyDataComboBox233.ColName = "R1790C0340";
this.SolvencyDataComboBox233.AxisID = 1321;
this.SolvencyDataComboBox233.OrdinateID = 7077;
this.SolvencyDataComboBox233.StartOrder = 0;
this.SolvencyDataComboBox233.NextOrder = 0;
this.SolvencyDataComboBox233.Enabled = false;
this.SolvencyDataComboBox233.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox234
//
this.solvencyCurrencyTextBox234.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox234.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox234.Location = new System.Drawing.Point(645,384);
this.solvencyCurrencyTextBox234.Name = "solvencyCurrencyTextBox234";
this.solvencyCurrencyTextBox234.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox234.TabIndex = 234;
this.solvencyCurrencyTextBox234.ColName = "R1790C0350";
this.solvencyCurrencyTextBox234.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox234.Enabled = false;
this.solvencyCurrencyTextBox234.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox235
//
this.solvencyCurrencyTextBox235.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox235.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox235.Location = new System.Drawing.Point(752,384);
this.solvencyCurrencyTextBox235.Name = "solvencyCurrencyTextBox235";
this.solvencyCurrencyTextBox235.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox235.TabIndex = 235;
this.solvencyCurrencyTextBox235.ColName = "R1790C0360";
this.solvencyCurrencyTextBox235.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox235.Enabled = false;
this.solvencyCurrencyTextBox235.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox236
//
this.solvencyCurrencyTextBox236.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox236.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox236.Location = new System.Drawing.Point(859,384);
this.solvencyCurrencyTextBox236.Name = "solvencyCurrencyTextBox236";
this.solvencyCurrencyTextBox236.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox236.TabIndex = 236;
this.solvencyCurrencyTextBox236.ColName = "R1790C0370";
this.solvencyCurrencyTextBox236.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox236.Enabled = false;
this.solvencyCurrencyTextBox236.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox237
//
this.solvencyCurrencyTextBox237.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox237.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox237.Location = new System.Drawing.Point(966,384);
this.solvencyCurrencyTextBox237.Name = "solvencyCurrencyTextBox237";
this.solvencyCurrencyTextBox237.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox237.TabIndex = 237;
this.solvencyCurrencyTextBox237.ColName = "R1790C0380";
this.solvencyCurrencyTextBox237.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox237.Enabled = false;
this.solvencyCurrencyTextBox237.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox238
//
this.solvencyCurrencyTextBox238.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox238.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox238.Location = new System.Drawing.Point(10,404);
this.solvencyCurrencyTextBox238.Name = "solvencyCurrencyTextBox238";
this.solvencyCurrencyTextBox238.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox238.TabIndex = 238;
this.solvencyCurrencyTextBox238.ColName = "R1800C0300";
this.solvencyCurrencyTextBox238.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox239
//
this.solvencyCurrencyTextBox239.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox239.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox239.Location = new System.Drawing.Point(117,404);
this.solvencyCurrencyTextBox239.Name = "solvencyCurrencyTextBox239";
this.solvencyCurrencyTextBox239.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox239.TabIndex = 239;
this.solvencyCurrencyTextBox239.ColName = "R1800C0310";
this.solvencyCurrencyTextBox239.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox239.Enabled = false;
this.solvencyCurrencyTextBox239.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox240
//
this.solvencyCurrencyTextBox240.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox240.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox240.Location = new System.Drawing.Point(224,404);
this.solvencyCurrencyTextBox240.Name = "solvencyCurrencyTextBox240";
this.solvencyCurrencyTextBox240.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox240.TabIndex = 240;
this.solvencyCurrencyTextBox240.ColName = "R1800C0320";
this.solvencyCurrencyTextBox240.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox240.Enabled = false;
this.solvencyCurrencyTextBox240.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox241
//
this.solvencyCurrencyTextBox241.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox241.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox241.Location = new System.Drawing.Point(331,404);
this.solvencyCurrencyTextBox241.Name = "solvencyCurrencyTextBox241";
this.solvencyCurrencyTextBox241.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox241.TabIndex = 241;
this.solvencyCurrencyTextBox241.ColName = "R1800C0330";
this.solvencyCurrencyTextBox241.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox241.Enabled = false;
this.solvencyCurrencyTextBox241.BackColor = System.Drawing.Color.Gray;
//
// SolvencyDataComboBox242
//
this.SolvencyDataComboBox242.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox242.Location = new System.Drawing.Point(438,404);
this.SolvencyDataComboBox242.Name = "SolvencyDataComboBox242";
this.SolvencyDataComboBox242.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox242.TabIndex = 242;
this.SolvencyDataComboBox242.ColName = "R1800C0340";
this.SolvencyDataComboBox242.AxisID = 1321;
this.SolvencyDataComboBox242.OrdinateID = 7077;
this.SolvencyDataComboBox242.StartOrder = 0;
this.SolvencyDataComboBox242.NextOrder = 0;
this.SolvencyDataComboBox242.Enabled = false;
this.SolvencyDataComboBox242.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox243
//
this.solvencyCurrencyTextBox243.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox243.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox243.Location = new System.Drawing.Point(645,404);
this.solvencyCurrencyTextBox243.Name = "solvencyCurrencyTextBox243";
this.solvencyCurrencyTextBox243.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox243.TabIndex = 243;
this.solvencyCurrencyTextBox243.ColName = "R1800C0350";
this.solvencyCurrencyTextBox243.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox243.Enabled = false;
this.solvencyCurrencyTextBox243.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox244
//
this.solvencyCurrencyTextBox244.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox244.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox244.Location = new System.Drawing.Point(752,404);
this.solvencyCurrencyTextBox244.Name = "solvencyCurrencyTextBox244";
this.solvencyCurrencyTextBox244.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox244.TabIndex = 244;
this.solvencyCurrencyTextBox244.ColName = "R1800C0360";
this.solvencyCurrencyTextBox244.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox244.Enabled = false;
this.solvencyCurrencyTextBox244.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox245
//
this.solvencyCurrencyTextBox245.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox245.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox245.Location = new System.Drawing.Point(859,404);
this.solvencyCurrencyTextBox245.Name = "solvencyCurrencyTextBox245";
this.solvencyCurrencyTextBox245.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox245.TabIndex = 245;
this.solvencyCurrencyTextBox245.ColName = "R1800C0370";
this.solvencyCurrencyTextBox245.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox245.Enabled = false;
this.solvencyCurrencyTextBox245.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox246
//
this.solvencyCurrencyTextBox246.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox246.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox246.Location = new System.Drawing.Point(966,404);
this.solvencyCurrencyTextBox246.Name = "solvencyCurrencyTextBox246";
this.solvencyCurrencyTextBox246.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox246.TabIndex = 246;
this.solvencyCurrencyTextBox246.ColName = "R1800C0380";
this.solvencyCurrencyTextBox246.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox246.Enabled = false;
this.solvencyCurrencyTextBox246.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox247
//
this.solvencyCurrencyTextBox247.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox247.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox247.Location = new System.Drawing.Point(10,424);
this.solvencyCurrencyTextBox247.Name = "solvencyCurrencyTextBox247";
this.solvencyCurrencyTextBox247.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox247.TabIndex = 247;
this.solvencyCurrencyTextBox247.ColName = "R1810C0300";
this.solvencyCurrencyTextBox247.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox248
//
this.solvencyCurrencyTextBox248.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox248.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox248.Location = new System.Drawing.Point(117,424);
this.solvencyCurrencyTextBox248.Name = "solvencyCurrencyTextBox248";
this.solvencyCurrencyTextBox248.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox248.TabIndex = 248;
this.solvencyCurrencyTextBox248.ColName = "R1810C0310";
this.solvencyCurrencyTextBox248.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox248.Enabled = false;
this.solvencyCurrencyTextBox248.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox249
//
this.solvencyCurrencyTextBox249.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox249.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox249.Location = new System.Drawing.Point(224,424);
this.solvencyCurrencyTextBox249.Name = "solvencyCurrencyTextBox249";
this.solvencyCurrencyTextBox249.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox249.TabIndex = 249;
this.solvencyCurrencyTextBox249.ColName = "R1810C0320";
this.solvencyCurrencyTextBox249.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox249.Enabled = false;
this.solvencyCurrencyTextBox249.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox250
//
this.solvencyCurrencyTextBox250.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox250.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox250.Location = new System.Drawing.Point(331,424);
this.solvencyCurrencyTextBox250.Name = "solvencyCurrencyTextBox250";
this.solvencyCurrencyTextBox250.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox250.TabIndex = 250;
this.solvencyCurrencyTextBox250.ColName = "R1810C0330";
this.solvencyCurrencyTextBox250.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox250.Enabled = false;
this.solvencyCurrencyTextBox250.BackColor = System.Drawing.Color.Gray;
//
// SolvencyDataComboBox251
//
this.SolvencyDataComboBox251.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox251.Location = new System.Drawing.Point(438,424);
this.SolvencyDataComboBox251.Name = "SolvencyDataComboBox251";
this.SolvencyDataComboBox251.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox251.TabIndex = 251;
this.SolvencyDataComboBox251.ColName = "R1810C0340";
this.SolvencyDataComboBox251.AxisID = 1321;
this.SolvencyDataComboBox251.OrdinateID = 7077;
this.SolvencyDataComboBox251.StartOrder = 0;
this.SolvencyDataComboBox251.NextOrder = 0;
this.SolvencyDataComboBox251.Enabled = false;
this.SolvencyDataComboBox251.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox252
//
this.solvencyCurrencyTextBox252.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox252.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox252.Location = new System.Drawing.Point(645,424);
this.solvencyCurrencyTextBox252.Name = "solvencyCurrencyTextBox252";
this.solvencyCurrencyTextBox252.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox252.TabIndex = 252;
this.solvencyCurrencyTextBox252.ColName = "R1810C0350";
this.solvencyCurrencyTextBox252.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox252.Enabled = false;
this.solvencyCurrencyTextBox252.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox253
//
this.solvencyCurrencyTextBox253.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox253.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox253.Location = new System.Drawing.Point(752,424);
this.solvencyCurrencyTextBox253.Name = "solvencyCurrencyTextBox253";
this.solvencyCurrencyTextBox253.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox253.TabIndex = 253;
this.solvencyCurrencyTextBox253.ColName = "R1810C0360";
this.solvencyCurrencyTextBox253.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox253.Enabled = false;
this.solvencyCurrencyTextBox253.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox254
//
this.solvencyCurrencyTextBox254.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox254.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox254.Location = new System.Drawing.Point(859,424);
this.solvencyCurrencyTextBox254.Name = "solvencyCurrencyTextBox254";
this.solvencyCurrencyTextBox254.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox254.TabIndex = 254;
this.solvencyCurrencyTextBox254.ColName = "R1810C0370";
this.solvencyCurrencyTextBox254.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox254.Enabled = false;
this.solvencyCurrencyTextBox254.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox255
//
this.solvencyCurrencyTextBox255.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox255.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox255.Location = new System.Drawing.Point(966,424);
this.solvencyCurrencyTextBox255.Name = "solvencyCurrencyTextBox255";
this.solvencyCurrencyTextBox255.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox255.TabIndex = 255;
this.solvencyCurrencyTextBox255.ColName = "R1810C0380";
this.solvencyCurrencyTextBox255.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox255.Enabled = false;
this.solvencyCurrencyTextBox255.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox256
//
this.solvencyCurrencyTextBox256.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox256.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox256.Location = new System.Drawing.Point(10,444);
this.solvencyCurrencyTextBox256.Name = "solvencyCurrencyTextBox256";
this.solvencyCurrencyTextBox256.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox256.TabIndex = 256;
this.solvencyCurrencyTextBox256.ColName = "R1820C0300";
this.solvencyCurrencyTextBox256.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox257
//
this.solvencyCurrencyTextBox257.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox257.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox257.Location = new System.Drawing.Point(117,444);
this.solvencyCurrencyTextBox257.Name = "solvencyCurrencyTextBox257";
this.solvencyCurrencyTextBox257.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox257.TabIndex = 257;
this.solvencyCurrencyTextBox257.ColName = "R1820C0310";
this.solvencyCurrencyTextBox257.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox257.Enabled = false;
this.solvencyCurrencyTextBox257.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox258
//
this.solvencyCurrencyTextBox258.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox258.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox258.Location = new System.Drawing.Point(224,444);
this.solvencyCurrencyTextBox258.Name = "solvencyCurrencyTextBox258";
this.solvencyCurrencyTextBox258.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox258.TabIndex = 258;
this.solvencyCurrencyTextBox258.ColName = "R1820C0320";
this.solvencyCurrencyTextBox258.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox258.Enabled = false;
this.solvencyCurrencyTextBox258.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox259
//
this.solvencyCurrencyTextBox259.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox259.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox259.Location = new System.Drawing.Point(331,444);
this.solvencyCurrencyTextBox259.Name = "solvencyCurrencyTextBox259";
this.solvencyCurrencyTextBox259.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox259.TabIndex = 259;
this.solvencyCurrencyTextBox259.ColName = "R1820C0330";
this.solvencyCurrencyTextBox259.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox259.Enabled = false;
this.solvencyCurrencyTextBox259.BackColor = System.Drawing.Color.Gray;
//
// SolvencyDataComboBox260
//
this.SolvencyDataComboBox260.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox260.Location = new System.Drawing.Point(438,444);
this.SolvencyDataComboBox260.Name = "SolvencyDataComboBox260";
this.SolvencyDataComboBox260.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox260.TabIndex = 260;
this.SolvencyDataComboBox260.ColName = "R1820C0340";
this.SolvencyDataComboBox260.AxisID = 1321;
this.SolvencyDataComboBox260.OrdinateID = 7077;
this.SolvencyDataComboBox260.StartOrder = 0;
this.SolvencyDataComboBox260.NextOrder = 0;
this.SolvencyDataComboBox260.Enabled = false;
this.SolvencyDataComboBox260.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox261
//
this.solvencyCurrencyTextBox261.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox261.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox261.Location = new System.Drawing.Point(645,444);
this.solvencyCurrencyTextBox261.Name = "solvencyCurrencyTextBox261";
this.solvencyCurrencyTextBox261.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox261.TabIndex = 261;
this.solvencyCurrencyTextBox261.ColName = "R1820C0350";
this.solvencyCurrencyTextBox261.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox261.Enabled = false;
this.solvencyCurrencyTextBox261.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox262
//
this.solvencyCurrencyTextBox262.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox262.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox262.Location = new System.Drawing.Point(752,444);
this.solvencyCurrencyTextBox262.Name = "solvencyCurrencyTextBox262";
this.solvencyCurrencyTextBox262.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox262.TabIndex = 262;
this.solvencyCurrencyTextBox262.ColName = "R1820C0360";
this.solvencyCurrencyTextBox262.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox262.Enabled = false;
this.solvencyCurrencyTextBox262.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox263
//
this.solvencyCurrencyTextBox263.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox263.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox263.Location = new System.Drawing.Point(859,444);
this.solvencyCurrencyTextBox263.Name = "solvencyCurrencyTextBox263";
this.solvencyCurrencyTextBox263.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox263.TabIndex = 263;
this.solvencyCurrencyTextBox263.ColName = "R1820C0370";
this.solvencyCurrencyTextBox263.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox263.Enabled = false;
this.solvencyCurrencyTextBox263.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox264
//
this.solvencyCurrencyTextBox264.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox264.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox264.Location = new System.Drawing.Point(966,444);
this.solvencyCurrencyTextBox264.Name = "solvencyCurrencyTextBox264";
this.solvencyCurrencyTextBox264.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox264.TabIndex = 264;
this.solvencyCurrencyTextBox264.ColName = "R1820C0380";
this.solvencyCurrencyTextBox264.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox264.Enabled = false;
this.solvencyCurrencyTextBox264.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox265
//
this.solvencyCurrencyTextBox265.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox265.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox265.Location = new System.Drawing.Point(10,464);
this.solvencyCurrencyTextBox265.Name = "solvencyCurrencyTextBox265";
this.solvencyCurrencyTextBox265.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox265.TabIndex = 265;
this.solvencyCurrencyTextBox265.ColName = "R1830C0300";
this.solvencyCurrencyTextBox265.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox266
//
this.solvencyCurrencyTextBox266.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox266.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox266.Location = new System.Drawing.Point(117,464);
this.solvencyCurrencyTextBox266.Name = "solvencyCurrencyTextBox266";
this.solvencyCurrencyTextBox266.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox266.TabIndex = 266;
this.solvencyCurrencyTextBox266.ColName = "R1830C0310";
this.solvencyCurrencyTextBox266.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox266.Enabled = false;
this.solvencyCurrencyTextBox266.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox267
//
this.solvencyCurrencyTextBox267.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox267.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox267.Location = new System.Drawing.Point(224,464);
this.solvencyCurrencyTextBox267.Name = "solvencyCurrencyTextBox267";
this.solvencyCurrencyTextBox267.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox267.TabIndex = 267;
this.solvencyCurrencyTextBox267.ColName = "R1830C0320";
this.solvencyCurrencyTextBox267.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox267.Enabled = false;
this.solvencyCurrencyTextBox267.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox268
//
this.solvencyCurrencyTextBox268.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox268.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox268.Location = new System.Drawing.Point(331,464);
this.solvencyCurrencyTextBox268.Name = "solvencyCurrencyTextBox268";
this.solvencyCurrencyTextBox268.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox268.TabIndex = 268;
this.solvencyCurrencyTextBox268.ColName = "R1830C0330";
this.solvencyCurrencyTextBox268.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox268.Enabled = false;
this.solvencyCurrencyTextBox268.BackColor = System.Drawing.Color.Gray;
//
// SolvencyDataComboBox269
//
this.SolvencyDataComboBox269.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox269.Location = new System.Drawing.Point(438,464);
this.SolvencyDataComboBox269.Name = "SolvencyDataComboBox269";
this.SolvencyDataComboBox269.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox269.TabIndex = 269;
this.SolvencyDataComboBox269.ColName = "R1830C0340";
this.SolvencyDataComboBox269.AxisID = 1321;
this.SolvencyDataComboBox269.OrdinateID = 7077;
this.SolvencyDataComboBox269.StartOrder = 0;
this.SolvencyDataComboBox269.NextOrder = 0;
this.SolvencyDataComboBox269.Enabled = false;
this.SolvencyDataComboBox269.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox270
//
this.solvencyCurrencyTextBox270.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox270.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox270.Location = new System.Drawing.Point(645,464);
this.solvencyCurrencyTextBox270.Name = "solvencyCurrencyTextBox270";
this.solvencyCurrencyTextBox270.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox270.TabIndex = 270;
this.solvencyCurrencyTextBox270.ColName = "R1830C0350";
this.solvencyCurrencyTextBox270.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox270.Enabled = false;
this.solvencyCurrencyTextBox270.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox271
//
this.solvencyCurrencyTextBox271.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox271.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox271.Location = new System.Drawing.Point(752,464);
this.solvencyCurrencyTextBox271.Name = "solvencyCurrencyTextBox271";
this.solvencyCurrencyTextBox271.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox271.TabIndex = 271;
this.solvencyCurrencyTextBox271.ColName = "R1830C0360";
this.solvencyCurrencyTextBox271.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox271.Enabled = false;
this.solvencyCurrencyTextBox271.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox272
//
this.solvencyCurrencyTextBox272.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox272.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox272.Location = new System.Drawing.Point(859,464);
this.solvencyCurrencyTextBox272.Name = "solvencyCurrencyTextBox272";
this.solvencyCurrencyTextBox272.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox272.TabIndex = 272;
this.solvencyCurrencyTextBox272.ColName = "R1830C0370";
this.solvencyCurrencyTextBox272.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox272.Enabled = false;
this.solvencyCurrencyTextBox272.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox273
//
this.solvencyCurrencyTextBox273.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox273.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox273.Location = new System.Drawing.Point(966,464);
this.solvencyCurrencyTextBox273.Name = "solvencyCurrencyTextBox273";
this.solvencyCurrencyTextBox273.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox273.TabIndex = 273;
this.solvencyCurrencyTextBox273.ColName = "R1830C0380";
this.solvencyCurrencyTextBox273.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox273.Enabled = false;
this.solvencyCurrencyTextBox273.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox274
//
this.solvencyCurrencyTextBox274.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox274.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox274.Location = new System.Drawing.Point(10,497);
this.solvencyCurrencyTextBox274.Name = "solvencyCurrencyTextBox274";
this.solvencyCurrencyTextBox274.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox274.TabIndex = 274;
this.solvencyCurrencyTextBox274.ColName = "R1840C0300";
this.solvencyCurrencyTextBox274.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox275
//
this.solvencyCurrencyTextBox275.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox275.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox275.Location = new System.Drawing.Point(117,497);
this.solvencyCurrencyTextBox275.Name = "solvencyCurrencyTextBox275";
this.solvencyCurrencyTextBox275.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox275.TabIndex = 275;
this.solvencyCurrencyTextBox275.ColName = "R1840C0310";
this.solvencyCurrencyTextBox275.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox275.Enabled = false;
this.solvencyCurrencyTextBox275.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox276
//
this.solvencyCurrencyTextBox276.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox276.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox276.Location = new System.Drawing.Point(224,497);
this.solvencyCurrencyTextBox276.Name = "solvencyCurrencyTextBox276";
this.solvencyCurrencyTextBox276.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox276.TabIndex = 276;
this.solvencyCurrencyTextBox276.ColName = "R1840C0320";
this.solvencyCurrencyTextBox276.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox276.Enabled = false;
this.solvencyCurrencyTextBox276.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox277
//
this.solvencyCurrencyTextBox277.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox277.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox277.Location = new System.Drawing.Point(331,497);
this.solvencyCurrencyTextBox277.Name = "solvencyCurrencyTextBox277";
this.solvencyCurrencyTextBox277.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox277.TabIndex = 277;
this.solvencyCurrencyTextBox277.ColName = "R1840C0330";
this.solvencyCurrencyTextBox277.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox277.Enabled = false;
this.solvencyCurrencyTextBox277.BackColor = System.Drawing.Color.Gray;
//
// SolvencyDataComboBox278
//
this.SolvencyDataComboBox278.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox278.Location = new System.Drawing.Point(438,497);
this.SolvencyDataComboBox278.Name = "SolvencyDataComboBox278";
this.SolvencyDataComboBox278.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox278.TabIndex = 278;
this.SolvencyDataComboBox278.ColName = "R1840C0340";
this.SolvencyDataComboBox278.AxisID = 1321;
this.SolvencyDataComboBox278.OrdinateID = 7077;
this.SolvencyDataComboBox278.StartOrder = 0;
this.SolvencyDataComboBox278.NextOrder = 0;
this.SolvencyDataComboBox278.Enabled = false;
this.SolvencyDataComboBox278.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox279
//
this.solvencyCurrencyTextBox279.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox279.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox279.Location = new System.Drawing.Point(645,497);
this.solvencyCurrencyTextBox279.Name = "solvencyCurrencyTextBox279";
this.solvencyCurrencyTextBox279.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox279.TabIndex = 279;
this.solvencyCurrencyTextBox279.ColName = "R1840C0350";
this.solvencyCurrencyTextBox279.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox279.Enabled = false;
this.solvencyCurrencyTextBox279.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox280
//
this.solvencyCurrencyTextBox280.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox280.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox280.Location = new System.Drawing.Point(752,497);
this.solvencyCurrencyTextBox280.Name = "solvencyCurrencyTextBox280";
this.solvencyCurrencyTextBox280.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox280.TabIndex = 280;
this.solvencyCurrencyTextBox280.ColName = "R1840C0360";
this.solvencyCurrencyTextBox280.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox280.Enabled = false;
this.solvencyCurrencyTextBox280.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox281
//
this.solvencyCurrencyTextBox281.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox281.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox281.Location = new System.Drawing.Point(859,497);
this.solvencyCurrencyTextBox281.Name = "solvencyCurrencyTextBox281";
this.solvencyCurrencyTextBox281.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox281.TabIndex = 281;
this.solvencyCurrencyTextBox281.ColName = "R1840C0370";
this.solvencyCurrencyTextBox281.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox281.Enabled = false;
this.solvencyCurrencyTextBox281.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox282
//
this.solvencyCurrencyTextBox282.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox282.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox282.Location = new System.Drawing.Point(966,497);
this.solvencyCurrencyTextBox282.Name = "solvencyCurrencyTextBox282";
this.solvencyCurrencyTextBox282.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox282.TabIndex = 282;
this.solvencyCurrencyTextBox282.ColName = "R1840C0380";
this.solvencyCurrencyTextBox282.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox282.Enabled = false;
this.solvencyCurrencyTextBox282.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox283
//
this.solvencyCurrencyTextBox283.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox283.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox283.Location = new System.Drawing.Point(10,517);
this.solvencyCurrencyTextBox283.Name = "solvencyCurrencyTextBox283";
this.solvencyCurrencyTextBox283.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox283.TabIndex = 283;
this.solvencyCurrencyTextBox283.ColName = "R1850C0300";
this.solvencyCurrencyTextBox283.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox284
//
this.solvencyCurrencyTextBox284.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox284.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox284.Location = new System.Drawing.Point(117,517);
this.solvencyCurrencyTextBox284.Name = "solvencyCurrencyTextBox284";
this.solvencyCurrencyTextBox284.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox284.TabIndex = 284;
this.solvencyCurrencyTextBox284.ColName = "R1850C0310";
this.solvencyCurrencyTextBox284.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox284.Enabled = false;
this.solvencyCurrencyTextBox284.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox285
//
this.solvencyCurrencyTextBox285.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox285.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox285.Location = new System.Drawing.Point(224,517);
this.solvencyCurrencyTextBox285.Name = "solvencyCurrencyTextBox285";
this.solvencyCurrencyTextBox285.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox285.TabIndex = 285;
this.solvencyCurrencyTextBox285.ColName = "R1850C0320";
this.solvencyCurrencyTextBox285.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox285.Enabled = false;
this.solvencyCurrencyTextBox285.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox286
//
this.solvencyCurrencyTextBox286.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox286.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox286.Location = new System.Drawing.Point(331,517);
this.solvencyCurrencyTextBox286.Name = "solvencyCurrencyTextBox286";
this.solvencyCurrencyTextBox286.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox286.TabIndex = 286;
this.solvencyCurrencyTextBox286.ColName = "R1850C0330";
this.solvencyCurrencyTextBox286.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox286.Enabled = false;
this.solvencyCurrencyTextBox286.BackColor = System.Drawing.Color.Gray;
//
// SolvencyDataComboBox287
//
this.SolvencyDataComboBox287.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox287.Location = new System.Drawing.Point(438,517);
this.SolvencyDataComboBox287.Name = "SolvencyDataComboBox287";
this.SolvencyDataComboBox287.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox287.TabIndex = 287;
this.SolvencyDataComboBox287.ColName = "R1850C0340";
this.SolvencyDataComboBox287.AxisID = 1321;
this.SolvencyDataComboBox287.OrdinateID = 7077;
this.SolvencyDataComboBox287.StartOrder = 0;
this.SolvencyDataComboBox287.NextOrder = 0;
this.SolvencyDataComboBox287.Enabled = false;
this.SolvencyDataComboBox287.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox288
//
this.solvencyCurrencyTextBox288.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox288.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox288.Location = new System.Drawing.Point(645,517);
this.solvencyCurrencyTextBox288.Name = "solvencyCurrencyTextBox288";
this.solvencyCurrencyTextBox288.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox288.TabIndex = 288;
this.solvencyCurrencyTextBox288.ColName = "R1850C0350";
this.solvencyCurrencyTextBox288.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox288.Enabled = false;
this.solvencyCurrencyTextBox288.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox289
//
this.solvencyCurrencyTextBox289.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox289.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox289.Location = new System.Drawing.Point(752,517);
this.solvencyCurrencyTextBox289.Name = "solvencyCurrencyTextBox289";
this.solvencyCurrencyTextBox289.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox289.TabIndex = 289;
this.solvencyCurrencyTextBox289.ColName = "R1850C0360";
this.solvencyCurrencyTextBox289.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox289.Enabled = false;
this.solvencyCurrencyTextBox289.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox290
//
this.solvencyCurrencyTextBox290.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox290.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox290.Location = new System.Drawing.Point(859,517);
this.solvencyCurrencyTextBox290.Name = "solvencyCurrencyTextBox290";
this.solvencyCurrencyTextBox290.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox290.TabIndex = 290;
this.solvencyCurrencyTextBox290.ColName = "R1850C0370";
this.solvencyCurrencyTextBox290.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox290.Enabled = false;
this.solvencyCurrencyTextBox290.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox291
//
this.solvencyCurrencyTextBox291.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox291.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox291.Location = new System.Drawing.Point(966,517);
this.solvencyCurrencyTextBox291.Name = "solvencyCurrencyTextBox291";
this.solvencyCurrencyTextBox291.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox291.TabIndex = 291;
this.solvencyCurrencyTextBox291.ColName = "R1850C0380";
this.solvencyCurrencyTextBox291.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox291.Enabled = false;
this.solvencyCurrencyTextBox291.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox292
//
this.solvencyCurrencyTextBox292.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox292.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox292.Location = new System.Drawing.Point(10,537);
this.solvencyCurrencyTextBox292.Name = "solvencyCurrencyTextBox292";
this.solvencyCurrencyTextBox292.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox292.TabIndex = 292;
this.solvencyCurrencyTextBox292.ColName = "R1860C0300";
this.solvencyCurrencyTextBox292.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox293
//
this.solvencyCurrencyTextBox293.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox293.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox293.Location = new System.Drawing.Point(117,537);
this.solvencyCurrencyTextBox293.Name = "solvencyCurrencyTextBox293";
this.solvencyCurrencyTextBox293.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox293.TabIndex = 293;
this.solvencyCurrencyTextBox293.ColName = "R1860C0310";
this.solvencyCurrencyTextBox293.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox293.Enabled = false;
this.solvencyCurrencyTextBox293.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox294
//
this.solvencyCurrencyTextBox294.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox294.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox294.Location = new System.Drawing.Point(224,537);
this.solvencyCurrencyTextBox294.Name = "solvencyCurrencyTextBox294";
this.solvencyCurrencyTextBox294.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox294.TabIndex = 294;
this.solvencyCurrencyTextBox294.ColName = "R1860C0320";
this.solvencyCurrencyTextBox294.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox294.Enabled = false;
this.solvencyCurrencyTextBox294.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox295
//
this.solvencyCurrencyTextBox295.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox295.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox295.Location = new System.Drawing.Point(331,537);
this.solvencyCurrencyTextBox295.Name = "solvencyCurrencyTextBox295";
this.solvencyCurrencyTextBox295.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox295.TabIndex = 295;
this.solvencyCurrencyTextBox295.ColName = "R1860C0330";
this.solvencyCurrencyTextBox295.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox295.Enabled = false;
this.solvencyCurrencyTextBox295.BackColor = System.Drawing.Color.Gray;
//
// SolvencyDataComboBox296
//
this.SolvencyDataComboBox296.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox296.Location = new System.Drawing.Point(438,537);
this.SolvencyDataComboBox296.Name = "SolvencyDataComboBox296";
this.SolvencyDataComboBox296.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox296.TabIndex = 296;
this.SolvencyDataComboBox296.ColName = "R1860C0340";
this.SolvencyDataComboBox296.AxisID = 1321;
this.SolvencyDataComboBox296.OrdinateID = 7077;
this.SolvencyDataComboBox296.StartOrder = 0;
this.SolvencyDataComboBox296.NextOrder = 0;
this.SolvencyDataComboBox296.Enabled = false;
this.SolvencyDataComboBox296.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox297
//
this.solvencyCurrencyTextBox297.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox297.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox297.Location = new System.Drawing.Point(645,537);
this.solvencyCurrencyTextBox297.Name = "solvencyCurrencyTextBox297";
this.solvencyCurrencyTextBox297.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox297.TabIndex = 297;
this.solvencyCurrencyTextBox297.ColName = "R1860C0350";
this.solvencyCurrencyTextBox297.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox297.Enabled = false;
this.solvencyCurrencyTextBox297.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox298
//
this.solvencyCurrencyTextBox298.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox298.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox298.Location = new System.Drawing.Point(752,537);
this.solvencyCurrencyTextBox298.Name = "solvencyCurrencyTextBox298";
this.solvencyCurrencyTextBox298.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox298.TabIndex = 298;
this.solvencyCurrencyTextBox298.ColName = "R1860C0360";
this.solvencyCurrencyTextBox298.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox298.Enabled = false;
this.solvencyCurrencyTextBox298.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox299
//
this.solvencyCurrencyTextBox299.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox299.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox299.Location = new System.Drawing.Point(859,537);
this.solvencyCurrencyTextBox299.Name = "solvencyCurrencyTextBox299";
this.solvencyCurrencyTextBox299.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox299.TabIndex = 299;
this.solvencyCurrencyTextBox299.ColName = "R1860C0370";
this.solvencyCurrencyTextBox299.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox299.Enabled = false;
this.solvencyCurrencyTextBox299.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox300
//
this.solvencyCurrencyTextBox300.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox300.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox300.Location = new System.Drawing.Point(966,537);
this.solvencyCurrencyTextBox300.Name = "solvencyCurrencyTextBox300";
this.solvencyCurrencyTextBox300.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox300.TabIndex = 300;
this.solvencyCurrencyTextBox300.ColName = "R1860C0380";
this.solvencyCurrencyTextBox300.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox300.Enabled = false;
this.solvencyCurrencyTextBox300.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox301
//
this.solvencyCurrencyTextBox301.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox301.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox301.Location = new System.Drawing.Point(10,557);
this.solvencyCurrencyTextBox301.Name = "solvencyCurrencyTextBox301";
this.solvencyCurrencyTextBox301.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox301.TabIndex = 301;
this.solvencyCurrencyTextBox301.ColName = "R1870C0300";
this.solvencyCurrencyTextBox301.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox302
//
this.solvencyCurrencyTextBox302.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox302.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox302.Location = new System.Drawing.Point(117,557);
this.solvencyCurrencyTextBox302.Name = "solvencyCurrencyTextBox302";
this.solvencyCurrencyTextBox302.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox302.TabIndex = 302;
this.solvencyCurrencyTextBox302.ColName = "R1870C0310";
this.solvencyCurrencyTextBox302.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox302.Enabled = false;
this.solvencyCurrencyTextBox302.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox303
//
this.solvencyCurrencyTextBox303.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox303.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox303.Location = new System.Drawing.Point(224,557);
this.solvencyCurrencyTextBox303.Name = "solvencyCurrencyTextBox303";
this.solvencyCurrencyTextBox303.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox303.TabIndex = 303;
this.solvencyCurrencyTextBox303.ColName = "R1870C0320";
this.solvencyCurrencyTextBox303.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox303.Enabled = false;
this.solvencyCurrencyTextBox303.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox304
//
this.solvencyCurrencyTextBox304.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox304.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox304.Location = new System.Drawing.Point(331,557);
this.solvencyCurrencyTextBox304.Name = "solvencyCurrencyTextBox304";
this.solvencyCurrencyTextBox304.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox304.TabIndex = 304;
this.solvencyCurrencyTextBox304.ColName = "R1870C0330";
this.solvencyCurrencyTextBox304.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox304.Enabled = false;
this.solvencyCurrencyTextBox304.BackColor = System.Drawing.Color.Gray;
//
// SolvencyDataComboBox305
//
this.SolvencyDataComboBox305.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox305.Location = new System.Drawing.Point(438,557);
this.SolvencyDataComboBox305.Name = "SolvencyDataComboBox305";
this.SolvencyDataComboBox305.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox305.TabIndex = 305;
this.SolvencyDataComboBox305.ColName = "R1870C0340";
this.SolvencyDataComboBox305.AxisID = 1321;
this.SolvencyDataComboBox305.OrdinateID = 7077;
this.SolvencyDataComboBox305.StartOrder = 0;
this.SolvencyDataComboBox305.NextOrder = 0;
this.SolvencyDataComboBox305.Enabled = false;
this.SolvencyDataComboBox305.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox306
//
this.solvencyCurrencyTextBox306.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox306.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox306.Location = new System.Drawing.Point(645,557);
this.solvencyCurrencyTextBox306.Name = "solvencyCurrencyTextBox306";
this.solvencyCurrencyTextBox306.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox306.TabIndex = 306;
this.solvencyCurrencyTextBox306.ColName = "R1870C0350";
this.solvencyCurrencyTextBox306.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox306.Enabled = false;
this.solvencyCurrencyTextBox306.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox307
//
this.solvencyCurrencyTextBox307.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox307.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox307.Location = new System.Drawing.Point(752,557);
this.solvencyCurrencyTextBox307.Name = "solvencyCurrencyTextBox307";
this.solvencyCurrencyTextBox307.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox307.TabIndex = 307;
this.solvencyCurrencyTextBox307.ColName = "R1870C0360";
this.solvencyCurrencyTextBox307.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox307.Enabled = false;
this.solvencyCurrencyTextBox307.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox308
//
this.solvencyCurrencyTextBox308.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox308.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox308.Location = new System.Drawing.Point(859,557);
this.solvencyCurrencyTextBox308.Name = "solvencyCurrencyTextBox308";
this.solvencyCurrencyTextBox308.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox308.TabIndex = 308;
this.solvencyCurrencyTextBox308.ColName = "R1870C0370";
this.solvencyCurrencyTextBox308.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox308.Enabled = false;
this.solvencyCurrencyTextBox308.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox309
//
this.solvencyCurrencyTextBox309.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox309.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox309.Location = new System.Drawing.Point(966,557);
this.solvencyCurrencyTextBox309.Name = "solvencyCurrencyTextBox309";
this.solvencyCurrencyTextBox309.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox309.TabIndex = 309;
this.solvencyCurrencyTextBox309.ColName = "R1870C0380";
this.solvencyCurrencyTextBox309.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox309.Enabled = false;
this.solvencyCurrencyTextBox309.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox310
//
this.solvencyCurrencyTextBox310.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox310.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox310.Location = new System.Drawing.Point(10,577);
this.solvencyCurrencyTextBox310.Name = "solvencyCurrencyTextBox310";
this.solvencyCurrencyTextBox310.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox310.TabIndex = 310;
this.solvencyCurrencyTextBox310.ColName = "R1880C0300";
this.solvencyCurrencyTextBox310.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox311
//
this.solvencyCurrencyTextBox311.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox311.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox311.Location = new System.Drawing.Point(117,577);
this.solvencyCurrencyTextBox311.Name = "solvencyCurrencyTextBox311";
this.solvencyCurrencyTextBox311.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox311.TabIndex = 311;
this.solvencyCurrencyTextBox311.ColName = "R1880C0310";
this.solvencyCurrencyTextBox311.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox311.Enabled = false;
this.solvencyCurrencyTextBox311.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox312
//
this.solvencyCurrencyTextBox312.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox312.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox312.Location = new System.Drawing.Point(224,577);
this.solvencyCurrencyTextBox312.Name = "solvencyCurrencyTextBox312";
this.solvencyCurrencyTextBox312.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox312.TabIndex = 312;
this.solvencyCurrencyTextBox312.ColName = "R1880C0320";
this.solvencyCurrencyTextBox312.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox312.Enabled = false;
this.solvencyCurrencyTextBox312.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox313
//
this.solvencyCurrencyTextBox313.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox313.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox313.Location = new System.Drawing.Point(331,577);
this.solvencyCurrencyTextBox313.Name = "solvencyCurrencyTextBox313";
this.solvencyCurrencyTextBox313.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox313.TabIndex = 313;
this.solvencyCurrencyTextBox313.ColName = "R1880C0330";
this.solvencyCurrencyTextBox313.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox313.Enabled = false;
this.solvencyCurrencyTextBox313.BackColor = System.Drawing.Color.Gray;
//
// SolvencyDataComboBox314
//
this.SolvencyDataComboBox314.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox314.Location = new System.Drawing.Point(438,577);
this.SolvencyDataComboBox314.Name = "SolvencyDataComboBox314";
this.SolvencyDataComboBox314.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox314.TabIndex = 314;
this.SolvencyDataComboBox314.ColName = "R1880C0340";
this.SolvencyDataComboBox314.AxisID = 1321;
this.SolvencyDataComboBox314.OrdinateID = 7077;
this.SolvencyDataComboBox314.StartOrder = 0;
this.SolvencyDataComboBox314.NextOrder = 0;
this.SolvencyDataComboBox314.Enabled = false;
this.SolvencyDataComboBox314.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox315
//
this.solvencyCurrencyTextBox315.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox315.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox315.Location = new System.Drawing.Point(645,577);
this.solvencyCurrencyTextBox315.Name = "solvencyCurrencyTextBox315";
this.solvencyCurrencyTextBox315.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox315.TabIndex = 315;
this.solvencyCurrencyTextBox315.ColName = "R1880C0350";
this.solvencyCurrencyTextBox315.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox315.Enabled = false;
this.solvencyCurrencyTextBox315.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox316
//
this.solvencyCurrencyTextBox316.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox316.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox316.Location = new System.Drawing.Point(752,577);
this.solvencyCurrencyTextBox316.Name = "solvencyCurrencyTextBox316";
this.solvencyCurrencyTextBox316.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox316.TabIndex = 316;
this.solvencyCurrencyTextBox316.ColName = "R1880C0360";
this.solvencyCurrencyTextBox316.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox316.Enabled = false;
this.solvencyCurrencyTextBox316.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox317
//
this.solvencyCurrencyTextBox317.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox317.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox317.Location = new System.Drawing.Point(859,577);
this.solvencyCurrencyTextBox317.Name = "solvencyCurrencyTextBox317";
this.solvencyCurrencyTextBox317.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox317.TabIndex = 317;
this.solvencyCurrencyTextBox317.ColName = "R1880C0370";
this.solvencyCurrencyTextBox317.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox317.Enabled = false;
this.solvencyCurrencyTextBox317.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox318
//
this.solvencyCurrencyTextBox318.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox318.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox318.Location = new System.Drawing.Point(966,577);
this.solvencyCurrencyTextBox318.Name = "solvencyCurrencyTextBox318";
this.solvencyCurrencyTextBox318.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox318.TabIndex = 318;
this.solvencyCurrencyTextBox318.ColName = "R1880C0380";
this.solvencyCurrencyTextBox318.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox318.Enabled = false;
this.solvencyCurrencyTextBox318.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox319
//
this.solvencyCurrencyTextBox319.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox319.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox319.Location = new System.Drawing.Point(10,597);
this.solvencyCurrencyTextBox319.Name = "solvencyCurrencyTextBox319";
this.solvencyCurrencyTextBox319.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox319.TabIndex = 319;
this.solvencyCurrencyTextBox319.ColName = "R1890C0300";
this.solvencyCurrencyTextBox319.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox320
//
this.solvencyCurrencyTextBox320.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox320.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox320.Location = new System.Drawing.Point(117,597);
this.solvencyCurrencyTextBox320.Name = "solvencyCurrencyTextBox320";
this.solvencyCurrencyTextBox320.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox320.TabIndex = 320;
this.solvencyCurrencyTextBox320.ColName = "R1890C0310";
this.solvencyCurrencyTextBox320.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox320.Enabled = false;
this.solvencyCurrencyTextBox320.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox321
//
this.solvencyCurrencyTextBox321.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox321.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox321.Location = new System.Drawing.Point(224,597);
this.solvencyCurrencyTextBox321.Name = "solvencyCurrencyTextBox321";
this.solvencyCurrencyTextBox321.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox321.TabIndex = 321;
this.solvencyCurrencyTextBox321.ColName = "R1890C0320";
this.solvencyCurrencyTextBox321.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox321.Enabled = false;
this.solvencyCurrencyTextBox321.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox322
//
this.solvencyCurrencyTextBox322.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox322.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox322.Location = new System.Drawing.Point(331,597);
this.solvencyCurrencyTextBox322.Name = "solvencyCurrencyTextBox322";
this.solvencyCurrencyTextBox322.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox322.TabIndex = 322;
this.solvencyCurrencyTextBox322.ColName = "R1890C0330";
this.solvencyCurrencyTextBox322.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox322.Enabled = false;
this.solvencyCurrencyTextBox322.BackColor = System.Drawing.Color.Gray;
//
// SolvencyDataComboBox323
//
this.SolvencyDataComboBox323.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox323.Location = new System.Drawing.Point(438,597);
this.SolvencyDataComboBox323.Name = "SolvencyDataComboBox323";
this.SolvencyDataComboBox323.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox323.TabIndex = 323;
this.SolvencyDataComboBox323.ColName = "R1890C0340";
this.SolvencyDataComboBox323.AxisID = 1321;
this.SolvencyDataComboBox323.OrdinateID = 7077;
this.SolvencyDataComboBox323.StartOrder = 0;
this.SolvencyDataComboBox323.NextOrder = 0;
this.SolvencyDataComboBox323.Enabled = false;
this.SolvencyDataComboBox323.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox324
//
this.solvencyCurrencyTextBox324.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox324.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox324.Location = new System.Drawing.Point(645,597);
this.solvencyCurrencyTextBox324.Name = "solvencyCurrencyTextBox324";
this.solvencyCurrencyTextBox324.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox324.TabIndex = 324;
this.solvencyCurrencyTextBox324.ColName = "R1890C0350";
this.solvencyCurrencyTextBox324.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox324.Enabled = false;
this.solvencyCurrencyTextBox324.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox325
//
this.solvencyCurrencyTextBox325.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox325.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox325.Location = new System.Drawing.Point(752,597);
this.solvencyCurrencyTextBox325.Name = "solvencyCurrencyTextBox325";
this.solvencyCurrencyTextBox325.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox325.TabIndex = 325;
this.solvencyCurrencyTextBox325.ColName = "R1890C0360";
this.solvencyCurrencyTextBox325.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox325.Enabled = false;
this.solvencyCurrencyTextBox325.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox326
//
this.solvencyCurrencyTextBox326.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox326.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox326.Location = new System.Drawing.Point(859,597);
this.solvencyCurrencyTextBox326.Name = "solvencyCurrencyTextBox326";
this.solvencyCurrencyTextBox326.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox326.TabIndex = 326;
this.solvencyCurrencyTextBox326.ColName = "R1890C0370";
this.solvencyCurrencyTextBox326.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox326.Enabled = false;
this.solvencyCurrencyTextBox326.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox327
//
this.solvencyCurrencyTextBox327.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox327.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox327.Location = new System.Drawing.Point(966,597);
this.solvencyCurrencyTextBox327.Name = "solvencyCurrencyTextBox327";
this.solvencyCurrencyTextBox327.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox327.TabIndex = 327;
this.solvencyCurrencyTextBox327.ColName = "R1890C0380";
this.solvencyCurrencyTextBox327.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox327.Enabled = false;
this.solvencyCurrencyTextBox327.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox328
//
this.solvencyCurrencyTextBox328.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox328.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox328.Location = new System.Drawing.Point(10,617);
this.solvencyCurrencyTextBox328.Name = "solvencyCurrencyTextBox328";
this.solvencyCurrencyTextBox328.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox328.TabIndex = 328;
this.solvencyCurrencyTextBox328.ColName = "R1900C0300";
this.solvencyCurrencyTextBox328.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox329
//
this.solvencyCurrencyTextBox329.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox329.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox329.Location = new System.Drawing.Point(117,617);
this.solvencyCurrencyTextBox329.Name = "solvencyCurrencyTextBox329";
this.solvencyCurrencyTextBox329.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox329.TabIndex = 329;
this.solvencyCurrencyTextBox329.ColName = "R1900C0310";
this.solvencyCurrencyTextBox329.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox329.Enabled = false;
this.solvencyCurrencyTextBox329.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox330
//
this.solvencyCurrencyTextBox330.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox330.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox330.Location = new System.Drawing.Point(224,617);
this.solvencyCurrencyTextBox330.Name = "solvencyCurrencyTextBox330";
this.solvencyCurrencyTextBox330.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox330.TabIndex = 330;
this.solvencyCurrencyTextBox330.ColName = "R1900C0320";
this.solvencyCurrencyTextBox330.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox330.Enabled = false;
this.solvencyCurrencyTextBox330.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox331
//
this.solvencyCurrencyTextBox331.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox331.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox331.Location = new System.Drawing.Point(331,617);
this.solvencyCurrencyTextBox331.Name = "solvencyCurrencyTextBox331";
this.solvencyCurrencyTextBox331.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox331.TabIndex = 331;
this.solvencyCurrencyTextBox331.ColName = "R1900C0330";
this.solvencyCurrencyTextBox331.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox331.Enabled = false;
this.solvencyCurrencyTextBox331.BackColor = System.Drawing.Color.Gray;
//
// SolvencyDataComboBox332
//
this.SolvencyDataComboBox332.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox332.Location = new System.Drawing.Point(438,617);
this.SolvencyDataComboBox332.Name = "SolvencyDataComboBox332";
this.SolvencyDataComboBox332.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox332.TabIndex = 332;
this.SolvencyDataComboBox332.ColName = "R1900C0340";
this.SolvencyDataComboBox332.AxisID = 1321;
this.SolvencyDataComboBox332.OrdinateID = 7077;
this.SolvencyDataComboBox332.StartOrder = 0;
this.SolvencyDataComboBox332.NextOrder = 0;
this.SolvencyDataComboBox332.Enabled = false;
this.SolvencyDataComboBox332.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox333
//
this.solvencyCurrencyTextBox333.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox333.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox333.Location = new System.Drawing.Point(645,617);
this.solvencyCurrencyTextBox333.Name = "solvencyCurrencyTextBox333";
this.solvencyCurrencyTextBox333.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox333.TabIndex = 333;
this.solvencyCurrencyTextBox333.ColName = "R1900C0350";
this.solvencyCurrencyTextBox333.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox333.Enabled = false;
this.solvencyCurrencyTextBox333.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox334
//
this.solvencyCurrencyTextBox334.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox334.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox334.Location = new System.Drawing.Point(752,617);
this.solvencyCurrencyTextBox334.Name = "solvencyCurrencyTextBox334";
this.solvencyCurrencyTextBox334.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox334.TabIndex = 334;
this.solvencyCurrencyTextBox334.ColName = "R1900C0360";
this.solvencyCurrencyTextBox334.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox334.Enabled = false;
this.solvencyCurrencyTextBox334.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox335
//
this.solvencyCurrencyTextBox335.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox335.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox335.Location = new System.Drawing.Point(859,617);
this.solvencyCurrencyTextBox335.Name = "solvencyCurrencyTextBox335";
this.solvencyCurrencyTextBox335.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox335.TabIndex = 335;
this.solvencyCurrencyTextBox335.ColName = "R1900C0370";
this.solvencyCurrencyTextBox335.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox335.Enabled = false;
this.solvencyCurrencyTextBox335.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox336
//
this.solvencyCurrencyTextBox336.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox336.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox336.Location = new System.Drawing.Point(966,617);
this.solvencyCurrencyTextBox336.Name = "solvencyCurrencyTextBox336";
this.solvencyCurrencyTextBox336.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox336.TabIndex = 336;
this.solvencyCurrencyTextBox336.ColName = "R1900C0380";
this.solvencyCurrencyTextBox336.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox336.Enabled = false;
this.solvencyCurrencyTextBox336.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox337
//
this.solvencyCurrencyTextBox337.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox337.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox337.Location = new System.Drawing.Point(10,637);
this.solvencyCurrencyTextBox337.Name = "solvencyCurrencyTextBox337";
this.solvencyCurrencyTextBox337.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox337.TabIndex = 337;
this.solvencyCurrencyTextBox337.ColName = "R1910C0300";
this.solvencyCurrencyTextBox337.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox338
//
this.solvencyCurrencyTextBox338.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox338.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox338.Location = new System.Drawing.Point(117,637);
this.solvencyCurrencyTextBox338.Name = "solvencyCurrencyTextBox338";
this.solvencyCurrencyTextBox338.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox338.TabIndex = 338;
this.solvencyCurrencyTextBox338.ColName = "R1910C0310";
this.solvencyCurrencyTextBox338.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox338.Enabled = false;
this.solvencyCurrencyTextBox338.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox339
//
this.solvencyCurrencyTextBox339.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox339.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox339.Location = new System.Drawing.Point(224,637);
this.solvencyCurrencyTextBox339.Name = "solvencyCurrencyTextBox339";
this.solvencyCurrencyTextBox339.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox339.TabIndex = 339;
this.solvencyCurrencyTextBox339.ColName = "R1910C0320";
this.solvencyCurrencyTextBox339.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox339.Enabled = false;
this.solvencyCurrencyTextBox339.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox340
//
this.solvencyCurrencyTextBox340.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox340.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox340.Location = new System.Drawing.Point(331,637);
this.solvencyCurrencyTextBox340.Name = "solvencyCurrencyTextBox340";
this.solvencyCurrencyTextBox340.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox340.TabIndex = 340;
this.solvencyCurrencyTextBox340.ColName = "R1910C0330";
this.solvencyCurrencyTextBox340.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox340.Enabled = false;
this.solvencyCurrencyTextBox340.BackColor = System.Drawing.Color.Gray;
//
// SolvencyDataComboBox341
//
this.SolvencyDataComboBox341.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox341.Location = new System.Drawing.Point(438,637);
this.SolvencyDataComboBox341.Name = "SolvencyDataComboBox341";
this.SolvencyDataComboBox341.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox341.TabIndex = 341;
this.SolvencyDataComboBox341.ColName = "R1910C0340";
this.SolvencyDataComboBox341.AxisID = 1321;
this.SolvencyDataComboBox341.OrdinateID = 7077;
this.SolvencyDataComboBox341.StartOrder = 0;
this.SolvencyDataComboBox341.NextOrder = 0;
this.SolvencyDataComboBox341.Enabled = false;
this.SolvencyDataComboBox341.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox342
//
this.solvencyCurrencyTextBox342.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox342.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox342.Location = new System.Drawing.Point(645,637);
this.solvencyCurrencyTextBox342.Name = "solvencyCurrencyTextBox342";
this.solvencyCurrencyTextBox342.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox342.TabIndex = 342;
this.solvencyCurrencyTextBox342.ColName = "R1910C0350";
this.solvencyCurrencyTextBox342.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox343
//
this.solvencyCurrencyTextBox343.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox343.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox343.Location = new System.Drawing.Point(752,637);
this.solvencyCurrencyTextBox343.Name = "solvencyCurrencyTextBox343";
this.solvencyCurrencyTextBox343.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox343.TabIndex = 343;
this.solvencyCurrencyTextBox343.ColName = "R1910C0360";
this.solvencyCurrencyTextBox343.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox344
//
this.solvencyCurrencyTextBox344.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox344.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox344.Location = new System.Drawing.Point(859,637);
this.solvencyCurrencyTextBox344.Name = "solvencyCurrencyTextBox344";
this.solvencyCurrencyTextBox344.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox344.TabIndex = 344;
this.solvencyCurrencyTextBox344.ColName = "R1910C0370";
this.solvencyCurrencyTextBox344.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox345
//
this.solvencyCurrencyTextBox345.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox345.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox345.Location = new System.Drawing.Point(966,637);
this.solvencyCurrencyTextBox345.Name = "solvencyCurrencyTextBox345";
this.solvencyCurrencyTextBox345.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox345.TabIndex = 345;
this.solvencyCurrencyTextBox345.ColName = "R1910C0380";
this.solvencyCurrencyTextBox345.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox346
//
this.solvencyCurrencyTextBox346.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox346.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox346.Location = new System.Drawing.Point(10,657);
this.solvencyCurrencyTextBox346.Name = "solvencyCurrencyTextBox346";
this.solvencyCurrencyTextBox346.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox346.TabIndex = 346;
this.solvencyCurrencyTextBox346.ColName = "R1920C0300";
this.solvencyCurrencyTextBox346.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox346.Enabled = false;
this.solvencyCurrencyTextBox346.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox347
//
this.solvencyCurrencyTextBox347.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox347.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox347.Location = new System.Drawing.Point(117,657);
this.solvencyCurrencyTextBox347.Name = "solvencyCurrencyTextBox347";
this.solvencyCurrencyTextBox347.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox347.TabIndex = 347;
this.solvencyCurrencyTextBox347.ColName = "R1920C0310";
this.solvencyCurrencyTextBox347.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox347.Enabled = false;
this.solvencyCurrencyTextBox347.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox348
//
this.solvencyCurrencyTextBox348.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox348.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox348.Location = new System.Drawing.Point(224,657);
this.solvencyCurrencyTextBox348.Name = "solvencyCurrencyTextBox348";
this.solvencyCurrencyTextBox348.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox348.TabIndex = 348;
this.solvencyCurrencyTextBox348.ColName = "R1920C0320";
this.solvencyCurrencyTextBox348.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox348.Enabled = false;
this.solvencyCurrencyTextBox348.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox349
//
this.solvencyCurrencyTextBox349.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox349.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox349.Location = new System.Drawing.Point(331,657);
this.solvencyCurrencyTextBox349.Name = "solvencyCurrencyTextBox349";
this.solvencyCurrencyTextBox349.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox349.TabIndex = 349;
this.solvencyCurrencyTextBox349.ColName = "R1920C0330";
this.solvencyCurrencyTextBox349.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox349.Enabled = false;
this.solvencyCurrencyTextBox349.BackColor = System.Drawing.Color.Gray;
//
// SolvencyDataComboBox350
//
this.SolvencyDataComboBox350.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox350.Location = new System.Drawing.Point(438,657);
this.SolvencyDataComboBox350.Name = "SolvencyDataComboBox350";
this.SolvencyDataComboBox350.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox350.TabIndex = 350;
this.SolvencyDataComboBox350.ColName = "R1920C0340";
this.SolvencyDataComboBox350.AxisID = 1321;
this.SolvencyDataComboBox350.OrdinateID = 7077;
this.SolvencyDataComboBox350.StartOrder = 0;
this.SolvencyDataComboBox350.NextOrder = 0;
this.SolvencyDataComboBox350.Enabled = false;
this.SolvencyDataComboBox350.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox351
//
this.solvencyCurrencyTextBox351.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox351.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox351.Location = new System.Drawing.Point(645,657);
this.solvencyCurrencyTextBox351.Name = "solvencyCurrencyTextBox351";
this.solvencyCurrencyTextBox351.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox351.TabIndex = 351;
this.solvencyCurrencyTextBox351.ColName = "R1920C0350";
this.solvencyCurrencyTextBox351.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox352
//
this.solvencyCurrencyTextBox352.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox352.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox352.Location = new System.Drawing.Point(752,657);
this.solvencyCurrencyTextBox352.Name = "solvencyCurrencyTextBox352";
this.solvencyCurrencyTextBox352.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox352.TabIndex = 352;
this.solvencyCurrencyTextBox352.ColName = "R1920C0360";
this.solvencyCurrencyTextBox352.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox353
//
this.solvencyCurrencyTextBox353.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox353.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox353.Location = new System.Drawing.Point(859,657);
this.solvencyCurrencyTextBox353.Name = "solvencyCurrencyTextBox353";
this.solvencyCurrencyTextBox353.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox353.TabIndex = 353;
this.solvencyCurrencyTextBox353.ColName = "R1920C0370";
this.solvencyCurrencyTextBox353.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox354
//
this.solvencyCurrencyTextBox354.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox354.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox354.Location = new System.Drawing.Point(966,657);
this.solvencyCurrencyTextBox354.Name = "solvencyCurrencyTextBox354";
this.solvencyCurrencyTextBox354.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox354.TabIndex = 354;
this.solvencyCurrencyTextBox354.ColName = "R1920C0380";
this.solvencyCurrencyTextBox354.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox355
//
this.solvencyCurrencyTextBox355.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox355.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox355.Location = new System.Drawing.Point(10,677);
this.solvencyCurrencyTextBox355.Name = "solvencyCurrencyTextBox355";
this.solvencyCurrencyTextBox355.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox355.TabIndex = 355;
this.solvencyCurrencyTextBox355.ColName = "R1930C0300";
this.solvencyCurrencyTextBox355.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox355.Enabled = false;
this.solvencyCurrencyTextBox355.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox356
//
this.solvencyCurrencyTextBox356.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox356.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox356.Location = new System.Drawing.Point(117,677);
this.solvencyCurrencyTextBox356.Name = "solvencyCurrencyTextBox356";
this.solvencyCurrencyTextBox356.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox356.TabIndex = 356;
this.solvencyCurrencyTextBox356.ColName = "R1930C0310";
this.solvencyCurrencyTextBox356.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox356.Enabled = false;
this.solvencyCurrencyTextBox356.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox357
//
this.solvencyCurrencyTextBox357.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox357.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox357.Location = new System.Drawing.Point(224,677);
this.solvencyCurrencyTextBox357.Name = "solvencyCurrencyTextBox357";
this.solvencyCurrencyTextBox357.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox357.TabIndex = 357;
this.solvencyCurrencyTextBox357.ColName = "R1930C0320";
this.solvencyCurrencyTextBox357.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox357.Enabled = false;
this.solvencyCurrencyTextBox357.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox358
//
this.solvencyCurrencyTextBox358.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox358.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox358.Location = new System.Drawing.Point(331,677);
this.solvencyCurrencyTextBox358.Name = "solvencyCurrencyTextBox358";
this.solvencyCurrencyTextBox358.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox358.TabIndex = 358;
this.solvencyCurrencyTextBox358.ColName = "R1930C0330";
this.solvencyCurrencyTextBox358.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox358.Enabled = false;
this.solvencyCurrencyTextBox358.BackColor = System.Drawing.Color.Gray;
//
// SolvencyDataComboBox359
//
this.SolvencyDataComboBox359.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox359.Location = new System.Drawing.Point(438,677);
this.SolvencyDataComboBox359.Name = "SolvencyDataComboBox359";
this.SolvencyDataComboBox359.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox359.TabIndex = 359;
this.SolvencyDataComboBox359.ColName = "R1930C0340";
this.SolvencyDataComboBox359.AxisID = 1321;
this.SolvencyDataComboBox359.OrdinateID = 7077;
this.SolvencyDataComboBox359.StartOrder = 0;
this.SolvencyDataComboBox359.NextOrder = 0;
this.SolvencyDataComboBox359.Enabled = false;
this.SolvencyDataComboBox359.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox360
//
this.solvencyCurrencyTextBox360.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox360.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox360.Location = new System.Drawing.Point(645,677);
this.solvencyCurrencyTextBox360.Name = "solvencyCurrencyTextBox360";
this.solvencyCurrencyTextBox360.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox360.TabIndex = 360;
this.solvencyCurrencyTextBox360.ColName = "R1930C0350";
this.solvencyCurrencyTextBox360.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox361
//
this.solvencyCurrencyTextBox361.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox361.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox361.Location = new System.Drawing.Point(752,677);
this.solvencyCurrencyTextBox361.Name = "solvencyCurrencyTextBox361";
this.solvencyCurrencyTextBox361.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox361.TabIndex = 361;
this.solvencyCurrencyTextBox361.ColName = "R1930C0360";
this.solvencyCurrencyTextBox361.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox361.Enabled = false;
this.solvencyCurrencyTextBox361.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox362
//
this.solvencyCurrencyTextBox362.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox362.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox362.Location = new System.Drawing.Point(859,677);
this.solvencyCurrencyTextBox362.Name = "solvencyCurrencyTextBox362";
this.solvencyCurrencyTextBox362.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox362.TabIndex = 362;
this.solvencyCurrencyTextBox362.ColName = "R1930C0370";
this.solvencyCurrencyTextBox362.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox362.Enabled = false;
this.solvencyCurrencyTextBox362.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox363
//
this.solvencyCurrencyTextBox363.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox363.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox363.Location = new System.Drawing.Point(966,677);
this.solvencyCurrencyTextBox363.Name = "solvencyCurrencyTextBox363";
this.solvencyCurrencyTextBox363.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox363.TabIndex = 363;
this.solvencyCurrencyTextBox363.ColName = "R1930C0380";
this.solvencyCurrencyTextBox363.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox364
//
this.solvencyCurrencyTextBox364.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox364.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox364.Location = new System.Drawing.Point(10,697);
this.solvencyCurrencyTextBox364.Name = "solvencyCurrencyTextBox364";
this.solvencyCurrencyTextBox364.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox364.TabIndex = 364;
this.solvencyCurrencyTextBox364.ColName = "R1940C0300";
this.solvencyCurrencyTextBox364.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox364.Enabled = false;
this.solvencyCurrencyTextBox364.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox365
//
this.solvencyCurrencyTextBox365.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox365.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox365.Location = new System.Drawing.Point(117,697);
this.solvencyCurrencyTextBox365.Name = "solvencyCurrencyTextBox365";
this.solvencyCurrencyTextBox365.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox365.TabIndex = 365;
this.solvencyCurrencyTextBox365.ColName = "R1940C0310";
this.solvencyCurrencyTextBox365.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox365.Enabled = false;
this.solvencyCurrencyTextBox365.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox366
//
this.solvencyCurrencyTextBox366.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox366.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox366.Location = new System.Drawing.Point(224,697);
this.solvencyCurrencyTextBox366.Name = "solvencyCurrencyTextBox366";
this.solvencyCurrencyTextBox366.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox366.TabIndex = 366;
this.solvencyCurrencyTextBox366.ColName = "R1940C0320";
this.solvencyCurrencyTextBox366.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox366.Enabled = false;
this.solvencyCurrencyTextBox366.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox367
//
this.solvencyCurrencyTextBox367.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox367.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox367.Location = new System.Drawing.Point(331,697);
this.solvencyCurrencyTextBox367.Name = "solvencyCurrencyTextBox367";
this.solvencyCurrencyTextBox367.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox367.TabIndex = 367;
this.solvencyCurrencyTextBox367.ColName = "R1940C0330";
this.solvencyCurrencyTextBox367.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox367.Enabled = false;
this.solvencyCurrencyTextBox367.BackColor = System.Drawing.Color.Gray;
//
// SolvencyDataComboBox368
//
this.SolvencyDataComboBox368.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox368.Location = new System.Drawing.Point(438,697);
this.SolvencyDataComboBox368.Name = "SolvencyDataComboBox368";
this.SolvencyDataComboBox368.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox368.TabIndex = 368;
this.SolvencyDataComboBox368.ColName = "R1940C0340";
this.SolvencyDataComboBox368.AxisID = 1321;
this.SolvencyDataComboBox368.OrdinateID = 7077;
this.SolvencyDataComboBox368.StartOrder = 0;
this.SolvencyDataComboBox368.NextOrder = 0;
this.SolvencyDataComboBox368.Enabled = false;
this.SolvencyDataComboBox368.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox369
//
this.solvencyCurrencyTextBox369.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox369.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox369.Location = new System.Drawing.Point(645,697);
this.solvencyCurrencyTextBox369.Name = "solvencyCurrencyTextBox369";
this.solvencyCurrencyTextBox369.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox369.TabIndex = 369;
this.solvencyCurrencyTextBox369.ColName = "R1940C0350";
this.solvencyCurrencyTextBox369.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox370
//
this.solvencyCurrencyTextBox370.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox370.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox370.Location = new System.Drawing.Point(752,697);
this.solvencyCurrencyTextBox370.Name = "solvencyCurrencyTextBox370";
this.solvencyCurrencyTextBox370.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox370.TabIndex = 370;
this.solvencyCurrencyTextBox370.ColName = "R1940C0360";
this.solvencyCurrencyTextBox370.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox370.Enabled = false;
this.solvencyCurrencyTextBox370.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox371
//
this.solvencyCurrencyTextBox371.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox371.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox371.Location = new System.Drawing.Point(859,697);
this.solvencyCurrencyTextBox371.Name = "solvencyCurrencyTextBox371";
this.solvencyCurrencyTextBox371.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox371.TabIndex = 371;
this.solvencyCurrencyTextBox371.ColName = "R1940C0370";
this.solvencyCurrencyTextBox371.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox371.Enabled = false;
this.solvencyCurrencyTextBox371.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox372
//
this.solvencyCurrencyTextBox372.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox372.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox372.Location = new System.Drawing.Point(966,697);
this.solvencyCurrencyTextBox372.Name = "solvencyCurrencyTextBox372";
this.solvencyCurrencyTextBox372.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox372.TabIndex = 372;
this.solvencyCurrencyTextBox372.ColName = "R1940C0380";
this.solvencyCurrencyTextBox372.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// splitContainerColTitles
//
this.splitContainerColTitles.Dock = System.Windows.Forms.DockStyle.Fill;
this.splitContainerColTitles.Location = new System.Drawing.Point(0,0);
this.splitContainerColTitles.Name = "splitContainerColTitles";
this.splitContainerColTitles.Orientation = System.Windows.Forms.Orientation.Vertical;
this.splitContainerColTitles.Panel1MinSize = 0;
//
// splitContainerColTitles.Panel1
//
//
// splitContainerColTitles.Panel2
//
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel0);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel1);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel2);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel3);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel4);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel5);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel6);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel7);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel8);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel9);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel10);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel11);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel12);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel13);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel14);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel15);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel16);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel17);
this.splitContainerColTitles.Size = new System.Drawing.Size(1512, 407);
this.splitContainerColTitles.SplitterDistance = 332;
//
// splitContainerRowTitles
//
this.splitContainerRowTitles.Dock = System.Windows.Forms.DockStyle.Fill;
this.splitContainerRowTitles.Location = new System.Drawing.Point(0,0);
this.splitContainerRowTitles.Name = "splitContainerRowTitles";
this.splitContainerRowTitles.Orientation = System.Windows.Forms.Orientation.Vertical;
this.splitContainerRowTitles.Panel1MinSize = 0;
//
// splitContainerRowTitles.Panel1
//
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel18);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel19);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel20);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel21);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel22);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel23);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel24);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel25);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel26);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel27);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel28);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel29);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel30);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel31);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel32);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel33);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel34);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel35);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel36);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel37);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel38);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel39);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel40);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel41);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel42);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel43);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel44);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel45);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel46);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel47);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel48);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel49);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel50);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel51);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel52);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel53);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel54);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel55);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel56);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel57);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel58);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel59);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel60);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel61);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel62);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel63);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel64);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel65);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel66);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel67);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel68);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel69);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel70);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel71);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel72);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel73);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel74);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel75);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel76);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel77);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel78);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel79);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel80);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel81);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel82);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel83);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel84);
//
// splitContainerRowTitles.Panel2
//
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox85);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox86);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox87);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox88);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox89);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox90);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox91);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox92);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox93);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox94);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox95);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox96);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox97);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox98);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox99);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox100);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox101);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox102);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox103);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox104);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox105);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox106);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox107);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox108);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox109);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox110);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox111);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox112);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox113);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox114);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox115);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox116);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox117);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox118);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox119);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox120);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox121);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox122);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox123);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox124);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox125);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox126);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox127);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox128);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox129);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox130);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox131);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox132);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox133);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox134);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox135);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox136);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox137);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox138);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox139);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox140);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox141);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox142);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox143);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox144);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox145);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox146);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox147);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox148);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox149);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox150);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox151);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox152);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox153);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox154);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox155);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox156);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox157);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox158);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox159);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox160);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox161);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox162);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox163);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox164);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox165);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox166);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox167);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox168);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox169);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox170);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox171);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox172);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox173);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox174);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox175);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox176);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox177);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox178);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox179);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox180);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox181);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox182);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox183);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox184);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox185);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox186);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox187);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox188);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox189);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox190);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox191);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox192);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox193);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox194);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox195);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox196);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox197);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox198);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox199);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox200);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox201);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox202);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox203);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox204);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox205);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox206);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox207);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox208);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox209);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox210);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox211);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox212);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox213);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox214);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox215);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox216);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox217);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox218);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox219);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox220);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox221);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox222);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox223);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox224);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox225);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox226);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox227);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox228);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox229);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox230);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox231);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox232);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox233);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox234);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox235);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox236);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox237);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox238);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox239);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox240);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox241);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox242);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox243);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox244);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox245);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox246);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox247);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox248);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox249);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox250);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox251);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox252);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox253);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox254);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox255);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox256);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox257);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox258);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox259);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox260);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox261);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox262);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox263);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox264);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox265);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox266);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox267);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox268);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox269);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox270);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox271);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox272);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox273);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox274);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox275);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox276);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox277);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox278);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox279);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox280);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox281);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox282);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox283);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox284);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox285);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox286);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox287);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox288);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox289);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox290);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox291);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox292);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox293);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox294);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox295);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox296);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox297);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox298);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox299);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox300);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox301);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox302);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox303);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox304);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox305);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox306);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox307);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox308);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox309);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox310);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox311);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox312);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox313);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox314);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox315);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox316);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox317);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox318);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox319);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox320);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox321);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox322);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox323);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox324);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox325);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox326);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox327);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox328);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox329);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox330);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox331);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox332);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox333);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox334);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox335);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox336);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox337);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox338);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox339);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox340);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox341);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox342);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox343);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox344);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox345);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox346);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox347);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox348);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox349);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox350);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox351);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox352);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox353);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox354);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox355);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox356);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox357);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox358);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox359);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox360);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox361);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox362);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox363);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox364);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox365);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox366);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox367);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox368);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox369);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox370);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox371);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox372);
this.splitContainerRowTitles.Panel2.AutoScroll = true;
this.splitContainerRowTitles.Size = new System.Drawing.Size(1512, 407);
this.splitContainerRowTitles.SplitterDistance = 332;
//
// spltMain
//
this.spltMain.Dock = System.Windows.Forms.DockStyle.Fill;
this.spltMain.Location = new System.Drawing.Point(0,0);
this.spltMain.Name = "spltMain";
this.spltMain.Orientation = System.Windows.Forms.Orientation.Horizontal;
this.spltMain.Panel1MinSize = 0;
//
// spltMain.Panel1
//
this.spltMain.Panel1.Controls.Add(this.splitContainerColTitles);
//
// spltMain.Panel2
//
this.spltMain.Panel2.Controls.Add(this.splitContainerRowTitles);
this.spltMain.Panel2.AutoScroll = true;
this.spltMain.Size = new System.Drawing.Size(1512, 870);
this.spltMain.SplitterDistance = 75;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F); 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font; 
this.Controls.Add(this.spltMain);
            this.Name = "S_27_01_04_05__sol2__2_0_1_ctrl"; 
            this.Size = new System.Drawing.Size(1512, 795); 
            this.Load += new System.EventHandler(this.BoundControl_Load);
            this.ResumeLayout(false); 
            this.PerformLayout(); 

      } 
private SolvencyLabel solvencyLabel0;
private SolvencyLabel solvencyLabel1;
private SolvencyLabel solvencyLabel2;
private SolvencyLabel solvencyLabel3;
private SolvencyLabel solvencyLabel4;
private SolvencyLabel solvencyLabel5;
private SolvencyLabel solvencyLabel6;
private SolvencyLabel solvencyLabel7;
private SolvencyLabel solvencyLabel8;
private SolvencyLabel solvencyLabel9;
private SolvencyLabel solvencyLabel10;
private SolvencyLabel solvencyLabel11;
private SolvencyLabel solvencyLabel12;
private SolvencyLabel solvencyLabel13;
private SolvencyLabel solvencyLabel14;
private SolvencyLabel solvencyLabel15;
private SolvencyLabel solvencyLabel16;
private SolvencyLabel solvencyLabel17;
private SolvencyLabel solvencyLabel18;
private SolvencyLabel solvencyLabel19;
private SolvencyLabel solvencyLabel20;
private SolvencyLabel solvencyLabel21;
private SolvencyLabel solvencyLabel22;
private SolvencyLabel solvencyLabel23;
private SolvencyLabel solvencyLabel24;
private SolvencyLabel solvencyLabel25;
private SolvencyLabel solvencyLabel26;
private SolvencyLabel solvencyLabel27;
private SolvencyLabel solvencyLabel28;
private SolvencyLabel solvencyLabel29;
private SolvencyLabel solvencyLabel30;
private SolvencyLabel solvencyLabel31;
private SolvencyLabel solvencyLabel32;
private SolvencyLabel solvencyLabel33;
private SolvencyLabel solvencyLabel34;
private SolvencyLabel solvencyLabel35;
private SolvencyLabel solvencyLabel36;
private SolvencyLabel solvencyLabel37;
private SolvencyLabel solvencyLabel38;
private SolvencyLabel solvencyLabel39;
private SolvencyLabel solvencyLabel40;
private SolvencyLabel solvencyLabel41;
private SolvencyLabel solvencyLabel42;
private SolvencyLabel solvencyLabel43;
private SolvencyLabel solvencyLabel44;
private SolvencyLabel solvencyLabel45;
private SolvencyLabel solvencyLabel46;
private SolvencyLabel solvencyLabel47;
private SolvencyLabel solvencyLabel48;
private SolvencyLabel solvencyLabel49;
private SolvencyLabel solvencyLabel50;
private SolvencyLabel solvencyLabel51;
private SolvencyLabel solvencyLabel52;
private SolvencyLabel solvencyLabel53;
private SolvencyLabel solvencyLabel54;
private SolvencyLabel solvencyLabel55;
private SolvencyLabel solvencyLabel56;
private SolvencyLabel solvencyLabel57;
private SolvencyLabel solvencyLabel58;
private SolvencyLabel solvencyLabel59;
private SolvencyLabel solvencyLabel60;
private SolvencyLabel solvencyLabel61;
private SolvencyLabel solvencyLabel62;
private SolvencyLabel solvencyLabel63;
private SolvencyLabel solvencyLabel64;
private SolvencyLabel solvencyLabel65;
private SolvencyLabel solvencyLabel66;
private SolvencyLabel solvencyLabel67;
private SolvencyLabel solvencyLabel68;
private SolvencyLabel solvencyLabel69;
private SolvencyLabel solvencyLabel70;
private SolvencyLabel solvencyLabel71;
private SolvencyLabel solvencyLabel72;
private SolvencyLabel solvencyLabel73;
private SolvencyLabel solvencyLabel74;
private SolvencyLabel solvencyLabel75;
private SolvencyLabel solvencyLabel76;
private SolvencyLabel solvencyLabel77;
private SolvencyLabel solvencyLabel78;
private SolvencyLabel solvencyLabel79;
private SolvencyLabel solvencyLabel80;
private SolvencyLabel solvencyLabel81;
private SolvencyLabel solvencyLabel82;
private SolvencyLabel solvencyLabel83;
private SolvencyLabel solvencyLabel84;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox85;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox86;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox87;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox88;
private SolvencyDataComboBox SolvencyDataComboBox89;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox90;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox91;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox92;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox93;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox94;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox95;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox96;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox97;
private SolvencyDataComboBox SolvencyDataComboBox98;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox99;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox100;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox101;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox102;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox103;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox104;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox105;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox106;
private SolvencyDataComboBox SolvencyDataComboBox107;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox108;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox109;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox110;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox111;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox112;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox113;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox114;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox115;
private SolvencyDataComboBox SolvencyDataComboBox116;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox117;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox118;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox119;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox120;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox121;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox122;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox123;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox124;
private SolvencyDataComboBox SolvencyDataComboBox125;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox126;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox127;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox128;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox129;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox130;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox131;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox132;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox133;
private SolvencyDataComboBox SolvencyDataComboBox134;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox135;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox136;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox137;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox138;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox139;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox140;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox141;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox142;
private SolvencyDataComboBox SolvencyDataComboBox143;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox144;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox145;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox146;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox147;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox148;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox149;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox150;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox151;
private SolvencyDataComboBox SolvencyDataComboBox152;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox153;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox154;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox155;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox156;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox157;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox158;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox159;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox160;
private SolvencyDataComboBox SolvencyDataComboBox161;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox162;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox163;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox164;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox165;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox166;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox167;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox168;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox169;
private SolvencyDataComboBox SolvencyDataComboBox170;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox171;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox172;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox173;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox174;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox175;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox176;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox177;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox178;
private SolvencyDataComboBox SolvencyDataComboBox179;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox180;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox181;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox182;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox183;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox184;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox185;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox186;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox187;
private SolvencyDataComboBox SolvencyDataComboBox188;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox189;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox190;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox191;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox192;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox193;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox194;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox195;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox196;
private SolvencyDataComboBox SolvencyDataComboBox197;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox198;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox199;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox200;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox201;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox202;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox203;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox204;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox205;
private SolvencyDataComboBox SolvencyDataComboBox206;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox207;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox208;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox209;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox210;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox211;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox212;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox213;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox214;
private SolvencyDataComboBox SolvencyDataComboBox215;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox216;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox217;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox218;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox219;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox220;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox221;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox222;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox223;
private SolvencyDataComboBox SolvencyDataComboBox224;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox225;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox226;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox227;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox228;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox229;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox230;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox231;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox232;
private SolvencyDataComboBox SolvencyDataComboBox233;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox234;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox235;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox236;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox237;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox238;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox239;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox240;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox241;
private SolvencyDataComboBox SolvencyDataComboBox242;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox243;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox244;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox245;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox246;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox247;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox248;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox249;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox250;
private SolvencyDataComboBox SolvencyDataComboBox251;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox252;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox253;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox254;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox255;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox256;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox257;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox258;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox259;
private SolvencyDataComboBox SolvencyDataComboBox260;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox261;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox262;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox263;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox264;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox265;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox266;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox267;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox268;
private SolvencyDataComboBox SolvencyDataComboBox269;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox270;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox271;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox272;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox273;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox274;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox275;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox276;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox277;
private SolvencyDataComboBox SolvencyDataComboBox278;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox279;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox280;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox281;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox282;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox283;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox284;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox285;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox286;
private SolvencyDataComboBox SolvencyDataComboBox287;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox288;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox289;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox290;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox291;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox292;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox293;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox294;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox295;
private SolvencyDataComboBox SolvencyDataComboBox296;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox297;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox298;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox299;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox300;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox301;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox302;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox303;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox304;
private SolvencyDataComboBox SolvencyDataComboBox305;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox306;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox307;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox308;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox309;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox310;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox311;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox312;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox313;
private SolvencyDataComboBox SolvencyDataComboBox314;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox315;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox316;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox317;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox318;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox319;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox320;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox321;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox322;
private SolvencyDataComboBox SolvencyDataComboBox323;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox324;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox325;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox326;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox327;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox328;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox329;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox330;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox331;
private SolvencyDataComboBox SolvencyDataComboBox332;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox333;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox334;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox335;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox336;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox337;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox338;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox339;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox340;
private SolvencyDataComboBox SolvencyDataComboBox341;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox342;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox343;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox344;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox345;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox346;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox347;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox348;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox349;
private SolvencyDataComboBox SolvencyDataComboBox350;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox351;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox352;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox353;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox354;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox355;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox356;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox357;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox358;
private SolvencyDataComboBox SolvencyDataComboBox359;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox360;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox361;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox362;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox363;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox364;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox365;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox366;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox367;
private SolvencyDataComboBox SolvencyDataComboBox368;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox369;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox370;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox371;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox372;
private SolvencySplitContainer splitContainerColTitles;
private SolvencySplitContainer splitContainerRowTitles;
private SolvencySplitContainer spltMain;

   }
}

