using SolvencyII.Domain.ENumerators; 
using SolvencyII.UI.Shared.Controls; 

namespace SolvencyII.UI.UserControls 
{ 
   partial class S_27_01_04_04__sol2__2_0_1_ctrl 
   { 
      private void InitializeComponent() 
      { 
this.solvencyLabel0 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel1 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel2 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel3 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel4 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel5 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel6 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel7 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel8 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel9 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel10 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel11 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel12 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel13 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel14 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel15 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel16 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel17 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel18 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel19 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel20 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel21 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel22 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel23 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel24 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel25 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel26 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel27 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel28 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel29 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel30 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel31 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel32 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel33 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel34 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel35 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel36 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel37 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel38 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel39 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel40 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel41 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel42 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel43 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel44 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel45 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel46 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel47 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel48 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel49 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel50 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel51 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel52 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel53 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel54 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel55 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel56 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel57 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel58 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel59 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel60 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel61 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel62 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel63 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel64 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel65 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel66 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel67 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel68 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel69 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel70 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel71 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel72 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel73 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel74 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel75 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel76 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel77 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel78 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel79 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel80 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel81 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel82 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel83 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel84 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel85 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel86 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel87 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel88 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel89 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel90 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel91 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel92 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel93 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel94 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyCurrencyTextBox95 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox96 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox97 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox98 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox99 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox100 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox101 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox102 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox103 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox104 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox105 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox106 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox107 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox108 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox109 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox110 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox111 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox112 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox113 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox114 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox115 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox116 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox117 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox118 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox119 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox120 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox121 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox122 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox123 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox124 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox125 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox126 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox127 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox128 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox129 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox130 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox131 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox132 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox133 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox134 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox135 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox136 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox137 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox138 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox139 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox140 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox141 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox142 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox143 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox144 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox145 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox146 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox147 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox148 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox149 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox150 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox151 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox152 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox153 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox154 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox155 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox156 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox157 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox158 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox159 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox160 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox161 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox162 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox163 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox164 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox165 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox166 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox167 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox168 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox169 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox170 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox171 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox172 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox173 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox174 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox175 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox176 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox177 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox178 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox179 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox180 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox181 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox182 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox183 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox184 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox185 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox186 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox187 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox188 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox189 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox190 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox191 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox192 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox193 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox194 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox195 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox196 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox197 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox198 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox199 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox200 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox201 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox202 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox203 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox204 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox205 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox206 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox207 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox208 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox209 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox210 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox211 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox212 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox213 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox214 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox215 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox216 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox217 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox218 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox219 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox220 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox221 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox222 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox223 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox224 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox225 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox226 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox227 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox228 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox229 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox230 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox231 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox232 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox233 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox234 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox235 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox236 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox237 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox238 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox239 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox240 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox241 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox242 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox243 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox244 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox245 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox246 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox247 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox248 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox249 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox250 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox251 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox252 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox253 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox254 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox255 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox256 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox257 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox258 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox259 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox260 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox261 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox262 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox263 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox264 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox265 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox266 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox267 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox268 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox269 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox270 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox271 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox272 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox273 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox274 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox275 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox276 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox277 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox278 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox279 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox280 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox281 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox282 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox283 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox284 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox285 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox286 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox287 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox288 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox289 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox290 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox291 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox292 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox293 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox294 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox295 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox296 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox297 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox298 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox299 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox300 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox301 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox302 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox303 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox304 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox305 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox306 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox307 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox308 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox309 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox310 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox311 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox312 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox313 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox314 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox315 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox316 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox317 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox318 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox319 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox320 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox321 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox322 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox323 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox324 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox325 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox326 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox327 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox328 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox329 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox330 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox331 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox332 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox333 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox334 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox335 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox336 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox337 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox338 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox339 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox340 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox341 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox342 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox343 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox344 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox345 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox346 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox347 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox348 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox349 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox350 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox351 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox352 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox353 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox354 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox355 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox356 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox357 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox358 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox359 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox360 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox361 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox362 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox363 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox364 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox365 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox366 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox367 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox368 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox369 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox370 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox371 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox372 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox373 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox374 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox375 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox376 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox377 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox378 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox379 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox380 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox381 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox382 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox383 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox384 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox385 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox386 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox387 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox388 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox389 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox390 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox391 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox392 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox393 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox394 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox395 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox396 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox397 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox398 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox399 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox400 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox401 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox402 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox403 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox404 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox405 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox406 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox407 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox408 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox409 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox410 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox411 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox412 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox413 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox414 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox415 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox416 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox417 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox418 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox419 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox420 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox421 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox422 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox423 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox424 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox425 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox426 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox427 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.splitContainerColTitles = new SolvencyII.UI.Shared.Controls.SolvencySplitContainer();
this.splitContainerRowTitles = new SolvencyII.UI.Shared.Controls.SolvencySplitContainer();
this.spltMain = new SolvencyII.UI.Shared.Controls.SolvencySplitContainer();
            this.SuspendLayout(); 

//
// solvencyLabel0
//
this.solvencyLabel0.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel0.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel0.Location = new System.Drawing.Point(966,10);
this.solvencyLabel0.Name = "solvencyLabel0";
this.solvencyLabel0.OrdinateID_Label = 7033;
this.solvencyLabel0.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel0.TabIndex = 0;
this.solvencyLabel0.Text = "Catastrophe Risk Charge after risk mitigation" ;
this.solvencyLabel0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel0.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel1
//
this.solvencyLabel1.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel1.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel1.Location = new System.Drawing.Point(966,55);
this.solvencyLabel1.Name = "solvencyLabel1";
this.solvencyLabel1.OrdinateID_Label = 0;
this.solvencyLabel1.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel1.TabIndex = 1;
this.solvencyLabel1.Text = "C0290" ;
this.solvencyLabel1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel2
//
this.solvencyLabel2.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel2.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel2.Location = new System.Drawing.Point(859,10);
this.solvencyLabel2.Name = "solvencyLabel2";
this.solvencyLabel2.OrdinateID_Label = 7032;
this.solvencyLabel2.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel2.TabIndex = 2;
this.solvencyLabel2.Text = "Estimated Reinstatement Premiums" ;
this.solvencyLabel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel3
//
this.solvencyLabel3.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel3.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel3.Location = new System.Drawing.Point(859,55);
this.solvencyLabel3.Name = "solvencyLabel3";
this.solvencyLabel3.OrdinateID_Label = 0;
this.solvencyLabel3.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel3.TabIndex = 3;
this.solvencyLabel3.Text = "C0280" ;
this.solvencyLabel3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel4
//
this.solvencyLabel4.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel4.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel4.Location = new System.Drawing.Point(752,10);
this.solvencyLabel4.Name = "solvencyLabel4";
this.solvencyLabel4.OrdinateID_Label = 7031;
this.solvencyLabel4.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel4.TabIndex = 4;
this.solvencyLabel4.Text = "Estimated Risk Mitigation" ;
this.solvencyLabel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel5
//
this.solvencyLabel5.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel5.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel5.Location = new System.Drawing.Point(752,55);
this.solvencyLabel5.Name = "solvencyLabel5";
this.solvencyLabel5.OrdinateID_Label = 0;
this.solvencyLabel5.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel5.TabIndex = 5;
this.solvencyLabel5.Text = "C0270" ;
this.solvencyLabel5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel6
//
this.solvencyLabel6.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel6.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel6.Location = new System.Drawing.Point(645,10);
this.solvencyLabel6.Name = "solvencyLabel6";
this.solvencyLabel6.OrdinateID_Label = 7030;
this.solvencyLabel6.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel6.TabIndex = 6;
this.solvencyLabel6.Text = "Catastrophe Risk Charge before risk mitigation" ;
this.solvencyLabel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel6.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel7
//
this.solvencyLabel7.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel7.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel7.Location = new System.Drawing.Point(645,55);
this.solvencyLabel7.Name = "solvencyLabel7";
this.solvencyLabel7.OrdinateID_Label = 0;
this.solvencyLabel7.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel7.TabIndex = 7;
this.solvencyLabel7.Text = "C0260" ;
this.solvencyLabel7.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel8
//
this.solvencyLabel8.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel8.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel8.Location = new System.Drawing.Point(438,10);
this.solvencyLabel8.Name = "solvencyLabel8";
this.solvencyLabel8.OrdinateID_Label = 7029;
this.solvencyLabel8.Size = new System.Drawing.Size(208, 45);
this.solvencyLabel8.TabIndex = 8;
this.solvencyLabel8.Text = "Scenario A or B" ;
this.solvencyLabel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel8.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel9
//
this.solvencyLabel9.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel9.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel9.Location = new System.Drawing.Point(438,55);
this.solvencyLabel9.Name = "solvencyLabel9";
this.solvencyLabel9.OrdinateID_Label = 0;
this.solvencyLabel9.Size = new System.Drawing.Size(208, 13);
this.solvencyLabel9.TabIndex = 9;
this.solvencyLabel9.Text = "C0250" ;
this.solvencyLabel9.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel10
//
this.solvencyLabel10.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel10.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel10.Location = new System.Drawing.Point(331,10);
this.solvencyLabel10.Name = "solvencyLabel10";
this.solvencyLabel10.OrdinateID_Label = 7028;
this.solvencyLabel10.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel10.TabIndex = 10;
this.solvencyLabel10.Text = "Catastrophe Risk Charge Factor before risk mitigation" ;
this.solvencyLabel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel10.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel11
//
this.solvencyLabel11.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel11.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel11.Location = new System.Drawing.Point(331,55);
this.solvencyLabel11.Name = "solvencyLabel11";
this.solvencyLabel11.OrdinateID_Label = 0;
this.solvencyLabel11.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel11.TabIndex = 11;
this.solvencyLabel11.Text = "C0240" ;
this.solvencyLabel11.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel12
//
this.solvencyLabel12.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel12.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel12.Location = new System.Drawing.Point(224,10);
this.solvencyLabel12.Name = "solvencyLabel12";
this.solvencyLabel12.OrdinateID_Label = 7027;
this.solvencyLabel12.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel12.TabIndex = 12;
this.solvencyLabel12.Text = "Specified Gross Loss" ;
this.solvencyLabel12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel12.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel13
//
this.solvencyLabel13.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel13.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel13.Location = new System.Drawing.Point(224,55);
this.solvencyLabel13.Name = "solvencyLabel13";
this.solvencyLabel13.OrdinateID_Label = 0;
this.solvencyLabel13.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel13.TabIndex = 13;
this.solvencyLabel13.Text = "C0230" ;
this.solvencyLabel13.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel14
//
this.solvencyLabel14.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel14.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel14.Location = new System.Drawing.Point(117,10);
this.solvencyLabel14.Name = "solvencyLabel14";
this.solvencyLabel14.OrdinateID_Label = 7026;
this.solvencyLabel14.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel14.TabIndex = 14;
this.solvencyLabel14.Text = "Exposure" ;
this.solvencyLabel14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel14.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel15
//
this.solvencyLabel15.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel15.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel15.Location = new System.Drawing.Point(117,55);
this.solvencyLabel15.Name = "solvencyLabel15";
this.solvencyLabel15.OrdinateID_Label = 0;
this.solvencyLabel15.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel15.TabIndex = 15;
this.solvencyLabel15.Text = "C0220" ;
this.solvencyLabel15.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel16
//
this.solvencyLabel16.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel16.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel16.Location = new System.Drawing.Point(10,10);
this.solvencyLabel16.Name = "solvencyLabel16";
this.solvencyLabel16.OrdinateID_Label = 7025;
this.solvencyLabel16.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel16.TabIndex = 16;
this.solvencyLabel16.Text = "Estimation of the gross premiums to be earned" ;
this.solvencyLabel16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel16.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel17
//
this.solvencyLabel17.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel17.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel17.Location = new System.Drawing.Point(10,55);
this.solvencyLabel17.Name = "solvencyLabel17";
this.solvencyLabel17.OrdinateID_Label = 0;
this.solvencyLabel17.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel17.TabIndex = 17;
this.solvencyLabel17.Text = "C0210" ;
this.solvencyLabel17.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel18
//
this.solvencyLabel18.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel18.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel18.Location = new System.Drawing.Point(10,3);
this.solvencyLabel18.Name = "solvencyLabel18";
this.solvencyLabel18.OrdinateID_Label = 7034;
this.solvencyLabel18.Size = new System.Drawing.Size(261, 15);
this.solvencyLabel18.TabIndex = 18;
this.solvencyLabel18.Text = "Natural Catastrophe risk - Flood" ;
this.solvencyLabel18.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel19
//
this.solvencyLabel19.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel19.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel19.Location = new System.Drawing.Point(285,3);
this.solvencyLabel19.Name = "solvencyLabel19";
this.solvencyLabel19.OrdinateID_Label = 0;
this.solvencyLabel19.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel19.TabIndex = 19;
this.solvencyLabel19.Text = "" ;
this.solvencyLabel19.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel20
//
this.solvencyLabel20.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel20.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel20.Location = new System.Drawing.Point(17,23);
this.solvencyLabel20.Name = "solvencyLabel20";
this.solvencyLabel20.OrdinateID_Label = 7035;
this.solvencyLabel20.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel20.TabIndex = 20;
this.solvencyLabel20.Text = "Republic of Austria" ;
this.solvencyLabel20.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel21
//
this.solvencyLabel21.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel21.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel21.Location = new System.Drawing.Point(285,23);
this.solvencyLabel21.Name = "solvencyLabel21";
this.solvencyLabel21.OrdinateID_Label = 0;
this.solvencyLabel21.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel21.TabIndex = 21;
this.solvencyLabel21.Text = "R1260" ;
this.solvencyLabel21.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel22
//
this.solvencyLabel22.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel22.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel22.Location = new System.Drawing.Point(17,43);
this.solvencyLabel22.Name = "solvencyLabel22";
this.solvencyLabel22.OrdinateID_Label = 7036;
this.solvencyLabel22.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel22.TabIndex = 22;
this.solvencyLabel22.Text = "Kingdom of Belgium" ;
this.solvencyLabel22.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel23
//
this.solvencyLabel23.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel23.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel23.Location = new System.Drawing.Point(285,43);
this.solvencyLabel23.Name = "solvencyLabel23";
this.solvencyLabel23.OrdinateID_Label = 0;
this.solvencyLabel23.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel23.TabIndex = 23;
this.solvencyLabel23.Text = "R1270" ;
this.solvencyLabel23.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel24
//
this.solvencyLabel24.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel24.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel24.Location = new System.Drawing.Point(17,63);
this.solvencyLabel24.Name = "solvencyLabel24";
this.solvencyLabel24.OrdinateID_Label = 7037;
this.solvencyLabel24.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel24.TabIndex = 24;
this.solvencyLabel24.Text = "Republic of Bulgaria" ;
this.solvencyLabel24.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel25
//
this.solvencyLabel25.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel25.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel25.Location = new System.Drawing.Point(285,63);
this.solvencyLabel25.Name = "solvencyLabel25";
this.solvencyLabel25.OrdinateID_Label = 0;
this.solvencyLabel25.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel25.TabIndex = 25;
this.solvencyLabel25.Text = "R1280" ;
this.solvencyLabel25.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel26
//
this.solvencyLabel26.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel26.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel26.Location = new System.Drawing.Point(17,83);
this.solvencyLabel26.Name = "solvencyLabel26";
this.solvencyLabel26.OrdinateID_Label = 7038;
this.solvencyLabel26.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel26.TabIndex = 26;
this.solvencyLabel26.Text = "Czech Republic" ;
this.solvencyLabel26.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel27
//
this.solvencyLabel27.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel27.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel27.Location = new System.Drawing.Point(285,83);
this.solvencyLabel27.Name = "solvencyLabel27";
this.solvencyLabel27.OrdinateID_Label = 0;
this.solvencyLabel27.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel27.TabIndex = 27;
this.solvencyLabel27.Text = "R1290" ;
this.solvencyLabel27.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel28
//
this.solvencyLabel28.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel28.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel28.Location = new System.Drawing.Point(17,103);
this.solvencyLabel28.Name = "solvencyLabel28";
this.solvencyLabel28.OrdinateID_Label = 7039;
this.solvencyLabel28.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel28.TabIndex = 28;
this.solvencyLabel28.Text = "Swiss Confederation; Principality of Lichtenstein" ;
this.solvencyLabel28.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel29
//
this.solvencyLabel29.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel29.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel29.Location = new System.Drawing.Point(285,103);
this.solvencyLabel29.Name = "solvencyLabel29";
this.solvencyLabel29.OrdinateID_Label = 0;
this.solvencyLabel29.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel29.TabIndex = 29;
this.solvencyLabel29.Text = "R1300" ;
this.solvencyLabel29.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel30
//
this.solvencyLabel30.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel30.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel30.Location = new System.Drawing.Point(17,123);
this.solvencyLabel30.Name = "solvencyLabel30";
this.solvencyLabel30.OrdinateID_Label = 7040;
this.solvencyLabel30.Size = new System.Drawing.Size(254, 45);
this.solvencyLabel30.TabIndex = 30;
this.solvencyLabel30.Text = "French Republic [except Guadeloupe, Martinique, the Collectivity of Saint Martin and Réunion]; Principality of Monaco; Principality of Andorra" ;
this.solvencyLabel30.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel31
//
this.solvencyLabel31.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel31.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel31.Location = new System.Drawing.Point(285,123);
this.solvencyLabel31.Name = "solvencyLabel31";
this.solvencyLabel31.OrdinateID_Label = 0;
this.solvencyLabel31.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel31.TabIndex = 31;
this.solvencyLabel31.Text = "R1310" ;
this.solvencyLabel31.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel32
//
this.solvencyLabel32.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel32.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel32.Location = new System.Drawing.Point(17,171);
this.solvencyLabel32.Name = "solvencyLabel32";
this.solvencyLabel32.OrdinateID_Label = 7041;
this.solvencyLabel32.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel32.TabIndex = 32;
this.solvencyLabel32.Text = "Federal Republic of Germany" ;
this.solvencyLabel32.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel33
//
this.solvencyLabel33.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel33.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel33.Location = new System.Drawing.Point(285,171);
this.solvencyLabel33.Name = "solvencyLabel33";
this.solvencyLabel33.OrdinateID_Label = 0;
this.solvencyLabel33.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel33.TabIndex = 33;
this.solvencyLabel33.Text = "R1320" ;
this.solvencyLabel33.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel34
//
this.solvencyLabel34.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel34.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel34.Location = new System.Drawing.Point(17,191);
this.solvencyLabel34.Name = "solvencyLabel34";
this.solvencyLabel34.OrdinateID_Label = 7042;
this.solvencyLabel34.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel34.TabIndex = 34;
this.solvencyLabel34.Text = "Republic of Hungary" ;
this.solvencyLabel34.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel35
//
this.solvencyLabel35.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel35.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel35.Location = new System.Drawing.Point(285,191);
this.solvencyLabel35.Name = "solvencyLabel35";
this.solvencyLabel35.OrdinateID_Label = 0;
this.solvencyLabel35.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel35.TabIndex = 35;
this.solvencyLabel35.Text = "R1330" ;
this.solvencyLabel35.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel36
//
this.solvencyLabel36.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel36.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel36.Location = new System.Drawing.Point(17,211);
this.solvencyLabel36.Name = "solvencyLabel36";
this.solvencyLabel36.OrdinateID_Label = 7043;
this.solvencyLabel36.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel36.TabIndex = 36;
this.solvencyLabel36.Text = "Italian Republic; Republic of San Marino; Vatican City State" ;
this.solvencyLabel36.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel37
//
this.solvencyLabel37.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel37.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel37.Location = new System.Drawing.Point(285,211);
this.solvencyLabel37.Name = "solvencyLabel37";
this.solvencyLabel37.OrdinateID_Label = 0;
this.solvencyLabel37.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel37.TabIndex = 37;
this.solvencyLabel37.Text = "R1340" ;
this.solvencyLabel37.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel38
//
this.solvencyLabel38.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel38.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel38.Location = new System.Drawing.Point(17,244);
this.solvencyLabel38.Name = "solvencyLabel38";
this.solvencyLabel38.OrdinateID_Label = 7044;
this.solvencyLabel38.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel38.TabIndex = 38;
this.solvencyLabel38.Text = "Republic of Poland" ;
this.solvencyLabel38.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel39
//
this.solvencyLabel39.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel39.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel39.Location = new System.Drawing.Point(285,244);
this.solvencyLabel39.Name = "solvencyLabel39";
this.solvencyLabel39.OrdinateID_Label = 0;
this.solvencyLabel39.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel39.TabIndex = 39;
this.solvencyLabel39.Text = "R1350" ;
this.solvencyLabel39.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel40
//
this.solvencyLabel40.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel40.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel40.Location = new System.Drawing.Point(17,264);
this.solvencyLabel40.Name = "solvencyLabel40";
this.solvencyLabel40.OrdinateID_Label = 7045;
this.solvencyLabel40.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel40.TabIndex = 40;
this.solvencyLabel40.Text = "Romania" ;
this.solvencyLabel40.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel41
//
this.solvencyLabel41.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel41.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel41.Location = new System.Drawing.Point(285,264);
this.solvencyLabel41.Name = "solvencyLabel41";
this.solvencyLabel41.OrdinateID_Label = 0;
this.solvencyLabel41.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel41.TabIndex = 41;
this.solvencyLabel41.Text = "R1360" ;
this.solvencyLabel41.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel42
//
this.solvencyLabel42.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel42.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel42.Location = new System.Drawing.Point(17,284);
this.solvencyLabel42.Name = "solvencyLabel42";
this.solvencyLabel42.OrdinateID_Label = 7046;
this.solvencyLabel42.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel42.TabIndex = 42;
this.solvencyLabel42.Text = "Slovak Republic" ;
this.solvencyLabel42.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel43
//
this.solvencyLabel43.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel43.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel43.Location = new System.Drawing.Point(285,284);
this.solvencyLabel43.Name = "solvencyLabel43";
this.solvencyLabel43.OrdinateID_Label = 0;
this.solvencyLabel43.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel43.TabIndex = 43;
this.solvencyLabel43.Text = "R1370" ;
this.solvencyLabel43.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel44
//
this.solvencyLabel44.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel44.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel44.Location = new System.Drawing.Point(17,304);
this.solvencyLabel44.Name = "solvencyLabel44";
this.solvencyLabel44.OrdinateID_Label = 7047;
this.solvencyLabel44.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel44.TabIndex = 44;
this.solvencyLabel44.Text = "Republic of Slovenia" ;
this.solvencyLabel44.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel45
//
this.solvencyLabel45.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel45.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel45.Location = new System.Drawing.Point(285,304);
this.solvencyLabel45.Name = "solvencyLabel45";
this.solvencyLabel45.OrdinateID_Label = 0;
this.solvencyLabel45.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel45.TabIndex = 45;
this.solvencyLabel45.Text = "R1380" ;
this.solvencyLabel45.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel46
//
this.solvencyLabel46.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel46.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel46.Location = new System.Drawing.Point(17,324);
this.solvencyLabel46.Name = "solvencyLabel46";
this.solvencyLabel46.OrdinateID_Label = 7048;
this.solvencyLabel46.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel46.TabIndex = 46;
this.solvencyLabel46.Text = "United Kingdom of Great Britain and Northern Ireland" ;
this.solvencyLabel46.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel47
//
this.solvencyLabel47.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel47.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel47.Location = new System.Drawing.Point(285,324);
this.solvencyLabel47.Name = "solvencyLabel47";
this.solvencyLabel47.OrdinateID_Label = 0;
this.solvencyLabel47.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel47.TabIndex = 47;
this.solvencyLabel47.Text = "R1390" ;
this.solvencyLabel47.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel48
//
this.solvencyLabel48.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel48.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel48.Location = new System.Drawing.Point(17,357);
this.solvencyLabel48.Name = "solvencyLabel48";
this.solvencyLabel48.OrdinateID_Label = 7049;
this.solvencyLabel48.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel48.TabIndex = 48;
this.solvencyLabel48.Text = "Total Flood EEA Regions before diversification" ;
this.solvencyLabel48.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel49
//
this.solvencyLabel49.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel49.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel49.Location = new System.Drawing.Point(285,357);
this.solvencyLabel49.Name = "solvencyLabel49";
this.solvencyLabel49.OrdinateID_Label = 0;
this.solvencyLabel49.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel49.TabIndex = 49;
this.solvencyLabel49.Text = "R1400" ;
this.solvencyLabel49.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel50
//
this.solvencyLabel50.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel50.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel50.Location = new System.Drawing.Point(17,377);
this.solvencyLabel50.Name = "solvencyLabel50";
this.solvencyLabel50.OrdinateID_Label = 7050;
this.solvencyLabel50.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel50.TabIndex = 50;
this.solvencyLabel50.Text = "Northern Europe" ;
this.solvencyLabel50.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel51
//
this.solvencyLabel51.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel51.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel51.Location = new System.Drawing.Point(285,377);
this.solvencyLabel51.Name = "solvencyLabel51";
this.solvencyLabel51.OrdinateID_Label = 0;
this.solvencyLabel51.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel51.TabIndex = 51;
this.solvencyLabel51.Text = "R1410" ;
this.solvencyLabel51.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel52
//
this.solvencyLabel52.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel52.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel52.Location = new System.Drawing.Point(17,397);
this.solvencyLabel52.Name = "solvencyLabel52";
this.solvencyLabel52.OrdinateID_Label = 7051;
this.solvencyLabel52.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel52.TabIndex = 52;
this.solvencyLabel52.Text = "Western Europe" ;
this.solvencyLabel52.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel53
//
this.solvencyLabel53.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel53.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel53.Location = new System.Drawing.Point(285,397);
this.solvencyLabel53.Name = "solvencyLabel53";
this.solvencyLabel53.OrdinateID_Label = 0;
this.solvencyLabel53.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel53.TabIndex = 53;
this.solvencyLabel53.Text = "R1420" ;
this.solvencyLabel53.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel54
//
this.solvencyLabel54.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel54.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel54.Location = new System.Drawing.Point(17,417);
this.solvencyLabel54.Name = "solvencyLabel54";
this.solvencyLabel54.OrdinateID_Label = 7052;
this.solvencyLabel54.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel54.TabIndex = 54;
this.solvencyLabel54.Text = "Eastern Europe" ;
this.solvencyLabel54.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel55
//
this.solvencyLabel55.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel55.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel55.Location = new System.Drawing.Point(285,417);
this.solvencyLabel55.Name = "solvencyLabel55";
this.solvencyLabel55.OrdinateID_Label = 0;
this.solvencyLabel55.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel55.TabIndex = 55;
this.solvencyLabel55.Text = "R1430" ;
this.solvencyLabel55.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel56
//
this.solvencyLabel56.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel56.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel56.Location = new System.Drawing.Point(17,437);
this.solvencyLabel56.Name = "solvencyLabel56";
this.solvencyLabel56.OrdinateID_Label = 7053;
this.solvencyLabel56.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel56.TabIndex = 56;
this.solvencyLabel56.Text = "Southern Europe" ;
this.solvencyLabel56.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel57
//
this.solvencyLabel57.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel57.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel57.Location = new System.Drawing.Point(285,437);
this.solvencyLabel57.Name = "solvencyLabel57";
this.solvencyLabel57.OrdinateID_Label = 0;
this.solvencyLabel57.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel57.TabIndex = 57;
this.solvencyLabel57.Text = "R1440" ;
this.solvencyLabel57.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel58
//
this.solvencyLabel58.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel58.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel58.Location = new System.Drawing.Point(17,457);
this.solvencyLabel58.Name = "solvencyLabel58";
this.solvencyLabel58.OrdinateID_Label = 7054;
this.solvencyLabel58.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel58.TabIndex = 58;
this.solvencyLabel58.Text = "Central and Western Asia" ;
this.solvencyLabel58.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel59
//
this.solvencyLabel59.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel59.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel59.Location = new System.Drawing.Point(285,457);
this.solvencyLabel59.Name = "solvencyLabel59";
this.solvencyLabel59.OrdinateID_Label = 0;
this.solvencyLabel59.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel59.TabIndex = 59;
this.solvencyLabel59.Text = "R1450" ;
this.solvencyLabel59.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel60
//
this.solvencyLabel60.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel60.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel60.Location = new System.Drawing.Point(17,477);
this.solvencyLabel60.Name = "solvencyLabel60";
this.solvencyLabel60.OrdinateID_Label = 7055;
this.solvencyLabel60.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel60.TabIndex = 60;
this.solvencyLabel60.Text = "Eastern Asia" ;
this.solvencyLabel60.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel61
//
this.solvencyLabel61.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel61.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel61.Location = new System.Drawing.Point(285,477);
this.solvencyLabel61.Name = "solvencyLabel61";
this.solvencyLabel61.OrdinateID_Label = 0;
this.solvencyLabel61.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel61.TabIndex = 61;
this.solvencyLabel61.Text = "R1460" ;
this.solvencyLabel61.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel62
//
this.solvencyLabel62.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel62.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel62.Location = new System.Drawing.Point(17,497);
this.solvencyLabel62.Name = "solvencyLabel62";
this.solvencyLabel62.OrdinateID_Label = 7056;
this.solvencyLabel62.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel62.TabIndex = 62;
this.solvencyLabel62.Text = "South and South-Eastern Asia" ;
this.solvencyLabel62.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel63
//
this.solvencyLabel63.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel63.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel63.Location = new System.Drawing.Point(285,497);
this.solvencyLabel63.Name = "solvencyLabel63";
this.solvencyLabel63.OrdinateID_Label = 0;
this.solvencyLabel63.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel63.TabIndex = 63;
this.solvencyLabel63.Text = "R1470" ;
this.solvencyLabel63.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel64
//
this.solvencyLabel64.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel64.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel64.Location = new System.Drawing.Point(17,517);
this.solvencyLabel64.Name = "solvencyLabel64";
this.solvencyLabel64.OrdinateID_Label = 7057;
this.solvencyLabel64.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel64.TabIndex = 64;
this.solvencyLabel64.Text = "Oceania" ;
this.solvencyLabel64.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel65
//
this.solvencyLabel65.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel65.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel65.Location = new System.Drawing.Point(285,517);
this.solvencyLabel65.Name = "solvencyLabel65";
this.solvencyLabel65.OrdinateID_Label = 0;
this.solvencyLabel65.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel65.TabIndex = 65;
this.solvencyLabel65.Text = "R1480" ;
this.solvencyLabel65.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel66
//
this.solvencyLabel66.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel66.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel66.Location = new System.Drawing.Point(17,537);
this.solvencyLabel66.Name = "solvencyLabel66";
this.solvencyLabel66.OrdinateID_Label = 7058;
this.solvencyLabel66.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel66.TabIndex = 66;
this.solvencyLabel66.Text = "Northern Africa" ;
this.solvencyLabel66.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel67
//
this.solvencyLabel67.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel67.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel67.Location = new System.Drawing.Point(285,537);
this.solvencyLabel67.Name = "solvencyLabel67";
this.solvencyLabel67.OrdinateID_Label = 0;
this.solvencyLabel67.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel67.TabIndex = 67;
this.solvencyLabel67.Text = "R1490" ;
this.solvencyLabel67.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel68
//
this.solvencyLabel68.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel68.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel68.Location = new System.Drawing.Point(17,557);
this.solvencyLabel68.Name = "solvencyLabel68";
this.solvencyLabel68.OrdinateID_Label = 7059;
this.solvencyLabel68.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel68.TabIndex = 68;
this.solvencyLabel68.Text = "Southern Africa" ;
this.solvencyLabel68.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel69
//
this.solvencyLabel69.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel69.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel69.Location = new System.Drawing.Point(285,557);
this.solvencyLabel69.Name = "solvencyLabel69";
this.solvencyLabel69.OrdinateID_Label = 0;
this.solvencyLabel69.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel69.TabIndex = 69;
this.solvencyLabel69.Text = "R1500" ;
this.solvencyLabel69.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel70
//
this.solvencyLabel70.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel70.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel70.Location = new System.Drawing.Point(17,577);
this.solvencyLabel70.Name = "solvencyLabel70";
this.solvencyLabel70.OrdinateID_Label = 7060;
this.solvencyLabel70.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel70.TabIndex = 70;
this.solvencyLabel70.Text = "Northern America excluding the United States of America" ;
this.solvencyLabel70.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel71
//
this.solvencyLabel71.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel71.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel71.Location = new System.Drawing.Point(285,577);
this.solvencyLabel71.Name = "solvencyLabel71";
this.solvencyLabel71.OrdinateID_Label = 0;
this.solvencyLabel71.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel71.TabIndex = 71;
this.solvencyLabel71.Text = "R1510" ;
this.solvencyLabel71.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel72
//
this.solvencyLabel72.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel72.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel72.Location = new System.Drawing.Point(17,610);
this.solvencyLabel72.Name = "solvencyLabel72";
this.solvencyLabel72.OrdinateID_Label = 7061;
this.solvencyLabel72.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel72.TabIndex = 72;
this.solvencyLabel72.Text = "Caribbean and Central America" ;
this.solvencyLabel72.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel73
//
this.solvencyLabel73.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel73.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel73.Location = new System.Drawing.Point(285,610);
this.solvencyLabel73.Name = "solvencyLabel73";
this.solvencyLabel73.OrdinateID_Label = 0;
this.solvencyLabel73.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel73.TabIndex = 73;
this.solvencyLabel73.Text = "R1520" ;
this.solvencyLabel73.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel74
//
this.solvencyLabel74.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel74.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel74.Location = new System.Drawing.Point(17,630);
this.solvencyLabel74.Name = "solvencyLabel74";
this.solvencyLabel74.OrdinateID_Label = 7062;
this.solvencyLabel74.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel74.TabIndex = 74;
this.solvencyLabel74.Text = "Eastern South America" ;
this.solvencyLabel74.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel75
//
this.solvencyLabel75.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel75.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel75.Location = new System.Drawing.Point(285,630);
this.solvencyLabel75.Name = "solvencyLabel75";
this.solvencyLabel75.OrdinateID_Label = 0;
this.solvencyLabel75.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel75.TabIndex = 75;
this.solvencyLabel75.Text = "R1530" ;
this.solvencyLabel75.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel76
//
this.solvencyLabel76.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel76.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel76.Location = new System.Drawing.Point(17,650);
this.solvencyLabel76.Name = "solvencyLabel76";
this.solvencyLabel76.OrdinateID_Label = 7063;
this.solvencyLabel76.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel76.TabIndex = 76;
this.solvencyLabel76.Text = "Northern, southern and western South America" ;
this.solvencyLabel76.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel77
//
this.solvencyLabel77.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel77.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel77.Location = new System.Drawing.Point(285,650);
this.solvencyLabel77.Name = "solvencyLabel77";
this.solvencyLabel77.OrdinateID_Label = 0;
this.solvencyLabel77.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel77.TabIndex = 77;
this.solvencyLabel77.Text = "R1540" ;
this.solvencyLabel77.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel78
//
this.solvencyLabel78.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel78.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel78.Location = new System.Drawing.Point(17,670);
this.solvencyLabel78.Name = "solvencyLabel78";
this.solvencyLabel78.OrdinateID_Label = 7064;
this.solvencyLabel78.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel78.TabIndex = 78;
this.solvencyLabel78.Text = "North-east United States of America" ;
this.solvencyLabel78.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel79
//
this.solvencyLabel79.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel79.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel79.Location = new System.Drawing.Point(285,670);
this.solvencyLabel79.Name = "solvencyLabel79";
this.solvencyLabel79.OrdinateID_Label = 0;
this.solvencyLabel79.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel79.TabIndex = 79;
this.solvencyLabel79.Text = "R1550" ;
this.solvencyLabel79.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel80
//
this.solvencyLabel80.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel80.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel80.Location = new System.Drawing.Point(17,690);
this.solvencyLabel80.Name = "solvencyLabel80";
this.solvencyLabel80.OrdinateID_Label = 7065;
this.solvencyLabel80.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel80.TabIndex = 80;
this.solvencyLabel80.Text = "South-east United States of America" ;
this.solvencyLabel80.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel81
//
this.solvencyLabel81.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel81.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel81.Location = new System.Drawing.Point(285,690);
this.solvencyLabel81.Name = "solvencyLabel81";
this.solvencyLabel81.OrdinateID_Label = 0;
this.solvencyLabel81.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel81.TabIndex = 81;
this.solvencyLabel81.Text = "R1560" ;
this.solvencyLabel81.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel82
//
this.solvencyLabel82.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel82.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel82.Location = new System.Drawing.Point(17,710);
this.solvencyLabel82.Name = "solvencyLabel82";
this.solvencyLabel82.OrdinateID_Label = 7066;
this.solvencyLabel82.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel82.TabIndex = 82;
this.solvencyLabel82.Text = "Mid-west United States of America" ;
this.solvencyLabel82.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel83
//
this.solvencyLabel83.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel83.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel83.Location = new System.Drawing.Point(285,710);
this.solvencyLabel83.Name = "solvencyLabel83";
this.solvencyLabel83.OrdinateID_Label = 0;
this.solvencyLabel83.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel83.TabIndex = 83;
this.solvencyLabel83.Text = "R1570" ;
this.solvencyLabel83.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel84
//
this.solvencyLabel84.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel84.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel84.Location = new System.Drawing.Point(17,730);
this.solvencyLabel84.Name = "solvencyLabel84";
this.solvencyLabel84.OrdinateID_Label = 7067;
this.solvencyLabel84.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel84.TabIndex = 84;
this.solvencyLabel84.Text = "Western United States of America" ;
this.solvencyLabel84.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel85
//
this.solvencyLabel85.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel85.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel85.Location = new System.Drawing.Point(285,730);
this.solvencyLabel85.Name = "solvencyLabel85";
this.solvencyLabel85.OrdinateID_Label = 0;
this.solvencyLabel85.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel85.TabIndex = 85;
this.solvencyLabel85.Text = "R1580" ;
this.solvencyLabel85.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel86
//
this.solvencyLabel86.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel86.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel86.Location = new System.Drawing.Point(17,750);
this.solvencyLabel86.Name = "solvencyLabel86";
this.solvencyLabel86.OrdinateID_Label = 7068;
this.solvencyLabel86.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel86.TabIndex = 86;
this.solvencyLabel86.Text = "Total Flood Other Regions before diversifications" ;
this.solvencyLabel86.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel87
//
this.solvencyLabel87.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel87.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel87.Location = new System.Drawing.Point(285,750);
this.solvencyLabel87.Name = "solvencyLabel87";
this.solvencyLabel87.OrdinateID_Label = 0;
this.solvencyLabel87.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel87.TabIndex = 87;
this.solvencyLabel87.Text = "R1590" ;
this.solvencyLabel87.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel88
//
this.solvencyLabel88.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel88.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel88.Location = new System.Drawing.Point(17,770);
this.solvencyLabel88.Name = "solvencyLabel88";
this.solvencyLabel88.OrdinateID_Label = 7069;
this.solvencyLabel88.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel88.TabIndex = 88;
this.solvencyLabel88.Text = "Total Flood all Regions before diversification" ;
this.solvencyLabel88.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel89
//
this.solvencyLabel89.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel89.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel89.Location = new System.Drawing.Point(285,770);
this.solvencyLabel89.Name = "solvencyLabel89";
this.solvencyLabel89.OrdinateID_Label = 0;
this.solvencyLabel89.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel89.TabIndex = 89;
this.solvencyLabel89.Text = "R1600" ;
this.solvencyLabel89.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel90
//
this.solvencyLabel90.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel90.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel90.Location = new System.Drawing.Point(17,790);
this.solvencyLabel90.Name = "solvencyLabel90";
this.solvencyLabel90.OrdinateID_Label = 7070;
this.solvencyLabel90.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel90.TabIndex = 90;
this.solvencyLabel90.Text = "Diversification effect between regions" ;
this.solvencyLabel90.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel91
//
this.solvencyLabel91.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel91.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel91.Location = new System.Drawing.Point(285,790);
this.solvencyLabel91.Name = "solvencyLabel91";
this.solvencyLabel91.OrdinateID_Label = 0;
this.solvencyLabel91.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel91.TabIndex = 91;
this.solvencyLabel91.Text = "R1610" ;
this.solvencyLabel91.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel92
//
this.solvencyLabel92.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel92.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel92.Location = new System.Drawing.Point(17,810);
this.solvencyLabel92.Name = "solvencyLabel92";
this.solvencyLabel92.OrdinateID_Label = 7071;
this.solvencyLabel92.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel92.TabIndex = 92;
this.solvencyLabel92.Text = "Total Flood after diversification" ;
this.solvencyLabel92.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel93
//
this.solvencyLabel93.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel93.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel93.Location = new System.Drawing.Point(285,810);
this.solvencyLabel93.Name = "solvencyLabel93";
this.solvencyLabel93.OrdinateID_Label = 0;
this.solvencyLabel93.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel93.TabIndex = 93;
this.solvencyLabel93.Text = "R1620" ;
this.solvencyLabel93.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel94
//
this.solvencyLabel94.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel94.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel94.Location = new System.Drawing.Point(285,830);
this.solvencyLabel94.Name = "solvencyLabel94";
this.solvencyLabel94.OrdinateID_Label = 0;
this.solvencyLabel94.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel94.TabIndex = 94;
this.solvencyLabel94.Text = "." ;
this.solvencyLabel94.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyCurrencyTextBox95
//
this.solvencyCurrencyTextBox95.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox95.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox95.Location = new System.Drawing.Point(10,23);
this.solvencyCurrencyTextBox95.Name = "solvencyCurrencyTextBox95";
this.solvencyCurrencyTextBox95.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox95.TabIndex = 95;
this.solvencyCurrencyTextBox95.ColName = "R1260C0210";
this.solvencyCurrencyTextBox95.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox95.Enabled = false;
this.solvencyCurrencyTextBox95.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox96
//
this.solvencyCurrencyTextBox96.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox96.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox96.Location = new System.Drawing.Point(117,23);
this.solvencyCurrencyTextBox96.Name = "solvencyCurrencyTextBox96";
this.solvencyCurrencyTextBox96.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox96.TabIndex = 96;
this.solvencyCurrencyTextBox96.ColName = "R1260C0220";
this.solvencyCurrencyTextBox96.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox97
//
this.solvencyCurrencyTextBox97.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox97.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox97.Location = new System.Drawing.Point(224,23);
this.solvencyCurrencyTextBox97.Name = "solvencyCurrencyTextBox97";
this.solvencyCurrencyTextBox97.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox97.TabIndex = 97;
this.solvencyCurrencyTextBox97.ColName = "R1260C0230";
this.solvencyCurrencyTextBox97.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox98
//
this.solvencyCurrencyTextBox98.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox98.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox98.Location = new System.Drawing.Point(331,23);
this.solvencyCurrencyTextBox98.Name = "solvencyCurrencyTextBox98";
this.solvencyCurrencyTextBox98.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox98.TabIndex = 98;
this.solvencyCurrencyTextBox98.ColName = "R1260C0240";
this.solvencyCurrencyTextBox98.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// SolvencyDataComboBox99
//
this.SolvencyDataComboBox99.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox99.Location = new System.Drawing.Point(438,23);
this.SolvencyDataComboBox99.Name = "SolvencyDataComboBox99";
this.SolvencyDataComboBox99.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox99.TabIndex = 99;
this.SolvencyDataComboBox99.ColName = "R1260C0250";
this.SolvencyDataComboBox99.AxisID = 1318;
this.SolvencyDataComboBox99.OrdinateID = 7029;
this.SolvencyDataComboBox99.StartOrder = 0;
this.SolvencyDataComboBox99.NextOrder = 0;
//
// solvencyCurrencyTextBox100
//
this.solvencyCurrencyTextBox100.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox100.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox100.Location = new System.Drawing.Point(645,23);
this.solvencyCurrencyTextBox100.Name = "solvencyCurrencyTextBox100";
this.solvencyCurrencyTextBox100.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox100.TabIndex = 100;
this.solvencyCurrencyTextBox100.ColName = "R1260C0260";
this.solvencyCurrencyTextBox100.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox101
//
this.solvencyCurrencyTextBox101.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox101.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox101.Location = new System.Drawing.Point(752,23);
this.solvencyCurrencyTextBox101.Name = "solvencyCurrencyTextBox101";
this.solvencyCurrencyTextBox101.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox101.TabIndex = 101;
this.solvencyCurrencyTextBox101.ColName = "R1260C0270";
this.solvencyCurrencyTextBox101.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox102
//
this.solvencyCurrencyTextBox102.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox102.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox102.Location = new System.Drawing.Point(859,23);
this.solvencyCurrencyTextBox102.Name = "solvencyCurrencyTextBox102";
this.solvencyCurrencyTextBox102.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox102.TabIndex = 102;
this.solvencyCurrencyTextBox102.ColName = "R1260C0280";
this.solvencyCurrencyTextBox102.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox103
//
this.solvencyCurrencyTextBox103.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox103.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox103.Location = new System.Drawing.Point(966,23);
this.solvencyCurrencyTextBox103.Name = "solvencyCurrencyTextBox103";
this.solvencyCurrencyTextBox103.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox103.TabIndex = 103;
this.solvencyCurrencyTextBox103.ColName = "R1260C0290";
this.solvencyCurrencyTextBox103.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox104
//
this.solvencyCurrencyTextBox104.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox104.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox104.Location = new System.Drawing.Point(10,43);
this.solvencyCurrencyTextBox104.Name = "solvencyCurrencyTextBox104";
this.solvencyCurrencyTextBox104.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox104.TabIndex = 104;
this.solvencyCurrencyTextBox104.ColName = "R1270C0210";
this.solvencyCurrencyTextBox104.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox104.Enabled = false;
this.solvencyCurrencyTextBox104.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox105
//
this.solvencyCurrencyTextBox105.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox105.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox105.Location = new System.Drawing.Point(117,43);
this.solvencyCurrencyTextBox105.Name = "solvencyCurrencyTextBox105";
this.solvencyCurrencyTextBox105.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox105.TabIndex = 105;
this.solvencyCurrencyTextBox105.ColName = "R1270C0220";
this.solvencyCurrencyTextBox105.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox106
//
this.solvencyCurrencyTextBox106.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox106.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox106.Location = new System.Drawing.Point(224,43);
this.solvencyCurrencyTextBox106.Name = "solvencyCurrencyTextBox106";
this.solvencyCurrencyTextBox106.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox106.TabIndex = 106;
this.solvencyCurrencyTextBox106.ColName = "R1270C0230";
this.solvencyCurrencyTextBox106.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox107
//
this.solvencyCurrencyTextBox107.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox107.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox107.Location = new System.Drawing.Point(331,43);
this.solvencyCurrencyTextBox107.Name = "solvencyCurrencyTextBox107";
this.solvencyCurrencyTextBox107.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox107.TabIndex = 107;
this.solvencyCurrencyTextBox107.ColName = "R1270C0240";
this.solvencyCurrencyTextBox107.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// SolvencyDataComboBox108
//
this.SolvencyDataComboBox108.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox108.Location = new System.Drawing.Point(438,43);
this.SolvencyDataComboBox108.Name = "SolvencyDataComboBox108";
this.SolvencyDataComboBox108.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox108.TabIndex = 108;
this.SolvencyDataComboBox108.ColName = "R1270C0250";
this.SolvencyDataComboBox108.AxisID = 1318;
this.SolvencyDataComboBox108.OrdinateID = 7029;
this.SolvencyDataComboBox108.StartOrder = 0;
this.SolvencyDataComboBox108.NextOrder = 0;
//
// solvencyCurrencyTextBox109
//
this.solvencyCurrencyTextBox109.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox109.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox109.Location = new System.Drawing.Point(645,43);
this.solvencyCurrencyTextBox109.Name = "solvencyCurrencyTextBox109";
this.solvencyCurrencyTextBox109.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox109.TabIndex = 109;
this.solvencyCurrencyTextBox109.ColName = "R1270C0260";
this.solvencyCurrencyTextBox109.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox110
//
this.solvencyCurrencyTextBox110.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox110.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox110.Location = new System.Drawing.Point(752,43);
this.solvencyCurrencyTextBox110.Name = "solvencyCurrencyTextBox110";
this.solvencyCurrencyTextBox110.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox110.TabIndex = 110;
this.solvencyCurrencyTextBox110.ColName = "R1270C0270";
this.solvencyCurrencyTextBox110.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox111
//
this.solvencyCurrencyTextBox111.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox111.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox111.Location = new System.Drawing.Point(859,43);
this.solvencyCurrencyTextBox111.Name = "solvencyCurrencyTextBox111";
this.solvencyCurrencyTextBox111.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox111.TabIndex = 111;
this.solvencyCurrencyTextBox111.ColName = "R1270C0280";
this.solvencyCurrencyTextBox111.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox112
//
this.solvencyCurrencyTextBox112.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox112.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox112.Location = new System.Drawing.Point(966,43);
this.solvencyCurrencyTextBox112.Name = "solvencyCurrencyTextBox112";
this.solvencyCurrencyTextBox112.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox112.TabIndex = 112;
this.solvencyCurrencyTextBox112.ColName = "R1270C0290";
this.solvencyCurrencyTextBox112.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox113
//
this.solvencyCurrencyTextBox113.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox113.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox113.Location = new System.Drawing.Point(10,63);
this.solvencyCurrencyTextBox113.Name = "solvencyCurrencyTextBox113";
this.solvencyCurrencyTextBox113.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox113.TabIndex = 113;
this.solvencyCurrencyTextBox113.ColName = "R1280C0210";
this.solvencyCurrencyTextBox113.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox113.Enabled = false;
this.solvencyCurrencyTextBox113.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox114
//
this.solvencyCurrencyTextBox114.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox114.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox114.Location = new System.Drawing.Point(117,63);
this.solvencyCurrencyTextBox114.Name = "solvencyCurrencyTextBox114";
this.solvencyCurrencyTextBox114.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox114.TabIndex = 114;
this.solvencyCurrencyTextBox114.ColName = "R1280C0220";
this.solvencyCurrencyTextBox114.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox115
//
this.solvencyCurrencyTextBox115.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox115.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox115.Location = new System.Drawing.Point(224,63);
this.solvencyCurrencyTextBox115.Name = "solvencyCurrencyTextBox115";
this.solvencyCurrencyTextBox115.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox115.TabIndex = 115;
this.solvencyCurrencyTextBox115.ColName = "R1280C0230";
this.solvencyCurrencyTextBox115.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox116
//
this.solvencyCurrencyTextBox116.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox116.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox116.Location = new System.Drawing.Point(331,63);
this.solvencyCurrencyTextBox116.Name = "solvencyCurrencyTextBox116";
this.solvencyCurrencyTextBox116.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox116.TabIndex = 116;
this.solvencyCurrencyTextBox116.ColName = "R1280C0240";
this.solvencyCurrencyTextBox116.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// SolvencyDataComboBox117
//
this.SolvencyDataComboBox117.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox117.Location = new System.Drawing.Point(438,63);
this.SolvencyDataComboBox117.Name = "SolvencyDataComboBox117";
this.SolvencyDataComboBox117.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox117.TabIndex = 117;
this.SolvencyDataComboBox117.ColName = "R1280C0250";
this.SolvencyDataComboBox117.AxisID = 1318;
this.SolvencyDataComboBox117.OrdinateID = 7029;
this.SolvencyDataComboBox117.StartOrder = 0;
this.SolvencyDataComboBox117.NextOrder = 0;
//
// solvencyCurrencyTextBox118
//
this.solvencyCurrencyTextBox118.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox118.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox118.Location = new System.Drawing.Point(645,63);
this.solvencyCurrencyTextBox118.Name = "solvencyCurrencyTextBox118";
this.solvencyCurrencyTextBox118.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox118.TabIndex = 118;
this.solvencyCurrencyTextBox118.ColName = "R1280C0260";
this.solvencyCurrencyTextBox118.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox119
//
this.solvencyCurrencyTextBox119.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox119.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox119.Location = new System.Drawing.Point(752,63);
this.solvencyCurrencyTextBox119.Name = "solvencyCurrencyTextBox119";
this.solvencyCurrencyTextBox119.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox119.TabIndex = 119;
this.solvencyCurrencyTextBox119.ColName = "R1280C0270";
this.solvencyCurrencyTextBox119.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox120
//
this.solvencyCurrencyTextBox120.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox120.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox120.Location = new System.Drawing.Point(859,63);
this.solvencyCurrencyTextBox120.Name = "solvencyCurrencyTextBox120";
this.solvencyCurrencyTextBox120.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox120.TabIndex = 120;
this.solvencyCurrencyTextBox120.ColName = "R1280C0280";
this.solvencyCurrencyTextBox120.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox121
//
this.solvencyCurrencyTextBox121.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox121.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox121.Location = new System.Drawing.Point(966,63);
this.solvencyCurrencyTextBox121.Name = "solvencyCurrencyTextBox121";
this.solvencyCurrencyTextBox121.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox121.TabIndex = 121;
this.solvencyCurrencyTextBox121.ColName = "R1280C0290";
this.solvencyCurrencyTextBox121.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox122
//
this.solvencyCurrencyTextBox122.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox122.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox122.Location = new System.Drawing.Point(10,83);
this.solvencyCurrencyTextBox122.Name = "solvencyCurrencyTextBox122";
this.solvencyCurrencyTextBox122.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox122.TabIndex = 122;
this.solvencyCurrencyTextBox122.ColName = "R1290C0210";
this.solvencyCurrencyTextBox122.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox122.Enabled = false;
this.solvencyCurrencyTextBox122.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox123
//
this.solvencyCurrencyTextBox123.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox123.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox123.Location = new System.Drawing.Point(117,83);
this.solvencyCurrencyTextBox123.Name = "solvencyCurrencyTextBox123";
this.solvencyCurrencyTextBox123.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox123.TabIndex = 123;
this.solvencyCurrencyTextBox123.ColName = "R1290C0220";
this.solvencyCurrencyTextBox123.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox124
//
this.solvencyCurrencyTextBox124.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox124.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox124.Location = new System.Drawing.Point(224,83);
this.solvencyCurrencyTextBox124.Name = "solvencyCurrencyTextBox124";
this.solvencyCurrencyTextBox124.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox124.TabIndex = 124;
this.solvencyCurrencyTextBox124.ColName = "R1290C0230";
this.solvencyCurrencyTextBox124.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox125
//
this.solvencyCurrencyTextBox125.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox125.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox125.Location = new System.Drawing.Point(331,83);
this.solvencyCurrencyTextBox125.Name = "solvencyCurrencyTextBox125";
this.solvencyCurrencyTextBox125.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox125.TabIndex = 125;
this.solvencyCurrencyTextBox125.ColName = "R1290C0240";
this.solvencyCurrencyTextBox125.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// SolvencyDataComboBox126
//
this.SolvencyDataComboBox126.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox126.Location = new System.Drawing.Point(438,83);
this.SolvencyDataComboBox126.Name = "SolvencyDataComboBox126";
this.SolvencyDataComboBox126.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox126.TabIndex = 126;
this.SolvencyDataComboBox126.ColName = "R1290C0250";
this.SolvencyDataComboBox126.AxisID = 1318;
this.SolvencyDataComboBox126.OrdinateID = 7029;
this.SolvencyDataComboBox126.StartOrder = 0;
this.SolvencyDataComboBox126.NextOrder = 0;
//
// solvencyCurrencyTextBox127
//
this.solvencyCurrencyTextBox127.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox127.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox127.Location = new System.Drawing.Point(645,83);
this.solvencyCurrencyTextBox127.Name = "solvencyCurrencyTextBox127";
this.solvencyCurrencyTextBox127.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox127.TabIndex = 127;
this.solvencyCurrencyTextBox127.ColName = "R1290C0260";
this.solvencyCurrencyTextBox127.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox128
//
this.solvencyCurrencyTextBox128.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox128.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox128.Location = new System.Drawing.Point(752,83);
this.solvencyCurrencyTextBox128.Name = "solvencyCurrencyTextBox128";
this.solvencyCurrencyTextBox128.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox128.TabIndex = 128;
this.solvencyCurrencyTextBox128.ColName = "R1290C0270";
this.solvencyCurrencyTextBox128.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox129
//
this.solvencyCurrencyTextBox129.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox129.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox129.Location = new System.Drawing.Point(859,83);
this.solvencyCurrencyTextBox129.Name = "solvencyCurrencyTextBox129";
this.solvencyCurrencyTextBox129.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox129.TabIndex = 129;
this.solvencyCurrencyTextBox129.ColName = "R1290C0280";
this.solvencyCurrencyTextBox129.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox130
//
this.solvencyCurrencyTextBox130.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox130.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox130.Location = new System.Drawing.Point(966,83);
this.solvencyCurrencyTextBox130.Name = "solvencyCurrencyTextBox130";
this.solvencyCurrencyTextBox130.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox130.TabIndex = 130;
this.solvencyCurrencyTextBox130.ColName = "R1290C0290";
this.solvencyCurrencyTextBox130.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox131
//
this.solvencyCurrencyTextBox131.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox131.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox131.Location = new System.Drawing.Point(10,103);
this.solvencyCurrencyTextBox131.Name = "solvencyCurrencyTextBox131";
this.solvencyCurrencyTextBox131.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox131.TabIndex = 131;
this.solvencyCurrencyTextBox131.ColName = "R1300C0210";
this.solvencyCurrencyTextBox131.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox131.Enabled = false;
this.solvencyCurrencyTextBox131.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox132
//
this.solvencyCurrencyTextBox132.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox132.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox132.Location = new System.Drawing.Point(117,103);
this.solvencyCurrencyTextBox132.Name = "solvencyCurrencyTextBox132";
this.solvencyCurrencyTextBox132.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox132.TabIndex = 132;
this.solvencyCurrencyTextBox132.ColName = "R1300C0220";
this.solvencyCurrencyTextBox132.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox133
//
this.solvencyCurrencyTextBox133.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox133.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox133.Location = new System.Drawing.Point(224,103);
this.solvencyCurrencyTextBox133.Name = "solvencyCurrencyTextBox133";
this.solvencyCurrencyTextBox133.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox133.TabIndex = 133;
this.solvencyCurrencyTextBox133.ColName = "R1300C0230";
this.solvencyCurrencyTextBox133.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox134
//
this.solvencyCurrencyTextBox134.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox134.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox134.Location = new System.Drawing.Point(331,103);
this.solvencyCurrencyTextBox134.Name = "solvencyCurrencyTextBox134";
this.solvencyCurrencyTextBox134.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox134.TabIndex = 134;
this.solvencyCurrencyTextBox134.ColName = "R1300C0240";
this.solvencyCurrencyTextBox134.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// SolvencyDataComboBox135
//
this.SolvencyDataComboBox135.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox135.Location = new System.Drawing.Point(438,103);
this.SolvencyDataComboBox135.Name = "SolvencyDataComboBox135";
this.SolvencyDataComboBox135.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox135.TabIndex = 135;
this.SolvencyDataComboBox135.ColName = "R1300C0250";
this.SolvencyDataComboBox135.AxisID = 1318;
this.SolvencyDataComboBox135.OrdinateID = 7029;
this.SolvencyDataComboBox135.StartOrder = 0;
this.SolvencyDataComboBox135.NextOrder = 0;
//
// solvencyCurrencyTextBox136
//
this.solvencyCurrencyTextBox136.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox136.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox136.Location = new System.Drawing.Point(645,103);
this.solvencyCurrencyTextBox136.Name = "solvencyCurrencyTextBox136";
this.solvencyCurrencyTextBox136.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox136.TabIndex = 136;
this.solvencyCurrencyTextBox136.ColName = "R1300C0260";
this.solvencyCurrencyTextBox136.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox137
//
this.solvencyCurrencyTextBox137.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox137.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox137.Location = new System.Drawing.Point(752,103);
this.solvencyCurrencyTextBox137.Name = "solvencyCurrencyTextBox137";
this.solvencyCurrencyTextBox137.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox137.TabIndex = 137;
this.solvencyCurrencyTextBox137.ColName = "R1300C0270";
this.solvencyCurrencyTextBox137.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox138
//
this.solvencyCurrencyTextBox138.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox138.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox138.Location = new System.Drawing.Point(859,103);
this.solvencyCurrencyTextBox138.Name = "solvencyCurrencyTextBox138";
this.solvencyCurrencyTextBox138.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox138.TabIndex = 138;
this.solvencyCurrencyTextBox138.ColName = "R1300C0280";
this.solvencyCurrencyTextBox138.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox139
//
this.solvencyCurrencyTextBox139.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox139.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox139.Location = new System.Drawing.Point(966,103);
this.solvencyCurrencyTextBox139.Name = "solvencyCurrencyTextBox139";
this.solvencyCurrencyTextBox139.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox139.TabIndex = 139;
this.solvencyCurrencyTextBox139.ColName = "R1300C0290";
this.solvencyCurrencyTextBox139.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox140
//
this.solvencyCurrencyTextBox140.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox140.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox140.Location = new System.Drawing.Point(10,123);
this.solvencyCurrencyTextBox140.Name = "solvencyCurrencyTextBox140";
this.solvencyCurrencyTextBox140.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox140.TabIndex = 140;
this.solvencyCurrencyTextBox140.ColName = "R1310C0210";
this.solvencyCurrencyTextBox140.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox140.Enabled = false;
this.solvencyCurrencyTextBox140.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox141
//
this.solvencyCurrencyTextBox141.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox141.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox141.Location = new System.Drawing.Point(117,123);
this.solvencyCurrencyTextBox141.Name = "solvencyCurrencyTextBox141";
this.solvencyCurrencyTextBox141.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox141.TabIndex = 141;
this.solvencyCurrencyTextBox141.ColName = "R1310C0220";
this.solvencyCurrencyTextBox141.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox142
//
this.solvencyCurrencyTextBox142.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox142.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox142.Location = new System.Drawing.Point(224,123);
this.solvencyCurrencyTextBox142.Name = "solvencyCurrencyTextBox142";
this.solvencyCurrencyTextBox142.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox142.TabIndex = 142;
this.solvencyCurrencyTextBox142.ColName = "R1310C0230";
this.solvencyCurrencyTextBox142.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox143
//
this.solvencyCurrencyTextBox143.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox143.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox143.Location = new System.Drawing.Point(331,123);
this.solvencyCurrencyTextBox143.Name = "solvencyCurrencyTextBox143";
this.solvencyCurrencyTextBox143.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox143.TabIndex = 143;
this.solvencyCurrencyTextBox143.ColName = "R1310C0240";
this.solvencyCurrencyTextBox143.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// SolvencyDataComboBox144
//
this.SolvencyDataComboBox144.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox144.Location = new System.Drawing.Point(438,123);
this.SolvencyDataComboBox144.Name = "SolvencyDataComboBox144";
this.SolvencyDataComboBox144.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox144.TabIndex = 144;
this.SolvencyDataComboBox144.ColName = "R1310C0250";
this.SolvencyDataComboBox144.AxisID = 1318;
this.SolvencyDataComboBox144.OrdinateID = 7029;
this.SolvencyDataComboBox144.StartOrder = 0;
this.SolvencyDataComboBox144.NextOrder = 0;
//
// solvencyCurrencyTextBox145
//
this.solvencyCurrencyTextBox145.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox145.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox145.Location = new System.Drawing.Point(645,123);
this.solvencyCurrencyTextBox145.Name = "solvencyCurrencyTextBox145";
this.solvencyCurrencyTextBox145.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox145.TabIndex = 145;
this.solvencyCurrencyTextBox145.ColName = "R1310C0260";
this.solvencyCurrencyTextBox145.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox146
//
this.solvencyCurrencyTextBox146.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox146.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox146.Location = new System.Drawing.Point(752,123);
this.solvencyCurrencyTextBox146.Name = "solvencyCurrencyTextBox146";
this.solvencyCurrencyTextBox146.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox146.TabIndex = 146;
this.solvencyCurrencyTextBox146.ColName = "R1310C0270";
this.solvencyCurrencyTextBox146.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox147
//
this.solvencyCurrencyTextBox147.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox147.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox147.Location = new System.Drawing.Point(859,123);
this.solvencyCurrencyTextBox147.Name = "solvencyCurrencyTextBox147";
this.solvencyCurrencyTextBox147.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox147.TabIndex = 147;
this.solvencyCurrencyTextBox147.ColName = "R1310C0280";
this.solvencyCurrencyTextBox147.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox148
//
this.solvencyCurrencyTextBox148.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox148.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox148.Location = new System.Drawing.Point(966,123);
this.solvencyCurrencyTextBox148.Name = "solvencyCurrencyTextBox148";
this.solvencyCurrencyTextBox148.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox148.TabIndex = 148;
this.solvencyCurrencyTextBox148.ColName = "R1310C0290";
this.solvencyCurrencyTextBox148.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox149
//
this.solvencyCurrencyTextBox149.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox149.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox149.Location = new System.Drawing.Point(10,171);
this.solvencyCurrencyTextBox149.Name = "solvencyCurrencyTextBox149";
this.solvencyCurrencyTextBox149.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox149.TabIndex = 149;
this.solvencyCurrencyTextBox149.ColName = "R1320C0210";
this.solvencyCurrencyTextBox149.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox149.Enabled = false;
this.solvencyCurrencyTextBox149.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox150
//
this.solvencyCurrencyTextBox150.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox150.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox150.Location = new System.Drawing.Point(117,171);
this.solvencyCurrencyTextBox150.Name = "solvencyCurrencyTextBox150";
this.solvencyCurrencyTextBox150.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox150.TabIndex = 150;
this.solvencyCurrencyTextBox150.ColName = "R1320C0220";
this.solvencyCurrencyTextBox150.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox151
//
this.solvencyCurrencyTextBox151.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox151.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox151.Location = new System.Drawing.Point(224,171);
this.solvencyCurrencyTextBox151.Name = "solvencyCurrencyTextBox151";
this.solvencyCurrencyTextBox151.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox151.TabIndex = 151;
this.solvencyCurrencyTextBox151.ColName = "R1320C0230";
this.solvencyCurrencyTextBox151.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox152
//
this.solvencyCurrencyTextBox152.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox152.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox152.Location = new System.Drawing.Point(331,171);
this.solvencyCurrencyTextBox152.Name = "solvencyCurrencyTextBox152";
this.solvencyCurrencyTextBox152.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox152.TabIndex = 152;
this.solvencyCurrencyTextBox152.ColName = "R1320C0240";
this.solvencyCurrencyTextBox152.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// SolvencyDataComboBox153
//
this.SolvencyDataComboBox153.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox153.Location = new System.Drawing.Point(438,171);
this.SolvencyDataComboBox153.Name = "SolvencyDataComboBox153";
this.SolvencyDataComboBox153.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox153.TabIndex = 153;
this.SolvencyDataComboBox153.ColName = "R1320C0250";
this.SolvencyDataComboBox153.AxisID = 1318;
this.SolvencyDataComboBox153.OrdinateID = 7029;
this.SolvencyDataComboBox153.StartOrder = 0;
this.SolvencyDataComboBox153.NextOrder = 0;
//
// solvencyCurrencyTextBox154
//
this.solvencyCurrencyTextBox154.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox154.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox154.Location = new System.Drawing.Point(645,171);
this.solvencyCurrencyTextBox154.Name = "solvencyCurrencyTextBox154";
this.solvencyCurrencyTextBox154.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox154.TabIndex = 154;
this.solvencyCurrencyTextBox154.ColName = "R1320C0260";
this.solvencyCurrencyTextBox154.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox155
//
this.solvencyCurrencyTextBox155.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox155.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox155.Location = new System.Drawing.Point(752,171);
this.solvencyCurrencyTextBox155.Name = "solvencyCurrencyTextBox155";
this.solvencyCurrencyTextBox155.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox155.TabIndex = 155;
this.solvencyCurrencyTextBox155.ColName = "R1320C0270";
this.solvencyCurrencyTextBox155.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox156
//
this.solvencyCurrencyTextBox156.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox156.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox156.Location = new System.Drawing.Point(859,171);
this.solvencyCurrencyTextBox156.Name = "solvencyCurrencyTextBox156";
this.solvencyCurrencyTextBox156.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox156.TabIndex = 156;
this.solvencyCurrencyTextBox156.ColName = "R1320C0280";
this.solvencyCurrencyTextBox156.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox157
//
this.solvencyCurrencyTextBox157.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox157.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox157.Location = new System.Drawing.Point(966,171);
this.solvencyCurrencyTextBox157.Name = "solvencyCurrencyTextBox157";
this.solvencyCurrencyTextBox157.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox157.TabIndex = 157;
this.solvencyCurrencyTextBox157.ColName = "R1320C0290";
this.solvencyCurrencyTextBox157.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox158
//
this.solvencyCurrencyTextBox158.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox158.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox158.Location = new System.Drawing.Point(10,191);
this.solvencyCurrencyTextBox158.Name = "solvencyCurrencyTextBox158";
this.solvencyCurrencyTextBox158.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox158.TabIndex = 158;
this.solvencyCurrencyTextBox158.ColName = "R1330C0210";
this.solvencyCurrencyTextBox158.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox158.Enabled = false;
this.solvencyCurrencyTextBox158.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox159
//
this.solvencyCurrencyTextBox159.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox159.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox159.Location = new System.Drawing.Point(117,191);
this.solvencyCurrencyTextBox159.Name = "solvencyCurrencyTextBox159";
this.solvencyCurrencyTextBox159.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox159.TabIndex = 159;
this.solvencyCurrencyTextBox159.ColName = "R1330C0220";
this.solvencyCurrencyTextBox159.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox160
//
this.solvencyCurrencyTextBox160.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox160.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox160.Location = new System.Drawing.Point(224,191);
this.solvencyCurrencyTextBox160.Name = "solvencyCurrencyTextBox160";
this.solvencyCurrencyTextBox160.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox160.TabIndex = 160;
this.solvencyCurrencyTextBox160.ColName = "R1330C0230";
this.solvencyCurrencyTextBox160.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox161
//
this.solvencyCurrencyTextBox161.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox161.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox161.Location = new System.Drawing.Point(331,191);
this.solvencyCurrencyTextBox161.Name = "solvencyCurrencyTextBox161";
this.solvencyCurrencyTextBox161.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox161.TabIndex = 161;
this.solvencyCurrencyTextBox161.ColName = "R1330C0240";
this.solvencyCurrencyTextBox161.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// SolvencyDataComboBox162
//
this.SolvencyDataComboBox162.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox162.Location = new System.Drawing.Point(438,191);
this.SolvencyDataComboBox162.Name = "SolvencyDataComboBox162";
this.SolvencyDataComboBox162.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox162.TabIndex = 162;
this.SolvencyDataComboBox162.ColName = "R1330C0250";
this.SolvencyDataComboBox162.AxisID = 1318;
this.SolvencyDataComboBox162.OrdinateID = 7029;
this.SolvencyDataComboBox162.StartOrder = 0;
this.SolvencyDataComboBox162.NextOrder = 0;
//
// solvencyCurrencyTextBox163
//
this.solvencyCurrencyTextBox163.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox163.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox163.Location = new System.Drawing.Point(645,191);
this.solvencyCurrencyTextBox163.Name = "solvencyCurrencyTextBox163";
this.solvencyCurrencyTextBox163.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox163.TabIndex = 163;
this.solvencyCurrencyTextBox163.ColName = "R1330C0260";
this.solvencyCurrencyTextBox163.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox164
//
this.solvencyCurrencyTextBox164.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox164.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox164.Location = new System.Drawing.Point(752,191);
this.solvencyCurrencyTextBox164.Name = "solvencyCurrencyTextBox164";
this.solvencyCurrencyTextBox164.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox164.TabIndex = 164;
this.solvencyCurrencyTextBox164.ColName = "R1330C0270";
this.solvencyCurrencyTextBox164.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox165
//
this.solvencyCurrencyTextBox165.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox165.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox165.Location = new System.Drawing.Point(859,191);
this.solvencyCurrencyTextBox165.Name = "solvencyCurrencyTextBox165";
this.solvencyCurrencyTextBox165.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox165.TabIndex = 165;
this.solvencyCurrencyTextBox165.ColName = "R1330C0280";
this.solvencyCurrencyTextBox165.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox166
//
this.solvencyCurrencyTextBox166.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox166.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox166.Location = new System.Drawing.Point(966,191);
this.solvencyCurrencyTextBox166.Name = "solvencyCurrencyTextBox166";
this.solvencyCurrencyTextBox166.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox166.TabIndex = 166;
this.solvencyCurrencyTextBox166.ColName = "R1330C0290";
this.solvencyCurrencyTextBox166.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox167
//
this.solvencyCurrencyTextBox167.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox167.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox167.Location = new System.Drawing.Point(10,211);
this.solvencyCurrencyTextBox167.Name = "solvencyCurrencyTextBox167";
this.solvencyCurrencyTextBox167.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox167.TabIndex = 167;
this.solvencyCurrencyTextBox167.ColName = "R1340C0210";
this.solvencyCurrencyTextBox167.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox167.Enabled = false;
this.solvencyCurrencyTextBox167.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox168
//
this.solvencyCurrencyTextBox168.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox168.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox168.Location = new System.Drawing.Point(117,211);
this.solvencyCurrencyTextBox168.Name = "solvencyCurrencyTextBox168";
this.solvencyCurrencyTextBox168.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox168.TabIndex = 168;
this.solvencyCurrencyTextBox168.ColName = "R1340C0220";
this.solvencyCurrencyTextBox168.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox169
//
this.solvencyCurrencyTextBox169.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox169.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox169.Location = new System.Drawing.Point(224,211);
this.solvencyCurrencyTextBox169.Name = "solvencyCurrencyTextBox169";
this.solvencyCurrencyTextBox169.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox169.TabIndex = 169;
this.solvencyCurrencyTextBox169.ColName = "R1340C0230";
this.solvencyCurrencyTextBox169.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox170
//
this.solvencyCurrencyTextBox170.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox170.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox170.Location = new System.Drawing.Point(331,211);
this.solvencyCurrencyTextBox170.Name = "solvencyCurrencyTextBox170";
this.solvencyCurrencyTextBox170.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox170.TabIndex = 170;
this.solvencyCurrencyTextBox170.ColName = "R1340C0240";
this.solvencyCurrencyTextBox170.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// SolvencyDataComboBox171
//
this.SolvencyDataComboBox171.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox171.Location = new System.Drawing.Point(438,211);
this.SolvencyDataComboBox171.Name = "SolvencyDataComboBox171";
this.SolvencyDataComboBox171.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox171.TabIndex = 171;
this.SolvencyDataComboBox171.ColName = "R1340C0250";
this.SolvencyDataComboBox171.AxisID = 1318;
this.SolvencyDataComboBox171.OrdinateID = 7029;
this.SolvencyDataComboBox171.StartOrder = 0;
this.SolvencyDataComboBox171.NextOrder = 0;
//
// solvencyCurrencyTextBox172
//
this.solvencyCurrencyTextBox172.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox172.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox172.Location = new System.Drawing.Point(645,211);
this.solvencyCurrencyTextBox172.Name = "solvencyCurrencyTextBox172";
this.solvencyCurrencyTextBox172.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox172.TabIndex = 172;
this.solvencyCurrencyTextBox172.ColName = "R1340C0260";
this.solvencyCurrencyTextBox172.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox173
//
this.solvencyCurrencyTextBox173.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox173.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox173.Location = new System.Drawing.Point(752,211);
this.solvencyCurrencyTextBox173.Name = "solvencyCurrencyTextBox173";
this.solvencyCurrencyTextBox173.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox173.TabIndex = 173;
this.solvencyCurrencyTextBox173.ColName = "R1340C0270";
this.solvencyCurrencyTextBox173.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox174
//
this.solvencyCurrencyTextBox174.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox174.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox174.Location = new System.Drawing.Point(859,211);
this.solvencyCurrencyTextBox174.Name = "solvencyCurrencyTextBox174";
this.solvencyCurrencyTextBox174.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox174.TabIndex = 174;
this.solvencyCurrencyTextBox174.ColName = "R1340C0280";
this.solvencyCurrencyTextBox174.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox175
//
this.solvencyCurrencyTextBox175.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox175.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox175.Location = new System.Drawing.Point(966,211);
this.solvencyCurrencyTextBox175.Name = "solvencyCurrencyTextBox175";
this.solvencyCurrencyTextBox175.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox175.TabIndex = 175;
this.solvencyCurrencyTextBox175.ColName = "R1340C0290";
this.solvencyCurrencyTextBox175.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox176
//
this.solvencyCurrencyTextBox176.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox176.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox176.Location = new System.Drawing.Point(10,244);
this.solvencyCurrencyTextBox176.Name = "solvencyCurrencyTextBox176";
this.solvencyCurrencyTextBox176.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox176.TabIndex = 176;
this.solvencyCurrencyTextBox176.ColName = "R1350C0210";
this.solvencyCurrencyTextBox176.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox176.Enabled = false;
this.solvencyCurrencyTextBox176.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox177
//
this.solvencyCurrencyTextBox177.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox177.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox177.Location = new System.Drawing.Point(117,244);
this.solvencyCurrencyTextBox177.Name = "solvencyCurrencyTextBox177";
this.solvencyCurrencyTextBox177.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox177.TabIndex = 177;
this.solvencyCurrencyTextBox177.ColName = "R1350C0220";
this.solvencyCurrencyTextBox177.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox178
//
this.solvencyCurrencyTextBox178.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox178.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox178.Location = new System.Drawing.Point(224,244);
this.solvencyCurrencyTextBox178.Name = "solvencyCurrencyTextBox178";
this.solvencyCurrencyTextBox178.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox178.TabIndex = 178;
this.solvencyCurrencyTextBox178.ColName = "R1350C0230";
this.solvencyCurrencyTextBox178.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox179
//
this.solvencyCurrencyTextBox179.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox179.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox179.Location = new System.Drawing.Point(331,244);
this.solvencyCurrencyTextBox179.Name = "solvencyCurrencyTextBox179";
this.solvencyCurrencyTextBox179.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox179.TabIndex = 179;
this.solvencyCurrencyTextBox179.ColName = "R1350C0240";
this.solvencyCurrencyTextBox179.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// SolvencyDataComboBox180
//
this.SolvencyDataComboBox180.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox180.Location = new System.Drawing.Point(438,244);
this.SolvencyDataComboBox180.Name = "SolvencyDataComboBox180";
this.SolvencyDataComboBox180.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox180.TabIndex = 180;
this.SolvencyDataComboBox180.ColName = "R1350C0250";
this.SolvencyDataComboBox180.AxisID = 1318;
this.SolvencyDataComboBox180.OrdinateID = 7029;
this.SolvencyDataComboBox180.StartOrder = 0;
this.SolvencyDataComboBox180.NextOrder = 0;
//
// solvencyCurrencyTextBox181
//
this.solvencyCurrencyTextBox181.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox181.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox181.Location = new System.Drawing.Point(645,244);
this.solvencyCurrencyTextBox181.Name = "solvencyCurrencyTextBox181";
this.solvencyCurrencyTextBox181.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox181.TabIndex = 181;
this.solvencyCurrencyTextBox181.ColName = "R1350C0260";
this.solvencyCurrencyTextBox181.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox182
//
this.solvencyCurrencyTextBox182.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox182.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox182.Location = new System.Drawing.Point(752,244);
this.solvencyCurrencyTextBox182.Name = "solvencyCurrencyTextBox182";
this.solvencyCurrencyTextBox182.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox182.TabIndex = 182;
this.solvencyCurrencyTextBox182.ColName = "R1350C0270";
this.solvencyCurrencyTextBox182.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox183
//
this.solvencyCurrencyTextBox183.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox183.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox183.Location = new System.Drawing.Point(859,244);
this.solvencyCurrencyTextBox183.Name = "solvencyCurrencyTextBox183";
this.solvencyCurrencyTextBox183.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox183.TabIndex = 183;
this.solvencyCurrencyTextBox183.ColName = "R1350C0280";
this.solvencyCurrencyTextBox183.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox184
//
this.solvencyCurrencyTextBox184.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox184.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox184.Location = new System.Drawing.Point(966,244);
this.solvencyCurrencyTextBox184.Name = "solvencyCurrencyTextBox184";
this.solvencyCurrencyTextBox184.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox184.TabIndex = 184;
this.solvencyCurrencyTextBox184.ColName = "R1350C0290";
this.solvencyCurrencyTextBox184.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox185
//
this.solvencyCurrencyTextBox185.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox185.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox185.Location = new System.Drawing.Point(10,264);
this.solvencyCurrencyTextBox185.Name = "solvencyCurrencyTextBox185";
this.solvencyCurrencyTextBox185.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox185.TabIndex = 185;
this.solvencyCurrencyTextBox185.ColName = "R1360C0210";
this.solvencyCurrencyTextBox185.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox185.Enabled = false;
this.solvencyCurrencyTextBox185.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox186
//
this.solvencyCurrencyTextBox186.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox186.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox186.Location = new System.Drawing.Point(117,264);
this.solvencyCurrencyTextBox186.Name = "solvencyCurrencyTextBox186";
this.solvencyCurrencyTextBox186.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox186.TabIndex = 186;
this.solvencyCurrencyTextBox186.ColName = "R1360C0220";
this.solvencyCurrencyTextBox186.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox187
//
this.solvencyCurrencyTextBox187.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox187.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox187.Location = new System.Drawing.Point(224,264);
this.solvencyCurrencyTextBox187.Name = "solvencyCurrencyTextBox187";
this.solvencyCurrencyTextBox187.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox187.TabIndex = 187;
this.solvencyCurrencyTextBox187.ColName = "R1360C0230";
this.solvencyCurrencyTextBox187.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox188
//
this.solvencyCurrencyTextBox188.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox188.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox188.Location = new System.Drawing.Point(331,264);
this.solvencyCurrencyTextBox188.Name = "solvencyCurrencyTextBox188";
this.solvencyCurrencyTextBox188.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox188.TabIndex = 188;
this.solvencyCurrencyTextBox188.ColName = "R1360C0240";
this.solvencyCurrencyTextBox188.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// SolvencyDataComboBox189
//
this.SolvencyDataComboBox189.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox189.Location = new System.Drawing.Point(438,264);
this.SolvencyDataComboBox189.Name = "SolvencyDataComboBox189";
this.SolvencyDataComboBox189.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox189.TabIndex = 189;
this.SolvencyDataComboBox189.ColName = "R1360C0250";
this.SolvencyDataComboBox189.AxisID = 1318;
this.SolvencyDataComboBox189.OrdinateID = 7029;
this.SolvencyDataComboBox189.StartOrder = 0;
this.SolvencyDataComboBox189.NextOrder = 0;
//
// solvencyCurrencyTextBox190
//
this.solvencyCurrencyTextBox190.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox190.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox190.Location = new System.Drawing.Point(645,264);
this.solvencyCurrencyTextBox190.Name = "solvencyCurrencyTextBox190";
this.solvencyCurrencyTextBox190.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox190.TabIndex = 190;
this.solvencyCurrencyTextBox190.ColName = "R1360C0260";
this.solvencyCurrencyTextBox190.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox191
//
this.solvencyCurrencyTextBox191.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox191.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox191.Location = new System.Drawing.Point(752,264);
this.solvencyCurrencyTextBox191.Name = "solvencyCurrencyTextBox191";
this.solvencyCurrencyTextBox191.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox191.TabIndex = 191;
this.solvencyCurrencyTextBox191.ColName = "R1360C0270";
this.solvencyCurrencyTextBox191.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox192
//
this.solvencyCurrencyTextBox192.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox192.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox192.Location = new System.Drawing.Point(859,264);
this.solvencyCurrencyTextBox192.Name = "solvencyCurrencyTextBox192";
this.solvencyCurrencyTextBox192.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox192.TabIndex = 192;
this.solvencyCurrencyTextBox192.ColName = "R1360C0280";
this.solvencyCurrencyTextBox192.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox193
//
this.solvencyCurrencyTextBox193.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox193.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox193.Location = new System.Drawing.Point(966,264);
this.solvencyCurrencyTextBox193.Name = "solvencyCurrencyTextBox193";
this.solvencyCurrencyTextBox193.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox193.TabIndex = 193;
this.solvencyCurrencyTextBox193.ColName = "R1360C0290";
this.solvencyCurrencyTextBox193.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox194
//
this.solvencyCurrencyTextBox194.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox194.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox194.Location = new System.Drawing.Point(10,284);
this.solvencyCurrencyTextBox194.Name = "solvencyCurrencyTextBox194";
this.solvencyCurrencyTextBox194.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox194.TabIndex = 194;
this.solvencyCurrencyTextBox194.ColName = "R1370C0210";
this.solvencyCurrencyTextBox194.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox194.Enabled = false;
this.solvencyCurrencyTextBox194.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox195
//
this.solvencyCurrencyTextBox195.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox195.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox195.Location = new System.Drawing.Point(117,284);
this.solvencyCurrencyTextBox195.Name = "solvencyCurrencyTextBox195";
this.solvencyCurrencyTextBox195.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox195.TabIndex = 195;
this.solvencyCurrencyTextBox195.ColName = "R1370C0220";
this.solvencyCurrencyTextBox195.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox196
//
this.solvencyCurrencyTextBox196.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox196.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox196.Location = new System.Drawing.Point(224,284);
this.solvencyCurrencyTextBox196.Name = "solvencyCurrencyTextBox196";
this.solvencyCurrencyTextBox196.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox196.TabIndex = 196;
this.solvencyCurrencyTextBox196.ColName = "R1370C0230";
this.solvencyCurrencyTextBox196.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox197
//
this.solvencyCurrencyTextBox197.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox197.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox197.Location = new System.Drawing.Point(331,284);
this.solvencyCurrencyTextBox197.Name = "solvencyCurrencyTextBox197";
this.solvencyCurrencyTextBox197.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox197.TabIndex = 197;
this.solvencyCurrencyTextBox197.ColName = "R1370C0240";
this.solvencyCurrencyTextBox197.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// SolvencyDataComboBox198
//
this.SolvencyDataComboBox198.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox198.Location = new System.Drawing.Point(438,284);
this.SolvencyDataComboBox198.Name = "SolvencyDataComboBox198";
this.SolvencyDataComboBox198.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox198.TabIndex = 198;
this.SolvencyDataComboBox198.ColName = "R1370C0250";
this.SolvencyDataComboBox198.AxisID = 1318;
this.SolvencyDataComboBox198.OrdinateID = 7029;
this.SolvencyDataComboBox198.StartOrder = 0;
this.SolvencyDataComboBox198.NextOrder = 0;
//
// solvencyCurrencyTextBox199
//
this.solvencyCurrencyTextBox199.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox199.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox199.Location = new System.Drawing.Point(645,284);
this.solvencyCurrencyTextBox199.Name = "solvencyCurrencyTextBox199";
this.solvencyCurrencyTextBox199.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox199.TabIndex = 199;
this.solvencyCurrencyTextBox199.ColName = "R1370C0260";
this.solvencyCurrencyTextBox199.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox200
//
this.solvencyCurrencyTextBox200.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox200.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox200.Location = new System.Drawing.Point(752,284);
this.solvencyCurrencyTextBox200.Name = "solvencyCurrencyTextBox200";
this.solvencyCurrencyTextBox200.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox200.TabIndex = 200;
this.solvencyCurrencyTextBox200.ColName = "R1370C0270";
this.solvencyCurrencyTextBox200.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox201
//
this.solvencyCurrencyTextBox201.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox201.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox201.Location = new System.Drawing.Point(859,284);
this.solvencyCurrencyTextBox201.Name = "solvencyCurrencyTextBox201";
this.solvencyCurrencyTextBox201.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox201.TabIndex = 201;
this.solvencyCurrencyTextBox201.ColName = "R1370C0280";
this.solvencyCurrencyTextBox201.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox202
//
this.solvencyCurrencyTextBox202.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox202.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox202.Location = new System.Drawing.Point(966,284);
this.solvencyCurrencyTextBox202.Name = "solvencyCurrencyTextBox202";
this.solvencyCurrencyTextBox202.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox202.TabIndex = 202;
this.solvencyCurrencyTextBox202.ColName = "R1370C0290";
this.solvencyCurrencyTextBox202.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox203
//
this.solvencyCurrencyTextBox203.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox203.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox203.Location = new System.Drawing.Point(10,304);
this.solvencyCurrencyTextBox203.Name = "solvencyCurrencyTextBox203";
this.solvencyCurrencyTextBox203.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox203.TabIndex = 203;
this.solvencyCurrencyTextBox203.ColName = "R1380C0210";
this.solvencyCurrencyTextBox203.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox203.Enabled = false;
this.solvencyCurrencyTextBox203.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox204
//
this.solvencyCurrencyTextBox204.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox204.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox204.Location = new System.Drawing.Point(117,304);
this.solvencyCurrencyTextBox204.Name = "solvencyCurrencyTextBox204";
this.solvencyCurrencyTextBox204.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox204.TabIndex = 204;
this.solvencyCurrencyTextBox204.ColName = "R1380C0220";
this.solvencyCurrencyTextBox204.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox205
//
this.solvencyCurrencyTextBox205.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox205.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox205.Location = new System.Drawing.Point(224,304);
this.solvencyCurrencyTextBox205.Name = "solvencyCurrencyTextBox205";
this.solvencyCurrencyTextBox205.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox205.TabIndex = 205;
this.solvencyCurrencyTextBox205.ColName = "R1380C0230";
this.solvencyCurrencyTextBox205.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox206
//
this.solvencyCurrencyTextBox206.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox206.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox206.Location = new System.Drawing.Point(331,304);
this.solvencyCurrencyTextBox206.Name = "solvencyCurrencyTextBox206";
this.solvencyCurrencyTextBox206.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox206.TabIndex = 206;
this.solvencyCurrencyTextBox206.ColName = "R1380C0240";
this.solvencyCurrencyTextBox206.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// SolvencyDataComboBox207
//
this.SolvencyDataComboBox207.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox207.Location = new System.Drawing.Point(438,304);
this.SolvencyDataComboBox207.Name = "SolvencyDataComboBox207";
this.SolvencyDataComboBox207.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox207.TabIndex = 207;
this.SolvencyDataComboBox207.ColName = "R1380C0250";
this.SolvencyDataComboBox207.AxisID = 1318;
this.SolvencyDataComboBox207.OrdinateID = 7029;
this.SolvencyDataComboBox207.StartOrder = 0;
this.SolvencyDataComboBox207.NextOrder = 0;
//
// solvencyCurrencyTextBox208
//
this.solvencyCurrencyTextBox208.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox208.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox208.Location = new System.Drawing.Point(645,304);
this.solvencyCurrencyTextBox208.Name = "solvencyCurrencyTextBox208";
this.solvencyCurrencyTextBox208.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox208.TabIndex = 208;
this.solvencyCurrencyTextBox208.ColName = "R1380C0260";
this.solvencyCurrencyTextBox208.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox209
//
this.solvencyCurrencyTextBox209.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox209.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox209.Location = new System.Drawing.Point(752,304);
this.solvencyCurrencyTextBox209.Name = "solvencyCurrencyTextBox209";
this.solvencyCurrencyTextBox209.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox209.TabIndex = 209;
this.solvencyCurrencyTextBox209.ColName = "R1380C0270";
this.solvencyCurrencyTextBox209.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox210
//
this.solvencyCurrencyTextBox210.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox210.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox210.Location = new System.Drawing.Point(859,304);
this.solvencyCurrencyTextBox210.Name = "solvencyCurrencyTextBox210";
this.solvencyCurrencyTextBox210.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox210.TabIndex = 210;
this.solvencyCurrencyTextBox210.ColName = "R1380C0280";
this.solvencyCurrencyTextBox210.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox211
//
this.solvencyCurrencyTextBox211.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox211.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox211.Location = new System.Drawing.Point(966,304);
this.solvencyCurrencyTextBox211.Name = "solvencyCurrencyTextBox211";
this.solvencyCurrencyTextBox211.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox211.TabIndex = 211;
this.solvencyCurrencyTextBox211.ColName = "R1380C0290";
this.solvencyCurrencyTextBox211.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox212
//
this.solvencyCurrencyTextBox212.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox212.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox212.Location = new System.Drawing.Point(10,324);
this.solvencyCurrencyTextBox212.Name = "solvencyCurrencyTextBox212";
this.solvencyCurrencyTextBox212.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox212.TabIndex = 212;
this.solvencyCurrencyTextBox212.ColName = "R1390C0210";
this.solvencyCurrencyTextBox212.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox212.Enabled = false;
this.solvencyCurrencyTextBox212.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox213
//
this.solvencyCurrencyTextBox213.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox213.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox213.Location = new System.Drawing.Point(117,324);
this.solvencyCurrencyTextBox213.Name = "solvencyCurrencyTextBox213";
this.solvencyCurrencyTextBox213.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox213.TabIndex = 213;
this.solvencyCurrencyTextBox213.ColName = "R1390C0220";
this.solvencyCurrencyTextBox213.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox214
//
this.solvencyCurrencyTextBox214.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox214.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox214.Location = new System.Drawing.Point(224,324);
this.solvencyCurrencyTextBox214.Name = "solvencyCurrencyTextBox214";
this.solvencyCurrencyTextBox214.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox214.TabIndex = 214;
this.solvencyCurrencyTextBox214.ColName = "R1390C0230";
this.solvencyCurrencyTextBox214.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox215
//
this.solvencyCurrencyTextBox215.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox215.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox215.Location = new System.Drawing.Point(331,324);
this.solvencyCurrencyTextBox215.Name = "solvencyCurrencyTextBox215";
this.solvencyCurrencyTextBox215.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox215.TabIndex = 215;
this.solvencyCurrencyTextBox215.ColName = "R1390C0240";
this.solvencyCurrencyTextBox215.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// SolvencyDataComboBox216
//
this.SolvencyDataComboBox216.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox216.Location = new System.Drawing.Point(438,324);
this.SolvencyDataComboBox216.Name = "SolvencyDataComboBox216";
this.SolvencyDataComboBox216.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox216.TabIndex = 216;
this.SolvencyDataComboBox216.ColName = "R1390C0250";
this.SolvencyDataComboBox216.AxisID = 1318;
this.SolvencyDataComboBox216.OrdinateID = 7029;
this.SolvencyDataComboBox216.StartOrder = 0;
this.SolvencyDataComboBox216.NextOrder = 0;
//
// solvencyCurrencyTextBox217
//
this.solvencyCurrencyTextBox217.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox217.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox217.Location = new System.Drawing.Point(645,324);
this.solvencyCurrencyTextBox217.Name = "solvencyCurrencyTextBox217";
this.solvencyCurrencyTextBox217.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox217.TabIndex = 217;
this.solvencyCurrencyTextBox217.ColName = "R1390C0260";
this.solvencyCurrencyTextBox217.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox218
//
this.solvencyCurrencyTextBox218.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox218.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox218.Location = new System.Drawing.Point(752,324);
this.solvencyCurrencyTextBox218.Name = "solvencyCurrencyTextBox218";
this.solvencyCurrencyTextBox218.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox218.TabIndex = 218;
this.solvencyCurrencyTextBox218.ColName = "R1390C0270";
this.solvencyCurrencyTextBox218.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox219
//
this.solvencyCurrencyTextBox219.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox219.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox219.Location = new System.Drawing.Point(859,324);
this.solvencyCurrencyTextBox219.Name = "solvencyCurrencyTextBox219";
this.solvencyCurrencyTextBox219.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox219.TabIndex = 219;
this.solvencyCurrencyTextBox219.ColName = "R1390C0280";
this.solvencyCurrencyTextBox219.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox220
//
this.solvencyCurrencyTextBox220.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox220.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox220.Location = new System.Drawing.Point(966,324);
this.solvencyCurrencyTextBox220.Name = "solvencyCurrencyTextBox220";
this.solvencyCurrencyTextBox220.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox220.TabIndex = 220;
this.solvencyCurrencyTextBox220.ColName = "R1390C0290";
this.solvencyCurrencyTextBox220.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox221
//
this.solvencyCurrencyTextBox221.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox221.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox221.Location = new System.Drawing.Point(10,357);
this.solvencyCurrencyTextBox221.Name = "solvencyCurrencyTextBox221";
this.solvencyCurrencyTextBox221.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox221.TabIndex = 221;
this.solvencyCurrencyTextBox221.ColName = "R1400C0210";
this.solvencyCurrencyTextBox221.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox221.Enabled = false;
this.solvencyCurrencyTextBox221.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox222
//
this.solvencyCurrencyTextBox222.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox222.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox222.Location = new System.Drawing.Point(117,357);
this.solvencyCurrencyTextBox222.Name = "solvencyCurrencyTextBox222";
this.solvencyCurrencyTextBox222.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox222.TabIndex = 222;
this.solvencyCurrencyTextBox222.ColName = "R1400C0220";
this.solvencyCurrencyTextBox222.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox223
//
this.solvencyCurrencyTextBox223.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox223.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox223.Location = new System.Drawing.Point(224,357);
this.solvencyCurrencyTextBox223.Name = "solvencyCurrencyTextBox223";
this.solvencyCurrencyTextBox223.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox223.TabIndex = 223;
this.solvencyCurrencyTextBox223.ColName = "R1400C0230";
this.solvencyCurrencyTextBox223.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox224
//
this.solvencyCurrencyTextBox224.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox224.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox224.Location = new System.Drawing.Point(331,357);
this.solvencyCurrencyTextBox224.Name = "solvencyCurrencyTextBox224";
this.solvencyCurrencyTextBox224.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox224.TabIndex = 224;
this.solvencyCurrencyTextBox224.ColName = "R1400C0240";
this.solvencyCurrencyTextBox224.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// SolvencyDataComboBox225
//
this.SolvencyDataComboBox225.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox225.Location = new System.Drawing.Point(438,357);
this.SolvencyDataComboBox225.Name = "SolvencyDataComboBox225";
this.SolvencyDataComboBox225.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox225.TabIndex = 225;
this.SolvencyDataComboBox225.ColName = "R1400C0250";
this.SolvencyDataComboBox225.AxisID = 1318;
this.SolvencyDataComboBox225.OrdinateID = 7029;
this.SolvencyDataComboBox225.StartOrder = 0;
this.SolvencyDataComboBox225.NextOrder = 0;
this.SolvencyDataComboBox225.Enabled = false;
this.SolvencyDataComboBox225.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox226
//
this.solvencyCurrencyTextBox226.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox226.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox226.Location = new System.Drawing.Point(645,357);
this.solvencyCurrencyTextBox226.Name = "solvencyCurrencyTextBox226";
this.solvencyCurrencyTextBox226.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox226.TabIndex = 226;
this.solvencyCurrencyTextBox226.ColName = "R1400C0260";
this.solvencyCurrencyTextBox226.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox227
//
this.solvencyCurrencyTextBox227.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox227.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox227.Location = new System.Drawing.Point(752,357);
this.solvencyCurrencyTextBox227.Name = "solvencyCurrencyTextBox227";
this.solvencyCurrencyTextBox227.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox227.TabIndex = 227;
this.solvencyCurrencyTextBox227.ColName = "R1400C0270";
this.solvencyCurrencyTextBox227.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox228
//
this.solvencyCurrencyTextBox228.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox228.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox228.Location = new System.Drawing.Point(859,357);
this.solvencyCurrencyTextBox228.Name = "solvencyCurrencyTextBox228";
this.solvencyCurrencyTextBox228.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox228.TabIndex = 228;
this.solvencyCurrencyTextBox228.ColName = "R1400C0280";
this.solvencyCurrencyTextBox228.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox229
//
this.solvencyCurrencyTextBox229.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox229.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox229.Location = new System.Drawing.Point(966,357);
this.solvencyCurrencyTextBox229.Name = "solvencyCurrencyTextBox229";
this.solvencyCurrencyTextBox229.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox229.TabIndex = 229;
this.solvencyCurrencyTextBox229.ColName = "R1400C0290";
this.solvencyCurrencyTextBox229.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox230
//
this.solvencyCurrencyTextBox230.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox230.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox230.Location = new System.Drawing.Point(10,377);
this.solvencyCurrencyTextBox230.Name = "solvencyCurrencyTextBox230";
this.solvencyCurrencyTextBox230.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox230.TabIndex = 230;
this.solvencyCurrencyTextBox230.ColName = "R1410C0210";
this.solvencyCurrencyTextBox230.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox231
//
this.solvencyCurrencyTextBox231.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox231.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox231.Location = new System.Drawing.Point(117,377);
this.solvencyCurrencyTextBox231.Name = "solvencyCurrencyTextBox231";
this.solvencyCurrencyTextBox231.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox231.TabIndex = 231;
this.solvencyCurrencyTextBox231.ColName = "R1410C0220";
this.solvencyCurrencyTextBox231.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox231.Enabled = false;
this.solvencyCurrencyTextBox231.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox232
//
this.solvencyCurrencyTextBox232.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox232.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox232.Location = new System.Drawing.Point(224,377);
this.solvencyCurrencyTextBox232.Name = "solvencyCurrencyTextBox232";
this.solvencyCurrencyTextBox232.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox232.TabIndex = 232;
this.solvencyCurrencyTextBox232.ColName = "R1410C0230";
this.solvencyCurrencyTextBox232.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox232.Enabled = false;
this.solvencyCurrencyTextBox232.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox233
//
this.solvencyCurrencyTextBox233.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox233.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox233.Location = new System.Drawing.Point(331,377);
this.solvencyCurrencyTextBox233.Name = "solvencyCurrencyTextBox233";
this.solvencyCurrencyTextBox233.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox233.TabIndex = 233;
this.solvencyCurrencyTextBox233.ColName = "R1410C0240";
this.solvencyCurrencyTextBox233.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox233.Enabled = false;
this.solvencyCurrencyTextBox233.BackColor = System.Drawing.Color.Gray;
//
// SolvencyDataComboBox234
//
this.SolvencyDataComboBox234.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox234.Location = new System.Drawing.Point(438,377);
this.SolvencyDataComboBox234.Name = "SolvencyDataComboBox234";
this.SolvencyDataComboBox234.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox234.TabIndex = 234;
this.SolvencyDataComboBox234.ColName = "R1410C0250";
this.SolvencyDataComboBox234.AxisID = 1318;
this.SolvencyDataComboBox234.OrdinateID = 7029;
this.SolvencyDataComboBox234.StartOrder = 0;
this.SolvencyDataComboBox234.NextOrder = 0;
this.SolvencyDataComboBox234.Enabled = false;
this.SolvencyDataComboBox234.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox235
//
this.solvencyCurrencyTextBox235.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox235.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox235.Location = new System.Drawing.Point(645,377);
this.solvencyCurrencyTextBox235.Name = "solvencyCurrencyTextBox235";
this.solvencyCurrencyTextBox235.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox235.TabIndex = 235;
this.solvencyCurrencyTextBox235.ColName = "R1410C0260";
this.solvencyCurrencyTextBox235.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox235.Enabled = false;
this.solvencyCurrencyTextBox235.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox236
//
this.solvencyCurrencyTextBox236.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox236.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox236.Location = new System.Drawing.Point(752,377);
this.solvencyCurrencyTextBox236.Name = "solvencyCurrencyTextBox236";
this.solvencyCurrencyTextBox236.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox236.TabIndex = 236;
this.solvencyCurrencyTextBox236.ColName = "R1410C0270";
this.solvencyCurrencyTextBox236.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox236.Enabled = false;
this.solvencyCurrencyTextBox236.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox237
//
this.solvencyCurrencyTextBox237.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox237.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox237.Location = new System.Drawing.Point(859,377);
this.solvencyCurrencyTextBox237.Name = "solvencyCurrencyTextBox237";
this.solvencyCurrencyTextBox237.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox237.TabIndex = 237;
this.solvencyCurrencyTextBox237.ColName = "R1410C0280";
this.solvencyCurrencyTextBox237.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox237.Enabled = false;
this.solvencyCurrencyTextBox237.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox238
//
this.solvencyCurrencyTextBox238.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox238.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox238.Location = new System.Drawing.Point(966,377);
this.solvencyCurrencyTextBox238.Name = "solvencyCurrencyTextBox238";
this.solvencyCurrencyTextBox238.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox238.TabIndex = 238;
this.solvencyCurrencyTextBox238.ColName = "R1410C0290";
this.solvencyCurrencyTextBox238.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox238.Enabled = false;
this.solvencyCurrencyTextBox238.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox239
//
this.solvencyCurrencyTextBox239.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox239.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox239.Location = new System.Drawing.Point(10,397);
this.solvencyCurrencyTextBox239.Name = "solvencyCurrencyTextBox239";
this.solvencyCurrencyTextBox239.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox239.TabIndex = 239;
this.solvencyCurrencyTextBox239.ColName = "R1420C0210";
this.solvencyCurrencyTextBox239.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox240
//
this.solvencyCurrencyTextBox240.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox240.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox240.Location = new System.Drawing.Point(117,397);
this.solvencyCurrencyTextBox240.Name = "solvencyCurrencyTextBox240";
this.solvencyCurrencyTextBox240.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox240.TabIndex = 240;
this.solvencyCurrencyTextBox240.ColName = "R1420C0220";
this.solvencyCurrencyTextBox240.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox240.Enabled = false;
this.solvencyCurrencyTextBox240.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox241
//
this.solvencyCurrencyTextBox241.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox241.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox241.Location = new System.Drawing.Point(224,397);
this.solvencyCurrencyTextBox241.Name = "solvencyCurrencyTextBox241";
this.solvencyCurrencyTextBox241.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox241.TabIndex = 241;
this.solvencyCurrencyTextBox241.ColName = "R1420C0230";
this.solvencyCurrencyTextBox241.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox241.Enabled = false;
this.solvencyCurrencyTextBox241.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox242
//
this.solvencyCurrencyTextBox242.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox242.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox242.Location = new System.Drawing.Point(331,397);
this.solvencyCurrencyTextBox242.Name = "solvencyCurrencyTextBox242";
this.solvencyCurrencyTextBox242.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox242.TabIndex = 242;
this.solvencyCurrencyTextBox242.ColName = "R1420C0240";
this.solvencyCurrencyTextBox242.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox242.Enabled = false;
this.solvencyCurrencyTextBox242.BackColor = System.Drawing.Color.Gray;
//
// SolvencyDataComboBox243
//
this.SolvencyDataComboBox243.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox243.Location = new System.Drawing.Point(438,397);
this.SolvencyDataComboBox243.Name = "SolvencyDataComboBox243";
this.SolvencyDataComboBox243.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox243.TabIndex = 243;
this.SolvencyDataComboBox243.ColName = "R1420C0250";
this.SolvencyDataComboBox243.AxisID = 1318;
this.SolvencyDataComboBox243.OrdinateID = 7029;
this.SolvencyDataComboBox243.StartOrder = 0;
this.SolvencyDataComboBox243.NextOrder = 0;
this.SolvencyDataComboBox243.Enabled = false;
this.SolvencyDataComboBox243.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox244
//
this.solvencyCurrencyTextBox244.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox244.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox244.Location = new System.Drawing.Point(645,397);
this.solvencyCurrencyTextBox244.Name = "solvencyCurrencyTextBox244";
this.solvencyCurrencyTextBox244.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox244.TabIndex = 244;
this.solvencyCurrencyTextBox244.ColName = "R1420C0260";
this.solvencyCurrencyTextBox244.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox244.Enabled = false;
this.solvencyCurrencyTextBox244.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox245
//
this.solvencyCurrencyTextBox245.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox245.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox245.Location = new System.Drawing.Point(752,397);
this.solvencyCurrencyTextBox245.Name = "solvencyCurrencyTextBox245";
this.solvencyCurrencyTextBox245.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox245.TabIndex = 245;
this.solvencyCurrencyTextBox245.ColName = "R1420C0270";
this.solvencyCurrencyTextBox245.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox245.Enabled = false;
this.solvencyCurrencyTextBox245.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox246
//
this.solvencyCurrencyTextBox246.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox246.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox246.Location = new System.Drawing.Point(859,397);
this.solvencyCurrencyTextBox246.Name = "solvencyCurrencyTextBox246";
this.solvencyCurrencyTextBox246.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox246.TabIndex = 246;
this.solvencyCurrencyTextBox246.ColName = "R1420C0280";
this.solvencyCurrencyTextBox246.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox246.Enabled = false;
this.solvencyCurrencyTextBox246.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox247
//
this.solvencyCurrencyTextBox247.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox247.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox247.Location = new System.Drawing.Point(966,397);
this.solvencyCurrencyTextBox247.Name = "solvencyCurrencyTextBox247";
this.solvencyCurrencyTextBox247.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox247.TabIndex = 247;
this.solvencyCurrencyTextBox247.ColName = "R1420C0290";
this.solvencyCurrencyTextBox247.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox247.Enabled = false;
this.solvencyCurrencyTextBox247.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox248
//
this.solvencyCurrencyTextBox248.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox248.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox248.Location = new System.Drawing.Point(10,417);
this.solvencyCurrencyTextBox248.Name = "solvencyCurrencyTextBox248";
this.solvencyCurrencyTextBox248.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox248.TabIndex = 248;
this.solvencyCurrencyTextBox248.ColName = "R1430C0210";
this.solvencyCurrencyTextBox248.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox249
//
this.solvencyCurrencyTextBox249.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox249.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox249.Location = new System.Drawing.Point(117,417);
this.solvencyCurrencyTextBox249.Name = "solvencyCurrencyTextBox249";
this.solvencyCurrencyTextBox249.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox249.TabIndex = 249;
this.solvencyCurrencyTextBox249.ColName = "R1430C0220";
this.solvencyCurrencyTextBox249.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox249.Enabled = false;
this.solvencyCurrencyTextBox249.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox250
//
this.solvencyCurrencyTextBox250.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox250.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox250.Location = new System.Drawing.Point(224,417);
this.solvencyCurrencyTextBox250.Name = "solvencyCurrencyTextBox250";
this.solvencyCurrencyTextBox250.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox250.TabIndex = 250;
this.solvencyCurrencyTextBox250.ColName = "R1430C0230";
this.solvencyCurrencyTextBox250.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox250.Enabled = false;
this.solvencyCurrencyTextBox250.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox251
//
this.solvencyCurrencyTextBox251.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox251.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox251.Location = new System.Drawing.Point(331,417);
this.solvencyCurrencyTextBox251.Name = "solvencyCurrencyTextBox251";
this.solvencyCurrencyTextBox251.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox251.TabIndex = 251;
this.solvencyCurrencyTextBox251.ColName = "R1430C0240";
this.solvencyCurrencyTextBox251.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox251.Enabled = false;
this.solvencyCurrencyTextBox251.BackColor = System.Drawing.Color.Gray;
//
// SolvencyDataComboBox252
//
this.SolvencyDataComboBox252.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox252.Location = new System.Drawing.Point(438,417);
this.SolvencyDataComboBox252.Name = "SolvencyDataComboBox252";
this.SolvencyDataComboBox252.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox252.TabIndex = 252;
this.SolvencyDataComboBox252.ColName = "R1430C0250";
this.SolvencyDataComboBox252.AxisID = 1318;
this.SolvencyDataComboBox252.OrdinateID = 7029;
this.SolvencyDataComboBox252.StartOrder = 0;
this.SolvencyDataComboBox252.NextOrder = 0;
this.SolvencyDataComboBox252.Enabled = false;
this.SolvencyDataComboBox252.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox253
//
this.solvencyCurrencyTextBox253.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox253.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox253.Location = new System.Drawing.Point(645,417);
this.solvencyCurrencyTextBox253.Name = "solvencyCurrencyTextBox253";
this.solvencyCurrencyTextBox253.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox253.TabIndex = 253;
this.solvencyCurrencyTextBox253.ColName = "R1430C0260";
this.solvencyCurrencyTextBox253.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox253.Enabled = false;
this.solvencyCurrencyTextBox253.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox254
//
this.solvencyCurrencyTextBox254.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox254.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox254.Location = new System.Drawing.Point(752,417);
this.solvencyCurrencyTextBox254.Name = "solvencyCurrencyTextBox254";
this.solvencyCurrencyTextBox254.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox254.TabIndex = 254;
this.solvencyCurrencyTextBox254.ColName = "R1430C0270";
this.solvencyCurrencyTextBox254.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox254.Enabled = false;
this.solvencyCurrencyTextBox254.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox255
//
this.solvencyCurrencyTextBox255.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox255.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox255.Location = new System.Drawing.Point(859,417);
this.solvencyCurrencyTextBox255.Name = "solvencyCurrencyTextBox255";
this.solvencyCurrencyTextBox255.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox255.TabIndex = 255;
this.solvencyCurrencyTextBox255.ColName = "R1430C0280";
this.solvencyCurrencyTextBox255.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox255.Enabled = false;
this.solvencyCurrencyTextBox255.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox256
//
this.solvencyCurrencyTextBox256.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox256.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox256.Location = new System.Drawing.Point(966,417);
this.solvencyCurrencyTextBox256.Name = "solvencyCurrencyTextBox256";
this.solvencyCurrencyTextBox256.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox256.TabIndex = 256;
this.solvencyCurrencyTextBox256.ColName = "R1430C0290";
this.solvencyCurrencyTextBox256.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox256.Enabled = false;
this.solvencyCurrencyTextBox256.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox257
//
this.solvencyCurrencyTextBox257.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox257.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox257.Location = new System.Drawing.Point(10,437);
this.solvencyCurrencyTextBox257.Name = "solvencyCurrencyTextBox257";
this.solvencyCurrencyTextBox257.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox257.TabIndex = 257;
this.solvencyCurrencyTextBox257.ColName = "R1440C0210";
this.solvencyCurrencyTextBox257.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox258
//
this.solvencyCurrencyTextBox258.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox258.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox258.Location = new System.Drawing.Point(117,437);
this.solvencyCurrencyTextBox258.Name = "solvencyCurrencyTextBox258";
this.solvencyCurrencyTextBox258.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox258.TabIndex = 258;
this.solvencyCurrencyTextBox258.ColName = "R1440C0220";
this.solvencyCurrencyTextBox258.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox258.Enabled = false;
this.solvencyCurrencyTextBox258.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox259
//
this.solvencyCurrencyTextBox259.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox259.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox259.Location = new System.Drawing.Point(224,437);
this.solvencyCurrencyTextBox259.Name = "solvencyCurrencyTextBox259";
this.solvencyCurrencyTextBox259.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox259.TabIndex = 259;
this.solvencyCurrencyTextBox259.ColName = "R1440C0230";
this.solvencyCurrencyTextBox259.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox259.Enabled = false;
this.solvencyCurrencyTextBox259.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox260
//
this.solvencyCurrencyTextBox260.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox260.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox260.Location = new System.Drawing.Point(331,437);
this.solvencyCurrencyTextBox260.Name = "solvencyCurrencyTextBox260";
this.solvencyCurrencyTextBox260.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox260.TabIndex = 260;
this.solvencyCurrencyTextBox260.ColName = "R1440C0240";
this.solvencyCurrencyTextBox260.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox260.Enabled = false;
this.solvencyCurrencyTextBox260.BackColor = System.Drawing.Color.Gray;
//
// SolvencyDataComboBox261
//
this.SolvencyDataComboBox261.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox261.Location = new System.Drawing.Point(438,437);
this.SolvencyDataComboBox261.Name = "SolvencyDataComboBox261";
this.SolvencyDataComboBox261.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox261.TabIndex = 261;
this.SolvencyDataComboBox261.ColName = "R1440C0250";
this.SolvencyDataComboBox261.AxisID = 1318;
this.SolvencyDataComboBox261.OrdinateID = 7029;
this.SolvencyDataComboBox261.StartOrder = 0;
this.SolvencyDataComboBox261.NextOrder = 0;
this.SolvencyDataComboBox261.Enabled = false;
this.SolvencyDataComboBox261.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox262
//
this.solvencyCurrencyTextBox262.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox262.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox262.Location = new System.Drawing.Point(645,437);
this.solvencyCurrencyTextBox262.Name = "solvencyCurrencyTextBox262";
this.solvencyCurrencyTextBox262.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox262.TabIndex = 262;
this.solvencyCurrencyTextBox262.ColName = "R1440C0260";
this.solvencyCurrencyTextBox262.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox262.Enabled = false;
this.solvencyCurrencyTextBox262.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox263
//
this.solvencyCurrencyTextBox263.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox263.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox263.Location = new System.Drawing.Point(752,437);
this.solvencyCurrencyTextBox263.Name = "solvencyCurrencyTextBox263";
this.solvencyCurrencyTextBox263.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox263.TabIndex = 263;
this.solvencyCurrencyTextBox263.ColName = "R1440C0270";
this.solvencyCurrencyTextBox263.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox263.Enabled = false;
this.solvencyCurrencyTextBox263.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox264
//
this.solvencyCurrencyTextBox264.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox264.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox264.Location = new System.Drawing.Point(859,437);
this.solvencyCurrencyTextBox264.Name = "solvencyCurrencyTextBox264";
this.solvencyCurrencyTextBox264.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox264.TabIndex = 264;
this.solvencyCurrencyTextBox264.ColName = "R1440C0280";
this.solvencyCurrencyTextBox264.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox264.Enabled = false;
this.solvencyCurrencyTextBox264.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox265
//
this.solvencyCurrencyTextBox265.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox265.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox265.Location = new System.Drawing.Point(966,437);
this.solvencyCurrencyTextBox265.Name = "solvencyCurrencyTextBox265";
this.solvencyCurrencyTextBox265.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox265.TabIndex = 265;
this.solvencyCurrencyTextBox265.ColName = "R1440C0290";
this.solvencyCurrencyTextBox265.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox265.Enabled = false;
this.solvencyCurrencyTextBox265.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox266
//
this.solvencyCurrencyTextBox266.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox266.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox266.Location = new System.Drawing.Point(10,457);
this.solvencyCurrencyTextBox266.Name = "solvencyCurrencyTextBox266";
this.solvencyCurrencyTextBox266.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox266.TabIndex = 266;
this.solvencyCurrencyTextBox266.ColName = "R1450C0210";
this.solvencyCurrencyTextBox266.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox267
//
this.solvencyCurrencyTextBox267.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox267.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox267.Location = new System.Drawing.Point(117,457);
this.solvencyCurrencyTextBox267.Name = "solvencyCurrencyTextBox267";
this.solvencyCurrencyTextBox267.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox267.TabIndex = 267;
this.solvencyCurrencyTextBox267.ColName = "R1450C0220";
this.solvencyCurrencyTextBox267.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox267.Enabled = false;
this.solvencyCurrencyTextBox267.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox268
//
this.solvencyCurrencyTextBox268.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox268.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox268.Location = new System.Drawing.Point(224,457);
this.solvencyCurrencyTextBox268.Name = "solvencyCurrencyTextBox268";
this.solvencyCurrencyTextBox268.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox268.TabIndex = 268;
this.solvencyCurrencyTextBox268.ColName = "R1450C0230";
this.solvencyCurrencyTextBox268.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox268.Enabled = false;
this.solvencyCurrencyTextBox268.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox269
//
this.solvencyCurrencyTextBox269.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox269.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox269.Location = new System.Drawing.Point(331,457);
this.solvencyCurrencyTextBox269.Name = "solvencyCurrencyTextBox269";
this.solvencyCurrencyTextBox269.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox269.TabIndex = 269;
this.solvencyCurrencyTextBox269.ColName = "R1450C0240";
this.solvencyCurrencyTextBox269.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox269.Enabled = false;
this.solvencyCurrencyTextBox269.BackColor = System.Drawing.Color.Gray;
//
// SolvencyDataComboBox270
//
this.SolvencyDataComboBox270.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox270.Location = new System.Drawing.Point(438,457);
this.SolvencyDataComboBox270.Name = "SolvencyDataComboBox270";
this.SolvencyDataComboBox270.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox270.TabIndex = 270;
this.SolvencyDataComboBox270.ColName = "R1450C0250";
this.SolvencyDataComboBox270.AxisID = 1318;
this.SolvencyDataComboBox270.OrdinateID = 7029;
this.SolvencyDataComboBox270.StartOrder = 0;
this.SolvencyDataComboBox270.NextOrder = 0;
this.SolvencyDataComboBox270.Enabled = false;
this.SolvencyDataComboBox270.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox271
//
this.solvencyCurrencyTextBox271.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox271.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox271.Location = new System.Drawing.Point(645,457);
this.solvencyCurrencyTextBox271.Name = "solvencyCurrencyTextBox271";
this.solvencyCurrencyTextBox271.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox271.TabIndex = 271;
this.solvencyCurrencyTextBox271.ColName = "R1450C0260";
this.solvencyCurrencyTextBox271.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox271.Enabled = false;
this.solvencyCurrencyTextBox271.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox272
//
this.solvencyCurrencyTextBox272.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox272.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox272.Location = new System.Drawing.Point(752,457);
this.solvencyCurrencyTextBox272.Name = "solvencyCurrencyTextBox272";
this.solvencyCurrencyTextBox272.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox272.TabIndex = 272;
this.solvencyCurrencyTextBox272.ColName = "R1450C0270";
this.solvencyCurrencyTextBox272.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox272.Enabled = false;
this.solvencyCurrencyTextBox272.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox273
//
this.solvencyCurrencyTextBox273.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox273.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox273.Location = new System.Drawing.Point(859,457);
this.solvencyCurrencyTextBox273.Name = "solvencyCurrencyTextBox273";
this.solvencyCurrencyTextBox273.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox273.TabIndex = 273;
this.solvencyCurrencyTextBox273.ColName = "R1450C0280";
this.solvencyCurrencyTextBox273.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox273.Enabled = false;
this.solvencyCurrencyTextBox273.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox274
//
this.solvencyCurrencyTextBox274.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox274.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox274.Location = new System.Drawing.Point(966,457);
this.solvencyCurrencyTextBox274.Name = "solvencyCurrencyTextBox274";
this.solvencyCurrencyTextBox274.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox274.TabIndex = 274;
this.solvencyCurrencyTextBox274.ColName = "R1450C0290";
this.solvencyCurrencyTextBox274.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox274.Enabled = false;
this.solvencyCurrencyTextBox274.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox275
//
this.solvencyCurrencyTextBox275.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox275.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox275.Location = new System.Drawing.Point(10,477);
this.solvencyCurrencyTextBox275.Name = "solvencyCurrencyTextBox275";
this.solvencyCurrencyTextBox275.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox275.TabIndex = 275;
this.solvencyCurrencyTextBox275.ColName = "R1460C0210";
this.solvencyCurrencyTextBox275.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox276
//
this.solvencyCurrencyTextBox276.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox276.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox276.Location = new System.Drawing.Point(117,477);
this.solvencyCurrencyTextBox276.Name = "solvencyCurrencyTextBox276";
this.solvencyCurrencyTextBox276.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox276.TabIndex = 276;
this.solvencyCurrencyTextBox276.ColName = "R1460C0220";
this.solvencyCurrencyTextBox276.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox276.Enabled = false;
this.solvencyCurrencyTextBox276.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox277
//
this.solvencyCurrencyTextBox277.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox277.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox277.Location = new System.Drawing.Point(224,477);
this.solvencyCurrencyTextBox277.Name = "solvencyCurrencyTextBox277";
this.solvencyCurrencyTextBox277.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox277.TabIndex = 277;
this.solvencyCurrencyTextBox277.ColName = "R1460C0230";
this.solvencyCurrencyTextBox277.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox277.Enabled = false;
this.solvencyCurrencyTextBox277.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox278
//
this.solvencyCurrencyTextBox278.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox278.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox278.Location = new System.Drawing.Point(331,477);
this.solvencyCurrencyTextBox278.Name = "solvencyCurrencyTextBox278";
this.solvencyCurrencyTextBox278.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox278.TabIndex = 278;
this.solvencyCurrencyTextBox278.ColName = "R1460C0240";
this.solvencyCurrencyTextBox278.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox278.Enabled = false;
this.solvencyCurrencyTextBox278.BackColor = System.Drawing.Color.Gray;
//
// SolvencyDataComboBox279
//
this.SolvencyDataComboBox279.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox279.Location = new System.Drawing.Point(438,477);
this.SolvencyDataComboBox279.Name = "SolvencyDataComboBox279";
this.SolvencyDataComboBox279.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox279.TabIndex = 279;
this.SolvencyDataComboBox279.ColName = "R1460C0250";
this.SolvencyDataComboBox279.AxisID = 1318;
this.SolvencyDataComboBox279.OrdinateID = 7029;
this.SolvencyDataComboBox279.StartOrder = 0;
this.SolvencyDataComboBox279.NextOrder = 0;
this.SolvencyDataComboBox279.Enabled = false;
this.SolvencyDataComboBox279.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox280
//
this.solvencyCurrencyTextBox280.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox280.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox280.Location = new System.Drawing.Point(645,477);
this.solvencyCurrencyTextBox280.Name = "solvencyCurrencyTextBox280";
this.solvencyCurrencyTextBox280.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox280.TabIndex = 280;
this.solvencyCurrencyTextBox280.ColName = "R1460C0260";
this.solvencyCurrencyTextBox280.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox280.Enabled = false;
this.solvencyCurrencyTextBox280.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox281
//
this.solvencyCurrencyTextBox281.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox281.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox281.Location = new System.Drawing.Point(752,477);
this.solvencyCurrencyTextBox281.Name = "solvencyCurrencyTextBox281";
this.solvencyCurrencyTextBox281.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox281.TabIndex = 281;
this.solvencyCurrencyTextBox281.ColName = "R1460C0270";
this.solvencyCurrencyTextBox281.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox281.Enabled = false;
this.solvencyCurrencyTextBox281.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox282
//
this.solvencyCurrencyTextBox282.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox282.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox282.Location = new System.Drawing.Point(859,477);
this.solvencyCurrencyTextBox282.Name = "solvencyCurrencyTextBox282";
this.solvencyCurrencyTextBox282.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox282.TabIndex = 282;
this.solvencyCurrencyTextBox282.ColName = "R1460C0280";
this.solvencyCurrencyTextBox282.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox282.Enabled = false;
this.solvencyCurrencyTextBox282.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox283
//
this.solvencyCurrencyTextBox283.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox283.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox283.Location = new System.Drawing.Point(966,477);
this.solvencyCurrencyTextBox283.Name = "solvencyCurrencyTextBox283";
this.solvencyCurrencyTextBox283.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox283.TabIndex = 283;
this.solvencyCurrencyTextBox283.ColName = "R1460C0290";
this.solvencyCurrencyTextBox283.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox283.Enabled = false;
this.solvencyCurrencyTextBox283.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox284
//
this.solvencyCurrencyTextBox284.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox284.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox284.Location = new System.Drawing.Point(10,497);
this.solvencyCurrencyTextBox284.Name = "solvencyCurrencyTextBox284";
this.solvencyCurrencyTextBox284.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox284.TabIndex = 284;
this.solvencyCurrencyTextBox284.ColName = "R1470C0210";
this.solvencyCurrencyTextBox284.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox285
//
this.solvencyCurrencyTextBox285.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox285.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox285.Location = new System.Drawing.Point(117,497);
this.solvencyCurrencyTextBox285.Name = "solvencyCurrencyTextBox285";
this.solvencyCurrencyTextBox285.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox285.TabIndex = 285;
this.solvencyCurrencyTextBox285.ColName = "R1470C0220";
this.solvencyCurrencyTextBox285.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox285.Enabled = false;
this.solvencyCurrencyTextBox285.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox286
//
this.solvencyCurrencyTextBox286.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox286.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox286.Location = new System.Drawing.Point(224,497);
this.solvencyCurrencyTextBox286.Name = "solvencyCurrencyTextBox286";
this.solvencyCurrencyTextBox286.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox286.TabIndex = 286;
this.solvencyCurrencyTextBox286.ColName = "R1470C0230";
this.solvencyCurrencyTextBox286.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox286.Enabled = false;
this.solvencyCurrencyTextBox286.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox287
//
this.solvencyCurrencyTextBox287.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox287.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox287.Location = new System.Drawing.Point(331,497);
this.solvencyCurrencyTextBox287.Name = "solvencyCurrencyTextBox287";
this.solvencyCurrencyTextBox287.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox287.TabIndex = 287;
this.solvencyCurrencyTextBox287.ColName = "R1470C0240";
this.solvencyCurrencyTextBox287.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox287.Enabled = false;
this.solvencyCurrencyTextBox287.BackColor = System.Drawing.Color.Gray;
//
// SolvencyDataComboBox288
//
this.SolvencyDataComboBox288.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox288.Location = new System.Drawing.Point(438,497);
this.SolvencyDataComboBox288.Name = "SolvencyDataComboBox288";
this.SolvencyDataComboBox288.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox288.TabIndex = 288;
this.SolvencyDataComboBox288.ColName = "R1470C0250";
this.SolvencyDataComboBox288.AxisID = 1318;
this.SolvencyDataComboBox288.OrdinateID = 7029;
this.SolvencyDataComboBox288.StartOrder = 0;
this.SolvencyDataComboBox288.NextOrder = 0;
this.SolvencyDataComboBox288.Enabled = false;
this.SolvencyDataComboBox288.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox289
//
this.solvencyCurrencyTextBox289.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox289.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox289.Location = new System.Drawing.Point(645,497);
this.solvencyCurrencyTextBox289.Name = "solvencyCurrencyTextBox289";
this.solvencyCurrencyTextBox289.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox289.TabIndex = 289;
this.solvencyCurrencyTextBox289.ColName = "R1470C0260";
this.solvencyCurrencyTextBox289.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox289.Enabled = false;
this.solvencyCurrencyTextBox289.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox290
//
this.solvencyCurrencyTextBox290.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox290.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox290.Location = new System.Drawing.Point(752,497);
this.solvencyCurrencyTextBox290.Name = "solvencyCurrencyTextBox290";
this.solvencyCurrencyTextBox290.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox290.TabIndex = 290;
this.solvencyCurrencyTextBox290.ColName = "R1470C0270";
this.solvencyCurrencyTextBox290.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox290.Enabled = false;
this.solvencyCurrencyTextBox290.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox291
//
this.solvencyCurrencyTextBox291.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox291.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox291.Location = new System.Drawing.Point(859,497);
this.solvencyCurrencyTextBox291.Name = "solvencyCurrencyTextBox291";
this.solvencyCurrencyTextBox291.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox291.TabIndex = 291;
this.solvencyCurrencyTextBox291.ColName = "R1470C0280";
this.solvencyCurrencyTextBox291.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox291.Enabled = false;
this.solvencyCurrencyTextBox291.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox292
//
this.solvencyCurrencyTextBox292.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox292.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox292.Location = new System.Drawing.Point(966,497);
this.solvencyCurrencyTextBox292.Name = "solvencyCurrencyTextBox292";
this.solvencyCurrencyTextBox292.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox292.TabIndex = 292;
this.solvencyCurrencyTextBox292.ColName = "R1470C0290";
this.solvencyCurrencyTextBox292.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox292.Enabled = false;
this.solvencyCurrencyTextBox292.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox293
//
this.solvencyCurrencyTextBox293.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox293.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox293.Location = new System.Drawing.Point(10,517);
this.solvencyCurrencyTextBox293.Name = "solvencyCurrencyTextBox293";
this.solvencyCurrencyTextBox293.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox293.TabIndex = 293;
this.solvencyCurrencyTextBox293.ColName = "R1480C0210";
this.solvencyCurrencyTextBox293.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox294
//
this.solvencyCurrencyTextBox294.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox294.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox294.Location = new System.Drawing.Point(117,517);
this.solvencyCurrencyTextBox294.Name = "solvencyCurrencyTextBox294";
this.solvencyCurrencyTextBox294.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox294.TabIndex = 294;
this.solvencyCurrencyTextBox294.ColName = "R1480C0220";
this.solvencyCurrencyTextBox294.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox294.Enabled = false;
this.solvencyCurrencyTextBox294.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox295
//
this.solvencyCurrencyTextBox295.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox295.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox295.Location = new System.Drawing.Point(224,517);
this.solvencyCurrencyTextBox295.Name = "solvencyCurrencyTextBox295";
this.solvencyCurrencyTextBox295.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox295.TabIndex = 295;
this.solvencyCurrencyTextBox295.ColName = "R1480C0230";
this.solvencyCurrencyTextBox295.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox295.Enabled = false;
this.solvencyCurrencyTextBox295.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox296
//
this.solvencyCurrencyTextBox296.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox296.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox296.Location = new System.Drawing.Point(331,517);
this.solvencyCurrencyTextBox296.Name = "solvencyCurrencyTextBox296";
this.solvencyCurrencyTextBox296.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox296.TabIndex = 296;
this.solvencyCurrencyTextBox296.ColName = "R1480C0240";
this.solvencyCurrencyTextBox296.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox296.Enabled = false;
this.solvencyCurrencyTextBox296.BackColor = System.Drawing.Color.Gray;
//
// SolvencyDataComboBox297
//
this.SolvencyDataComboBox297.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox297.Location = new System.Drawing.Point(438,517);
this.SolvencyDataComboBox297.Name = "SolvencyDataComboBox297";
this.SolvencyDataComboBox297.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox297.TabIndex = 297;
this.SolvencyDataComboBox297.ColName = "R1480C0250";
this.SolvencyDataComboBox297.AxisID = 1318;
this.SolvencyDataComboBox297.OrdinateID = 7029;
this.SolvencyDataComboBox297.StartOrder = 0;
this.SolvencyDataComboBox297.NextOrder = 0;
this.SolvencyDataComboBox297.Enabled = false;
this.SolvencyDataComboBox297.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox298
//
this.solvencyCurrencyTextBox298.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox298.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox298.Location = new System.Drawing.Point(645,517);
this.solvencyCurrencyTextBox298.Name = "solvencyCurrencyTextBox298";
this.solvencyCurrencyTextBox298.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox298.TabIndex = 298;
this.solvencyCurrencyTextBox298.ColName = "R1480C0260";
this.solvencyCurrencyTextBox298.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox298.Enabled = false;
this.solvencyCurrencyTextBox298.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox299
//
this.solvencyCurrencyTextBox299.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox299.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox299.Location = new System.Drawing.Point(752,517);
this.solvencyCurrencyTextBox299.Name = "solvencyCurrencyTextBox299";
this.solvencyCurrencyTextBox299.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox299.TabIndex = 299;
this.solvencyCurrencyTextBox299.ColName = "R1480C0270";
this.solvencyCurrencyTextBox299.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox299.Enabled = false;
this.solvencyCurrencyTextBox299.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox300
//
this.solvencyCurrencyTextBox300.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox300.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox300.Location = new System.Drawing.Point(859,517);
this.solvencyCurrencyTextBox300.Name = "solvencyCurrencyTextBox300";
this.solvencyCurrencyTextBox300.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox300.TabIndex = 300;
this.solvencyCurrencyTextBox300.ColName = "R1480C0280";
this.solvencyCurrencyTextBox300.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox300.Enabled = false;
this.solvencyCurrencyTextBox300.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox301
//
this.solvencyCurrencyTextBox301.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox301.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox301.Location = new System.Drawing.Point(966,517);
this.solvencyCurrencyTextBox301.Name = "solvencyCurrencyTextBox301";
this.solvencyCurrencyTextBox301.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox301.TabIndex = 301;
this.solvencyCurrencyTextBox301.ColName = "R1480C0290";
this.solvencyCurrencyTextBox301.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox301.Enabled = false;
this.solvencyCurrencyTextBox301.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox302
//
this.solvencyCurrencyTextBox302.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox302.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox302.Location = new System.Drawing.Point(10,537);
this.solvencyCurrencyTextBox302.Name = "solvencyCurrencyTextBox302";
this.solvencyCurrencyTextBox302.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox302.TabIndex = 302;
this.solvencyCurrencyTextBox302.ColName = "R1490C0210";
this.solvencyCurrencyTextBox302.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox303
//
this.solvencyCurrencyTextBox303.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox303.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox303.Location = new System.Drawing.Point(117,537);
this.solvencyCurrencyTextBox303.Name = "solvencyCurrencyTextBox303";
this.solvencyCurrencyTextBox303.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox303.TabIndex = 303;
this.solvencyCurrencyTextBox303.ColName = "R1490C0220";
this.solvencyCurrencyTextBox303.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox303.Enabled = false;
this.solvencyCurrencyTextBox303.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox304
//
this.solvencyCurrencyTextBox304.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox304.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox304.Location = new System.Drawing.Point(224,537);
this.solvencyCurrencyTextBox304.Name = "solvencyCurrencyTextBox304";
this.solvencyCurrencyTextBox304.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox304.TabIndex = 304;
this.solvencyCurrencyTextBox304.ColName = "R1490C0230";
this.solvencyCurrencyTextBox304.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox304.Enabled = false;
this.solvencyCurrencyTextBox304.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox305
//
this.solvencyCurrencyTextBox305.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox305.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox305.Location = new System.Drawing.Point(331,537);
this.solvencyCurrencyTextBox305.Name = "solvencyCurrencyTextBox305";
this.solvencyCurrencyTextBox305.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox305.TabIndex = 305;
this.solvencyCurrencyTextBox305.ColName = "R1490C0240";
this.solvencyCurrencyTextBox305.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox305.Enabled = false;
this.solvencyCurrencyTextBox305.BackColor = System.Drawing.Color.Gray;
//
// SolvencyDataComboBox306
//
this.SolvencyDataComboBox306.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox306.Location = new System.Drawing.Point(438,537);
this.SolvencyDataComboBox306.Name = "SolvencyDataComboBox306";
this.SolvencyDataComboBox306.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox306.TabIndex = 306;
this.SolvencyDataComboBox306.ColName = "R1490C0250";
this.SolvencyDataComboBox306.AxisID = 1318;
this.SolvencyDataComboBox306.OrdinateID = 7029;
this.SolvencyDataComboBox306.StartOrder = 0;
this.SolvencyDataComboBox306.NextOrder = 0;
this.SolvencyDataComboBox306.Enabled = false;
this.SolvencyDataComboBox306.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox307
//
this.solvencyCurrencyTextBox307.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox307.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox307.Location = new System.Drawing.Point(645,537);
this.solvencyCurrencyTextBox307.Name = "solvencyCurrencyTextBox307";
this.solvencyCurrencyTextBox307.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox307.TabIndex = 307;
this.solvencyCurrencyTextBox307.ColName = "R1490C0260";
this.solvencyCurrencyTextBox307.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox307.Enabled = false;
this.solvencyCurrencyTextBox307.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox308
//
this.solvencyCurrencyTextBox308.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox308.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox308.Location = new System.Drawing.Point(752,537);
this.solvencyCurrencyTextBox308.Name = "solvencyCurrencyTextBox308";
this.solvencyCurrencyTextBox308.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox308.TabIndex = 308;
this.solvencyCurrencyTextBox308.ColName = "R1490C0270";
this.solvencyCurrencyTextBox308.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox308.Enabled = false;
this.solvencyCurrencyTextBox308.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox309
//
this.solvencyCurrencyTextBox309.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox309.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox309.Location = new System.Drawing.Point(859,537);
this.solvencyCurrencyTextBox309.Name = "solvencyCurrencyTextBox309";
this.solvencyCurrencyTextBox309.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox309.TabIndex = 309;
this.solvencyCurrencyTextBox309.ColName = "R1490C0280";
this.solvencyCurrencyTextBox309.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox309.Enabled = false;
this.solvencyCurrencyTextBox309.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox310
//
this.solvencyCurrencyTextBox310.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox310.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox310.Location = new System.Drawing.Point(966,537);
this.solvencyCurrencyTextBox310.Name = "solvencyCurrencyTextBox310";
this.solvencyCurrencyTextBox310.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox310.TabIndex = 310;
this.solvencyCurrencyTextBox310.ColName = "R1490C0290";
this.solvencyCurrencyTextBox310.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox310.Enabled = false;
this.solvencyCurrencyTextBox310.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox311
//
this.solvencyCurrencyTextBox311.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox311.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox311.Location = new System.Drawing.Point(10,557);
this.solvencyCurrencyTextBox311.Name = "solvencyCurrencyTextBox311";
this.solvencyCurrencyTextBox311.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox311.TabIndex = 311;
this.solvencyCurrencyTextBox311.ColName = "R1500C0210";
this.solvencyCurrencyTextBox311.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox312
//
this.solvencyCurrencyTextBox312.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox312.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox312.Location = new System.Drawing.Point(117,557);
this.solvencyCurrencyTextBox312.Name = "solvencyCurrencyTextBox312";
this.solvencyCurrencyTextBox312.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox312.TabIndex = 312;
this.solvencyCurrencyTextBox312.ColName = "R1500C0220";
this.solvencyCurrencyTextBox312.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox312.Enabled = false;
this.solvencyCurrencyTextBox312.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox313
//
this.solvencyCurrencyTextBox313.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox313.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox313.Location = new System.Drawing.Point(224,557);
this.solvencyCurrencyTextBox313.Name = "solvencyCurrencyTextBox313";
this.solvencyCurrencyTextBox313.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox313.TabIndex = 313;
this.solvencyCurrencyTextBox313.ColName = "R1500C0230";
this.solvencyCurrencyTextBox313.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox313.Enabled = false;
this.solvencyCurrencyTextBox313.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox314
//
this.solvencyCurrencyTextBox314.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox314.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox314.Location = new System.Drawing.Point(331,557);
this.solvencyCurrencyTextBox314.Name = "solvencyCurrencyTextBox314";
this.solvencyCurrencyTextBox314.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox314.TabIndex = 314;
this.solvencyCurrencyTextBox314.ColName = "R1500C0240";
this.solvencyCurrencyTextBox314.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox314.Enabled = false;
this.solvencyCurrencyTextBox314.BackColor = System.Drawing.Color.Gray;
//
// SolvencyDataComboBox315
//
this.SolvencyDataComboBox315.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox315.Location = new System.Drawing.Point(438,557);
this.SolvencyDataComboBox315.Name = "SolvencyDataComboBox315";
this.SolvencyDataComboBox315.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox315.TabIndex = 315;
this.SolvencyDataComboBox315.ColName = "R1500C0250";
this.SolvencyDataComboBox315.AxisID = 1318;
this.SolvencyDataComboBox315.OrdinateID = 7029;
this.SolvencyDataComboBox315.StartOrder = 0;
this.SolvencyDataComboBox315.NextOrder = 0;
this.SolvencyDataComboBox315.Enabled = false;
this.SolvencyDataComboBox315.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox316
//
this.solvencyCurrencyTextBox316.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox316.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox316.Location = new System.Drawing.Point(645,557);
this.solvencyCurrencyTextBox316.Name = "solvencyCurrencyTextBox316";
this.solvencyCurrencyTextBox316.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox316.TabIndex = 316;
this.solvencyCurrencyTextBox316.ColName = "R1500C0260";
this.solvencyCurrencyTextBox316.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox316.Enabled = false;
this.solvencyCurrencyTextBox316.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox317
//
this.solvencyCurrencyTextBox317.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox317.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox317.Location = new System.Drawing.Point(752,557);
this.solvencyCurrencyTextBox317.Name = "solvencyCurrencyTextBox317";
this.solvencyCurrencyTextBox317.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox317.TabIndex = 317;
this.solvencyCurrencyTextBox317.ColName = "R1500C0270";
this.solvencyCurrencyTextBox317.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox317.Enabled = false;
this.solvencyCurrencyTextBox317.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox318
//
this.solvencyCurrencyTextBox318.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox318.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox318.Location = new System.Drawing.Point(859,557);
this.solvencyCurrencyTextBox318.Name = "solvencyCurrencyTextBox318";
this.solvencyCurrencyTextBox318.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox318.TabIndex = 318;
this.solvencyCurrencyTextBox318.ColName = "R1500C0280";
this.solvencyCurrencyTextBox318.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox318.Enabled = false;
this.solvencyCurrencyTextBox318.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox319
//
this.solvencyCurrencyTextBox319.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox319.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox319.Location = new System.Drawing.Point(966,557);
this.solvencyCurrencyTextBox319.Name = "solvencyCurrencyTextBox319";
this.solvencyCurrencyTextBox319.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox319.TabIndex = 319;
this.solvencyCurrencyTextBox319.ColName = "R1500C0290";
this.solvencyCurrencyTextBox319.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox319.Enabled = false;
this.solvencyCurrencyTextBox319.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox320
//
this.solvencyCurrencyTextBox320.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox320.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox320.Location = new System.Drawing.Point(10,577);
this.solvencyCurrencyTextBox320.Name = "solvencyCurrencyTextBox320";
this.solvencyCurrencyTextBox320.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox320.TabIndex = 320;
this.solvencyCurrencyTextBox320.ColName = "R1510C0210";
this.solvencyCurrencyTextBox320.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox321
//
this.solvencyCurrencyTextBox321.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox321.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox321.Location = new System.Drawing.Point(117,577);
this.solvencyCurrencyTextBox321.Name = "solvencyCurrencyTextBox321";
this.solvencyCurrencyTextBox321.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox321.TabIndex = 321;
this.solvencyCurrencyTextBox321.ColName = "R1510C0220";
this.solvencyCurrencyTextBox321.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox321.Enabled = false;
this.solvencyCurrencyTextBox321.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox322
//
this.solvencyCurrencyTextBox322.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox322.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox322.Location = new System.Drawing.Point(224,577);
this.solvencyCurrencyTextBox322.Name = "solvencyCurrencyTextBox322";
this.solvencyCurrencyTextBox322.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox322.TabIndex = 322;
this.solvencyCurrencyTextBox322.ColName = "R1510C0230";
this.solvencyCurrencyTextBox322.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox322.Enabled = false;
this.solvencyCurrencyTextBox322.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox323
//
this.solvencyCurrencyTextBox323.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox323.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox323.Location = new System.Drawing.Point(331,577);
this.solvencyCurrencyTextBox323.Name = "solvencyCurrencyTextBox323";
this.solvencyCurrencyTextBox323.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox323.TabIndex = 323;
this.solvencyCurrencyTextBox323.ColName = "R1510C0240";
this.solvencyCurrencyTextBox323.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox323.Enabled = false;
this.solvencyCurrencyTextBox323.BackColor = System.Drawing.Color.Gray;
//
// SolvencyDataComboBox324
//
this.SolvencyDataComboBox324.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox324.Location = new System.Drawing.Point(438,577);
this.SolvencyDataComboBox324.Name = "SolvencyDataComboBox324";
this.SolvencyDataComboBox324.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox324.TabIndex = 324;
this.SolvencyDataComboBox324.ColName = "R1510C0250";
this.SolvencyDataComboBox324.AxisID = 1318;
this.SolvencyDataComboBox324.OrdinateID = 7029;
this.SolvencyDataComboBox324.StartOrder = 0;
this.SolvencyDataComboBox324.NextOrder = 0;
this.SolvencyDataComboBox324.Enabled = false;
this.SolvencyDataComboBox324.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox325
//
this.solvencyCurrencyTextBox325.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox325.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox325.Location = new System.Drawing.Point(645,577);
this.solvencyCurrencyTextBox325.Name = "solvencyCurrencyTextBox325";
this.solvencyCurrencyTextBox325.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox325.TabIndex = 325;
this.solvencyCurrencyTextBox325.ColName = "R1510C0260";
this.solvencyCurrencyTextBox325.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox325.Enabled = false;
this.solvencyCurrencyTextBox325.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox326
//
this.solvencyCurrencyTextBox326.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox326.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox326.Location = new System.Drawing.Point(752,577);
this.solvencyCurrencyTextBox326.Name = "solvencyCurrencyTextBox326";
this.solvencyCurrencyTextBox326.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox326.TabIndex = 326;
this.solvencyCurrencyTextBox326.ColName = "R1510C0270";
this.solvencyCurrencyTextBox326.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox326.Enabled = false;
this.solvencyCurrencyTextBox326.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox327
//
this.solvencyCurrencyTextBox327.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox327.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox327.Location = new System.Drawing.Point(859,577);
this.solvencyCurrencyTextBox327.Name = "solvencyCurrencyTextBox327";
this.solvencyCurrencyTextBox327.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox327.TabIndex = 327;
this.solvencyCurrencyTextBox327.ColName = "R1510C0280";
this.solvencyCurrencyTextBox327.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox327.Enabled = false;
this.solvencyCurrencyTextBox327.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox328
//
this.solvencyCurrencyTextBox328.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox328.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox328.Location = new System.Drawing.Point(966,577);
this.solvencyCurrencyTextBox328.Name = "solvencyCurrencyTextBox328";
this.solvencyCurrencyTextBox328.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox328.TabIndex = 328;
this.solvencyCurrencyTextBox328.ColName = "R1510C0290";
this.solvencyCurrencyTextBox328.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox328.Enabled = false;
this.solvencyCurrencyTextBox328.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox329
//
this.solvencyCurrencyTextBox329.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox329.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox329.Location = new System.Drawing.Point(10,610);
this.solvencyCurrencyTextBox329.Name = "solvencyCurrencyTextBox329";
this.solvencyCurrencyTextBox329.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox329.TabIndex = 329;
this.solvencyCurrencyTextBox329.ColName = "R1520C0210";
this.solvencyCurrencyTextBox329.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox330
//
this.solvencyCurrencyTextBox330.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox330.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox330.Location = new System.Drawing.Point(117,610);
this.solvencyCurrencyTextBox330.Name = "solvencyCurrencyTextBox330";
this.solvencyCurrencyTextBox330.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox330.TabIndex = 330;
this.solvencyCurrencyTextBox330.ColName = "R1520C0220";
this.solvencyCurrencyTextBox330.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox330.Enabled = false;
this.solvencyCurrencyTextBox330.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox331
//
this.solvencyCurrencyTextBox331.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox331.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox331.Location = new System.Drawing.Point(224,610);
this.solvencyCurrencyTextBox331.Name = "solvencyCurrencyTextBox331";
this.solvencyCurrencyTextBox331.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox331.TabIndex = 331;
this.solvencyCurrencyTextBox331.ColName = "R1520C0230";
this.solvencyCurrencyTextBox331.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox331.Enabled = false;
this.solvencyCurrencyTextBox331.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox332
//
this.solvencyCurrencyTextBox332.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox332.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox332.Location = new System.Drawing.Point(331,610);
this.solvencyCurrencyTextBox332.Name = "solvencyCurrencyTextBox332";
this.solvencyCurrencyTextBox332.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox332.TabIndex = 332;
this.solvencyCurrencyTextBox332.ColName = "R1520C0240";
this.solvencyCurrencyTextBox332.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox332.Enabled = false;
this.solvencyCurrencyTextBox332.BackColor = System.Drawing.Color.Gray;
//
// SolvencyDataComboBox333
//
this.SolvencyDataComboBox333.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox333.Location = new System.Drawing.Point(438,610);
this.SolvencyDataComboBox333.Name = "SolvencyDataComboBox333";
this.SolvencyDataComboBox333.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox333.TabIndex = 333;
this.SolvencyDataComboBox333.ColName = "R1520C0250";
this.SolvencyDataComboBox333.AxisID = 1318;
this.SolvencyDataComboBox333.OrdinateID = 7029;
this.SolvencyDataComboBox333.StartOrder = 0;
this.SolvencyDataComboBox333.NextOrder = 0;
this.SolvencyDataComboBox333.Enabled = false;
this.SolvencyDataComboBox333.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox334
//
this.solvencyCurrencyTextBox334.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox334.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox334.Location = new System.Drawing.Point(645,610);
this.solvencyCurrencyTextBox334.Name = "solvencyCurrencyTextBox334";
this.solvencyCurrencyTextBox334.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox334.TabIndex = 334;
this.solvencyCurrencyTextBox334.ColName = "R1520C0260";
this.solvencyCurrencyTextBox334.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox334.Enabled = false;
this.solvencyCurrencyTextBox334.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox335
//
this.solvencyCurrencyTextBox335.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox335.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox335.Location = new System.Drawing.Point(752,610);
this.solvencyCurrencyTextBox335.Name = "solvencyCurrencyTextBox335";
this.solvencyCurrencyTextBox335.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox335.TabIndex = 335;
this.solvencyCurrencyTextBox335.ColName = "R1520C0270";
this.solvencyCurrencyTextBox335.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox335.Enabled = false;
this.solvencyCurrencyTextBox335.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox336
//
this.solvencyCurrencyTextBox336.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox336.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox336.Location = new System.Drawing.Point(859,610);
this.solvencyCurrencyTextBox336.Name = "solvencyCurrencyTextBox336";
this.solvencyCurrencyTextBox336.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox336.TabIndex = 336;
this.solvencyCurrencyTextBox336.ColName = "R1520C0280";
this.solvencyCurrencyTextBox336.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox336.Enabled = false;
this.solvencyCurrencyTextBox336.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox337
//
this.solvencyCurrencyTextBox337.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox337.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox337.Location = new System.Drawing.Point(966,610);
this.solvencyCurrencyTextBox337.Name = "solvencyCurrencyTextBox337";
this.solvencyCurrencyTextBox337.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox337.TabIndex = 337;
this.solvencyCurrencyTextBox337.ColName = "R1520C0290";
this.solvencyCurrencyTextBox337.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox337.Enabled = false;
this.solvencyCurrencyTextBox337.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox338
//
this.solvencyCurrencyTextBox338.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox338.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox338.Location = new System.Drawing.Point(10,630);
this.solvencyCurrencyTextBox338.Name = "solvencyCurrencyTextBox338";
this.solvencyCurrencyTextBox338.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox338.TabIndex = 338;
this.solvencyCurrencyTextBox338.ColName = "R1530C0210";
this.solvencyCurrencyTextBox338.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox339
//
this.solvencyCurrencyTextBox339.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox339.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox339.Location = new System.Drawing.Point(117,630);
this.solvencyCurrencyTextBox339.Name = "solvencyCurrencyTextBox339";
this.solvencyCurrencyTextBox339.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox339.TabIndex = 339;
this.solvencyCurrencyTextBox339.ColName = "R1530C0220";
this.solvencyCurrencyTextBox339.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox339.Enabled = false;
this.solvencyCurrencyTextBox339.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox340
//
this.solvencyCurrencyTextBox340.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox340.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox340.Location = new System.Drawing.Point(224,630);
this.solvencyCurrencyTextBox340.Name = "solvencyCurrencyTextBox340";
this.solvencyCurrencyTextBox340.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox340.TabIndex = 340;
this.solvencyCurrencyTextBox340.ColName = "R1530C0230";
this.solvencyCurrencyTextBox340.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox340.Enabled = false;
this.solvencyCurrencyTextBox340.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox341
//
this.solvencyCurrencyTextBox341.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox341.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox341.Location = new System.Drawing.Point(331,630);
this.solvencyCurrencyTextBox341.Name = "solvencyCurrencyTextBox341";
this.solvencyCurrencyTextBox341.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox341.TabIndex = 341;
this.solvencyCurrencyTextBox341.ColName = "R1530C0240";
this.solvencyCurrencyTextBox341.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox341.Enabled = false;
this.solvencyCurrencyTextBox341.BackColor = System.Drawing.Color.Gray;
//
// SolvencyDataComboBox342
//
this.SolvencyDataComboBox342.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox342.Location = new System.Drawing.Point(438,630);
this.SolvencyDataComboBox342.Name = "SolvencyDataComboBox342";
this.SolvencyDataComboBox342.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox342.TabIndex = 342;
this.SolvencyDataComboBox342.ColName = "R1530C0250";
this.SolvencyDataComboBox342.AxisID = 1318;
this.SolvencyDataComboBox342.OrdinateID = 7029;
this.SolvencyDataComboBox342.StartOrder = 0;
this.SolvencyDataComboBox342.NextOrder = 0;
this.SolvencyDataComboBox342.Enabled = false;
this.SolvencyDataComboBox342.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox343
//
this.solvencyCurrencyTextBox343.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox343.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox343.Location = new System.Drawing.Point(645,630);
this.solvencyCurrencyTextBox343.Name = "solvencyCurrencyTextBox343";
this.solvencyCurrencyTextBox343.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox343.TabIndex = 343;
this.solvencyCurrencyTextBox343.ColName = "R1530C0260";
this.solvencyCurrencyTextBox343.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox343.Enabled = false;
this.solvencyCurrencyTextBox343.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox344
//
this.solvencyCurrencyTextBox344.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox344.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox344.Location = new System.Drawing.Point(752,630);
this.solvencyCurrencyTextBox344.Name = "solvencyCurrencyTextBox344";
this.solvencyCurrencyTextBox344.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox344.TabIndex = 344;
this.solvencyCurrencyTextBox344.ColName = "R1530C0270";
this.solvencyCurrencyTextBox344.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox344.Enabled = false;
this.solvencyCurrencyTextBox344.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox345
//
this.solvencyCurrencyTextBox345.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox345.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox345.Location = new System.Drawing.Point(859,630);
this.solvencyCurrencyTextBox345.Name = "solvencyCurrencyTextBox345";
this.solvencyCurrencyTextBox345.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox345.TabIndex = 345;
this.solvencyCurrencyTextBox345.ColName = "R1530C0280";
this.solvencyCurrencyTextBox345.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox345.Enabled = false;
this.solvencyCurrencyTextBox345.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox346
//
this.solvencyCurrencyTextBox346.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox346.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox346.Location = new System.Drawing.Point(966,630);
this.solvencyCurrencyTextBox346.Name = "solvencyCurrencyTextBox346";
this.solvencyCurrencyTextBox346.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox346.TabIndex = 346;
this.solvencyCurrencyTextBox346.ColName = "R1530C0290";
this.solvencyCurrencyTextBox346.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox346.Enabled = false;
this.solvencyCurrencyTextBox346.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox347
//
this.solvencyCurrencyTextBox347.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox347.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox347.Location = new System.Drawing.Point(10,650);
this.solvencyCurrencyTextBox347.Name = "solvencyCurrencyTextBox347";
this.solvencyCurrencyTextBox347.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox347.TabIndex = 347;
this.solvencyCurrencyTextBox347.ColName = "R1540C0210";
this.solvencyCurrencyTextBox347.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox348
//
this.solvencyCurrencyTextBox348.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox348.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox348.Location = new System.Drawing.Point(117,650);
this.solvencyCurrencyTextBox348.Name = "solvencyCurrencyTextBox348";
this.solvencyCurrencyTextBox348.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox348.TabIndex = 348;
this.solvencyCurrencyTextBox348.ColName = "R1540C0220";
this.solvencyCurrencyTextBox348.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox348.Enabled = false;
this.solvencyCurrencyTextBox348.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox349
//
this.solvencyCurrencyTextBox349.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox349.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox349.Location = new System.Drawing.Point(224,650);
this.solvencyCurrencyTextBox349.Name = "solvencyCurrencyTextBox349";
this.solvencyCurrencyTextBox349.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox349.TabIndex = 349;
this.solvencyCurrencyTextBox349.ColName = "R1540C0230";
this.solvencyCurrencyTextBox349.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox349.Enabled = false;
this.solvencyCurrencyTextBox349.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox350
//
this.solvencyCurrencyTextBox350.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox350.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox350.Location = new System.Drawing.Point(331,650);
this.solvencyCurrencyTextBox350.Name = "solvencyCurrencyTextBox350";
this.solvencyCurrencyTextBox350.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox350.TabIndex = 350;
this.solvencyCurrencyTextBox350.ColName = "R1540C0240";
this.solvencyCurrencyTextBox350.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox350.Enabled = false;
this.solvencyCurrencyTextBox350.BackColor = System.Drawing.Color.Gray;
//
// SolvencyDataComboBox351
//
this.SolvencyDataComboBox351.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox351.Location = new System.Drawing.Point(438,650);
this.SolvencyDataComboBox351.Name = "SolvencyDataComboBox351";
this.SolvencyDataComboBox351.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox351.TabIndex = 351;
this.SolvencyDataComboBox351.ColName = "R1540C0250";
this.SolvencyDataComboBox351.AxisID = 1318;
this.SolvencyDataComboBox351.OrdinateID = 7029;
this.SolvencyDataComboBox351.StartOrder = 0;
this.SolvencyDataComboBox351.NextOrder = 0;
this.SolvencyDataComboBox351.Enabled = false;
this.SolvencyDataComboBox351.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox352
//
this.solvencyCurrencyTextBox352.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox352.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox352.Location = new System.Drawing.Point(645,650);
this.solvencyCurrencyTextBox352.Name = "solvencyCurrencyTextBox352";
this.solvencyCurrencyTextBox352.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox352.TabIndex = 352;
this.solvencyCurrencyTextBox352.ColName = "R1540C0260";
this.solvencyCurrencyTextBox352.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox352.Enabled = false;
this.solvencyCurrencyTextBox352.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox353
//
this.solvencyCurrencyTextBox353.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox353.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox353.Location = new System.Drawing.Point(752,650);
this.solvencyCurrencyTextBox353.Name = "solvencyCurrencyTextBox353";
this.solvencyCurrencyTextBox353.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox353.TabIndex = 353;
this.solvencyCurrencyTextBox353.ColName = "R1540C0270";
this.solvencyCurrencyTextBox353.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox353.Enabled = false;
this.solvencyCurrencyTextBox353.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox354
//
this.solvencyCurrencyTextBox354.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox354.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox354.Location = new System.Drawing.Point(859,650);
this.solvencyCurrencyTextBox354.Name = "solvencyCurrencyTextBox354";
this.solvencyCurrencyTextBox354.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox354.TabIndex = 354;
this.solvencyCurrencyTextBox354.ColName = "R1540C0280";
this.solvencyCurrencyTextBox354.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox354.Enabled = false;
this.solvencyCurrencyTextBox354.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox355
//
this.solvencyCurrencyTextBox355.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox355.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox355.Location = new System.Drawing.Point(966,650);
this.solvencyCurrencyTextBox355.Name = "solvencyCurrencyTextBox355";
this.solvencyCurrencyTextBox355.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox355.TabIndex = 355;
this.solvencyCurrencyTextBox355.ColName = "R1540C0290";
this.solvencyCurrencyTextBox355.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox355.Enabled = false;
this.solvencyCurrencyTextBox355.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox356
//
this.solvencyCurrencyTextBox356.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox356.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox356.Location = new System.Drawing.Point(10,670);
this.solvencyCurrencyTextBox356.Name = "solvencyCurrencyTextBox356";
this.solvencyCurrencyTextBox356.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox356.TabIndex = 356;
this.solvencyCurrencyTextBox356.ColName = "R1550C0210";
this.solvencyCurrencyTextBox356.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox357
//
this.solvencyCurrencyTextBox357.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox357.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox357.Location = new System.Drawing.Point(117,670);
this.solvencyCurrencyTextBox357.Name = "solvencyCurrencyTextBox357";
this.solvencyCurrencyTextBox357.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox357.TabIndex = 357;
this.solvencyCurrencyTextBox357.ColName = "R1550C0220";
this.solvencyCurrencyTextBox357.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox357.Enabled = false;
this.solvencyCurrencyTextBox357.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox358
//
this.solvencyCurrencyTextBox358.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox358.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox358.Location = new System.Drawing.Point(224,670);
this.solvencyCurrencyTextBox358.Name = "solvencyCurrencyTextBox358";
this.solvencyCurrencyTextBox358.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox358.TabIndex = 358;
this.solvencyCurrencyTextBox358.ColName = "R1550C0230";
this.solvencyCurrencyTextBox358.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox358.Enabled = false;
this.solvencyCurrencyTextBox358.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox359
//
this.solvencyCurrencyTextBox359.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox359.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox359.Location = new System.Drawing.Point(331,670);
this.solvencyCurrencyTextBox359.Name = "solvencyCurrencyTextBox359";
this.solvencyCurrencyTextBox359.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox359.TabIndex = 359;
this.solvencyCurrencyTextBox359.ColName = "R1550C0240";
this.solvencyCurrencyTextBox359.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox359.Enabled = false;
this.solvencyCurrencyTextBox359.BackColor = System.Drawing.Color.Gray;
//
// SolvencyDataComboBox360
//
this.SolvencyDataComboBox360.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox360.Location = new System.Drawing.Point(438,670);
this.SolvencyDataComboBox360.Name = "SolvencyDataComboBox360";
this.SolvencyDataComboBox360.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox360.TabIndex = 360;
this.SolvencyDataComboBox360.ColName = "R1550C0250";
this.SolvencyDataComboBox360.AxisID = 1318;
this.SolvencyDataComboBox360.OrdinateID = 7029;
this.SolvencyDataComboBox360.StartOrder = 0;
this.SolvencyDataComboBox360.NextOrder = 0;
this.SolvencyDataComboBox360.Enabled = false;
this.SolvencyDataComboBox360.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox361
//
this.solvencyCurrencyTextBox361.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox361.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox361.Location = new System.Drawing.Point(645,670);
this.solvencyCurrencyTextBox361.Name = "solvencyCurrencyTextBox361";
this.solvencyCurrencyTextBox361.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox361.TabIndex = 361;
this.solvencyCurrencyTextBox361.ColName = "R1550C0260";
this.solvencyCurrencyTextBox361.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox361.Enabled = false;
this.solvencyCurrencyTextBox361.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox362
//
this.solvencyCurrencyTextBox362.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox362.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox362.Location = new System.Drawing.Point(752,670);
this.solvencyCurrencyTextBox362.Name = "solvencyCurrencyTextBox362";
this.solvencyCurrencyTextBox362.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox362.TabIndex = 362;
this.solvencyCurrencyTextBox362.ColName = "R1550C0270";
this.solvencyCurrencyTextBox362.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox362.Enabled = false;
this.solvencyCurrencyTextBox362.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox363
//
this.solvencyCurrencyTextBox363.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox363.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox363.Location = new System.Drawing.Point(859,670);
this.solvencyCurrencyTextBox363.Name = "solvencyCurrencyTextBox363";
this.solvencyCurrencyTextBox363.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox363.TabIndex = 363;
this.solvencyCurrencyTextBox363.ColName = "R1550C0280";
this.solvencyCurrencyTextBox363.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox363.Enabled = false;
this.solvencyCurrencyTextBox363.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox364
//
this.solvencyCurrencyTextBox364.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox364.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox364.Location = new System.Drawing.Point(966,670);
this.solvencyCurrencyTextBox364.Name = "solvencyCurrencyTextBox364";
this.solvencyCurrencyTextBox364.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox364.TabIndex = 364;
this.solvencyCurrencyTextBox364.ColName = "R1550C0290";
this.solvencyCurrencyTextBox364.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox364.Enabled = false;
this.solvencyCurrencyTextBox364.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox365
//
this.solvencyCurrencyTextBox365.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox365.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox365.Location = new System.Drawing.Point(10,690);
this.solvencyCurrencyTextBox365.Name = "solvencyCurrencyTextBox365";
this.solvencyCurrencyTextBox365.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox365.TabIndex = 365;
this.solvencyCurrencyTextBox365.ColName = "R1560C0210";
this.solvencyCurrencyTextBox365.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox366
//
this.solvencyCurrencyTextBox366.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox366.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox366.Location = new System.Drawing.Point(117,690);
this.solvencyCurrencyTextBox366.Name = "solvencyCurrencyTextBox366";
this.solvencyCurrencyTextBox366.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox366.TabIndex = 366;
this.solvencyCurrencyTextBox366.ColName = "R1560C0220";
this.solvencyCurrencyTextBox366.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox366.Enabled = false;
this.solvencyCurrencyTextBox366.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox367
//
this.solvencyCurrencyTextBox367.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox367.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox367.Location = new System.Drawing.Point(224,690);
this.solvencyCurrencyTextBox367.Name = "solvencyCurrencyTextBox367";
this.solvencyCurrencyTextBox367.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox367.TabIndex = 367;
this.solvencyCurrencyTextBox367.ColName = "R1560C0230";
this.solvencyCurrencyTextBox367.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox367.Enabled = false;
this.solvencyCurrencyTextBox367.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox368
//
this.solvencyCurrencyTextBox368.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox368.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox368.Location = new System.Drawing.Point(331,690);
this.solvencyCurrencyTextBox368.Name = "solvencyCurrencyTextBox368";
this.solvencyCurrencyTextBox368.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox368.TabIndex = 368;
this.solvencyCurrencyTextBox368.ColName = "R1560C0240";
this.solvencyCurrencyTextBox368.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox368.Enabled = false;
this.solvencyCurrencyTextBox368.BackColor = System.Drawing.Color.Gray;
//
// SolvencyDataComboBox369
//
this.SolvencyDataComboBox369.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox369.Location = new System.Drawing.Point(438,690);
this.SolvencyDataComboBox369.Name = "SolvencyDataComboBox369";
this.SolvencyDataComboBox369.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox369.TabIndex = 369;
this.SolvencyDataComboBox369.ColName = "R1560C0250";
this.SolvencyDataComboBox369.AxisID = 1318;
this.SolvencyDataComboBox369.OrdinateID = 7029;
this.SolvencyDataComboBox369.StartOrder = 0;
this.SolvencyDataComboBox369.NextOrder = 0;
this.SolvencyDataComboBox369.Enabled = false;
this.SolvencyDataComboBox369.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox370
//
this.solvencyCurrencyTextBox370.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox370.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox370.Location = new System.Drawing.Point(645,690);
this.solvencyCurrencyTextBox370.Name = "solvencyCurrencyTextBox370";
this.solvencyCurrencyTextBox370.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox370.TabIndex = 370;
this.solvencyCurrencyTextBox370.ColName = "R1560C0260";
this.solvencyCurrencyTextBox370.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox370.Enabled = false;
this.solvencyCurrencyTextBox370.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox371
//
this.solvencyCurrencyTextBox371.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox371.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox371.Location = new System.Drawing.Point(752,690);
this.solvencyCurrencyTextBox371.Name = "solvencyCurrencyTextBox371";
this.solvencyCurrencyTextBox371.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox371.TabIndex = 371;
this.solvencyCurrencyTextBox371.ColName = "R1560C0270";
this.solvencyCurrencyTextBox371.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox371.Enabled = false;
this.solvencyCurrencyTextBox371.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox372
//
this.solvencyCurrencyTextBox372.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox372.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox372.Location = new System.Drawing.Point(859,690);
this.solvencyCurrencyTextBox372.Name = "solvencyCurrencyTextBox372";
this.solvencyCurrencyTextBox372.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox372.TabIndex = 372;
this.solvencyCurrencyTextBox372.ColName = "R1560C0280";
this.solvencyCurrencyTextBox372.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox372.Enabled = false;
this.solvencyCurrencyTextBox372.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox373
//
this.solvencyCurrencyTextBox373.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox373.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox373.Location = new System.Drawing.Point(966,690);
this.solvencyCurrencyTextBox373.Name = "solvencyCurrencyTextBox373";
this.solvencyCurrencyTextBox373.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox373.TabIndex = 373;
this.solvencyCurrencyTextBox373.ColName = "R1560C0290";
this.solvencyCurrencyTextBox373.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox373.Enabled = false;
this.solvencyCurrencyTextBox373.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox374
//
this.solvencyCurrencyTextBox374.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox374.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox374.Location = new System.Drawing.Point(10,710);
this.solvencyCurrencyTextBox374.Name = "solvencyCurrencyTextBox374";
this.solvencyCurrencyTextBox374.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox374.TabIndex = 374;
this.solvencyCurrencyTextBox374.ColName = "R1570C0210";
this.solvencyCurrencyTextBox374.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox375
//
this.solvencyCurrencyTextBox375.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox375.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox375.Location = new System.Drawing.Point(117,710);
this.solvencyCurrencyTextBox375.Name = "solvencyCurrencyTextBox375";
this.solvencyCurrencyTextBox375.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox375.TabIndex = 375;
this.solvencyCurrencyTextBox375.ColName = "R1570C0220";
this.solvencyCurrencyTextBox375.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox375.Enabled = false;
this.solvencyCurrencyTextBox375.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox376
//
this.solvencyCurrencyTextBox376.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox376.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox376.Location = new System.Drawing.Point(224,710);
this.solvencyCurrencyTextBox376.Name = "solvencyCurrencyTextBox376";
this.solvencyCurrencyTextBox376.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox376.TabIndex = 376;
this.solvencyCurrencyTextBox376.ColName = "R1570C0230";
this.solvencyCurrencyTextBox376.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox376.Enabled = false;
this.solvencyCurrencyTextBox376.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox377
//
this.solvencyCurrencyTextBox377.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox377.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox377.Location = new System.Drawing.Point(331,710);
this.solvencyCurrencyTextBox377.Name = "solvencyCurrencyTextBox377";
this.solvencyCurrencyTextBox377.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox377.TabIndex = 377;
this.solvencyCurrencyTextBox377.ColName = "R1570C0240";
this.solvencyCurrencyTextBox377.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox377.Enabled = false;
this.solvencyCurrencyTextBox377.BackColor = System.Drawing.Color.Gray;
//
// SolvencyDataComboBox378
//
this.SolvencyDataComboBox378.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox378.Location = new System.Drawing.Point(438,710);
this.SolvencyDataComboBox378.Name = "SolvencyDataComboBox378";
this.SolvencyDataComboBox378.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox378.TabIndex = 378;
this.SolvencyDataComboBox378.ColName = "R1570C0250";
this.SolvencyDataComboBox378.AxisID = 1318;
this.SolvencyDataComboBox378.OrdinateID = 7029;
this.SolvencyDataComboBox378.StartOrder = 0;
this.SolvencyDataComboBox378.NextOrder = 0;
this.SolvencyDataComboBox378.Enabled = false;
this.SolvencyDataComboBox378.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox379
//
this.solvencyCurrencyTextBox379.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox379.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox379.Location = new System.Drawing.Point(645,710);
this.solvencyCurrencyTextBox379.Name = "solvencyCurrencyTextBox379";
this.solvencyCurrencyTextBox379.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox379.TabIndex = 379;
this.solvencyCurrencyTextBox379.ColName = "R1570C0260";
this.solvencyCurrencyTextBox379.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox379.Enabled = false;
this.solvencyCurrencyTextBox379.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox380
//
this.solvencyCurrencyTextBox380.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox380.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox380.Location = new System.Drawing.Point(752,710);
this.solvencyCurrencyTextBox380.Name = "solvencyCurrencyTextBox380";
this.solvencyCurrencyTextBox380.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox380.TabIndex = 380;
this.solvencyCurrencyTextBox380.ColName = "R1570C0270";
this.solvencyCurrencyTextBox380.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox380.Enabled = false;
this.solvencyCurrencyTextBox380.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox381
//
this.solvencyCurrencyTextBox381.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox381.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox381.Location = new System.Drawing.Point(859,710);
this.solvencyCurrencyTextBox381.Name = "solvencyCurrencyTextBox381";
this.solvencyCurrencyTextBox381.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox381.TabIndex = 381;
this.solvencyCurrencyTextBox381.ColName = "R1570C0280";
this.solvencyCurrencyTextBox381.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox381.Enabled = false;
this.solvencyCurrencyTextBox381.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox382
//
this.solvencyCurrencyTextBox382.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox382.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox382.Location = new System.Drawing.Point(966,710);
this.solvencyCurrencyTextBox382.Name = "solvencyCurrencyTextBox382";
this.solvencyCurrencyTextBox382.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox382.TabIndex = 382;
this.solvencyCurrencyTextBox382.ColName = "R1570C0290";
this.solvencyCurrencyTextBox382.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox382.Enabled = false;
this.solvencyCurrencyTextBox382.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox383
//
this.solvencyCurrencyTextBox383.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox383.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox383.Location = new System.Drawing.Point(10,730);
this.solvencyCurrencyTextBox383.Name = "solvencyCurrencyTextBox383";
this.solvencyCurrencyTextBox383.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox383.TabIndex = 383;
this.solvencyCurrencyTextBox383.ColName = "R1580C0210";
this.solvencyCurrencyTextBox383.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox384
//
this.solvencyCurrencyTextBox384.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox384.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox384.Location = new System.Drawing.Point(117,730);
this.solvencyCurrencyTextBox384.Name = "solvencyCurrencyTextBox384";
this.solvencyCurrencyTextBox384.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox384.TabIndex = 384;
this.solvencyCurrencyTextBox384.ColName = "R1580C0220";
this.solvencyCurrencyTextBox384.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox384.Enabled = false;
this.solvencyCurrencyTextBox384.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox385
//
this.solvencyCurrencyTextBox385.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox385.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox385.Location = new System.Drawing.Point(224,730);
this.solvencyCurrencyTextBox385.Name = "solvencyCurrencyTextBox385";
this.solvencyCurrencyTextBox385.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox385.TabIndex = 385;
this.solvencyCurrencyTextBox385.ColName = "R1580C0230";
this.solvencyCurrencyTextBox385.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox385.Enabled = false;
this.solvencyCurrencyTextBox385.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox386
//
this.solvencyCurrencyTextBox386.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox386.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox386.Location = new System.Drawing.Point(331,730);
this.solvencyCurrencyTextBox386.Name = "solvencyCurrencyTextBox386";
this.solvencyCurrencyTextBox386.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox386.TabIndex = 386;
this.solvencyCurrencyTextBox386.ColName = "R1580C0240";
this.solvencyCurrencyTextBox386.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox386.Enabled = false;
this.solvencyCurrencyTextBox386.BackColor = System.Drawing.Color.Gray;
//
// SolvencyDataComboBox387
//
this.SolvencyDataComboBox387.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox387.Location = new System.Drawing.Point(438,730);
this.SolvencyDataComboBox387.Name = "SolvencyDataComboBox387";
this.SolvencyDataComboBox387.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox387.TabIndex = 387;
this.SolvencyDataComboBox387.ColName = "R1580C0250";
this.SolvencyDataComboBox387.AxisID = 1318;
this.SolvencyDataComboBox387.OrdinateID = 7029;
this.SolvencyDataComboBox387.StartOrder = 0;
this.SolvencyDataComboBox387.NextOrder = 0;
this.SolvencyDataComboBox387.Enabled = false;
this.SolvencyDataComboBox387.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox388
//
this.solvencyCurrencyTextBox388.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox388.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox388.Location = new System.Drawing.Point(645,730);
this.solvencyCurrencyTextBox388.Name = "solvencyCurrencyTextBox388";
this.solvencyCurrencyTextBox388.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox388.TabIndex = 388;
this.solvencyCurrencyTextBox388.ColName = "R1580C0260";
this.solvencyCurrencyTextBox388.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox388.Enabled = false;
this.solvencyCurrencyTextBox388.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox389
//
this.solvencyCurrencyTextBox389.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox389.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox389.Location = new System.Drawing.Point(752,730);
this.solvencyCurrencyTextBox389.Name = "solvencyCurrencyTextBox389";
this.solvencyCurrencyTextBox389.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox389.TabIndex = 389;
this.solvencyCurrencyTextBox389.ColName = "R1580C0270";
this.solvencyCurrencyTextBox389.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox389.Enabled = false;
this.solvencyCurrencyTextBox389.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox390
//
this.solvencyCurrencyTextBox390.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox390.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox390.Location = new System.Drawing.Point(859,730);
this.solvencyCurrencyTextBox390.Name = "solvencyCurrencyTextBox390";
this.solvencyCurrencyTextBox390.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox390.TabIndex = 390;
this.solvencyCurrencyTextBox390.ColName = "R1580C0280";
this.solvencyCurrencyTextBox390.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox390.Enabled = false;
this.solvencyCurrencyTextBox390.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox391
//
this.solvencyCurrencyTextBox391.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox391.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox391.Location = new System.Drawing.Point(966,730);
this.solvencyCurrencyTextBox391.Name = "solvencyCurrencyTextBox391";
this.solvencyCurrencyTextBox391.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox391.TabIndex = 391;
this.solvencyCurrencyTextBox391.ColName = "R1580C0290";
this.solvencyCurrencyTextBox391.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox391.Enabled = false;
this.solvencyCurrencyTextBox391.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox392
//
this.solvencyCurrencyTextBox392.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox392.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox392.Location = new System.Drawing.Point(10,750);
this.solvencyCurrencyTextBox392.Name = "solvencyCurrencyTextBox392";
this.solvencyCurrencyTextBox392.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox392.TabIndex = 392;
this.solvencyCurrencyTextBox392.ColName = "R1590C0210";
this.solvencyCurrencyTextBox392.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox393
//
this.solvencyCurrencyTextBox393.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox393.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox393.Location = new System.Drawing.Point(117,750);
this.solvencyCurrencyTextBox393.Name = "solvencyCurrencyTextBox393";
this.solvencyCurrencyTextBox393.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox393.TabIndex = 393;
this.solvencyCurrencyTextBox393.ColName = "R1590C0220";
this.solvencyCurrencyTextBox393.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox393.Enabled = false;
this.solvencyCurrencyTextBox393.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox394
//
this.solvencyCurrencyTextBox394.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox394.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox394.Location = new System.Drawing.Point(224,750);
this.solvencyCurrencyTextBox394.Name = "solvencyCurrencyTextBox394";
this.solvencyCurrencyTextBox394.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox394.TabIndex = 394;
this.solvencyCurrencyTextBox394.ColName = "R1590C0230";
this.solvencyCurrencyTextBox394.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox394.Enabled = false;
this.solvencyCurrencyTextBox394.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox395
//
this.solvencyCurrencyTextBox395.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox395.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox395.Location = new System.Drawing.Point(331,750);
this.solvencyCurrencyTextBox395.Name = "solvencyCurrencyTextBox395";
this.solvencyCurrencyTextBox395.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox395.TabIndex = 395;
this.solvencyCurrencyTextBox395.ColName = "R1590C0240";
this.solvencyCurrencyTextBox395.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox395.Enabled = false;
this.solvencyCurrencyTextBox395.BackColor = System.Drawing.Color.Gray;
//
// SolvencyDataComboBox396
//
this.SolvencyDataComboBox396.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox396.Location = new System.Drawing.Point(438,750);
this.SolvencyDataComboBox396.Name = "SolvencyDataComboBox396";
this.SolvencyDataComboBox396.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox396.TabIndex = 396;
this.SolvencyDataComboBox396.ColName = "R1590C0250";
this.SolvencyDataComboBox396.AxisID = 1318;
this.SolvencyDataComboBox396.OrdinateID = 7029;
this.SolvencyDataComboBox396.StartOrder = 0;
this.SolvencyDataComboBox396.NextOrder = 0;
this.SolvencyDataComboBox396.Enabled = false;
this.SolvencyDataComboBox396.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox397
//
this.solvencyCurrencyTextBox397.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox397.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox397.Location = new System.Drawing.Point(645,750);
this.solvencyCurrencyTextBox397.Name = "solvencyCurrencyTextBox397";
this.solvencyCurrencyTextBox397.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox397.TabIndex = 397;
this.solvencyCurrencyTextBox397.ColName = "R1590C0260";
this.solvencyCurrencyTextBox397.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox398
//
this.solvencyCurrencyTextBox398.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox398.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox398.Location = new System.Drawing.Point(752,750);
this.solvencyCurrencyTextBox398.Name = "solvencyCurrencyTextBox398";
this.solvencyCurrencyTextBox398.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox398.TabIndex = 398;
this.solvencyCurrencyTextBox398.ColName = "R1590C0270";
this.solvencyCurrencyTextBox398.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox399
//
this.solvencyCurrencyTextBox399.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox399.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox399.Location = new System.Drawing.Point(859,750);
this.solvencyCurrencyTextBox399.Name = "solvencyCurrencyTextBox399";
this.solvencyCurrencyTextBox399.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox399.TabIndex = 399;
this.solvencyCurrencyTextBox399.ColName = "R1590C0280";
this.solvencyCurrencyTextBox399.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox400
//
this.solvencyCurrencyTextBox400.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox400.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox400.Location = new System.Drawing.Point(966,750);
this.solvencyCurrencyTextBox400.Name = "solvencyCurrencyTextBox400";
this.solvencyCurrencyTextBox400.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox400.TabIndex = 400;
this.solvencyCurrencyTextBox400.ColName = "R1590C0290";
this.solvencyCurrencyTextBox400.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox401
//
this.solvencyCurrencyTextBox401.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox401.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox401.Location = new System.Drawing.Point(10,770);
this.solvencyCurrencyTextBox401.Name = "solvencyCurrencyTextBox401";
this.solvencyCurrencyTextBox401.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox401.TabIndex = 401;
this.solvencyCurrencyTextBox401.ColName = "R1600C0210";
this.solvencyCurrencyTextBox401.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox401.Enabled = false;
this.solvencyCurrencyTextBox401.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox402
//
this.solvencyCurrencyTextBox402.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox402.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox402.Location = new System.Drawing.Point(117,770);
this.solvencyCurrencyTextBox402.Name = "solvencyCurrencyTextBox402";
this.solvencyCurrencyTextBox402.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox402.TabIndex = 402;
this.solvencyCurrencyTextBox402.ColName = "R1600C0220";
this.solvencyCurrencyTextBox402.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox402.Enabled = false;
this.solvencyCurrencyTextBox402.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox403
//
this.solvencyCurrencyTextBox403.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox403.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox403.Location = new System.Drawing.Point(224,770);
this.solvencyCurrencyTextBox403.Name = "solvencyCurrencyTextBox403";
this.solvencyCurrencyTextBox403.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox403.TabIndex = 403;
this.solvencyCurrencyTextBox403.ColName = "R1600C0230";
this.solvencyCurrencyTextBox403.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox403.Enabled = false;
this.solvencyCurrencyTextBox403.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox404
//
this.solvencyCurrencyTextBox404.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox404.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox404.Location = new System.Drawing.Point(331,770);
this.solvencyCurrencyTextBox404.Name = "solvencyCurrencyTextBox404";
this.solvencyCurrencyTextBox404.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox404.TabIndex = 404;
this.solvencyCurrencyTextBox404.ColName = "R1600C0240";
this.solvencyCurrencyTextBox404.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox404.Enabled = false;
this.solvencyCurrencyTextBox404.BackColor = System.Drawing.Color.Gray;
//
// SolvencyDataComboBox405
//
this.SolvencyDataComboBox405.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox405.Location = new System.Drawing.Point(438,770);
this.SolvencyDataComboBox405.Name = "SolvencyDataComboBox405";
this.SolvencyDataComboBox405.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox405.TabIndex = 405;
this.SolvencyDataComboBox405.ColName = "R1600C0250";
this.SolvencyDataComboBox405.AxisID = 1318;
this.SolvencyDataComboBox405.OrdinateID = 7029;
this.SolvencyDataComboBox405.StartOrder = 0;
this.SolvencyDataComboBox405.NextOrder = 0;
this.SolvencyDataComboBox405.Enabled = false;
this.SolvencyDataComboBox405.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox406
//
this.solvencyCurrencyTextBox406.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox406.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox406.Location = new System.Drawing.Point(645,770);
this.solvencyCurrencyTextBox406.Name = "solvencyCurrencyTextBox406";
this.solvencyCurrencyTextBox406.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox406.TabIndex = 406;
this.solvencyCurrencyTextBox406.ColName = "R1600C0260";
this.solvencyCurrencyTextBox406.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox407
//
this.solvencyCurrencyTextBox407.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox407.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox407.Location = new System.Drawing.Point(752,770);
this.solvencyCurrencyTextBox407.Name = "solvencyCurrencyTextBox407";
this.solvencyCurrencyTextBox407.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox407.TabIndex = 407;
this.solvencyCurrencyTextBox407.ColName = "R1600C0270";
this.solvencyCurrencyTextBox407.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox408
//
this.solvencyCurrencyTextBox408.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox408.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox408.Location = new System.Drawing.Point(859,770);
this.solvencyCurrencyTextBox408.Name = "solvencyCurrencyTextBox408";
this.solvencyCurrencyTextBox408.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox408.TabIndex = 408;
this.solvencyCurrencyTextBox408.ColName = "R1600C0280";
this.solvencyCurrencyTextBox408.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox409
//
this.solvencyCurrencyTextBox409.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox409.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox409.Location = new System.Drawing.Point(966,770);
this.solvencyCurrencyTextBox409.Name = "solvencyCurrencyTextBox409";
this.solvencyCurrencyTextBox409.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox409.TabIndex = 409;
this.solvencyCurrencyTextBox409.ColName = "R1600C0290";
this.solvencyCurrencyTextBox409.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox410
//
this.solvencyCurrencyTextBox410.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox410.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox410.Location = new System.Drawing.Point(10,790);
this.solvencyCurrencyTextBox410.Name = "solvencyCurrencyTextBox410";
this.solvencyCurrencyTextBox410.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox410.TabIndex = 410;
this.solvencyCurrencyTextBox410.ColName = "R1610C0210";
this.solvencyCurrencyTextBox410.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox410.Enabled = false;
this.solvencyCurrencyTextBox410.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox411
//
this.solvencyCurrencyTextBox411.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox411.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox411.Location = new System.Drawing.Point(117,790);
this.solvencyCurrencyTextBox411.Name = "solvencyCurrencyTextBox411";
this.solvencyCurrencyTextBox411.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox411.TabIndex = 411;
this.solvencyCurrencyTextBox411.ColName = "R1610C0220";
this.solvencyCurrencyTextBox411.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox411.Enabled = false;
this.solvencyCurrencyTextBox411.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox412
//
this.solvencyCurrencyTextBox412.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox412.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox412.Location = new System.Drawing.Point(224,790);
this.solvencyCurrencyTextBox412.Name = "solvencyCurrencyTextBox412";
this.solvencyCurrencyTextBox412.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox412.TabIndex = 412;
this.solvencyCurrencyTextBox412.ColName = "R1610C0230";
this.solvencyCurrencyTextBox412.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox412.Enabled = false;
this.solvencyCurrencyTextBox412.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox413
//
this.solvencyCurrencyTextBox413.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox413.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox413.Location = new System.Drawing.Point(331,790);
this.solvencyCurrencyTextBox413.Name = "solvencyCurrencyTextBox413";
this.solvencyCurrencyTextBox413.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox413.TabIndex = 413;
this.solvencyCurrencyTextBox413.ColName = "R1610C0240";
this.solvencyCurrencyTextBox413.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox413.Enabled = false;
this.solvencyCurrencyTextBox413.BackColor = System.Drawing.Color.Gray;
//
// SolvencyDataComboBox414
//
this.SolvencyDataComboBox414.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox414.Location = new System.Drawing.Point(438,790);
this.SolvencyDataComboBox414.Name = "SolvencyDataComboBox414";
this.SolvencyDataComboBox414.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox414.TabIndex = 414;
this.SolvencyDataComboBox414.ColName = "R1610C0250";
this.SolvencyDataComboBox414.AxisID = 1318;
this.SolvencyDataComboBox414.OrdinateID = 7029;
this.SolvencyDataComboBox414.StartOrder = 0;
this.SolvencyDataComboBox414.NextOrder = 0;
this.SolvencyDataComboBox414.Enabled = false;
this.SolvencyDataComboBox414.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox415
//
this.solvencyCurrencyTextBox415.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox415.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox415.Location = new System.Drawing.Point(645,790);
this.solvencyCurrencyTextBox415.Name = "solvencyCurrencyTextBox415";
this.solvencyCurrencyTextBox415.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox415.TabIndex = 415;
this.solvencyCurrencyTextBox415.ColName = "R1610C0260";
this.solvencyCurrencyTextBox415.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox416
//
this.solvencyCurrencyTextBox416.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox416.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox416.Location = new System.Drawing.Point(752,790);
this.solvencyCurrencyTextBox416.Name = "solvencyCurrencyTextBox416";
this.solvencyCurrencyTextBox416.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox416.TabIndex = 416;
this.solvencyCurrencyTextBox416.ColName = "R1610C0270";
this.solvencyCurrencyTextBox416.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox416.Enabled = false;
this.solvencyCurrencyTextBox416.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox417
//
this.solvencyCurrencyTextBox417.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox417.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox417.Location = new System.Drawing.Point(859,790);
this.solvencyCurrencyTextBox417.Name = "solvencyCurrencyTextBox417";
this.solvencyCurrencyTextBox417.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox417.TabIndex = 417;
this.solvencyCurrencyTextBox417.ColName = "R1610C0280";
this.solvencyCurrencyTextBox417.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox417.Enabled = false;
this.solvencyCurrencyTextBox417.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox418
//
this.solvencyCurrencyTextBox418.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox418.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox418.Location = new System.Drawing.Point(966,790);
this.solvencyCurrencyTextBox418.Name = "solvencyCurrencyTextBox418";
this.solvencyCurrencyTextBox418.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox418.TabIndex = 418;
this.solvencyCurrencyTextBox418.ColName = "R1610C0290";
this.solvencyCurrencyTextBox418.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox419
//
this.solvencyCurrencyTextBox419.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox419.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox419.Location = new System.Drawing.Point(10,810);
this.solvencyCurrencyTextBox419.Name = "solvencyCurrencyTextBox419";
this.solvencyCurrencyTextBox419.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox419.TabIndex = 419;
this.solvencyCurrencyTextBox419.ColName = "R1620C0210";
this.solvencyCurrencyTextBox419.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox419.Enabled = false;
this.solvencyCurrencyTextBox419.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox420
//
this.solvencyCurrencyTextBox420.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox420.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox420.Location = new System.Drawing.Point(117,810);
this.solvencyCurrencyTextBox420.Name = "solvencyCurrencyTextBox420";
this.solvencyCurrencyTextBox420.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox420.TabIndex = 420;
this.solvencyCurrencyTextBox420.ColName = "R1620C0220";
this.solvencyCurrencyTextBox420.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox420.Enabled = false;
this.solvencyCurrencyTextBox420.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox421
//
this.solvencyCurrencyTextBox421.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox421.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox421.Location = new System.Drawing.Point(224,810);
this.solvencyCurrencyTextBox421.Name = "solvencyCurrencyTextBox421";
this.solvencyCurrencyTextBox421.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox421.TabIndex = 421;
this.solvencyCurrencyTextBox421.ColName = "R1620C0230";
this.solvencyCurrencyTextBox421.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox421.Enabled = false;
this.solvencyCurrencyTextBox421.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox422
//
this.solvencyCurrencyTextBox422.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox422.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox422.Location = new System.Drawing.Point(331,810);
this.solvencyCurrencyTextBox422.Name = "solvencyCurrencyTextBox422";
this.solvencyCurrencyTextBox422.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox422.TabIndex = 422;
this.solvencyCurrencyTextBox422.ColName = "R1620C0240";
this.solvencyCurrencyTextBox422.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox422.Enabled = false;
this.solvencyCurrencyTextBox422.BackColor = System.Drawing.Color.Gray;
//
// SolvencyDataComboBox423
//
this.SolvencyDataComboBox423.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox423.Location = new System.Drawing.Point(438,810);
this.SolvencyDataComboBox423.Name = "SolvencyDataComboBox423";
this.SolvencyDataComboBox423.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox423.TabIndex = 423;
this.SolvencyDataComboBox423.ColName = "R1620C0250";
this.SolvencyDataComboBox423.AxisID = 1318;
this.SolvencyDataComboBox423.OrdinateID = 7029;
this.SolvencyDataComboBox423.StartOrder = 0;
this.SolvencyDataComboBox423.NextOrder = 0;
this.SolvencyDataComboBox423.Enabled = false;
this.SolvencyDataComboBox423.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox424
//
this.solvencyCurrencyTextBox424.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox424.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox424.Location = new System.Drawing.Point(645,810);
this.solvencyCurrencyTextBox424.Name = "solvencyCurrencyTextBox424";
this.solvencyCurrencyTextBox424.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox424.TabIndex = 424;
this.solvencyCurrencyTextBox424.ColName = "R1620C0260";
this.solvencyCurrencyTextBox424.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox425
//
this.solvencyCurrencyTextBox425.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox425.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox425.Location = new System.Drawing.Point(752,810);
this.solvencyCurrencyTextBox425.Name = "solvencyCurrencyTextBox425";
this.solvencyCurrencyTextBox425.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox425.TabIndex = 425;
this.solvencyCurrencyTextBox425.ColName = "R1620C0270";
this.solvencyCurrencyTextBox425.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox425.Enabled = false;
this.solvencyCurrencyTextBox425.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox426
//
this.solvencyCurrencyTextBox426.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox426.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox426.Location = new System.Drawing.Point(859,810);
this.solvencyCurrencyTextBox426.Name = "solvencyCurrencyTextBox426";
this.solvencyCurrencyTextBox426.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox426.TabIndex = 426;
this.solvencyCurrencyTextBox426.ColName = "R1620C0280";
this.solvencyCurrencyTextBox426.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox426.Enabled = false;
this.solvencyCurrencyTextBox426.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox427
//
this.solvencyCurrencyTextBox427.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox427.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox427.Location = new System.Drawing.Point(966,810);
this.solvencyCurrencyTextBox427.Name = "solvencyCurrencyTextBox427";
this.solvencyCurrencyTextBox427.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox427.TabIndex = 427;
this.solvencyCurrencyTextBox427.ColName = "R1620C0290";
this.solvencyCurrencyTextBox427.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// splitContainerColTitles
//
this.splitContainerColTitles.Dock = System.Windows.Forms.DockStyle.Fill;
this.splitContainerColTitles.Location = new System.Drawing.Point(0,0);
this.splitContainerColTitles.Name = "splitContainerColTitles";
this.splitContainerColTitles.Orientation = System.Windows.Forms.Orientation.Vertical;
this.splitContainerColTitles.Panel1MinSize = 0;
//
// splitContainerColTitles.Panel1
//
//
// splitContainerColTitles.Panel2
//
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel0);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel1);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel2);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel3);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel4);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel5);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel6);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel7);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel8);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel9);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel10);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel11);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel12);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel13);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel14);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel15);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel16);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel17);
this.splitContainerColTitles.Size = new System.Drawing.Size(1512, 407);
this.splitContainerColTitles.SplitterDistance = 332;
//
// splitContainerRowTitles
//
this.splitContainerRowTitles.Dock = System.Windows.Forms.DockStyle.Fill;
this.splitContainerRowTitles.Location = new System.Drawing.Point(0,0);
this.splitContainerRowTitles.Name = "splitContainerRowTitles";
this.splitContainerRowTitles.Orientation = System.Windows.Forms.Orientation.Vertical;
this.splitContainerRowTitles.Panel1MinSize = 0;
//
// splitContainerRowTitles.Panel1
//
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel18);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel19);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel20);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel21);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel22);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel23);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel24);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel25);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel26);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel27);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel28);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel29);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel30);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel31);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel32);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel33);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel34);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel35);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel36);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel37);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel38);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel39);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel40);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel41);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel42);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel43);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel44);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel45);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel46);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel47);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel48);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel49);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel50);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel51);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel52);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel53);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel54);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel55);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel56);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel57);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel58);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel59);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel60);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel61);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel62);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel63);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel64);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel65);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel66);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel67);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel68);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel69);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel70);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel71);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel72);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel73);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel74);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel75);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel76);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel77);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel78);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel79);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel80);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel81);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel82);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel83);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel84);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel85);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel86);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel87);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel88);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel89);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel90);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel91);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel92);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel93);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel94);
//
// splitContainerRowTitles.Panel2
//
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox95);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox96);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox97);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox98);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox99);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox100);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox101);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox102);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox103);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox104);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox105);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox106);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox107);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox108);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox109);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox110);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox111);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox112);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox113);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox114);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox115);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox116);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox117);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox118);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox119);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox120);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox121);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox122);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox123);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox124);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox125);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox126);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox127);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox128);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox129);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox130);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox131);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox132);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox133);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox134);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox135);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox136);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox137);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox138);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox139);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox140);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox141);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox142);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox143);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox144);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox145);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox146);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox147);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox148);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox149);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox150);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox151);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox152);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox153);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox154);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox155);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox156);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox157);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox158);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox159);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox160);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox161);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox162);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox163);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox164);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox165);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox166);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox167);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox168);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox169);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox170);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox171);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox172);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox173);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox174);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox175);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox176);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox177);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox178);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox179);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox180);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox181);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox182);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox183);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox184);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox185);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox186);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox187);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox188);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox189);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox190);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox191);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox192);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox193);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox194);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox195);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox196);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox197);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox198);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox199);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox200);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox201);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox202);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox203);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox204);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox205);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox206);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox207);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox208);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox209);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox210);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox211);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox212);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox213);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox214);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox215);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox216);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox217);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox218);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox219);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox220);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox221);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox222);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox223);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox224);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox225);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox226);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox227);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox228);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox229);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox230);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox231);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox232);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox233);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox234);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox235);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox236);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox237);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox238);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox239);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox240);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox241);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox242);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox243);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox244);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox245);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox246);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox247);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox248);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox249);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox250);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox251);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox252);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox253);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox254);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox255);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox256);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox257);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox258);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox259);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox260);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox261);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox262);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox263);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox264);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox265);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox266);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox267);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox268);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox269);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox270);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox271);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox272);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox273);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox274);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox275);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox276);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox277);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox278);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox279);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox280);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox281);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox282);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox283);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox284);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox285);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox286);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox287);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox288);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox289);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox290);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox291);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox292);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox293);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox294);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox295);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox296);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox297);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox298);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox299);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox300);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox301);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox302);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox303);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox304);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox305);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox306);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox307);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox308);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox309);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox310);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox311);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox312);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox313);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox314);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox315);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox316);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox317);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox318);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox319);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox320);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox321);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox322);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox323);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox324);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox325);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox326);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox327);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox328);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox329);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox330);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox331);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox332);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox333);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox334);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox335);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox336);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox337);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox338);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox339);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox340);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox341);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox342);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox343);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox344);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox345);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox346);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox347);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox348);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox349);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox350);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox351);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox352);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox353);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox354);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox355);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox356);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox357);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox358);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox359);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox360);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox361);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox362);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox363);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox364);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox365);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox366);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox367);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox368);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox369);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox370);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox371);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox372);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox373);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox374);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox375);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox376);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox377);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox378);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox379);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox380);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox381);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox382);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox383);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox384);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox385);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox386);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox387);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox388);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox389);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox390);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox391);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox392);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox393);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox394);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox395);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox396);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox397);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox398);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox399);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox400);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox401);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox402);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox403);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox404);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox405);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox406);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox407);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox408);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox409);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox410);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox411);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox412);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox413);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox414);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox415);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox416);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox417);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox418);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox419);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox420);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox421);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox422);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox423);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox424);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox425);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox426);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox427);
this.splitContainerRowTitles.Panel2.AutoScroll = true;
this.splitContainerRowTitles.Size = new System.Drawing.Size(1512, 407);
this.splitContainerRowTitles.SplitterDistance = 332;
//
// spltMain
//
this.spltMain.Dock = System.Windows.Forms.DockStyle.Fill;
this.spltMain.Location = new System.Drawing.Point(0,0);
this.spltMain.Name = "spltMain";
this.spltMain.Orientation = System.Windows.Forms.Orientation.Horizontal;
this.spltMain.Panel1MinSize = 0;
//
// spltMain.Panel1
//
this.spltMain.Panel1.Controls.Add(this.splitContainerColTitles);
//
// spltMain.Panel2
//
this.spltMain.Panel2.Controls.Add(this.splitContainerRowTitles);
this.spltMain.Panel2.AutoScroll = true;
this.spltMain.Size = new System.Drawing.Size(1512, 983);
this.spltMain.SplitterDistance = 75;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F); 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font; 
this.Controls.Add(this.spltMain);
            this.Name = "S_27_01_04_04__sol2__2_0_1_ctrl"; 
            this.Size = new System.Drawing.Size(1512, 908); 
            this.Load += new System.EventHandler(this.BoundControl_Load);
            this.ResumeLayout(false); 
            this.PerformLayout(); 

      } 
private SolvencyLabel solvencyLabel0;
private SolvencyLabel solvencyLabel1;
private SolvencyLabel solvencyLabel2;
private SolvencyLabel solvencyLabel3;
private SolvencyLabel solvencyLabel4;
private SolvencyLabel solvencyLabel5;
private SolvencyLabel solvencyLabel6;
private SolvencyLabel solvencyLabel7;
private SolvencyLabel solvencyLabel8;
private SolvencyLabel solvencyLabel9;
private SolvencyLabel solvencyLabel10;
private SolvencyLabel solvencyLabel11;
private SolvencyLabel solvencyLabel12;
private SolvencyLabel solvencyLabel13;
private SolvencyLabel solvencyLabel14;
private SolvencyLabel solvencyLabel15;
private SolvencyLabel solvencyLabel16;
private SolvencyLabel solvencyLabel17;
private SolvencyLabel solvencyLabel18;
private SolvencyLabel solvencyLabel19;
private SolvencyLabel solvencyLabel20;
private SolvencyLabel solvencyLabel21;
private SolvencyLabel solvencyLabel22;
private SolvencyLabel solvencyLabel23;
private SolvencyLabel solvencyLabel24;
private SolvencyLabel solvencyLabel25;
private SolvencyLabel solvencyLabel26;
private SolvencyLabel solvencyLabel27;
private SolvencyLabel solvencyLabel28;
private SolvencyLabel solvencyLabel29;
private SolvencyLabel solvencyLabel30;
private SolvencyLabel solvencyLabel31;
private SolvencyLabel solvencyLabel32;
private SolvencyLabel solvencyLabel33;
private SolvencyLabel solvencyLabel34;
private SolvencyLabel solvencyLabel35;
private SolvencyLabel solvencyLabel36;
private SolvencyLabel solvencyLabel37;
private SolvencyLabel solvencyLabel38;
private SolvencyLabel solvencyLabel39;
private SolvencyLabel solvencyLabel40;
private SolvencyLabel solvencyLabel41;
private SolvencyLabel solvencyLabel42;
private SolvencyLabel solvencyLabel43;
private SolvencyLabel solvencyLabel44;
private SolvencyLabel solvencyLabel45;
private SolvencyLabel solvencyLabel46;
private SolvencyLabel solvencyLabel47;
private SolvencyLabel solvencyLabel48;
private SolvencyLabel solvencyLabel49;
private SolvencyLabel solvencyLabel50;
private SolvencyLabel solvencyLabel51;
private SolvencyLabel solvencyLabel52;
private SolvencyLabel solvencyLabel53;
private SolvencyLabel solvencyLabel54;
private SolvencyLabel solvencyLabel55;
private SolvencyLabel solvencyLabel56;
private SolvencyLabel solvencyLabel57;
private SolvencyLabel solvencyLabel58;
private SolvencyLabel solvencyLabel59;
private SolvencyLabel solvencyLabel60;
private SolvencyLabel solvencyLabel61;
private SolvencyLabel solvencyLabel62;
private SolvencyLabel solvencyLabel63;
private SolvencyLabel solvencyLabel64;
private SolvencyLabel solvencyLabel65;
private SolvencyLabel solvencyLabel66;
private SolvencyLabel solvencyLabel67;
private SolvencyLabel solvencyLabel68;
private SolvencyLabel solvencyLabel69;
private SolvencyLabel solvencyLabel70;
private SolvencyLabel solvencyLabel71;
private SolvencyLabel solvencyLabel72;
private SolvencyLabel solvencyLabel73;
private SolvencyLabel solvencyLabel74;
private SolvencyLabel solvencyLabel75;
private SolvencyLabel solvencyLabel76;
private SolvencyLabel solvencyLabel77;
private SolvencyLabel solvencyLabel78;
private SolvencyLabel solvencyLabel79;
private SolvencyLabel solvencyLabel80;
private SolvencyLabel solvencyLabel81;
private SolvencyLabel solvencyLabel82;
private SolvencyLabel solvencyLabel83;
private SolvencyLabel solvencyLabel84;
private SolvencyLabel solvencyLabel85;
private SolvencyLabel solvencyLabel86;
private SolvencyLabel solvencyLabel87;
private SolvencyLabel solvencyLabel88;
private SolvencyLabel solvencyLabel89;
private SolvencyLabel solvencyLabel90;
private SolvencyLabel solvencyLabel91;
private SolvencyLabel solvencyLabel92;
private SolvencyLabel solvencyLabel93;
private SolvencyLabel solvencyLabel94;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox95;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox96;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox97;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox98;
private SolvencyDataComboBox SolvencyDataComboBox99;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox100;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox101;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox102;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox103;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox104;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox105;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox106;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox107;
private SolvencyDataComboBox SolvencyDataComboBox108;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox109;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox110;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox111;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox112;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox113;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox114;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox115;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox116;
private SolvencyDataComboBox SolvencyDataComboBox117;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox118;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox119;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox120;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox121;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox122;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox123;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox124;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox125;
private SolvencyDataComboBox SolvencyDataComboBox126;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox127;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox128;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox129;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox130;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox131;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox132;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox133;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox134;
private SolvencyDataComboBox SolvencyDataComboBox135;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox136;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox137;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox138;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox139;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox140;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox141;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox142;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox143;
private SolvencyDataComboBox SolvencyDataComboBox144;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox145;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox146;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox147;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox148;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox149;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox150;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox151;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox152;
private SolvencyDataComboBox SolvencyDataComboBox153;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox154;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox155;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox156;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox157;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox158;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox159;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox160;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox161;
private SolvencyDataComboBox SolvencyDataComboBox162;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox163;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox164;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox165;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox166;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox167;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox168;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox169;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox170;
private SolvencyDataComboBox SolvencyDataComboBox171;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox172;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox173;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox174;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox175;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox176;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox177;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox178;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox179;
private SolvencyDataComboBox SolvencyDataComboBox180;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox181;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox182;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox183;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox184;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox185;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox186;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox187;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox188;
private SolvencyDataComboBox SolvencyDataComboBox189;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox190;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox191;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox192;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox193;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox194;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox195;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox196;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox197;
private SolvencyDataComboBox SolvencyDataComboBox198;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox199;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox200;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox201;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox202;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox203;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox204;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox205;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox206;
private SolvencyDataComboBox SolvencyDataComboBox207;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox208;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox209;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox210;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox211;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox212;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox213;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox214;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox215;
private SolvencyDataComboBox SolvencyDataComboBox216;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox217;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox218;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox219;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox220;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox221;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox222;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox223;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox224;
private SolvencyDataComboBox SolvencyDataComboBox225;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox226;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox227;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox228;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox229;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox230;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox231;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox232;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox233;
private SolvencyDataComboBox SolvencyDataComboBox234;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox235;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox236;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox237;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox238;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox239;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox240;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox241;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox242;
private SolvencyDataComboBox SolvencyDataComboBox243;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox244;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox245;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox246;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox247;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox248;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox249;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox250;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox251;
private SolvencyDataComboBox SolvencyDataComboBox252;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox253;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox254;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox255;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox256;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox257;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox258;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox259;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox260;
private SolvencyDataComboBox SolvencyDataComboBox261;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox262;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox263;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox264;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox265;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox266;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox267;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox268;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox269;
private SolvencyDataComboBox SolvencyDataComboBox270;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox271;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox272;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox273;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox274;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox275;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox276;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox277;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox278;
private SolvencyDataComboBox SolvencyDataComboBox279;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox280;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox281;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox282;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox283;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox284;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox285;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox286;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox287;
private SolvencyDataComboBox SolvencyDataComboBox288;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox289;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox290;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox291;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox292;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox293;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox294;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox295;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox296;
private SolvencyDataComboBox SolvencyDataComboBox297;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox298;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox299;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox300;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox301;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox302;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox303;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox304;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox305;
private SolvencyDataComboBox SolvencyDataComboBox306;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox307;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox308;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox309;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox310;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox311;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox312;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox313;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox314;
private SolvencyDataComboBox SolvencyDataComboBox315;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox316;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox317;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox318;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox319;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox320;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox321;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox322;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox323;
private SolvencyDataComboBox SolvencyDataComboBox324;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox325;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox326;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox327;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox328;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox329;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox330;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox331;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox332;
private SolvencyDataComboBox SolvencyDataComboBox333;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox334;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox335;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox336;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox337;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox338;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox339;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox340;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox341;
private SolvencyDataComboBox SolvencyDataComboBox342;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox343;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox344;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox345;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox346;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox347;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox348;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox349;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox350;
private SolvencyDataComboBox SolvencyDataComboBox351;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox352;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox353;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox354;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox355;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox356;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox357;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox358;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox359;
private SolvencyDataComboBox SolvencyDataComboBox360;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox361;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox362;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox363;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox364;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox365;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox366;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox367;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox368;
private SolvencyDataComboBox SolvencyDataComboBox369;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox370;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox371;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox372;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox373;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox374;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox375;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox376;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox377;
private SolvencyDataComboBox SolvencyDataComboBox378;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox379;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox380;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox381;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox382;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox383;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox384;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox385;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox386;
private SolvencyDataComboBox SolvencyDataComboBox387;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox388;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox389;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox390;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox391;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox392;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox393;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox394;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox395;
private SolvencyDataComboBox SolvencyDataComboBox396;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox397;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox398;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox399;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox400;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox401;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox402;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox403;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox404;
private SolvencyDataComboBox SolvencyDataComboBox405;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox406;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox407;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox408;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox409;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox410;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox411;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox412;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox413;
private SolvencyDataComboBox SolvencyDataComboBox414;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox415;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox416;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox417;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox418;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox419;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox420;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox421;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox422;
private SolvencyDataComboBox SolvencyDataComboBox423;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox424;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox425;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox426;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox427;
private SolvencySplitContainer splitContainerColTitles;
private SolvencySplitContainer splitContainerRowTitles;
private SolvencySplitContainer spltMain;

   }
}

