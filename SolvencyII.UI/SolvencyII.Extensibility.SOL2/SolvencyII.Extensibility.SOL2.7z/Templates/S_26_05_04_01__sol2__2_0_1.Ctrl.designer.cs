using SolvencyII.Domain.ENumerators; 
using SolvencyII.UI.Shared.Controls; 

namespace SolvencyII.UI.UserControls 
{ 
   partial class S_26_05_04_01__sol2__2_0_1_ctrl 
   { 
      private void InitializeComponent() 
      { 
this.solvencyLabel0 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel1 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel2 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel3 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel4 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel5 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel6 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel7 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel8 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel9 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel10 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel11 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel12 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel13 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel14 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel15 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel16 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel17 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel18 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel19 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel20 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel21 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel22 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel23 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel24 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel25 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel26 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel27 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel28 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel29 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel30 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel31 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel32 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel33 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel34 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel35 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel36 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel37 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel38 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel39 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel40 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel41 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel42 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel43 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel44 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel45 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel46 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel47 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyCurrencyTextBox48 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox49 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox50 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox51 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox52 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox53 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox54 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox55 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox56 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox57 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox58 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox59 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox60 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox61 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox62 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox63 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox64 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox65 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox66 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox67 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox68 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox69 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox70 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox71 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox72 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox73 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox74 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox75 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox76 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox77 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox78 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox79 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox80 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox81 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox82 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox83 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox84 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox85 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox86 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox87 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox88 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox89 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox90 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox91 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox92 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox93 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox94 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox95 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox96 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox97 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox98 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox99 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox100 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox101 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox102 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox103 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox104 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox105 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox106 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox107 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox108 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox109 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox110 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox111 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox112 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox113 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox114 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox115 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox116 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox117 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox118 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox119 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox120 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox121 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox122 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox123 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox124 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox125 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox126 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox127 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox128 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox129 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox130 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox131 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox132 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox133 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox134 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox135 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox136 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox137 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox138 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox139 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox140 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox141 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox142 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox143 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox144 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox145 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox146 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox147 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox148 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox149 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox150 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox151 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox152 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.SolvencyDataComboBox153 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyCurrencyTextBox154 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox155 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox156 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox157 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox158 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox159 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.splitContainerColTitles = new SolvencyII.UI.Shared.Controls.SolvencySplitContainer();
this.splitContainerRowTitles = new SolvencyII.UI.Shared.Controls.SolvencySplitContainer();
this.spltMain = new SolvencyII.UI.Shared.Controls.SolvencySplitContainer();
            this.SuspendLayout(); 

//
// solvencyLabel0
//
this.solvencyLabel0.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel0.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel0.Location = new System.Drawing.Point(759,40);
this.solvencyLabel0.Name = "solvencyLabel0";
this.solvencyLabel0.OrdinateID_Label = 5968;
this.solvencyLabel0.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel0.TabIndex = 0;
this.solvencyLabel0.Text = "V" ;
this.solvencyLabel0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel0.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel1
//
this.solvencyLabel1.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel1.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel1.Location = new System.Drawing.Point(759,85);
this.solvencyLabel1.Name = "solvencyLabel1";
this.solvencyLabel1.OrdinateID_Label = 0;
this.solvencyLabel1.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel1.TabIndex = 1;
this.solvencyLabel1.Text = "C0090" ;
this.solvencyLabel1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel2
//
this.solvencyLabel2.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel2.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel2.Location = new System.Drawing.Point(652,40);
this.solvencyLabel2.Name = "solvencyLabel2";
this.solvencyLabel2.OrdinateID_Label = 5967;
this.solvencyLabel2.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel2.TabIndex = 2;
this.solvencyLabel2.Text = "Geographical Diversification" ;
this.solvencyLabel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel3
//
this.solvencyLabel3.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel3.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel3.Location = new System.Drawing.Point(652,85);
this.solvencyLabel3.Name = "solvencyLabel3";
this.solvencyLabel3.OrdinateID_Label = 0;
this.solvencyLabel3.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel3.TabIndex = 3;
this.solvencyLabel3.Text = "C0080" ;
this.solvencyLabel3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel4
//
this.solvencyLabel4.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel4.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel4.Location = new System.Drawing.Point(545,40);
this.solvencyLabel4.Name = "solvencyLabel4";
this.solvencyLabel4.OrdinateID_Label = 5966;
this.solvencyLabel4.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel4.TabIndex = 4;
this.solvencyLabel4.Text = "Vres" ;
this.solvencyLabel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel5
//
this.solvencyLabel5.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel5.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel5.Location = new System.Drawing.Point(545,85);
this.solvencyLabel5.Name = "solvencyLabel5";
this.solvencyLabel5.OrdinateID_Label = 0;
this.solvencyLabel5.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel5.TabIndex = 5;
this.solvencyLabel5.Text = "C0070" ;
this.solvencyLabel5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel6
//
this.solvencyLabel6.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel6.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel6.Location = new System.Drawing.Point(438,40);
this.solvencyLabel6.Name = "solvencyLabel6";
this.solvencyLabel6.OrdinateID_Label = 5965;
this.solvencyLabel6.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel6.TabIndex = 6;
this.solvencyLabel6.Text = "Vprem" ;
this.solvencyLabel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel6.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel7
//
this.solvencyLabel7.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel7.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel7.Location = new System.Drawing.Point(438,85);
this.solvencyLabel7.Name = "solvencyLabel7";
this.solvencyLabel7.OrdinateID_Label = 0;
this.solvencyLabel7.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel7.TabIndex = 7;
this.solvencyLabel7.Text = "C0060" ;
this.solvencyLabel7.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel8
//
this.solvencyLabel8.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel8.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel8.Location = new System.Drawing.Point(438,10);
this.solvencyLabel8.Name = "solvencyLabel8";
this.solvencyLabel8.OrdinateID_Label = 5964;
this.solvencyLabel8.Size = new System.Drawing.Size(429, 75);
this.solvencyLabel8.TabIndex = 8;
this.solvencyLabel8.Text = "Volume measure for premium and reserve risk" ;
this.solvencyLabel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel8.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel9
//
this.solvencyLabel9.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel9.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel9.Location = new System.Drawing.Point(331,40);
this.solvencyLabel9.Name = "solvencyLabel9";
this.solvencyLabel9.OrdinateID_Label = 5963;
this.solvencyLabel9.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel9.TabIndex = 9;
this.solvencyLabel9.Text = "USP" ;
this.solvencyLabel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel9.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel10
//
this.solvencyLabel10.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel10.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel10.Location = new System.Drawing.Point(331,85);
this.solvencyLabel10.Name = "solvencyLabel10";
this.solvencyLabel10.OrdinateID_Label = 0;
this.solvencyLabel10.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel10.TabIndex = 10;
this.solvencyLabel10.Text = "C0050" ;
this.solvencyLabel10.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel11
//
this.solvencyLabel11.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel11.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel11.Location = new System.Drawing.Point(331,10);
this.solvencyLabel11.Name = "solvencyLabel11";
this.solvencyLabel11.OrdinateID_Label = 5962;
this.solvencyLabel11.Size = new System.Drawing.Size(108, 75);
this.solvencyLabel11.TabIndex = 11;
this.solvencyLabel11.Text = "Standard deviation for reserve risk" ;
this.solvencyLabel11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel11.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel12
//
this.solvencyLabel12.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel12.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel12.Location = new System.Drawing.Point(224,40);
this.solvencyLabel12.Name = "solvencyLabel12";
this.solvencyLabel12.OrdinateID_Label = 5961;
this.solvencyLabel12.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel12.TabIndex = 12;
this.solvencyLabel12.Text = "USP Adjustment factor for non-proportional reinsurance" ;
this.solvencyLabel12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel12.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel13
//
this.solvencyLabel13.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel13.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel13.Location = new System.Drawing.Point(224,85);
this.solvencyLabel13.Name = "solvencyLabel13";
this.solvencyLabel13.OrdinateID_Label = 0;
this.solvencyLabel13.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel13.TabIndex = 13;
this.solvencyLabel13.Text = "C0040" ;
this.solvencyLabel13.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel14
//
this.solvencyLabel14.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel14.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel14.Location = new System.Drawing.Point(117,40);
this.solvencyLabel14.Name = "solvencyLabel14";
this.solvencyLabel14.OrdinateID_Label = 5960;
this.solvencyLabel14.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel14.TabIndex = 14;
this.solvencyLabel14.Text = "USP Standard Deviation gross/net" ;
this.solvencyLabel14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel14.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel15
//
this.solvencyLabel15.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel15.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel15.Location = new System.Drawing.Point(117,85);
this.solvencyLabel15.Name = "solvencyLabel15";
this.solvencyLabel15.OrdinateID_Label = 0;
this.solvencyLabel15.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel15.TabIndex = 15;
this.solvencyLabel15.Text = "C0030" ;
this.solvencyLabel15.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel16
//
this.solvencyLabel16.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel16.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel16.Location = new System.Drawing.Point(10,40);
this.solvencyLabel16.Name = "solvencyLabel16";
this.solvencyLabel16.OrdinateID_Label = 5959;
this.solvencyLabel16.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel16.TabIndex = 16;
this.solvencyLabel16.Text = "USP Standard Deviation" ;
this.solvencyLabel16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel16.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel17
//
this.solvencyLabel17.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel17.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel17.Location = new System.Drawing.Point(10,85);
this.solvencyLabel17.Name = "solvencyLabel17";
this.solvencyLabel17.OrdinateID_Label = 0;
this.solvencyLabel17.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel17.TabIndex = 17;
this.solvencyLabel17.Text = "C0020" ;
this.solvencyLabel17.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel18
//
this.solvencyLabel18.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel18.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel18.Location = new System.Drawing.Point(10,10);
this.solvencyLabel18.Name = "solvencyLabel18";
this.solvencyLabel18.OrdinateID_Label = 5958;
this.solvencyLabel18.Size = new System.Drawing.Size(322, 75);
this.solvencyLabel18.TabIndex = 18;
this.solvencyLabel18.Text = "Standard deviation for premium risk" ;
this.solvencyLabel18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel18.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel19
//
this.solvencyLabel19.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel19.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel19.Location = new System.Drawing.Point(10,3);
this.solvencyLabel19.Name = "solvencyLabel19";
this.solvencyLabel19.OrdinateID_Label = 5969;
this.solvencyLabel19.Size = new System.Drawing.Size(205, 15);
this.solvencyLabel19.TabIndex = 19;
this.solvencyLabel19.Text = "Motor vehicle liability" ;
this.solvencyLabel19.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel20
//
this.solvencyLabel20.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel20.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel20.Location = new System.Drawing.Point(229,3);
this.solvencyLabel20.Name = "solvencyLabel20";
this.solvencyLabel20.OrdinateID_Label = 0;
this.solvencyLabel20.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel20.TabIndex = 20;
this.solvencyLabel20.Text = "R0100" ;
this.solvencyLabel20.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel21
//
this.solvencyLabel21.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel21.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel21.Location = new System.Drawing.Point(10,23);
this.solvencyLabel21.Name = "solvencyLabel21";
this.solvencyLabel21.OrdinateID_Label = 5970;
this.solvencyLabel21.Size = new System.Drawing.Size(205, 15);
this.solvencyLabel21.TabIndex = 21;
this.solvencyLabel21.Text = "Motor, other classes" ;
this.solvencyLabel21.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel22
//
this.solvencyLabel22.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel22.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel22.Location = new System.Drawing.Point(229,23);
this.solvencyLabel22.Name = "solvencyLabel22";
this.solvencyLabel22.OrdinateID_Label = 0;
this.solvencyLabel22.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel22.TabIndex = 22;
this.solvencyLabel22.Text = "R0110" ;
this.solvencyLabel22.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel23
//
this.solvencyLabel23.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel23.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel23.Location = new System.Drawing.Point(10,43);
this.solvencyLabel23.Name = "solvencyLabel23";
this.solvencyLabel23.OrdinateID_Label = 5971;
this.solvencyLabel23.Size = new System.Drawing.Size(205, 15);
this.solvencyLabel23.TabIndex = 23;
this.solvencyLabel23.Text = "Marine, aviation, transport (MAT)" ;
this.solvencyLabel23.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel24
//
this.solvencyLabel24.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel24.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel24.Location = new System.Drawing.Point(229,43);
this.solvencyLabel24.Name = "solvencyLabel24";
this.solvencyLabel24.OrdinateID_Label = 0;
this.solvencyLabel24.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel24.TabIndex = 24;
this.solvencyLabel24.Text = "R0120" ;
this.solvencyLabel24.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel25
//
this.solvencyLabel25.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel25.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel25.Location = new System.Drawing.Point(10,63);
this.solvencyLabel25.Name = "solvencyLabel25";
this.solvencyLabel25.OrdinateID_Label = 5972;
this.solvencyLabel25.Size = new System.Drawing.Size(205, 15);
this.solvencyLabel25.TabIndex = 25;
this.solvencyLabel25.Text = "Fire and other property damage" ;
this.solvencyLabel25.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel26
//
this.solvencyLabel26.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel26.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel26.Location = new System.Drawing.Point(229,63);
this.solvencyLabel26.Name = "solvencyLabel26";
this.solvencyLabel26.OrdinateID_Label = 0;
this.solvencyLabel26.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel26.TabIndex = 26;
this.solvencyLabel26.Text = "R0130" ;
this.solvencyLabel26.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel27
//
this.solvencyLabel27.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel27.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel27.Location = new System.Drawing.Point(10,83);
this.solvencyLabel27.Name = "solvencyLabel27";
this.solvencyLabel27.OrdinateID_Label = 5973;
this.solvencyLabel27.Size = new System.Drawing.Size(205, 15);
this.solvencyLabel27.TabIndex = 27;
this.solvencyLabel27.Text = "Third-party liability" ;
this.solvencyLabel27.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel28
//
this.solvencyLabel28.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel28.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel28.Location = new System.Drawing.Point(229,83);
this.solvencyLabel28.Name = "solvencyLabel28";
this.solvencyLabel28.OrdinateID_Label = 0;
this.solvencyLabel28.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel28.TabIndex = 28;
this.solvencyLabel28.Text = "R0140" ;
this.solvencyLabel28.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel29
//
this.solvencyLabel29.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel29.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel29.Location = new System.Drawing.Point(10,103);
this.solvencyLabel29.Name = "solvencyLabel29";
this.solvencyLabel29.OrdinateID_Label = 5974;
this.solvencyLabel29.Size = new System.Drawing.Size(205, 15);
this.solvencyLabel29.TabIndex = 29;
this.solvencyLabel29.Text = "Credit and suretyship" ;
this.solvencyLabel29.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel30
//
this.solvencyLabel30.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel30.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel30.Location = new System.Drawing.Point(229,103);
this.solvencyLabel30.Name = "solvencyLabel30";
this.solvencyLabel30.OrdinateID_Label = 0;
this.solvencyLabel30.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel30.TabIndex = 30;
this.solvencyLabel30.Text = "R0150" ;
this.solvencyLabel30.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel31
//
this.solvencyLabel31.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel31.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel31.Location = new System.Drawing.Point(10,123);
this.solvencyLabel31.Name = "solvencyLabel31";
this.solvencyLabel31.OrdinateID_Label = 5975;
this.solvencyLabel31.Size = new System.Drawing.Size(205, 15);
this.solvencyLabel31.TabIndex = 31;
this.solvencyLabel31.Text = "Legal expenses" ;
this.solvencyLabel31.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel32
//
this.solvencyLabel32.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel32.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel32.Location = new System.Drawing.Point(229,123);
this.solvencyLabel32.Name = "solvencyLabel32";
this.solvencyLabel32.OrdinateID_Label = 0;
this.solvencyLabel32.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel32.TabIndex = 32;
this.solvencyLabel32.Text = "R0160" ;
this.solvencyLabel32.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel33
//
this.solvencyLabel33.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel33.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel33.Location = new System.Drawing.Point(10,143);
this.solvencyLabel33.Name = "solvencyLabel33";
this.solvencyLabel33.OrdinateID_Label = 5976;
this.solvencyLabel33.Size = new System.Drawing.Size(205, 15);
this.solvencyLabel33.TabIndex = 33;
this.solvencyLabel33.Text = "Assistance" ;
this.solvencyLabel33.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel34
//
this.solvencyLabel34.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel34.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel34.Location = new System.Drawing.Point(229,143);
this.solvencyLabel34.Name = "solvencyLabel34";
this.solvencyLabel34.OrdinateID_Label = 0;
this.solvencyLabel34.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel34.TabIndex = 34;
this.solvencyLabel34.Text = "R0170" ;
this.solvencyLabel34.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel35
//
this.solvencyLabel35.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel35.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel35.Location = new System.Drawing.Point(10,163);
this.solvencyLabel35.Name = "solvencyLabel35";
this.solvencyLabel35.OrdinateID_Label = 5977;
this.solvencyLabel35.Size = new System.Drawing.Size(205, 15);
this.solvencyLabel35.TabIndex = 35;
this.solvencyLabel35.Text = "Miscellaneous" ;
this.solvencyLabel35.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel36
//
this.solvencyLabel36.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel36.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel36.Location = new System.Drawing.Point(229,163);
this.solvencyLabel36.Name = "solvencyLabel36";
this.solvencyLabel36.OrdinateID_Label = 0;
this.solvencyLabel36.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel36.TabIndex = 36;
this.solvencyLabel36.Text = "R0180" ;
this.solvencyLabel36.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel37
//
this.solvencyLabel37.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel37.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel37.Location = new System.Drawing.Point(10,183);
this.solvencyLabel37.Name = "solvencyLabel37";
this.solvencyLabel37.OrdinateID_Label = 5978;
this.solvencyLabel37.Size = new System.Drawing.Size(205, 15);
this.solvencyLabel37.TabIndex = 37;
this.solvencyLabel37.Text = "Non-proportional reinsurance - property" ;
this.solvencyLabel37.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel38
//
this.solvencyLabel38.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel38.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel38.Location = new System.Drawing.Point(229,183);
this.solvencyLabel38.Name = "solvencyLabel38";
this.solvencyLabel38.OrdinateID_Label = 0;
this.solvencyLabel38.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel38.TabIndex = 38;
this.solvencyLabel38.Text = "R0190" ;
this.solvencyLabel38.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel39
//
this.solvencyLabel39.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel39.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel39.Location = new System.Drawing.Point(10,203);
this.solvencyLabel39.Name = "solvencyLabel39";
this.solvencyLabel39.OrdinateID_Label = 5979;
this.solvencyLabel39.Size = new System.Drawing.Size(205, 15);
this.solvencyLabel39.TabIndex = 39;
this.solvencyLabel39.Text = "Non-proportional reinsurance - casualty" ;
this.solvencyLabel39.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel40
//
this.solvencyLabel40.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel40.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel40.Location = new System.Drawing.Point(229,203);
this.solvencyLabel40.Name = "solvencyLabel40";
this.solvencyLabel40.OrdinateID_Label = 0;
this.solvencyLabel40.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel40.TabIndex = 40;
this.solvencyLabel40.Text = "R0200" ;
this.solvencyLabel40.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel41
//
this.solvencyLabel41.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel41.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel41.Location = new System.Drawing.Point(10,223);
this.solvencyLabel41.Name = "solvencyLabel41";
this.solvencyLabel41.OrdinateID_Label = 5980;
this.solvencyLabel41.Size = new System.Drawing.Size(205, 15);
this.solvencyLabel41.TabIndex = 41;
this.solvencyLabel41.Text = "Non-proportional reinsurance - MAT" ;
this.solvencyLabel41.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel42
//
this.solvencyLabel42.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel42.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel42.Location = new System.Drawing.Point(229,223);
this.solvencyLabel42.Name = "solvencyLabel42";
this.solvencyLabel42.OrdinateID_Label = 0;
this.solvencyLabel42.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel42.TabIndex = 42;
this.solvencyLabel42.Text = "R0210" ;
this.solvencyLabel42.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel43
//
this.solvencyLabel43.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel43.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel43.Location = new System.Drawing.Point(10,243);
this.solvencyLabel43.Name = "solvencyLabel43";
this.solvencyLabel43.OrdinateID_Label = 5981;
this.solvencyLabel43.Size = new System.Drawing.Size(205, 15);
this.solvencyLabel43.TabIndex = 43;
this.solvencyLabel43.Text = "Total Volume measure" ;
this.solvencyLabel43.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel44
//
this.solvencyLabel44.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel44.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel44.Location = new System.Drawing.Point(229,243);
this.solvencyLabel44.Name = "solvencyLabel44";
this.solvencyLabel44.OrdinateID_Label = 0;
this.solvencyLabel44.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel44.TabIndex = 44;
this.solvencyLabel44.Text = "R0220" ;
this.solvencyLabel44.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel45
//
this.solvencyLabel45.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel45.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel45.Location = new System.Drawing.Point(10,263);
this.solvencyLabel45.Name = "solvencyLabel45";
this.solvencyLabel45.OrdinateID_Label = 5982;
this.solvencyLabel45.Size = new System.Drawing.Size(205, 15);
this.solvencyLabel45.TabIndex = 45;
this.solvencyLabel45.Text = "Combined standard deviation" ;
this.solvencyLabel45.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel46
//
this.solvencyLabel46.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel46.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel46.Location = new System.Drawing.Point(229,263);
this.solvencyLabel46.Name = "solvencyLabel46";
this.solvencyLabel46.OrdinateID_Label = 0;
this.solvencyLabel46.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel46.TabIndex = 46;
this.solvencyLabel46.Text = "R0230" ;
this.solvencyLabel46.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel47
//
this.solvencyLabel47.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel47.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel47.Location = new System.Drawing.Point(229,283);
this.solvencyLabel47.Name = "solvencyLabel47";
this.solvencyLabel47.OrdinateID_Label = 0;
this.solvencyLabel47.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel47.TabIndex = 47;
this.solvencyLabel47.Text = "." ;
this.solvencyLabel47.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyCurrencyTextBox48
//
this.solvencyCurrencyTextBox48.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox48.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox48.Location = new System.Drawing.Point(10,3);
this.solvencyCurrencyTextBox48.Name = "solvencyCurrencyTextBox48";
this.solvencyCurrencyTextBox48.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox48.TabIndex = 48;
this.solvencyCurrencyTextBox48.ColName = "R0100C0020";
this.solvencyCurrencyTextBox48.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// SolvencyDataComboBox49
//
this.SolvencyDataComboBox49.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox49.Location = new System.Drawing.Point(117,3);
this.SolvencyDataComboBox49.Name = "SolvencyDataComboBox49";
this.SolvencyDataComboBox49.Size = new System.Drawing.Size(100, 13);
this.SolvencyDataComboBox49.TabIndex = 49;
this.SolvencyDataComboBox49.ColName = "R0100C0030";
this.SolvencyDataComboBox49.AxisID = 1113;
this.SolvencyDataComboBox49.OrdinateID = 5960;
this.SolvencyDataComboBox49.StartOrder = 0;
this.SolvencyDataComboBox49.NextOrder = 0;
//
// solvencyCurrencyTextBox50
//
this.solvencyCurrencyTextBox50.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox50.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox50.Location = new System.Drawing.Point(224,3);
this.solvencyCurrencyTextBox50.Name = "solvencyCurrencyTextBox50";
this.solvencyCurrencyTextBox50.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox50.TabIndex = 50;
this.solvencyCurrencyTextBox50.ColName = "R0100C0040";
this.solvencyCurrencyTextBox50.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox51
//
this.solvencyCurrencyTextBox51.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox51.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox51.Location = new System.Drawing.Point(331,3);
this.solvencyCurrencyTextBox51.Name = "solvencyCurrencyTextBox51";
this.solvencyCurrencyTextBox51.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox51.TabIndex = 51;
this.solvencyCurrencyTextBox51.ColName = "R0100C0050";
this.solvencyCurrencyTextBox51.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox52
//
this.solvencyCurrencyTextBox52.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox52.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox52.Location = new System.Drawing.Point(438,3);
this.solvencyCurrencyTextBox52.Name = "solvencyCurrencyTextBox52";
this.solvencyCurrencyTextBox52.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox52.TabIndex = 52;
this.solvencyCurrencyTextBox52.ColName = "R0100C0060";
this.solvencyCurrencyTextBox52.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox53
//
this.solvencyCurrencyTextBox53.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox53.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox53.Location = new System.Drawing.Point(545,3);
this.solvencyCurrencyTextBox53.Name = "solvencyCurrencyTextBox53";
this.solvencyCurrencyTextBox53.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox53.TabIndex = 53;
this.solvencyCurrencyTextBox53.ColName = "R0100C0070";
this.solvencyCurrencyTextBox53.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox54
//
this.solvencyCurrencyTextBox54.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox54.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox54.Location = new System.Drawing.Point(652,3);
this.solvencyCurrencyTextBox54.Name = "solvencyCurrencyTextBox54";
this.solvencyCurrencyTextBox54.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox54.TabIndex = 54;
this.solvencyCurrencyTextBox54.ColName = "R0100C0080";
this.solvencyCurrencyTextBox54.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox55
//
this.solvencyCurrencyTextBox55.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox55.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox55.Location = new System.Drawing.Point(759,3);
this.solvencyCurrencyTextBox55.Name = "solvencyCurrencyTextBox55";
this.solvencyCurrencyTextBox55.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox55.TabIndex = 55;
this.solvencyCurrencyTextBox55.ColName = "R0100C0090";
this.solvencyCurrencyTextBox55.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox56
//
this.solvencyCurrencyTextBox56.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox56.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox56.Location = new System.Drawing.Point(10,23);
this.solvencyCurrencyTextBox56.Name = "solvencyCurrencyTextBox56";
this.solvencyCurrencyTextBox56.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox56.TabIndex = 56;
this.solvencyCurrencyTextBox56.ColName = "R0110C0020";
this.solvencyCurrencyTextBox56.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// SolvencyDataComboBox57
//
this.SolvencyDataComboBox57.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox57.Location = new System.Drawing.Point(117,23);
this.SolvencyDataComboBox57.Name = "SolvencyDataComboBox57";
this.SolvencyDataComboBox57.Size = new System.Drawing.Size(100, 13);
this.SolvencyDataComboBox57.TabIndex = 57;
this.SolvencyDataComboBox57.ColName = "R0110C0030";
this.SolvencyDataComboBox57.AxisID = 1113;
this.SolvencyDataComboBox57.OrdinateID = 5960;
this.SolvencyDataComboBox57.StartOrder = 0;
this.SolvencyDataComboBox57.NextOrder = 0;
//
// solvencyCurrencyTextBox58
//
this.solvencyCurrencyTextBox58.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox58.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox58.Location = new System.Drawing.Point(224,23);
this.solvencyCurrencyTextBox58.Name = "solvencyCurrencyTextBox58";
this.solvencyCurrencyTextBox58.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox58.TabIndex = 58;
this.solvencyCurrencyTextBox58.ColName = "R0110C0040";
this.solvencyCurrencyTextBox58.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox59
//
this.solvencyCurrencyTextBox59.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox59.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox59.Location = new System.Drawing.Point(331,23);
this.solvencyCurrencyTextBox59.Name = "solvencyCurrencyTextBox59";
this.solvencyCurrencyTextBox59.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox59.TabIndex = 59;
this.solvencyCurrencyTextBox59.ColName = "R0110C0050";
this.solvencyCurrencyTextBox59.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox60
//
this.solvencyCurrencyTextBox60.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox60.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox60.Location = new System.Drawing.Point(438,23);
this.solvencyCurrencyTextBox60.Name = "solvencyCurrencyTextBox60";
this.solvencyCurrencyTextBox60.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox60.TabIndex = 60;
this.solvencyCurrencyTextBox60.ColName = "R0110C0060";
this.solvencyCurrencyTextBox60.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox61
//
this.solvencyCurrencyTextBox61.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox61.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox61.Location = new System.Drawing.Point(545,23);
this.solvencyCurrencyTextBox61.Name = "solvencyCurrencyTextBox61";
this.solvencyCurrencyTextBox61.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox61.TabIndex = 61;
this.solvencyCurrencyTextBox61.ColName = "R0110C0070";
this.solvencyCurrencyTextBox61.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox62
//
this.solvencyCurrencyTextBox62.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox62.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox62.Location = new System.Drawing.Point(652,23);
this.solvencyCurrencyTextBox62.Name = "solvencyCurrencyTextBox62";
this.solvencyCurrencyTextBox62.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox62.TabIndex = 62;
this.solvencyCurrencyTextBox62.ColName = "R0110C0080";
this.solvencyCurrencyTextBox62.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox63
//
this.solvencyCurrencyTextBox63.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox63.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox63.Location = new System.Drawing.Point(759,23);
this.solvencyCurrencyTextBox63.Name = "solvencyCurrencyTextBox63";
this.solvencyCurrencyTextBox63.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox63.TabIndex = 63;
this.solvencyCurrencyTextBox63.ColName = "R0110C0090";
this.solvencyCurrencyTextBox63.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox64
//
this.solvencyCurrencyTextBox64.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox64.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox64.Location = new System.Drawing.Point(10,43);
this.solvencyCurrencyTextBox64.Name = "solvencyCurrencyTextBox64";
this.solvencyCurrencyTextBox64.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox64.TabIndex = 64;
this.solvencyCurrencyTextBox64.ColName = "R0120C0020";
this.solvencyCurrencyTextBox64.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// SolvencyDataComboBox65
//
this.SolvencyDataComboBox65.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox65.Location = new System.Drawing.Point(117,43);
this.SolvencyDataComboBox65.Name = "SolvencyDataComboBox65";
this.SolvencyDataComboBox65.Size = new System.Drawing.Size(100, 13);
this.SolvencyDataComboBox65.TabIndex = 65;
this.SolvencyDataComboBox65.ColName = "R0120C0030";
this.SolvencyDataComboBox65.AxisID = 1113;
this.SolvencyDataComboBox65.OrdinateID = 5960;
this.SolvencyDataComboBox65.StartOrder = 0;
this.SolvencyDataComboBox65.NextOrder = 0;
//
// solvencyCurrencyTextBox66
//
this.solvencyCurrencyTextBox66.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox66.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox66.Location = new System.Drawing.Point(224,43);
this.solvencyCurrencyTextBox66.Name = "solvencyCurrencyTextBox66";
this.solvencyCurrencyTextBox66.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox66.TabIndex = 66;
this.solvencyCurrencyTextBox66.ColName = "R0120C0040";
this.solvencyCurrencyTextBox66.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox67
//
this.solvencyCurrencyTextBox67.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox67.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox67.Location = new System.Drawing.Point(331,43);
this.solvencyCurrencyTextBox67.Name = "solvencyCurrencyTextBox67";
this.solvencyCurrencyTextBox67.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox67.TabIndex = 67;
this.solvencyCurrencyTextBox67.ColName = "R0120C0050";
this.solvencyCurrencyTextBox67.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox68
//
this.solvencyCurrencyTextBox68.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox68.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox68.Location = new System.Drawing.Point(438,43);
this.solvencyCurrencyTextBox68.Name = "solvencyCurrencyTextBox68";
this.solvencyCurrencyTextBox68.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox68.TabIndex = 68;
this.solvencyCurrencyTextBox68.ColName = "R0120C0060";
this.solvencyCurrencyTextBox68.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox69
//
this.solvencyCurrencyTextBox69.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox69.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox69.Location = new System.Drawing.Point(545,43);
this.solvencyCurrencyTextBox69.Name = "solvencyCurrencyTextBox69";
this.solvencyCurrencyTextBox69.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox69.TabIndex = 69;
this.solvencyCurrencyTextBox69.ColName = "R0120C0070";
this.solvencyCurrencyTextBox69.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox70
//
this.solvencyCurrencyTextBox70.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox70.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox70.Location = new System.Drawing.Point(652,43);
this.solvencyCurrencyTextBox70.Name = "solvencyCurrencyTextBox70";
this.solvencyCurrencyTextBox70.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox70.TabIndex = 70;
this.solvencyCurrencyTextBox70.ColName = "R0120C0080";
this.solvencyCurrencyTextBox70.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox71
//
this.solvencyCurrencyTextBox71.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox71.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox71.Location = new System.Drawing.Point(759,43);
this.solvencyCurrencyTextBox71.Name = "solvencyCurrencyTextBox71";
this.solvencyCurrencyTextBox71.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox71.TabIndex = 71;
this.solvencyCurrencyTextBox71.ColName = "R0120C0090";
this.solvencyCurrencyTextBox71.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox72
//
this.solvencyCurrencyTextBox72.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox72.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox72.Location = new System.Drawing.Point(10,63);
this.solvencyCurrencyTextBox72.Name = "solvencyCurrencyTextBox72";
this.solvencyCurrencyTextBox72.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox72.TabIndex = 72;
this.solvencyCurrencyTextBox72.ColName = "R0130C0020";
this.solvencyCurrencyTextBox72.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// SolvencyDataComboBox73
//
this.SolvencyDataComboBox73.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox73.Location = new System.Drawing.Point(117,63);
this.SolvencyDataComboBox73.Name = "SolvencyDataComboBox73";
this.SolvencyDataComboBox73.Size = new System.Drawing.Size(100, 13);
this.SolvencyDataComboBox73.TabIndex = 73;
this.SolvencyDataComboBox73.ColName = "R0130C0030";
this.SolvencyDataComboBox73.AxisID = 1113;
this.SolvencyDataComboBox73.OrdinateID = 5960;
this.SolvencyDataComboBox73.StartOrder = 0;
this.SolvencyDataComboBox73.NextOrder = 0;
//
// solvencyCurrencyTextBox74
//
this.solvencyCurrencyTextBox74.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox74.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox74.Location = new System.Drawing.Point(224,63);
this.solvencyCurrencyTextBox74.Name = "solvencyCurrencyTextBox74";
this.solvencyCurrencyTextBox74.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox74.TabIndex = 74;
this.solvencyCurrencyTextBox74.ColName = "R0130C0040";
this.solvencyCurrencyTextBox74.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox75
//
this.solvencyCurrencyTextBox75.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox75.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox75.Location = new System.Drawing.Point(331,63);
this.solvencyCurrencyTextBox75.Name = "solvencyCurrencyTextBox75";
this.solvencyCurrencyTextBox75.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox75.TabIndex = 75;
this.solvencyCurrencyTextBox75.ColName = "R0130C0050";
this.solvencyCurrencyTextBox75.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox76
//
this.solvencyCurrencyTextBox76.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox76.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox76.Location = new System.Drawing.Point(438,63);
this.solvencyCurrencyTextBox76.Name = "solvencyCurrencyTextBox76";
this.solvencyCurrencyTextBox76.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox76.TabIndex = 76;
this.solvencyCurrencyTextBox76.ColName = "R0130C0060";
this.solvencyCurrencyTextBox76.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox77
//
this.solvencyCurrencyTextBox77.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox77.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox77.Location = new System.Drawing.Point(545,63);
this.solvencyCurrencyTextBox77.Name = "solvencyCurrencyTextBox77";
this.solvencyCurrencyTextBox77.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox77.TabIndex = 77;
this.solvencyCurrencyTextBox77.ColName = "R0130C0070";
this.solvencyCurrencyTextBox77.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox78
//
this.solvencyCurrencyTextBox78.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox78.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox78.Location = new System.Drawing.Point(652,63);
this.solvencyCurrencyTextBox78.Name = "solvencyCurrencyTextBox78";
this.solvencyCurrencyTextBox78.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox78.TabIndex = 78;
this.solvencyCurrencyTextBox78.ColName = "R0130C0080";
this.solvencyCurrencyTextBox78.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox79
//
this.solvencyCurrencyTextBox79.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox79.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox79.Location = new System.Drawing.Point(759,63);
this.solvencyCurrencyTextBox79.Name = "solvencyCurrencyTextBox79";
this.solvencyCurrencyTextBox79.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox79.TabIndex = 79;
this.solvencyCurrencyTextBox79.ColName = "R0130C0090";
this.solvencyCurrencyTextBox79.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox80
//
this.solvencyCurrencyTextBox80.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox80.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox80.Location = new System.Drawing.Point(10,83);
this.solvencyCurrencyTextBox80.Name = "solvencyCurrencyTextBox80";
this.solvencyCurrencyTextBox80.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox80.TabIndex = 80;
this.solvencyCurrencyTextBox80.ColName = "R0140C0020";
this.solvencyCurrencyTextBox80.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// SolvencyDataComboBox81
//
this.SolvencyDataComboBox81.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox81.Location = new System.Drawing.Point(117,83);
this.SolvencyDataComboBox81.Name = "SolvencyDataComboBox81";
this.SolvencyDataComboBox81.Size = new System.Drawing.Size(100, 13);
this.SolvencyDataComboBox81.TabIndex = 81;
this.SolvencyDataComboBox81.ColName = "R0140C0030";
this.SolvencyDataComboBox81.AxisID = 1113;
this.SolvencyDataComboBox81.OrdinateID = 5960;
this.SolvencyDataComboBox81.StartOrder = 0;
this.SolvencyDataComboBox81.NextOrder = 0;
//
// solvencyCurrencyTextBox82
//
this.solvencyCurrencyTextBox82.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox82.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox82.Location = new System.Drawing.Point(224,83);
this.solvencyCurrencyTextBox82.Name = "solvencyCurrencyTextBox82";
this.solvencyCurrencyTextBox82.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox82.TabIndex = 82;
this.solvencyCurrencyTextBox82.ColName = "R0140C0040";
this.solvencyCurrencyTextBox82.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox83
//
this.solvencyCurrencyTextBox83.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox83.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox83.Location = new System.Drawing.Point(331,83);
this.solvencyCurrencyTextBox83.Name = "solvencyCurrencyTextBox83";
this.solvencyCurrencyTextBox83.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox83.TabIndex = 83;
this.solvencyCurrencyTextBox83.ColName = "R0140C0050";
this.solvencyCurrencyTextBox83.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox84
//
this.solvencyCurrencyTextBox84.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox84.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox84.Location = new System.Drawing.Point(438,83);
this.solvencyCurrencyTextBox84.Name = "solvencyCurrencyTextBox84";
this.solvencyCurrencyTextBox84.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox84.TabIndex = 84;
this.solvencyCurrencyTextBox84.ColName = "R0140C0060";
this.solvencyCurrencyTextBox84.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox85
//
this.solvencyCurrencyTextBox85.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox85.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox85.Location = new System.Drawing.Point(545,83);
this.solvencyCurrencyTextBox85.Name = "solvencyCurrencyTextBox85";
this.solvencyCurrencyTextBox85.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox85.TabIndex = 85;
this.solvencyCurrencyTextBox85.ColName = "R0140C0070";
this.solvencyCurrencyTextBox85.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox86
//
this.solvencyCurrencyTextBox86.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox86.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox86.Location = new System.Drawing.Point(652,83);
this.solvencyCurrencyTextBox86.Name = "solvencyCurrencyTextBox86";
this.solvencyCurrencyTextBox86.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox86.TabIndex = 86;
this.solvencyCurrencyTextBox86.ColName = "R0140C0080";
this.solvencyCurrencyTextBox86.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox87
//
this.solvencyCurrencyTextBox87.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox87.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox87.Location = new System.Drawing.Point(759,83);
this.solvencyCurrencyTextBox87.Name = "solvencyCurrencyTextBox87";
this.solvencyCurrencyTextBox87.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox87.TabIndex = 87;
this.solvencyCurrencyTextBox87.ColName = "R0140C0090";
this.solvencyCurrencyTextBox87.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox88
//
this.solvencyCurrencyTextBox88.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox88.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox88.Location = new System.Drawing.Point(10,103);
this.solvencyCurrencyTextBox88.Name = "solvencyCurrencyTextBox88";
this.solvencyCurrencyTextBox88.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox88.TabIndex = 88;
this.solvencyCurrencyTextBox88.ColName = "R0150C0020";
this.solvencyCurrencyTextBox88.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// SolvencyDataComboBox89
//
this.SolvencyDataComboBox89.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox89.Location = new System.Drawing.Point(117,103);
this.SolvencyDataComboBox89.Name = "SolvencyDataComboBox89";
this.SolvencyDataComboBox89.Size = new System.Drawing.Size(100, 13);
this.SolvencyDataComboBox89.TabIndex = 89;
this.SolvencyDataComboBox89.ColName = "R0150C0030";
this.SolvencyDataComboBox89.AxisID = 1113;
this.SolvencyDataComboBox89.OrdinateID = 5960;
this.SolvencyDataComboBox89.StartOrder = 0;
this.SolvencyDataComboBox89.NextOrder = 0;
//
// solvencyCurrencyTextBox90
//
this.solvencyCurrencyTextBox90.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox90.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox90.Location = new System.Drawing.Point(224,103);
this.solvencyCurrencyTextBox90.Name = "solvencyCurrencyTextBox90";
this.solvencyCurrencyTextBox90.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox90.TabIndex = 90;
this.solvencyCurrencyTextBox90.ColName = "R0150C0040";
this.solvencyCurrencyTextBox90.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox91
//
this.solvencyCurrencyTextBox91.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox91.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox91.Location = new System.Drawing.Point(331,103);
this.solvencyCurrencyTextBox91.Name = "solvencyCurrencyTextBox91";
this.solvencyCurrencyTextBox91.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox91.TabIndex = 91;
this.solvencyCurrencyTextBox91.ColName = "R0150C0050";
this.solvencyCurrencyTextBox91.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox92
//
this.solvencyCurrencyTextBox92.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox92.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox92.Location = new System.Drawing.Point(438,103);
this.solvencyCurrencyTextBox92.Name = "solvencyCurrencyTextBox92";
this.solvencyCurrencyTextBox92.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox92.TabIndex = 92;
this.solvencyCurrencyTextBox92.ColName = "R0150C0060";
this.solvencyCurrencyTextBox92.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox93
//
this.solvencyCurrencyTextBox93.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox93.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox93.Location = new System.Drawing.Point(545,103);
this.solvencyCurrencyTextBox93.Name = "solvencyCurrencyTextBox93";
this.solvencyCurrencyTextBox93.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox93.TabIndex = 93;
this.solvencyCurrencyTextBox93.ColName = "R0150C0070";
this.solvencyCurrencyTextBox93.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox94
//
this.solvencyCurrencyTextBox94.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox94.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox94.Location = new System.Drawing.Point(652,103);
this.solvencyCurrencyTextBox94.Name = "solvencyCurrencyTextBox94";
this.solvencyCurrencyTextBox94.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox94.TabIndex = 94;
this.solvencyCurrencyTextBox94.ColName = "R0150C0080";
this.solvencyCurrencyTextBox94.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox95
//
this.solvencyCurrencyTextBox95.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox95.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox95.Location = new System.Drawing.Point(759,103);
this.solvencyCurrencyTextBox95.Name = "solvencyCurrencyTextBox95";
this.solvencyCurrencyTextBox95.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox95.TabIndex = 95;
this.solvencyCurrencyTextBox95.ColName = "R0150C0090";
this.solvencyCurrencyTextBox95.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox96
//
this.solvencyCurrencyTextBox96.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox96.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox96.Location = new System.Drawing.Point(10,123);
this.solvencyCurrencyTextBox96.Name = "solvencyCurrencyTextBox96";
this.solvencyCurrencyTextBox96.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox96.TabIndex = 96;
this.solvencyCurrencyTextBox96.ColName = "R0160C0020";
this.solvencyCurrencyTextBox96.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// SolvencyDataComboBox97
//
this.SolvencyDataComboBox97.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox97.Location = new System.Drawing.Point(117,123);
this.SolvencyDataComboBox97.Name = "SolvencyDataComboBox97";
this.SolvencyDataComboBox97.Size = new System.Drawing.Size(100, 13);
this.SolvencyDataComboBox97.TabIndex = 97;
this.SolvencyDataComboBox97.ColName = "R0160C0030";
this.SolvencyDataComboBox97.AxisID = 1113;
this.SolvencyDataComboBox97.OrdinateID = 5960;
this.SolvencyDataComboBox97.StartOrder = 0;
this.SolvencyDataComboBox97.NextOrder = 0;
//
// solvencyCurrencyTextBox98
//
this.solvencyCurrencyTextBox98.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox98.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox98.Location = new System.Drawing.Point(224,123);
this.solvencyCurrencyTextBox98.Name = "solvencyCurrencyTextBox98";
this.solvencyCurrencyTextBox98.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox98.TabIndex = 98;
this.solvencyCurrencyTextBox98.ColName = "R0160C0040";
this.solvencyCurrencyTextBox98.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox99
//
this.solvencyCurrencyTextBox99.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox99.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox99.Location = new System.Drawing.Point(331,123);
this.solvencyCurrencyTextBox99.Name = "solvencyCurrencyTextBox99";
this.solvencyCurrencyTextBox99.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox99.TabIndex = 99;
this.solvencyCurrencyTextBox99.ColName = "R0160C0050";
this.solvencyCurrencyTextBox99.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox100
//
this.solvencyCurrencyTextBox100.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox100.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox100.Location = new System.Drawing.Point(438,123);
this.solvencyCurrencyTextBox100.Name = "solvencyCurrencyTextBox100";
this.solvencyCurrencyTextBox100.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox100.TabIndex = 100;
this.solvencyCurrencyTextBox100.ColName = "R0160C0060";
this.solvencyCurrencyTextBox100.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox101
//
this.solvencyCurrencyTextBox101.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox101.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox101.Location = new System.Drawing.Point(545,123);
this.solvencyCurrencyTextBox101.Name = "solvencyCurrencyTextBox101";
this.solvencyCurrencyTextBox101.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox101.TabIndex = 101;
this.solvencyCurrencyTextBox101.ColName = "R0160C0070";
this.solvencyCurrencyTextBox101.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox102
//
this.solvencyCurrencyTextBox102.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox102.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox102.Location = new System.Drawing.Point(652,123);
this.solvencyCurrencyTextBox102.Name = "solvencyCurrencyTextBox102";
this.solvencyCurrencyTextBox102.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox102.TabIndex = 102;
this.solvencyCurrencyTextBox102.ColName = "R0160C0080";
this.solvencyCurrencyTextBox102.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox103
//
this.solvencyCurrencyTextBox103.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox103.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox103.Location = new System.Drawing.Point(759,123);
this.solvencyCurrencyTextBox103.Name = "solvencyCurrencyTextBox103";
this.solvencyCurrencyTextBox103.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox103.TabIndex = 103;
this.solvencyCurrencyTextBox103.ColName = "R0160C0090";
this.solvencyCurrencyTextBox103.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox104
//
this.solvencyCurrencyTextBox104.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox104.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox104.Location = new System.Drawing.Point(10,143);
this.solvencyCurrencyTextBox104.Name = "solvencyCurrencyTextBox104";
this.solvencyCurrencyTextBox104.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox104.TabIndex = 104;
this.solvencyCurrencyTextBox104.ColName = "R0170C0020";
this.solvencyCurrencyTextBox104.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// SolvencyDataComboBox105
//
this.SolvencyDataComboBox105.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox105.Location = new System.Drawing.Point(117,143);
this.SolvencyDataComboBox105.Name = "SolvencyDataComboBox105";
this.SolvencyDataComboBox105.Size = new System.Drawing.Size(100, 13);
this.SolvencyDataComboBox105.TabIndex = 105;
this.SolvencyDataComboBox105.ColName = "R0170C0030";
this.SolvencyDataComboBox105.AxisID = 1113;
this.SolvencyDataComboBox105.OrdinateID = 5960;
this.SolvencyDataComboBox105.StartOrder = 0;
this.SolvencyDataComboBox105.NextOrder = 0;
//
// solvencyCurrencyTextBox106
//
this.solvencyCurrencyTextBox106.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox106.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox106.Location = new System.Drawing.Point(224,143);
this.solvencyCurrencyTextBox106.Name = "solvencyCurrencyTextBox106";
this.solvencyCurrencyTextBox106.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox106.TabIndex = 106;
this.solvencyCurrencyTextBox106.ColName = "R0170C0040";
this.solvencyCurrencyTextBox106.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox107
//
this.solvencyCurrencyTextBox107.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox107.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox107.Location = new System.Drawing.Point(331,143);
this.solvencyCurrencyTextBox107.Name = "solvencyCurrencyTextBox107";
this.solvencyCurrencyTextBox107.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox107.TabIndex = 107;
this.solvencyCurrencyTextBox107.ColName = "R0170C0050";
this.solvencyCurrencyTextBox107.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox108
//
this.solvencyCurrencyTextBox108.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox108.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox108.Location = new System.Drawing.Point(438,143);
this.solvencyCurrencyTextBox108.Name = "solvencyCurrencyTextBox108";
this.solvencyCurrencyTextBox108.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox108.TabIndex = 108;
this.solvencyCurrencyTextBox108.ColName = "R0170C0060";
this.solvencyCurrencyTextBox108.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox109
//
this.solvencyCurrencyTextBox109.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox109.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox109.Location = new System.Drawing.Point(545,143);
this.solvencyCurrencyTextBox109.Name = "solvencyCurrencyTextBox109";
this.solvencyCurrencyTextBox109.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox109.TabIndex = 109;
this.solvencyCurrencyTextBox109.ColName = "R0170C0070";
this.solvencyCurrencyTextBox109.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox110
//
this.solvencyCurrencyTextBox110.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox110.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox110.Location = new System.Drawing.Point(652,143);
this.solvencyCurrencyTextBox110.Name = "solvencyCurrencyTextBox110";
this.solvencyCurrencyTextBox110.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox110.TabIndex = 110;
this.solvencyCurrencyTextBox110.ColName = "R0170C0080";
this.solvencyCurrencyTextBox110.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox111
//
this.solvencyCurrencyTextBox111.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox111.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox111.Location = new System.Drawing.Point(759,143);
this.solvencyCurrencyTextBox111.Name = "solvencyCurrencyTextBox111";
this.solvencyCurrencyTextBox111.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox111.TabIndex = 111;
this.solvencyCurrencyTextBox111.ColName = "R0170C0090";
this.solvencyCurrencyTextBox111.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox112
//
this.solvencyCurrencyTextBox112.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox112.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox112.Location = new System.Drawing.Point(10,163);
this.solvencyCurrencyTextBox112.Name = "solvencyCurrencyTextBox112";
this.solvencyCurrencyTextBox112.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox112.TabIndex = 112;
this.solvencyCurrencyTextBox112.ColName = "R0180C0020";
this.solvencyCurrencyTextBox112.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// SolvencyDataComboBox113
//
this.SolvencyDataComboBox113.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox113.Location = new System.Drawing.Point(117,163);
this.SolvencyDataComboBox113.Name = "SolvencyDataComboBox113";
this.SolvencyDataComboBox113.Size = new System.Drawing.Size(100, 13);
this.SolvencyDataComboBox113.TabIndex = 113;
this.SolvencyDataComboBox113.ColName = "R0180C0030";
this.SolvencyDataComboBox113.AxisID = 1113;
this.SolvencyDataComboBox113.OrdinateID = 5960;
this.SolvencyDataComboBox113.StartOrder = 0;
this.SolvencyDataComboBox113.NextOrder = 0;
//
// solvencyCurrencyTextBox114
//
this.solvencyCurrencyTextBox114.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox114.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox114.Location = new System.Drawing.Point(224,163);
this.solvencyCurrencyTextBox114.Name = "solvencyCurrencyTextBox114";
this.solvencyCurrencyTextBox114.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox114.TabIndex = 114;
this.solvencyCurrencyTextBox114.ColName = "R0180C0040";
this.solvencyCurrencyTextBox114.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox115
//
this.solvencyCurrencyTextBox115.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox115.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox115.Location = new System.Drawing.Point(331,163);
this.solvencyCurrencyTextBox115.Name = "solvencyCurrencyTextBox115";
this.solvencyCurrencyTextBox115.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox115.TabIndex = 115;
this.solvencyCurrencyTextBox115.ColName = "R0180C0050";
this.solvencyCurrencyTextBox115.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox116
//
this.solvencyCurrencyTextBox116.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox116.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox116.Location = new System.Drawing.Point(438,163);
this.solvencyCurrencyTextBox116.Name = "solvencyCurrencyTextBox116";
this.solvencyCurrencyTextBox116.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox116.TabIndex = 116;
this.solvencyCurrencyTextBox116.ColName = "R0180C0060";
this.solvencyCurrencyTextBox116.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox117
//
this.solvencyCurrencyTextBox117.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox117.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox117.Location = new System.Drawing.Point(545,163);
this.solvencyCurrencyTextBox117.Name = "solvencyCurrencyTextBox117";
this.solvencyCurrencyTextBox117.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox117.TabIndex = 117;
this.solvencyCurrencyTextBox117.ColName = "R0180C0070";
this.solvencyCurrencyTextBox117.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox118
//
this.solvencyCurrencyTextBox118.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox118.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox118.Location = new System.Drawing.Point(652,163);
this.solvencyCurrencyTextBox118.Name = "solvencyCurrencyTextBox118";
this.solvencyCurrencyTextBox118.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox118.TabIndex = 118;
this.solvencyCurrencyTextBox118.ColName = "R0180C0080";
this.solvencyCurrencyTextBox118.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox119
//
this.solvencyCurrencyTextBox119.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox119.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox119.Location = new System.Drawing.Point(759,163);
this.solvencyCurrencyTextBox119.Name = "solvencyCurrencyTextBox119";
this.solvencyCurrencyTextBox119.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox119.TabIndex = 119;
this.solvencyCurrencyTextBox119.ColName = "R0180C0090";
this.solvencyCurrencyTextBox119.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox120
//
this.solvencyCurrencyTextBox120.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox120.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox120.Location = new System.Drawing.Point(10,183);
this.solvencyCurrencyTextBox120.Name = "solvencyCurrencyTextBox120";
this.solvencyCurrencyTextBox120.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox120.TabIndex = 120;
this.solvencyCurrencyTextBox120.ColName = "R0190C0020";
this.solvencyCurrencyTextBox120.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// SolvencyDataComboBox121
//
this.SolvencyDataComboBox121.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox121.Location = new System.Drawing.Point(117,183);
this.SolvencyDataComboBox121.Name = "SolvencyDataComboBox121";
this.SolvencyDataComboBox121.Size = new System.Drawing.Size(100, 13);
this.SolvencyDataComboBox121.TabIndex = 121;
this.SolvencyDataComboBox121.ColName = "R0190C0030";
this.SolvencyDataComboBox121.AxisID = 1113;
this.SolvencyDataComboBox121.OrdinateID = 5960;
this.SolvencyDataComboBox121.StartOrder = 0;
this.SolvencyDataComboBox121.NextOrder = 0;
//
// solvencyCurrencyTextBox122
//
this.solvencyCurrencyTextBox122.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox122.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox122.Location = new System.Drawing.Point(224,183);
this.solvencyCurrencyTextBox122.Name = "solvencyCurrencyTextBox122";
this.solvencyCurrencyTextBox122.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox122.TabIndex = 122;
this.solvencyCurrencyTextBox122.ColName = "R0190C0040";
this.solvencyCurrencyTextBox122.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox123
//
this.solvencyCurrencyTextBox123.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox123.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox123.Location = new System.Drawing.Point(331,183);
this.solvencyCurrencyTextBox123.Name = "solvencyCurrencyTextBox123";
this.solvencyCurrencyTextBox123.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox123.TabIndex = 123;
this.solvencyCurrencyTextBox123.ColName = "R0190C0050";
this.solvencyCurrencyTextBox123.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox124
//
this.solvencyCurrencyTextBox124.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox124.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox124.Location = new System.Drawing.Point(438,183);
this.solvencyCurrencyTextBox124.Name = "solvencyCurrencyTextBox124";
this.solvencyCurrencyTextBox124.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox124.TabIndex = 124;
this.solvencyCurrencyTextBox124.ColName = "R0190C0060";
this.solvencyCurrencyTextBox124.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox125
//
this.solvencyCurrencyTextBox125.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox125.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox125.Location = new System.Drawing.Point(545,183);
this.solvencyCurrencyTextBox125.Name = "solvencyCurrencyTextBox125";
this.solvencyCurrencyTextBox125.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox125.TabIndex = 125;
this.solvencyCurrencyTextBox125.ColName = "R0190C0070";
this.solvencyCurrencyTextBox125.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox126
//
this.solvencyCurrencyTextBox126.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox126.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox126.Location = new System.Drawing.Point(652,183);
this.solvencyCurrencyTextBox126.Name = "solvencyCurrencyTextBox126";
this.solvencyCurrencyTextBox126.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox126.TabIndex = 126;
this.solvencyCurrencyTextBox126.ColName = "R0190C0080";
this.solvencyCurrencyTextBox126.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox127
//
this.solvencyCurrencyTextBox127.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox127.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox127.Location = new System.Drawing.Point(759,183);
this.solvencyCurrencyTextBox127.Name = "solvencyCurrencyTextBox127";
this.solvencyCurrencyTextBox127.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox127.TabIndex = 127;
this.solvencyCurrencyTextBox127.ColName = "R0190C0090";
this.solvencyCurrencyTextBox127.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox128
//
this.solvencyCurrencyTextBox128.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox128.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox128.Location = new System.Drawing.Point(10,203);
this.solvencyCurrencyTextBox128.Name = "solvencyCurrencyTextBox128";
this.solvencyCurrencyTextBox128.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox128.TabIndex = 128;
this.solvencyCurrencyTextBox128.ColName = "R0200C0020";
this.solvencyCurrencyTextBox128.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// SolvencyDataComboBox129
//
this.SolvencyDataComboBox129.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox129.Location = new System.Drawing.Point(117,203);
this.SolvencyDataComboBox129.Name = "SolvencyDataComboBox129";
this.SolvencyDataComboBox129.Size = new System.Drawing.Size(100, 13);
this.SolvencyDataComboBox129.TabIndex = 129;
this.SolvencyDataComboBox129.ColName = "R0200C0030";
this.SolvencyDataComboBox129.AxisID = 1113;
this.SolvencyDataComboBox129.OrdinateID = 5960;
this.SolvencyDataComboBox129.StartOrder = 0;
this.SolvencyDataComboBox129.NextOrder = 0;
//
// solvencyCurrencyTextBox130
//
this.solvencyCurrencyTextBox130.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox130.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox130.Location = new System.Drawing.Point(224,203);
this.solvencyCurrencyTextBox130.Name = "solvencyCurrencyTextBox130";
this.solvencyCurrencyTextBox130.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox130.TabIndex = 130;
this.solvencyCurrencyTextBox130.ColName = "R0200C0040";
this.solvencyCurrencyTextBox130.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox131
//
this.solvencyCurrencyTextBox131.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox131.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox131.Location = new System.Drawing.Point(331,203);
this.solvencyCurrencyTextBox131.Name = "solvencyCurrencyTextBox131";
this.solvencyCurrencyTextBox131.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox131.TabIndex = 131;
this.solvencyCurrencyTextBox131.ColName = "R0200C0050";
this.solvencyCurrencyTextBox131.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox132
//
this.solvencyCurrencyTextBox132.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox132.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox132.Location = new System.Drawing.Point(438,203);
this.solvencyCurrencyTextBox132.Name = "solvencyCurrencyTextBox132";
this.solvencyCurrencyTextBox132.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox132.TabIndex = 132;
this.solvencyCurrencyTextBox132.ColName = "R0200C0060";
this.solvencyCurrencyTextBox132.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox133
//
this.solvencyCurrencyTextBox133.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox133.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox133.Location = new System.Drawing.Point(545,203);
this.solvencyCurrencyTextBox133.Name = "solvencyCurrencyTextBox133";
this.solvencyCurrencyTextBox133.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox133.TabIndex = 133;
this.solvencyCurrencyTextBox133.ColName = "R0200C0070";
this.solvencyCurrencyTextBox133.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox134
//
this.solvencyCurrencyTextBox134.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox134.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox134.Location = new System.Drawing.Point(652,203);
this.solvencyCurrencyTextBox134.Name = "solvencyCurrencyTextBox134";
this.solvencyCurrencyTextBox134.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox134.TabIndex = 134;
this.solvencyCurrencyTextBox134.ColName = "R0200C0080";
this.solvencyCurrencyTextBox134.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox135
//
this.solvencyCurrencyTextBox135.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox135.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox135.Location = new System.Drawing.Point(759,203);
this.solvencyCurrencyTextBox135.Name = "solvencyCurrencyTextBox135";
this.solvencyCurrencyTextBox135.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox135.TabIndex = 135;
this.solvencyCurrencyTextBox135.ColName = "R0200C0090";
this.solvencyCurrencyTextBox135.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox136
//
this.solvencyCurrencyTextBox136.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox136.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox136.Location = new System.Drawing.Point(10,223);
this.solvencyCurrencyTextBox136.Name = "solvencyCurrencyTextBox136";
this.solvencyCurrencyTextBox136.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox136.TabIndex = 136;
this.solvencyCurrencyTextBox136.ColName = "R0210C0020";
this.solvencyCurrencyTextBox136.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// SolvencyDataComboBox137
//
this.SolvencyDataComboBox137.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox137.Location = new System.Drawing.Point(117,223);
this.SolvencyDataComboBox137.Name = "SolvencyDataComboBox137";
this.SolvencyDataComboBox137.Size = new System.Drawing.Size(100, 13);
this.SolvencyDataComboBox137.TabIndex = 137;
this.SolvencyDataComboBox137.ColName = "R0210C0030";
this.SolvencyDataComboBox137.AxisID = 1113;
this.SolvencyDataComboBox137.OrdinateID = 5960;
this.SolvencyDataComboBox137.StartOrder = 0;
this.SolvencyDataComboBox137.NextOrder = 0;
//
// solvencyCurrencyTextBox138
//
this.solvencyCurrencyTextBox138.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox138.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox138.Location = new System.Drawing.Point(224,223);
this.solvencyCurrencyTextBox138.Name = "solvencyCurrencyTextBox138";
this.solvencyCurrencyTextBox138.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox138.TabIndex = 138;
this.solvencyCurrencyTextBox138.ColName = "R0210C0040";
this.solvencyCurrencyTextBox138.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox139
//
this.solvencyCurrencyTextBox139.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox139.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox139.Location = new System.Drawing.Point(331,223);
this.solvencyCurrencyTextBox139.Name = "solvencyCurrencyTextBox139";
this.solvencyCurrencyTextBox139.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox139.TabIndex = 139;
this.solvencyCurrencyTextBox139.ColName = "R0210C0050";
this.solvencyCurrencyTextBox139.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox140
//
this.solvencyCurrencyTextBox140.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox140.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox140.Location = new System.Drawing.Point(438,223);
this.solvencyCurrencyTextBox140.Name = "solvencyCurrencyTextBox140";
this.solvencyCurrencyTextBox140.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox140.TabIndex = 140;
this.solvencyCurrencyTextBox140.ColName = "R0210C0060";
this.solvencyCurrencyTextBox140.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox141
//
this.solvencyCurrencyTextBox141.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox141.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox141.Location = new System.Drawing.Point(545,223);
this.solvencyCurrencyTextBox141.Name = "solvencyCurrencyTextBox141";
this.solvencyCurrencyTextBox141.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox141.TabIndex = 141;
this.solvencyCurrencyTextBox141.ColName = "R0210C0070";
this.solvencyCurrencyTextBox141.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox142
//
this.solvencyCurrencyTextBox142.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox142.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox142.Location = new System.Drawing.Point(652,223);
this.solvencyCurrencyTextBox142.Name = "solvencyCurrencyTextBox142";
this.solvencyCurrencyTextBox142.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox142.TabIndex = 142;
this.solvencyCurrencyTextBox142.ColName = "R0210C0080";
this.solvencyCurrencyTextBox142.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox143
//
this.solvencyCurrencyTextBox143.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox143.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox143.Location = new System.Drawing.Point(759,223);
this.solvencyCurrencyTextBox143.Name = "solvencyCurrencyTextBox143";
this.solvencyCurrencyTextBox143.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox143.TabIndex = 143;
this.solvencyCurrencyTextBox143.ColName = "R0210C0090";
this.solvencyCurrencyTextBox143.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox144
//
this.solvencyCurrencyTextBox144.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox144.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox144.Location = new System.Drawing.Point(10,243);
this.solvencyCurrencyTextBox144.Name = "solvencyCurrencyTextBox144";
this.solvencyCurrencyTextBox144.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox144.TabIndex = 144;
this.solvencyCurrencyTextBox144.ColName = "R0220C0020";
this.solvencyCurrencyTextBox144.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox144.Enabled = false;
this.solvencyCurrencyTextBox144.BackColor = System.Drawing.Color.Gray;
//
// SolvencyDataComboBox145
//
this.SolvencyDataComboBox145.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox145.Location = new System.Drawing.Point(117,243);
this.SolvencyDataComboBox145.Name = "SolvencyDataComboBox145";
this.SolvencyDataComboBox145.Size = new System.Drawing.Size(100, 13);
this.SolvencyDataComboBox145.TabIndex = 145;
this.SolvencyDataComboBox145.ColName = "R0220C0030";
this.SolvencyDataComboBox145.AxisID = 1113;
this.SolvencyDataComboBox145.OrdinateID = 5960;
this.SolvencyDataComboBox145.StartOrder = 0;
this.SolvencyDataComboBox145.NextOrder = 0;
this.SolvencyDataComboBox145.Enabled = false;
this.SolvencyDataComboBox145.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox146
//
this.solvencyCurrencyTextBox146.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox146.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox146.Location = new System.Drawing.Point(224,243);
this.solvencyCurrencyTextBox146.Name = "solvencyCurrencyTextBox146";
this.solvencyCurrencyTextBox146.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox146.TabIndex = 146;
this.solvencyCurrencyTextBox146.ColName = "R0220C0040";
this.solvencyCurrencyTextBox146.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox146.Enabled = false;
this.solvencyCurrencyTextBox146.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox147
//
this.solvencyCurrencyTextBox147.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox147.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox147.Location = new System.Drawing.Point(331,243);
this.solvencyCurrencyTextBox147.Name = "solvencyCurrencyTextBox147";
this.solvencyCurrencyTextBox147.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox147.TabIndex = 147;
this.solvencyCurrencyTextBox147.ColName = "R0220C0050";
this.solvencyCurrencyTextBox147.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox147.Enabled = false;
this.solvencyCurrencyTextBox147.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox148
//
this.solvencyCurrencyTextBox148.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox148.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox148.Location = new System.Drawing.Point(438,243);
this.solvencyCurrencyTextBox148.Name = "solvencyCurrencyTextBox148";
this.solvencyCurrencyTextBox148.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox148.TabIndex = 148;
this.solvencyCurrencyTextBox148.ColName = "R0220C0060";
this.solvencyCurrencyTextBox148.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox148.Enabled = false;
this.solvencyCurrencyTextBox148.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox149
//
this.solvencyCurrencyTextBox149.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox149.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox149.Location = new System.Drawing.Point(545,243);
this.solvencyCurrencyTextBox149.Name = "solvencyCurrencyTextBox149";
this.solvencyCurrencyTextBox149.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox149.TabIndex = 149;
this.solvencyCurrencyTextBox149.ColName = "R0220C0070";
this.solvencyCurrencyTextBox149.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox149.Enabled = false;
this.solvencyCurrencyTextBox149.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox150
//
this.solvencyCurrencyTextBox150.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox150.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox150.Location = new System.Drawing.Point(652,243);
this.solvencyCurrencyTextBox150.Name = "solvencyCurrencyTextBox150";
this.solvencyCurrencyTextBox150.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox150.TabIndex = 150;
this.solvencyCurrencyTextBox150.ColName = "R0220C0080";
this.solvencyCurrencyTextBox150.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox150.Enabled = false;
this.solvencyCurrencyTextBox150.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox151
//
this.solvencyCurrencyTextBox151.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox151.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox151.Location = new System.Drawing.Point(759,243);
this.solvencyCurrencyTextBox151.Name = "solvencyCurrencyTextBox151";
this.solvencyCurrencyTextBox151.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox151.TabIndex = 151;
this.solvencyCurrencyTextBox151.ColName = "R0220C0090";
this.solvencyCurrencyTextBox151.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox152
//
this.solvencyCurrencyTextBox152.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox152.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox152.Location = new System.Drawing.Point(10,263);
this.solvencyCurrencyTextBox152.Name = "solvencyCurrencyTextBox152";
this.solvencyCurrencyTextBox152.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox152.TabIndex = 152;
this.solvencyCurrencyTextBox152.ColName = "R0230C0020";
this.solvencyCurrencyTextBox152.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// SolvencyDataComboBox153
//
this.SolvencyDataComboBox153.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox153.Location = new System.Drawing.Point(117,263);
this.SolvencyDataComboBox153.Name = "SolvencyDataComboBox153";
this.SolvencyDataComboBox153.Size = new System.Drawing.Size(100, 13);
this.SolvencyDataComboBox153.TabIndex = 153;
this.SolvencyDataComboBox153.ColName = "R0230C0030";
this.SolvencyDataComboBox153.AxisID = 1113;
this.SolvencyDataComboBox153.OrdinateID = 5960;
this.SolvencyDataComboBox153.StartOrder = 0;
this.SolvencyDataComboBox153.NextOrder = 0;
this.SolvencyDataComboBox153.Enabled = false;
this.SolvencyDataComboBox153.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox154
//
this.solvencyCurrencyTextBox154.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox154.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox154.Location = new System.Drawing.Point(224,263);
this.solvencyCurrencyTextBox154.Name = "solvencyCurrencyTextBox154";
this.solvencyCurrencyTextBox154.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox154.TabIndex = 154;
this.solvencyCurrencyTextBox154.ColName = "R0230C0040";
this.solvencyCurrencyTextBox154.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox154.Enabled = false;
this.solvencyCurrencyTextBox154.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox155
//
this.solvencyCurrencyTextBox155.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox155.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox155.Location = new System.Drawing.Point(331,263);
this.solvencyCurrencyTextBox155.Name = "solvencyCurrencyTextBox155";
this.solvencyCurrencyTextBox155.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox155.TabIndex = 155;
this.solvencyCurrencyTextBox155.ColName = "R0230C0050";
this.solvencyCurrencyTextBox155.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox155.Enabled = false;
this.solvencyCurrencyTextBox155.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox156
//
this.solvencyCurrencyTextBox156.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox156.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox156.Location = new System.Drawing.Point(438,263);
this.solvencyCurrencyTextBox156.Name = "solvencyCurrencyTextBox156";
this.solvencyCurrencyTextBox156.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox156.TabIndex = 156;
this.solvencyCurrencyTextBox156.ColName = "R0230C0060";
this.solvencyCurrencyTextBox156.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox156.Enabled = false;
this.solvencyCurrencyTextBox156.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox157
//
this.solvencyCurrencyTextBox157.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox157.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox157.Location = new System.Drawing.Point(545,263);
this.solvencyCurrencyTextBox157.Name = "solvencyCurrencyTextBox157";
this.solvencyCurrencyTextBox157.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox157.TabIndex = 157;
this.solvencyCurrencyTextBox157.ColName = "R0230C0070";
this.solvencyCurrencyTextBox157.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox157.Enabled = false;
this.solvencyCurrencyTextBox157.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox158
//
this.solvencyCurrencyTextBox158.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox158.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox158.Location = new System.Drawing.Point(652,263);
this.solvencyCurrencyTextBox158.Name = "solvencyCurrencyTextBox158";
this.solvencyCurrencyTextBox158.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox158.TabIndex = 158;
this.solvencyCurrencyTextBox158.ColName = "R0230C0080";
this.solvencyCurrencyTextBox158.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox158.Enabled = false;
this.solvencyCurrencyTextBox158.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox159
//
this.solvencyCurrencyTextBox159.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox159.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox159.Location = new System.Drawing.Point(759,263);
this.solvencyCurrencyTextBox159.Name = "solvencyCurrencyTextBox159";
this.solvencyCurrencyTextBox159.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox159.TabIndex = 159;
this.solvencyCurrencyTextBox159.ColName = "R0230C0090";
this.solvencyCurrencyTextBox159.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox159.Enabled = false;
this.solvencyCurrencyTextBox159.BackColor = System.Drawing.Color.Gray;
//
// splitContainerColTitles
//
this.splitContainerColTitles.Dock = System.Windows.Forms.DockStyle.Fill;
this.splitContainerColTitles.Location = new System.Drawing.Point(0,0);
this.splitContainerColTitles.Name = "splitContainerColTitles";
this.splitContainerColTitles.Orientation = System.Windows.Forms.Orientation.Vertical;
this.splitContainerColTitles.Panel1MinSize = 0;
//
// splitContainerColTitles.Panel1
//
//
// splitContainerColTitles.Panel2
//
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel0);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel1);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel2);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel3);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel4);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel5);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel6);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel7);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel8);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel9);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel10);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel11);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel12);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel13);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel14);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel15);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel16);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel17);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel18);
this.splitContainerColTitles.Size = new System.Drawing.Size(1249, 381);
this.splitContainerColTitles.SplitterDistance = 276;
//
// splitContainerRowTitles
//
this.splitContainerRowTitles.Dock = System.Windows.Forms.DockStyle.Fill;
this.splitContainerRowTitles.Location = new System.Drawing.Point(0,0);
this.splitContainerRowTitles.Name = "splitContainerRowTitles";
this.splitContainerRowTitles.Orientation = System.Windows.Forms.Orientation.Vertical;
this.splitContainerRowTitles.Panel1MinSize = 0;
//
// splitContainerRowTitles.Panel1
//
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel19);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel20);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel21);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel22);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel23);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel24);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel25);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel26);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel27);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel28);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel29);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel30);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel31);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel32);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel33);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel34);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel35);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel36);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel37);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel38);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel39);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel40);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel41);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel42);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel43);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel44);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel45);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel46);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel47);
//
// splitContainerRowTitles.Panel2
//
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox48);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox49);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox50);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox51);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox52);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox53);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox54);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox55);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox56);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox57);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox58);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox59);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox60);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox61);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox62);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox63);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox64);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox65);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox66);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox67);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox68);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox69);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox70);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox71);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox72);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox73);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox74);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox75);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox76);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox77);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox78);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox79);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox80);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox81);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox82);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox83);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox84);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox85);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox86);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox87);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox88);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox89);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox90);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox91);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox92);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox93);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox94);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox95);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox96);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox97);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox98);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox99);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox100);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox101);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox102);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox103);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox104);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox105);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox106);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox107);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox108);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox109);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox110);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox111);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox112);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox113);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox114);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox115);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox116);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox117);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox118);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox119);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox120);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox121);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox122);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox123);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox124);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox125);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox126);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox127);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox128);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox129);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox130);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox131);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox132);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox133);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox134);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox135);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox136);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox137);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox138);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox139);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox140);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox141);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox142);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox143);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox144);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox145);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox146);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox147);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox148);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox149);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox150);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox151);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox152);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox153);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox154);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox155);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox156);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox157);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox158);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox159);
this.splitContainerRowTitles.Panel2.AutoScroll = true;
this.splitContainerRowTitles.Size = new System.Drawing.Size(1249, 381);
this.splitContainerRowTitles.SplitterDistance = 276;
//
// spltMain
//
this.spltMain.Dock = System.Windows.Forms.DockStyle.Fill;
this.spltMain.Location = new System.Drawing.Point(0,0);
this.spltMain.Name = "spltMain";
this.spltMain.Orientation = System.Windows.Forms.Orientation.Horizontal;
this.spltMain.Panel1MinSize = 0;
//
// spltMain.Panel1
//
this.spltMain.Panel1.Controls.Add(this.splitContainerColTitles);
//
// spltMain.Panel2
//
this.spltMain.Panel2.Controls.Add(this.splitContainerRowTitles);
this.spltMain.Panel2.AutoScroll = true;
this.spltMain.Size = new System.Drawing.Size(1249, 496);
this.spltMain.SplitterDistance = 105;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F); 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font; 
this.Controls.Add(this.spltMain);
            this.Name = "S_26_05_04_01__sol2__2_0_1_ctrl"; 
            this.Size = new System.Drawing.Size(1249, 391); 
            this.Load += new System.EventHandler(this.BoundControl_Load);
            this.ResumeLayout(false); 
            this.PerformLayout(); 

      } 
private SolvencyLabel solvencyLabel0;
private SolvencyLabel solvencyLabel1;
private SolvencyLabel solvencyLabel2;
private SolvencyLabel solvencyLabel3;
private SolvencyLabel solvencyLabel4;
private SolvencyLabel solvencyLabel5;
private SolvencyLabel solvencyLabel6;
private SolvencyLabel solvencyLabel7;
private SolvencyLabel solvencyLabel8;
private SolvencyLabel solvencyLabel9;
private SolvencyLabel solvencyLabel10;
private SolvencyLabel solvencyLabel11;
private SolvencyLabel solvencyLabel12;
private SolvencyLabel solvencyLabel13;
private SolvencyLabel solvencyLabel14;
private SolvencyLabel solvencyLabel15;
private SolvencyLabel solvencyLabel16;
private SolvencyLabel solvencyLabel17;
private SolvencyLabel solvencyLabel18;
private SolvencyLabel solvencyLabel19;
private SolvencyLabel solvencyLabel20;
private SolvencyLabel solvencyLabel21;
private SolvencyLabel solvencyLabel22;
private SolvencyLabel solvencyLabel23;
private SolvencyLabel solvencyLabel24;
private SolvencyLabel solvencyLabel25;
private SolvencyLabel solvencyLabel26;
private SolvencyLabel solvencyLabel27;
private SolvencyLabel solvencyLabel28;
private SolvencyLabel solvencyLabel29;
private SolvencyLabel solvencyLabel30;
private SolvencyLabel solvencyLabel31;
private SolvencyLabel solvencyLabel32;
private SolvencyLabel solvencyLabel33;
private SolvencyLabel solvencyLabel34;
private SolvencyLabel solvencyLabel35;
private SolvencyLabel solvencyLabel36;
private SolvencyLabel solvencyLabel37;
private SolvencyLabel solvencyLabel38;
private SolvencyLabel solvencyLabel39;
private SolvencyLabel solvencyLabel40;
private SolvencyLabel solvencyLabel41;
private SolvencyLabel solvencyLabel42;
private SolvencyLabel solvencyLabel43;
private SolvencyLabel solvencyLabel44;
private SolvencyLabel solvencyLabel45;
private SolvencyLabel solvencyLabel46;
private SolvencyLabel solvencyLabel47;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox48;
private SolvencyDataComboBox SolvencyDataComboBox49;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox50;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox51;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox52;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox53;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox54;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox55;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox56;
private SolvencyDataComboBox SolvencyDataComboBox57;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox58;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox59;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox60;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox61;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox62;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox63;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox64;
private SolvencyDataComboBox SolvencyDataComboBox65;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox66;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox67;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox68;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox69;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox70;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox71;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox72;
private SolvencyDataComboBox SolvencyDataComboBox73;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox74;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox75;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox76;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox77;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox78;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox79;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox80;
private SolvencyDataComboBox SolvencyDataComboBox81;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox82;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox83;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox84;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox85;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox86;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox87;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox88;
private SolvencyDataComboBox SolvencyDataComboBox89;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox90;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox91;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox92;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox93;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox94;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox95;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox96;
private SolvencyDataComboBox SolvencyDataComboBox97;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox98;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox99;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox100;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox101;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox102;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox103;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox104;
private SolvencyDataComboBox SolvencyDataComboBox105;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox106;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox107;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox108;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox109;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox110;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox111;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox112;
private SolvencyDataComboBox SolvencyDataComboBox113;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox114;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox115;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox116;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox117;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox118;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox119;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox120;
private SolvencyDataComboBox SolvencyDataComboBox121;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox122;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox123;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox124;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox125;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox126;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox127;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox128;
private SolvencyDataComboBox SolvencyDataComboBox129;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox130;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox131;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox132;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox133;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox134;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox135;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox136;
private SolvencyDataComboBox SolvencyDataComboBox137;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox138;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox139;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox140;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox141;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox142;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox143;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox144;
private SolvencyDataComboBox SolvencyDataComboBox145;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox146;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox147;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox148;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox149;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox150;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox151;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox152;
private SolvencyDataComboBox SolvencyDataComboBox153;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox154;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox155;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox156;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox157;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox158;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox159;
private SolvencySplitContainer splitContainerColTitles;
private SolvencySplitContainer splitContainerRowTitles;
private SolvencySplitContainer spltMain;

   }
}

