using SolvencyII.Domain.ENumerators; 
using SolvencyII.UI.Shared.Controls; 

namespace SolvencyII.UI.UserControls 
{ 
   partial class SPV_02_01_20_02__sol2__2_0_1 
   { 
      private void InitializeComponent() 
      { 
            this.SuspendLayout(); 

            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F); 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font; 
            this.Name = "SPV_02_01_20_02__sol2__2_0_1"; 
            this.Size = new System.Drawing.Size(40, 140); 
            this.ResumeLayout(false); 
            this.PerformLayout(); 

      } 

   }
}

