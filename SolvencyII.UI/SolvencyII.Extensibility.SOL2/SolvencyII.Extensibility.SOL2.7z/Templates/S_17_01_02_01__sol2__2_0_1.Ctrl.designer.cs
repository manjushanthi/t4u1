using SolvencyII.Domain.ENumerators; 
using SolvencyII.UI.Shared.Controls; 

namespace SolvencyII.UI.UserControls 
{ 
   partial class S_17_01_02_01__sol2__2_0_1_ctrl 
   { 
      private void InitializeComponent() 
      { 
this.solvencyLabel0 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel1 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel2 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel3 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel4 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel5 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel6 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel7 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel8 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel9 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel10 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel11 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel12 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel13 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel14 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel15 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel16 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel17 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel18 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel19 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel20 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel21 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel22 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel23 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel24 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel25 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel26 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel27 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel28 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel29 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel30 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel31 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel32 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel33 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel34 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel35 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel36 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel37 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel38 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel39 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel40 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel41 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel42 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel43 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel44 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel45 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel46 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel47 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel48 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel49 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel50 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel51 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel52 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel53 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel54 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel55 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel56 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel57 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel58 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel59 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel60 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel61 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel62 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel63 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel64 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel65 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel66 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel67 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel68 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel69 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel70 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel71 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel72 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel73 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel74 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel75 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel76 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel77 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel78 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel79 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel80 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel81 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel82 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyCurrencyTextBox83 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox84 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox85 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox86 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox87 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox88 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox89 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox90 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox91 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox92 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox93 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox94 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox95 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox96 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox97 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox98 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox99 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox100 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox101 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox102 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox103 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox104 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox105 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox106 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox107 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox108 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox109 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox110 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox111 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox112 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox113 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox114 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox115 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox116 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox117 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox118 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox119 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox120 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox121 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox122 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox123 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox124 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox125 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox126 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox127 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox128 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox129 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox130 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox131 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox132 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox133 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox134 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox135 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox136 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox137 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox138 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox139 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox140 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox141 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox142 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox143 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox144 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox145 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox146 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox147 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox148 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox149 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox150 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox151 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox152 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox153 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox154 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox155 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox156 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox157 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox158 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox159 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox160 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox161 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox162 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox163 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox164 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox165 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox166 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox167 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox168 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox169 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox170 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox171 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox172 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox173 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox174 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox175 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox176 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox177 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox178 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox179 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox180 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox181 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox182 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox183 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox184 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox185 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox186 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox187 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox188 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox189 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox190 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox191 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox192 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox193 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox194 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox195 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox196 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox197 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox198 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox199 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox200 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox201 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox202 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox203 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox204 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox205 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox206 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox207 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox208 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox209 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox210 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox211 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox212 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox213 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox214 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox215 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox216 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox217 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox218 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox219 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox220 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox221 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox222 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox223 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox224 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox225 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox226 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox227 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox228 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox229 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox230 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox231 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox232 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox233 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox234 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox235 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox236 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox237 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox238 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox239 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox240 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox241 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox242 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox243 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox244 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox245 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox246 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox247 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox248 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox249 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox250 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox251 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox252 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox253 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox254 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox255 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox256 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox257 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox258 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox259 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox260 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox261 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox262 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox263 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox264 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox265 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox266 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox267 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox268 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox269 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox270 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox271 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox272 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox273 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox274 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox275 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox276 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox277 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox278 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox279 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox280 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox281 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox282 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox283 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox284 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox285 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox286 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox287 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox288 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox289 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox290 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox291 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox292 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox293 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox294 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox295 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox296 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox297 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox298 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox299 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox300 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox301 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox302 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox303 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox304 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox305 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox306 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox307 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox308 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox309 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox310 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox311 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox312 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox313 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox314 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox315 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox316 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox317 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox318 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox319 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox320 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox321 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox322 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox323 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox324 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox325 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox326 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox327 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox328 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox329 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox330 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox331 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox332 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox333 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox334 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox335 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox336 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox337 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox338 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox339 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox340 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox341 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox342 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox343 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox344 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox345 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox346 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox347 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox348 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox349 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox350 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox351 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox352 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox353 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox354 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox355 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox356 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox357 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox358 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox359 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox360 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox361 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox362 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox363 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox364 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox365 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox366 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox367 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox368 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox369 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox370 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox371 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.splitContainerColTitles = new SolvencyII.UI.Shared.Controls.SolvencySplitContainer();
this.splitContainerRowTitles = new SolvencyII.UI.Shared.Controls.SolvencySplitContainer();
this.spltMain = new SolvencyII.UI.Shared.Controls.SolvencySplitContainer();
            this.SuspendLayout(); 

//
// solvencyLabel0
//
this.solvencyLabel0.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel0.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel0.Location = new System.Drawing.Point(1722,10);
this.solvencyLabel0.Name = "solvencyLabel0";
this.solvencyLabel0.OrdinateID_Label = 3091;
this.solvencyLabel0.Size = new System.Drawing.Size(108, 65);
this.solvencyLabel0.TabIndex = 0;
this.solvencyLabel0.Text = "Total Non-Life obligation" ;
this.solvencyLabel0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel0.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel1
//
this.solvencyLabel1.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel1.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel1.Location = new System.Drawing.Point(1722,75);
this.solvencyLabel1.Name = "solvencyLabel1";
this.solvencyLabel1.OrdinateID_Label = 0;
this.solvencyLabel1.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel1.TabIndex = 1;
this.solvencyLabel1.Text = "C0180" ;
this.solvencyLabel1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel2
//
this.solvencyLabel2.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel2.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel2.Location = new System.Drawing.Point(1615,30);
this.solvencyLabel2.Name = "solvencyLabel2";
this.solvencyLabel2.OrdinateID_Label = 3090;
this.solvencyLabel2.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel2.TabIndex = 2;
this.solvencyLabel2.Text = "Non-proportional property reinsurance" ;
this.solvencyLabel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel3
//
this.solvencyLabel3.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel3.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel3.Location = new System.Drawing.Point(1615,75);
this.solvencyLabel3.Name = "solvencyLabel3";
this.solvencyLabel3.OrdinateID_Label = 0;
this.solvencyLabel3.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel3.TabIndex = 3;
this.solvencyLabel3.Text = "C0170" ;
this.solvencyLabel3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel4
//
this.solvencyLabel4.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel4.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel4.Location = new System.Drawing.Point(1508,30);
this.solvencyLabel4.Name = "solvencyLabel4";
this.solvencyLabel4.OrdinateID_Label = 3089;
this.solvencyLabel4.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel4.TabIndex = 4;
this.solvencyLabel4.Text = "Non-proportional marine, aviation and transport reinsurance" ;
this.solvencyLabel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel5
//
this.solvencyLabel5.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel5.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel5.Location = new System.Drawing.Point(1508,75);
this.solvencyLabel5.Name = "solvencyLabel5";
this.solvencyLabel5.OrdinateID_Label = 0;
this.solvencyLabel5.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel5.TabIndex = 5;
this.solvencyLabel5.Text = "C0160" ;
this.solvencyLabel5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel6
//
this.solvencyLabel6.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel6.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel6.Location = new System.Drawing.Point(1401,30);
this.solvencyLabel6.Name = "solvencyLabel6";
this.solvencyLabel6.OrdinateID_Label = 3088;
this.solvencyLabel6.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel6.TabIndex = 6;
this.solvencyLabel6.Text = "Non-proportional casualty reinsurance" ;
this.solvencyLabel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel6.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel7
//
this.solvencyLabel7.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel7.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel7.Location = new System.Drawing.Point(1401,75);
this.solvencyLabel7.Name = "solvencyLabel7";
this.solvencyLabel7.OrdinateID_Label = 0;
this.solvencyLabel7.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel7.TabIndex = 7;
this.solvencyLabel7.Text = "C0150" ;
this.solvencyLabel7.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel8
//
this.solvencyLabel8.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel8.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel8.Location = new System.Drawing.Point(1294,30);
this.solvencyLabel8.Name = "solvencyLabel8";
this.solvencyLabel8.OrdinateID_Label = 3087;
this.solvencyLabel8.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel8.TabIndex = 8;
this.solvencyLabel8.Text = "Non-proportional health reinsurance" ;
this.solvencyLabel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel8.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel9
//
this.solvencyLabel9.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel9.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel9.Location = new System.Drawing.Point(1294,75);
this.solvencyLabel9.Name = "solvencyLabel9";
this.solvencyLabel9.OrdinateID_Label = 0;
this.solvencyLabel9.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel9.TabIndex = 9;
this.solvencyLabel9.Text = "C0140" ;
this.solvencyLabel9.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel10
//
this.solvencyLabel10.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel10.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel10.Location = new System.Drawing.Point(1294,10);
this.solvencyLabel10.Name = "solvencyLabel10";
this.solvencyLabel10.OrdinateID_Label = 3086;
this.solvencyLabel10.Size = new System.Drawing.Size(429, 65);
this.solvencyLabel10.TabIndex = 10;
this.solvencyLabel10.Text = "Accepted non-proportional reinsurance" ;
this.solvencyLabel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel10.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel11
//
this.solvencyLabel11.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel11.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel11.Location = new System.Drawing.Point(1187,30);
this.solvencyLabel11.Name = "solvencyLabel11";
this.solvencyLabel11.OrdinateID_Label = 3085;
this.solvencyLabel11.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel11.TabIndex = 11;
this.solvencyLabel11.Text = "Miscellaneous financial loss" ;
this.solvencyLabel11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel11.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel12
//
this.solvencyLabel12.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel12.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel12.Location = new System.Drawing.Point(1187,75);
this.solvencyLabel12.Name = "solvencyLabel12";
this.solvencyLabel12.OrdinateID_Label = 0;
this.solvencyLabel12.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel12.TabIndex = 12;
this.solvencyLabel12.Text = "C0130" ;
this.solvencyLabel12.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel13
//
this.solvencyLabel13.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel13.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel13.Location = new System.Drawing.Point(1080,30);
this.solvencyLabel13.Name = "solvencyLabel13";
this.solvencyLabel13.OrdinateID_Label = 3084;
this.solvencyLabel13.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel13.TabIndex = 13;
this.solvencyLabel13.Text = "Assistance" ;
this.solvencyLabel13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel13.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel14
//
this.solvencyLabel14.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel14.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel14.Location = new System.Drawing.Point(1080,75);
this.solvencyLabel14.Name = "solvencyLabel14";
this.solvencyLabel14.OrdinateID_Label = 0;
this.solvencyLabel14.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel14.TabIndex = 14;
this.solvencyLabel14.Text = "C0120" ;
this.solvencyLabel14.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel15
//
this.solvencyLabel15.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel15.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel15.Location = new System.Drawing.Point(973,30);
this.solvencyLabel15.Name = "solvencyLabel15";
this.solvencyLabel15.OrdinateID_Label = 3083;
this.solvencyLabel15.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel15.TabIndex = 15;
this.solvencyLabel15.Text = "Legal expenses insurance" ;
this.solvencyLabel15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel15.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel16
//
this.solvencyLabel16.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel16.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel16.Location = new System.Drawing.Point(973,75);
this.solvencyLabel16.Name = "solvencyLabel16";
this.solvencyLabel16.OrdinateID_Label = 0;
this.solvencyLabel16.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel16.TabIndex = 16;
this.solvencyLabel16.Text = "C0110" ;
this.solvencyLabel16.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel17
//
this.solvencyLabel17.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel17.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel17.Location = new System.Drawing.Point(866,30);
this.solvencyLabel17.Name = "solvencyLabel17";
this.solvencyLabel17.OrdinateID_Label = 3082;
this.solvencyLabel17.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel17.TabIndex = 17;
this.solvencyLabel17.Text = "Credit and suretyship insurance" ;
this.solvencyLabel17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel17.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel18
//
this.solvencyLabel18.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel18.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel18.Location = new System.Drawing.Point(866,75);
this.solvencyLabel18.Name = "solvencyLabel18";
this.solvencyLabel18.OrdinateID_Label = 0;
this.solvencyLabel18.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel18.TabIndex = 18;
this.solvencyLabel18.Text = "C0100" ;
this.solvencyLabel18.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel19
//
this.solvencyLabel19.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel19.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel19.Location = new System.Drawing.Point(759,30);
this.solvencyLabel19.Name = "solvencyLabel19";
this.solvencyLabel19.OrdinateID_Label = 3081;
this.solvencyLabel19.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel19.TabIndex = 19;
this.solvencyLabel19.Text = "General liability insurance" ;
this.solvencyLabel19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel19.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel20
//
this.solvencyLabel20.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel20.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel20.Location = new System.Drawing.Point(759,75);
this.solvencyLabel20.Name = "solvencyLabel20";
this.solvencyLabel20.OrdinateID_Label = 0;
this.solvencyLabel20.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel20.TabIndex = 20;
this.solvencyLabel20.Text = "C0090" ;
this.solvencyLabel20.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel21
//
this.solvencyLabel21.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel21.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel21.Location = new System.Drawing.Point(652,30);
this.solvencyLabel21.Name = "solvencyLabel21";
this.solvencyLabel21.OrdinateID_Label = 3080;
this.solvencyLabel21.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel21.TabIndex = 21;
this.solvencyLabel21.Text = "Fire and other damage to property insurance" ;
this.solvencyLabel21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel21.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel22
//
this.solvencyLabel22.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel22.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel22.Location = new System.Drawing.Point(652,75);
this.solvencyLabel22.Name = "solvencyLabel22";
this.solvencyLabel22.OrdinateID_Label = 0;
this.solvencyLabel22.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel22.TabIndex = 22;
this.solvencyLabel22.Text = "C0080" ;
this.solvencyLabel22.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel23
//
this.solvencyLabel23.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel23.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel23.Location = new System.Drawing.Point(545,30);
this.solvencyLabel23.Name = "solvencyLabel23";
this.solvencyLabel23.OrdinateID_Label = 3079;
this.solvencyLabel23.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel23.TabIndex = 23;
this.solvencyLabel23.Text = "Marine, aviation and transport insurance" ;
this.solvencyLabel23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel23.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel24
//
this.solvencyLabel24.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel24.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel24.Location = new System.Drawing.Point(545,75);
this.solvencyLabel24.Name = "solvencyLabel24";
this.solvencyLabel24.OrdinateID_Label = 0;
this.solvencyLabel24.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel24.TabIndex = 24;
this.solvencyLabel24.Text = "C0070" ;
this.solvencyLabel24.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel25
//
this.solvencyLabel25.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel25.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel25.Location = new System.Drawing.Point(438,30);
this.solvencyLabel25.Name = "solvencyLabel25";
this.solvencyLabel25.OrdinateID_Label = 3078;
this.solvencyLabel25.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel25.TabIndex = 25;
this.solvencyLabel25.Text = "Other motor insurance" ;
this.solvencyLabel25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel25.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel26
//
this.solvencyLabel26.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel26.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel26.Location = new System.Drawing.Point(438,75);
this.solvencyLabel26.Name = "solvencyLabel26";
this.solvencyLabel26.OrdinateID_Label = 0;
this.solvencyLabel26.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel26.TabIndex = 26;
this.solvencyLabel26.Text = "C0060" ;
this.solvencyLabel26.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel27
//
this.solvencyLabel27.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel27.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel27.Location = new System.Drawing.Point(331,30);
this.solvencyLabel27.Name = "solvencyLabel27";
this.solvencyLabel27.OrdinateID_Label = 3077;
this.solvencyLabel27.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel27.TabIndex = 27;
this.solvencyLabel27.Text = "Motor vehicle liability insurance" ;
this.solvencyLabel27.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel27.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel28
//
this.solvencyLabel28.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel28.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel28.Location = new System.Drawing.Point(331,75);
this.solvencyLabel28.Name = "solvencyLabel28";
this.solvencyLabel28.OrdinateID_Label = 0;
this.solvencyLabel28.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel28.TabIndex = 28;
this.solvencyLabel28.Text = "C0050" ;
this.solvencyLabel28.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel29
//
this.solvencyLabel29.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel29.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel29.Location = new System.Drawing.Point(224,30);
this.solvencyLabel29.Name = "solvencyLabel29";
this.solvencyLabel29.OrdinateID_Label = 3076;
this.solvencyLabel29.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel29.TabIndex = 29;
this.solvencyLabel29.Text = "Workers' compensation insurance" ;
this.solvencyLabel29.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel29.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel30
//
this.solvencyLabel30.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel30.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel30.Location = new System.Drawing.Point(224,75);
this.solvencyLabel30.Name = "solvencyLabel30";
this.solvencyLabel30.OrdinateID_Label = 0;
this.solvencyLabel30.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel30.TabIndex = 30;
this.solvencyLabel30.Text = "C0040" ;
this.solvencyLabel30.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel31
//
this.solvencyLabel31.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel31.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel31.Location = new System.Drawing.Point(117,30);
this.solvencyLabel31.Name = "solvencyLabel31";
this.solvencyLabel31.OrdinateID_Label = 3075;
this.solvencyLabel31.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel31.TabIndex = 31;
this.solvencyLabel31.Text = "Income protection insurance" ;
this.solvencyLabel31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel31.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel32
//
this.solvencyLabel32.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel32.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel32.Location = new System.Drawing.Point(117,75);
this.solvencyLabel32.Name = "solvencyLabel32";
this.solvencyLabel32.OrdinateID_Label = 0;
this.solvencyLabel32.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel32.TabIndex = 32;
this.solvencyLabel32.Text = "C0030" ;
this.solvencyLabel32.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel33
//
this.solvencyLabel33.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel33.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel33.Location = new System.Drawing.Point(10,30);
this.solvencyLabel33.Name = "solvencyLabel33";
this.solvencyLabel33.OrdinateID_Label = 3074;
this.solvencyLabel33.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel33.TabIndex = 33;
this.solvencyLabel33.Text = "Medical expense insurance" ;
this.solvencyLabel33.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel33.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel34
//
this.solvencyLabel34.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel34.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel34.Location = new System.Drawing.Point(10,75);
this.solvencyLabel34.Name = "solvencyLabel34";
this.solvencyLabel34.OrdinateID_Label = 0;
this.solvencyLabel34.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel34.TabIndex = 34;
this.solvencyLabel34.Text = "C0020" ;
this.solvencyLabel34.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel35
//
this.solvencyLabel35.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel35.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel35.Location = new System.Drawing.Point(10,10);
this.solvencyLabel35.Name = "solvencyLabel35";
this.solvencyLabel35.OrdinateID_Label = 3073;
this.solvencyLabel35.Size = new System.Drawing.Size(1285, 65);
this.solvencyLabel35.TabIndex = 35;
this.solvencyLabel35.Text = "Direct business and accepted proportional reinsurance" ;
this.solvencyLabel35.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel35.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel36
//
this.solvencyLabel36.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel36.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel36.Location = new System.Drawing.Point(10,3);
this.solvencyLabel36.Name = "solvencyLabel36";
this.solvencyLabel36.OrdinateID_Label = 3092;
this.solvencyLabel36.Size = new System.Drawing.Size(261, 15);
this.solvencyLabel36.TabIndex = 36;
this.solvencyLabel36.Text = "Technical provisions calculated as a whole" ;
this.solvencyLabel36.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel37
//
this.solvencyLabel37.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel37.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel37.Location = new System.Drawing.Point(285,3);
this.solvencyLabel37.Name = "solvencyLabel37";
this.solvencyLabel37.OrdinateID_Label = 0;
this.solvencyLabel37.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel37.TabIndex = 37;
this.solvencyLabel37.Text = "R0010" ;
this.solvencyLabel37.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel38
//
this.solvencyLabel38.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel38.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel38.Location = new System.Drawing.Point(10,23);
this.solvencyLabel38.Name = "solvencyLabel38";
this.solvencyLabel38.OrdinateID_Label = 3093;
this.solvencyLabel38.Size = new System.Drawing.Size(261, 45);
this.solvencyLabel38.TabIndex = 38;
this.solvencyLabel38.Text = "Total Recoverables from reinsurance/SPV and Finite Re after the adjustment for expected losses due to counterparty default associated to TP calculated as a whole" ;
this.solvencyLabel38.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel39
//
this.solvencyLabel39.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel39.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel39.Location = new System.Drawing.Point(285,23);
this.solvencyLabel39.Name = "solvencyLabel39";
this.solvencyLabel39.OrdinateID_Label = 0;
this.solvencyLabel39.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel39.TabIndex = 39;
this.solvencyLabel39.Text = "R0050" ;
this.solvencyLabel39.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel40
//
this.solvencyLabel40.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel40.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel40.Location = new System.Drawing.Point(10,71);
this.solvencyLabel40.Name = "solvencyLabel40";
this.solvencyLabel40.OrdinateID_Label = 3094;
this.solvencyLabel40.Size = new System.Drawing.Size(261, 30);
this.solvencyLabel40.TabIndex = 40;
this.solvencyLabel40.Text = "Technical provisions calculated as a sum of BE and RM" ;
this.solvencyLabel40.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel41
//
this.solvencyLabel41.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel41.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel41.Location = new System.Drawing.Point(285,71);
this.solvencyLabel41.Name = "solvencyLabel41";
this.solvencyLabel41.OrdinateID_Label = 0;
this.solvencyLabel41.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel41.TabIndex = 41;
this.solvencyLabel41.Text = "" ;
this.solvencyLabel41.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel42
//
this.solvencyLabel42.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel42.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel42.Location = new System.Drawing.Point(17,104);
this.solvencyLabel42.Name = "solvencyLabel42";
this.solvencyLabel42.OrdinateID_Label = 3095;
this.solvencyLabel42.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel42.TabIndex = 42;
this.solvencyLabel42.Text = "Best estimate" ;
this.solvencyLabel42.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel43
//
this.solvencyLabel43.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel43.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel43.Location = new System.Drawing.Point(285,104);
this.solvencyLabel43.Name = "solvencyLabel43";
this.solvencyLabel43.OrdinateID_Label = 0;
this.solvencyLabel43.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel43.TabIndex = 43;
this.solvencyLabel43.Text = "" ;
this.solvencyLabel43.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel44
//
this.solvencyLabel44.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel44.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel44.Location = new System.Drawing.Point(24,124);
this.solvencyLabel44.Name = "solvencyLabel44";
this.solvencyLabel44.OrdinateID_Label = 3096;
this.solvencyLabel44.Size = new System.Drawing.Size(247, 15);
this.solvencyLabel44.TabIndex = 44;
this.solvencyLabel44.Text = "Premium provisions" ;
this.solvencyLabel44.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel45
//
this.solvencyLabel45.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel45.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel45.Location = new System.Drawing.Point(285,124);
this.solvencyLabel45.Name = "solvencyLabel45";
this.solvencyLabel45.OrdinateID_Label = 0;
this.solvencyLabel45.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel45.TabIndex = 45;
this.solvencyLabel45.Text = "" ;
this.solvencyLabel45.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel46
//
this.solvencyLabel46.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel46.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel46.Location = new System.Drawing.Point(31,144);
this.solvencyLabel46.Name = "solvencyLabel46";
this.solvencyLabel46.OrdinateID_Label = 3097;
this.solvencyLabel46.Size = new System.Drawing.Size(240, 15);
this.solvencyLabel46.TabIndex = 46;
this.solvencyLabel46.Text = "Gross" ;
this.solvencyLabel46.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel47
//
this.solvencyLabel47.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel47.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel47.Location = new System.Drawing.Point(285,144);
this.solvencyLabel47.Name = "solvencyLabel47";
this.solvencyLabel47.OrdinateID_Label = 0;
this.solvencyLabel47.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel47.TabIndex = 47;
this.solvencyLabel47.Text = "R0060" ;
this.solvencyLabel47.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel48
//
this.solvencyLabel48.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel48.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel48.Location = new System.Drawing.Point(31,164);
this.solvencyLabel48.Name = "solvencyLabel48";
this.solvencyLabel48.OrdinateID_Label = 3098;
this.solvencyLabel48.Size = new System.Drawing.Size(240, 45);
this.solvencyLabel48.TabIndex = 48;
this.solvencyLabel48.Text = "Total recoverable from reinsurance/SPV and Finite Re after the adjustment for expected losses due to counterparty default" ;
this.solvencyLabel48.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel49
//
this.solvencyLabel49.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel49.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel49.Location = new System.Drawing.Point(285,164);
this.solvencyLabel49.Name = "solvencyLabel49";
this.solvencyLabel49.OrdinateID_Label = 0;
this.solvencyLabel49.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel49.TabIndex = 49;
this.solvencyLabel49.Text = "R0140" ;
this.solvencyLabel49.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel50
//
this.solvencyLabel50.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel50.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel50.Location = new System.Drawing.Point(31,212);
this.solvencyLabel50.Name = "solvencyLabel50";
this.solvencyLabel50.OrdinateID_Label = 3099;
this.solvencyLabel50.Size = new System.Drawing.Size(240, 15);
this.solvencyLabel50.TabIndex = 50;
this.solvencyLabel50.Text = "Net Best Estimate of Premium Provisions" ;
this.solvencyLabel50.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel51
//
this.solvencyLabel51.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel51.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel51.Location = new System.Drawing.Point(285,212);
this.solvencyLabel51.Name = "solvencyLabel51";
this.solvencyLabel51.OrdinateID_Label = 0;
this.solvencyLabel51.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel51.TabIndex = 51;
this.solvencyLabel51.Text = "R0150" ;
this.solvencyLabel51.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel52
//
this.solvencyLabel52.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel52.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel52.Location = new System.Drawing.Point(24,232);
this.solvencyLabel52.Name = "solvencyLabel52";
this.solvencyLabel52.OrdinateID_Label = 3100;
this.solvencyLabel52.Size = new System.Drawing.Size(247, 15);
this.solvencyLabel52.TabIndex = 52;
this.solvencyLabel52.Text = "Claims provisions" ;
this.solvencyLabel52.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel53
//
this.solvencyLabel53.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel53.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel53.Location = new System.Drawing.Point(285,232);
this.solvencyLabel53.Name = "solvencyLabel53";
this.solvencyLabel53.OrdinateID_Label = 0;
this.solvencyLabel53.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel53.TabIndex = 53;
this.solvencyLabel53.Text = "" ;
this.solvencyLabel53.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel54
//
this.solvencyLabel54.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel54.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel54.Location = new System.Drawing.Point(31,252);
this.solvencyLabel54.Name = "solvencyLabel54";
this.solvencyLabel54.OrdinateID_Label = 3101;
this.solvencyLabel54.Size = new System.Drawing.Size(240, 15);
this.solvencyLabel54.TabIndex = 54;
this.solvencyLabel54.Text = "Gross" ;
this.solvencyLabel54.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel55
//
this.solvencyLabel55.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel55.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel55.Location = new System.Drawing.Point(285,252);
this.solvencyLabel55.Name = "solvencyLabel55";
this.solvencyLabel55.OrdinateID_Label = 0;
this.solvencyLabel55.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel55.TabIndex = 55;
this.solvencyLabel55.Text = "R0160" ;
this.solvencyLabel55.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel56
//
this.solvencyLabel56.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel56.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel56.Location = new System.Drawing.Point(31,272);
this.solvencyLabel56.Name = "solvencyLabel56";
this.solvencyLabel56.OrdinateID_Label = 3102;
this.solvencyLabel56.Size = new System.Drawing.Size(240, 45);
this.solvencyLabel56.TabIndex = 56;
this.solvencyLabel56.Text = "Total recoverable from reinsurance/SPV and Finite Re after the adjustment for expected losses due to counterparty default" ;
this.solvencyLabel56.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel57
//
this.solvencyLabel57.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel57.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel57.Location = new System.Drawing.Point(285,272);
this.solvencyLabel57.Name = "solvencyLabel57";
this.solvencyLabel57.OrdinateID_Label = 0;
this.solvencyLabel57.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel57.TabIndex = 57;
this.solvencyLabel57.Text = "R0240" ;
this.solvencyLabel57.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel58
//
this.solvencyLabel58.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel58.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel58.Location = new System.Drawing.Point(31,320);
this.solvencyLabel58.Name = "solvencyLabel58";
this.solvencyLabel58.OrdinateID_Label = 3103;
this.solvencyLabel58.Size = new System.Drawing.Size(240, 15);
this.solvencyLabel58.TabIndex = 58;
this.solvencyLabel58.Text = "Net Best Estimate of Claims Provisions" ;
this.solvencyLabel58.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel59
//
this.solvencyLabel59.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel59.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel59.Location = new System.Drawing.Point(285,320);
this.solvencyLabel59.Name = "solvencyLabel59";
this.solvencyLabel59.OrdinateID_Label = 0;
this.solvencyLabel59.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel59.TabIndex = 59;
this.solvencyLabel59.Text = "R0250" ;
this.solvencyLabel59.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel60
//
this.solvencyLabel60.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel60.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel60.Location = new System.Drawing.Point(17,340);
this.solvencyLabel60.Name = "solvencyLabel60";
this.solvencyLabel60.OrdinateID_Label = 3104;
this.solvencyLabel60.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel60.TabIndex = 60;
this.solvencyLabel60.Text = "Total Best estimate - gross" ;
this.solvencyLabel60.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel61
//
this.solvencyLabel61.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel61.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel61.Location = new System.Drawing.Point(285,340);
this.solvencyLabel61.Name = "solvencyLabel61";
this.solvencyLabel61.OrdinateID_Label = 0;
this.solvencyLabel61.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel61.TabIndex = 61;
this.solvencyLabel61.Text = "R0260" ;
this.solvencyLabel61.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel62
//
this.solvencyLabel62.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel62.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel62.Location = new System.Drawing.Point(17,360);
this.solvencyLabel62.Name = "solvencyLabel62";
this.solvencyLabel62.OrdinateID_Label = 3105;
this.solvencyLabel62.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel62.TabIndex = 62;
this.solvencyLabel62.Text = "Total Best estimate - net" ;
this.solvencyLabel62.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel63
//
this.solvencyLabel63.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel63.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel63.Location = new System.Drawing.Point(285,360);
this.solvencyLabel63.Name = "solvencyLabel63";
this.solvencyLabel63.OrdinateID_Label = 0;
this.solvencyLabel63.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel63.TabIndex = 63;
this.solvencyLabel63.Text = "R0270" ;
this.solvencyLabel63.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel64
//
this.solvencyLabel64.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel64.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel64.Location = new System.Drawing.Point(17,380);
this.solvencyLabel64.Name = "solvencyLabel64";
this.solvencyLabel64.OrdinateID_Label = 3106;
this.solvencyLabel64.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel64.TabIndex = 64;
this.solvencyLabel64.Text = "Risk margin" ;
this.solvencyLabel64.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel65
//
this.solvencyLabel65.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel65.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel65.Location = new System.Drawing.Point(285,380);
this.solvencyLabel65.Name = "solvencyLabel65";
this.solvencyLabel65.OrdinateID_Label = 0;
this.solvencyLabel65.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel65.TabIndex = 65;
this.solvencyLabel65.Text = "R0280" ;
this.solvencyLabel65.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel66
//
this.solvencyLabel66.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel66.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel66.Location = new System.Drawing.Point(17,400);
this.solvencyLabel66.Name = "solvencyLabel66";
this.solvencyLabel66.OrdinateID_Label = 3107;
this.solvencyLabel66.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel66.TabIndex = 66;
this.solvencyLabel66.Text = "Amount of the transitional on Technical Provisions" ;
this.solvencyLabel66.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel67
//
this.solvencyLabel67.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel67.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel67.Location = new System.Drawing.Point(285,400);
this.solvencyLabel67.Name = "solvencyLabel67";
this.solvencyLabel67.OrdinateID_Label = 0;
this.solvencyLabel67.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel67.TabIndex = 67;
this.solvencyLabel67.Text = "" ;
this.solvencyLabel67.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel68
//
this.solvencyLabel68.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel68.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel68.Location = new System.Drawing.Point(24,420);
this.solvencyLabel68.Name = "solvencyLabel68";
this.solvencyLabel68.OrdinateID_Label = 3108;
this.solvencyLabel68.Size = new System.Drawing.Size(247, 15);
this.solvencyLabel68.TabIndex = 68;
this.solvencyLabel68.Text = "Technical Provisions calculated as a whole" ;
this.solvencyLabel68.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel69
//
this.solvencyLabel69.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel69.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel69.Location = new System.Drawing.Point(285,420);
this.solvencyLabel69.Name = "solvencyLabel69";
this.solvencyLabel69.OrdinateID_Label = 0;
this.solvencyLabel69.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel69.TabIndex = 69;
this.solvencyLabel69.Text = "R0290" ;
this.solvencyLabel69.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel70
//
this.solvencyLabel70.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel70.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel70.Location = new System.Drawing.Point(24,440);
this.solvencyLabel70.Name = "solvencyLabel70";
this.solvencyLabel70.OrdinateID_Label = 3109;
this.solvencyLabel70.Size = new System.Drawing.Size(247, 15);
this.solvencyLabel70.TabIndex = 70;
this.solvencyLabel70.Text = "Best estimate" ;
this.solvencyLabel70.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel71
//
this.solvencyLabel71.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel71.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel71.Location = new System.Drawing.Point(285,440);
this.solvencyLabel71.Name = "solvencyLabel71";
this.solvencyLabel71.OrdinateID_Label = 0;
this.solvencyLabel71.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel71.TabIndex = 71;
this.solvencyLabel71.Text = "R0300" ;
this.solvencyLabel71.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel72
//
this.solvencyLabel72.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel72.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel72.Location = new System.Drawing.Point(24,460);
this.solvencyLabel72.Name = "solvencyLabel72";
this.solvencyLabel72.OrdinateID_Label = 3110;
this.solvencyLabel72.Size = new System.Drawing.Size(247, 15);
this.solvencyLabel72.TabIndex = 72;
this.solvencyLabel72.Text = "Risk margin" ;
this.solvencyLabel72.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel73
//
this.solvencyLabel73.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel73.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel73.Location = new System.Drawing.Point(285,460);
this.solvencyLabel73.Name = "solvencyLabel73";
this.solvencyLabel73.OrdinateID_Label = 0;
this.solvencyLabel73.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel73.TabIndex = 73;
this.solvencyLabel73.Text = "R0310" ;
this.solvencyLabel73.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel74
//
this.solvencyLabel74.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel74.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel74.Location = new System.Drawing.Point(10,480);
this.solvencyLabel74.Name = "solvencyLabel74";
this.solvencyLabel74.OrdinateID_Label = 3111;
this.solvencyLabel74.Size = new System.Drawing.Size(261, 15);
this.solvencyLabel74.TabIndex = 74;
this.solvencyLabel74.Text = "Technical provisions - total" ;
this.solvencyLabel74.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel75
//
this.solvencyLabel75.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel75.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel75.Location = new System.Drawing.Point(285,480);
this.solvencyLabel75.Name = "solvencyLabel75";
this.solvencyLabel75.OrdinateID_Label = 0;
this.solvencyLabel75.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel75.TabIndex = 75;
this.solvencyLabel75.Text = "" ;
this.solvencyLabel75.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel76
//
this.solvencyLabel76.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel76.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel76.Location = new System.Drawing.Point(17,500);
this.solvencyLabel76.Name = "solvencyLabel76";
this.solvencyLabel76.OrdinateID_Label = 3112;
this.solvencyLabel76.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel76.TabIndex = 76;
this.solvencyLabel76.Text = "Technical provisions - total" ;
this.solvencyLabel76.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel77
//
this.solvencyLabel77.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel77.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel77.Location = new System.Drawing.Point(285,500);
this.solvencyLabel77.Name = "solvencyLabel77";
this.solvencyLabel77.OrdinateID_Label = 0;
this.solvencyLabel77.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel77.TabIndex = 77;
this.solvencyLabel77.Text = "R0320" ;
this.solvencyLabel77.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel78
//
this.solvencyLabel78.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel78.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel78.Location = new System.Drawing.Point(17,520);
this.solvencyLabel78.Name = "solvencyLabel78";
this.solvencyLabel78.OrdinateID_Label = 3113;
this.solvencyLabel78.Size = new System.Drawing.Size(254, 45);
this.solvencyLabel78.TabIndex = 78;
this.solvencyLabel78.Text = "Recoverable from reinsurance contract/SPV and Finite Re after the adjustment for expected losses due to counterparty default - total" ;
this.solvencyLabel78.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel79
//
this.solvencyLabel79.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel79.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel79.Location = new System.Drawing.Point(285,520);
this.solvencyLabel79.Name = "solvencyLabel79";
this.solvencyLabel79.OrdinateID_Label = 0;
this.solvencyLabel79.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel79.TabIndex = 79;
this.solvencyLabel79.Text = "R0330" ;
this.solvencyLabel79.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel80
//
this.solvencyLabel80.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel80.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel80.Location = new System.Drawing.Point(17,568);
this.solvencyLabel80.Name = "solvencyLabel80";
this.solvencyLabel80.OrdinateID_Label = 3114;
this.solvencyLabel80.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel80.TabIndex = 80;
this.solvencyLabel80.Text = "Technical provisions minus recoverables from reinsurance/SPV and Finite Re - total" ;
this.solvencyLabel80.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel81
//
this.solvencyLabel81.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel81.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel81.Location = new System.Drawing.Point(285,568);
this.solvencyLabel81.Name = "solvencyLabel81";
this.solvencyLabel81.OrdinateID_Label = 0;
this.solvencyLabel81.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel81.TabIndex = 81;
this.solvencyLabel81.Text = "R0340" ;
this.solvencyLabel81.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel82
//
this.solvencyLabel82.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel82.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel82.Location = new System.Drawing.Point(285,588);
this.solvencyLabel82.Name = "solvencyLabel82";
this.solvencyLabel82.OrdinateID_Label = 0;
this.solvencyLabel82.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel82.TabIndex = 82;
this.solvencyLabel82.Text = "." ;
this.solvencyLabel82.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyCurrencyTextBox83
//
this.solvencyCurrencyTextBox83.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox83.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox83.Location = new System.Drawing.Point(10,3);
this.solvencyCurrencyTextBox83.Name = "solvencyCurrencyTextBox83";
this.solvencyCurrencyTextBox83.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox83.TabIndex = 83;
this.solvencyCurrencyTextBox83.ColName = "R0010C0020";
this.solvencyCurrencyTextBox83.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox84
//
this.solvencyCurrencyTextBox84.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox84.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox84.Location = new System.Drawing.Point(117,3);
this.solvencyCurrencyTextBox84.Name = "solvencyCurrencyTextBox84";
this.solvencyCurrencyTextBox84.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox84.TabIndex = 84;
this.solvencyCurrencyTextBox84.ColName = "R0010C0030";
this.solvencyCurrencyTextBox84.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox85
//
this.solvencyCurrencyTextBox85.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox85.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox85.Location = new System.Drawing.Point(224,3);
this.solvencyCurrencyTextBox85.Name = "solvencyCurrencyTextBox85";
this.solvencyCurrencyTextBox85.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox85.TabIndex = 85;
this.solvencyCurrencyTextBox85.ColName = "R0010C0040";
this.solvencyCurrencyTextBox85.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox86
//
this.solvencyCurrencyTextBox86.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox86.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox86.Location = new System.Drawing.Point(331,3);
this.solvencyCurrencyTextBox86.Name = "solvencyCurrencyTextBox86";
this.solvencyCurrencyTextBox86.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox86.TabIndex = 86;
this.solvencyCurrencyTextBox86.ColName = "R0010C0050";
this.solvencyCurrencyTextBox86.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox87
//
this.solvencyCurrencyTextBox87.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox87.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox87.Location = new System.Drawing.Point(438,3);
this.solvencyCurrencyTextBox87.Name = "solvencyCurrencyTextBox87";
this.solvencyCurrencyTextBox87.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox87.TabIndex = 87;
this.solvencyCurrencyTextBox87.ColName = "R0010C0060";
this.solvencyCurrencyTextBox87.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox88
//
this.solvencyCurrencyTextBox88.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox88.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox88.Location = new System.Drawing.Point(545,3);
this.solvencyCurrencyTextBox88.Name = "solvencyCurrencyTextBox88";
this.solvencyCurrencyTextBox88.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox88.TabIndex = 88;
this.solvencyCurrencyTextBox88.ColName = "R0010C0070";
this.solvencyCurrencyTextBox88.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox89
//
this.solvencyCurrencyTextBox89.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox89.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox89.Location = new System.Drawing.Point(652,3);
this.solvencyCurrencyTextBox89.Name = "solvencyCurrencyTextBox89";
this.solvencyCurrencyTextBox89.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox89.TabIndex = 89;
this.solvencyCurrencyTextBox89.ColName = "R0010C0080";
this.solvencyCurrencyTextBox89.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox90
//
this.solvencyCurrencyTextBox90.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox90.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox90.Location = new System.Drawing.Point(759,3);
this.solvencyCurrencyTextBox90.Name = "solvencyCurrencyTextBox90";
this.solvencyCurrencyTextBox90.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox90.TabIndex = 90;
this.solvencyCurrencyTextBox90.ColName = "R0010C0090";
this.solvencyCurrencyTextBox90.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox91
//
this.solvencyCurrencyTextBox91.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox91.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox91.Location = new System.Drawing.Point(866,3);
this.solvencyCurrencyTextBox91.Name = "solvencyCurrencyTextBox91";
this.solvencyCurrencyTextBox91.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox91.TabIndex = 91;
this.solvencyCurrencyTextBox91.ColName = "R0010C0100";
this.solvencyCurrencyTextBox91.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox92
//
this.solvencyCurrencyTextBox92.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox92.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox92.Location = new System.Drawing.Point(973,3);
this.solvencyCurrencyTextBox92.Name = "solvencyCurrencyTextBox92";
this.solvencyCurrencyTextBox92.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox92.TabIndex = 92;
this.solvencyCurrencyTextBox92.ColName = "R0010C0110";
this.solvencyCurrencyTextBox92.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox93
//
this.solvencyCurrencyTextBox93.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox93.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox93.Location = new System.Drawing.Point(1080,3);
this.solvencyCurrencyTextBox93.Name = "solvencyCurrencyTextBox93";
this.solvencyCurrencyTextBox93.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox93.TabIndex = 93;
this.solvencyCurrencyTextBox93.ColName = "R0010C0120";
this.solvencyCurrencyTextBox93.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox94
//
this.solvencyCurrencyTextBox94.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox94.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox94.Location = new System.Drawing.Point(1187,3);
this.solvencyCurrencyTextBox94.Name = "solvencyCurrencyTextBox94";
this.solvencyCurrencyTextBox94.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox94.TabIndex = 94;
this.solvencyCurrencyTextBox94.ColName = "R0010C0130";
this.solvencyCurrencyTextBox94.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox95
//
this.solvencyCurrencyTextBox95.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox95.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox95.Location = new System.Drawing.Point(1294,3);
this.solvencyCurrencyTextBox95.Name = "solvencyCurrencyTextBox95";
this.solvencyCurrencyTextBox95.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox95.TabIndex = 95;
this.solvencyCurrencyTextBox95.ColName = "R0010C0140";
this.solvencyCurrencyTextBox95.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox96
//
this.solvencyCurrencyTextBox96.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox96.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox96.Location = new System.Drawing.Point(1401,3);
this.solvencyCurrencyTextBox96.Name = "solvencyCurrencyTextBox96";
this.solvencyCurrencyTextBox96.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox96.TabIndex = 96;
this.solvencyCurrencyTextBox96.ColName = "R0010C0150";
this.solvencyCurrencyTextBox96.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox97
//
this.solvencyCurrencyTextBox97.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox97.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox97.Location = new System.Drawing.Point(1508,3);
this.solvencyCurrencyTextBox97.Name = "solvencyCurrencyTextBox97";
this.solvencyCurrencyTextBox97.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox97.TabIndex = 97;
this.solvencyCurrencyTextBox97.ColName = "R0010C0160";
this.solvencyCurrencyTextBox97.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox98
//
this.solvencyCurrencyTextBox98.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox98.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox98.Location = new System.Drawing.Point(1615,3);
this.solvencyCurrencyTextBox98.Name = "solvencyCurrencyTextBox98";
this.solvencyCurrencyTextBox98.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox98.TabIndex = 98;
this.solvencyCurrencyTextBox98.ColName = "R0010C0170";
this.solvencyCurrencyTextBox98.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox99
//
this.solvencyCurrencyTextBox99.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox99.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox99.Location = new System.Drawing.Point(1722,3);
this.solvencyCurrencyTextBox99.Name = "solvencyCurrencyTextBox99";
this.solvencyCurrencyTextBox99.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox99.TabIndex = 99;
this.solvencyCurrencyTextBox99.ColName = "R0010C0180";
this.solvencyCurrencyTextBox99.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox100
//
this.solvencyCurrencyTextBox100.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox100.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox100.Location = new System.Drawing.Point(10,23);
this.solvencyCurrencyTextBox100.Name = "solvencyCurrencyTextBox100";
this.solvencyCurrencyTextBox100.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox100.TabIndex = 100;
this.solvencyCurrencyTextBox100.ColName = "R0050C0020";
this.solvencyCurrencyTextBox100.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox101
//
this.solvencyCurrencyTextBox101.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox101.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox101.Location = new System.Drawing.Point(117,23);
this.solvencyCurrencyTextBox101.Name = "solvencyCurrencyTextBox101";
this.solvencyCurrencyTextBox101.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox101.TabIndex = 101;
this.solvencyCurrencyTextBox101.ColName = "R0050C0030";
this.solvencyCurrencyTextBox101.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox102
//
this.solvencyCurrencyTextBox102.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox102.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox102.Location = new System.Drawing.Point(224,23);
this.solvencyCurrencyTextBox102.Name = "solvencyCurrencyTextBox102";
this.solvencyCurrencyTextBox102.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox102.TabIndex = 102;
this.solvencyCurrencyTextBox102.ColName = "R0050C0040";
this.solvencyCurrencyTextBox102.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox103
//
this.solvencyCurrencyTextBox103.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox103.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox103.Location = new System.Drawing.Point(331,23);
this.solvencyCurrencyTextBox103.Name = "solvencyCurrencyTextBox103";
this.solvencyCurrencyTextBox103.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox103.TabIndex = 103;
this.solvencyCurrencyTextBox103.ColName = "R0050C0050";
this.solvencyCurrencyTextBox103.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox104
//
this.solvencyCurrencyTextBox104.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox104.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox104.Location = new System.Drawing.Point(438,23);
this.solvencyCurrencyTextBox104.Name = "solvencyCurrencyTextBox104";
this.solvencyCurrencyTextBox104.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox104.TabIndex = 104;
this.solvencyCurrencyTextBox104.ColName = "R0050C0060";
this.solvencyCurrencyTextBox104.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox105
//
this.solvencyCurrencyTextBox105.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox105.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox105.Location = new System.Drawing.Point(545,23);
this.solvencyCurrencyTextBox105.Name = "solvencyCurrencyTextBox105";
this.solvencyCurrencyTextBox105.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox105.TabIndex = 105;
this.solvencyCurrencyTextBox105.ColName = "R0050C0070";
this.solvencyCurrencyTextBox105.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox106
//
this.solvencyCurrencyTextBox106.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox106.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox106.Location = new System.Drawing.Point(652,23);
this.solvencyCurrencyTextBox106.Name = "solvencyCurrencyTextBox106";
this.solvencyCurrencyTextBox106.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox106.TabIndex = 106;
this.solvencyCurrencyTextBox106.ColName = "R0050C0080";
this.solvencyCurrencyTextBox106.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox107
//
this.solvencyCurrencyTextBox107.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox107.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox107.Location = new System.Drawing.Point(759,23);
this.solvencyCurrencyTextBox107.Name = "solvencyCurrencyTextBox107";
this.solvencyCurrencyTextBox107.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox107.TabIndex = 107;
this.solvencyCurrencyTextBox107.ColName = "R0050C0090";
this.solvencyCurrencyTextBox107.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox108
//
this.solvencyCurrencyTextBox108.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox108.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox108.Location = new System.Drawing.Point(866,23);
this.solvencyCurrencyTextBox108.Name = "solvencyCurrencyTextBox108";
this.solvencyCurrencyTextBox108.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox108.TabIndex = 108;
this.solvencyCurrencyTextBox108.ColName = "R0050C0100";
this.solvencyCurrencyTextBox108.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox109
//
this.solvencyCurrencyTextBox109.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox109.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox109.Location = new System.Drawing.Point(973,23);
this.solvencyCurrencyTextBox109.Name = "solvencyCurrencyTextBox109";
this.solvencyCurrencyTextBox109.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox109.TabIndex = 109;
this.solvencyCurrencyTextBox109.ColName = "R0050C0110";
this.solvencyCurrencyTextBox109.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox110
//
this.solvencyCurrencyTextBox110.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox110.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox110.Location = new System.Drawing.Point(1080,23);
this.solvencyCurrencyTextBox110.Name = "solvencyCurrencyTextBox110";
this.solvencyCurrencyTextBox110.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox110.TabIndex = 110;
this.solvencyCurrencyTextBox110.ColName = "R0050C0120";
this.solvencyCurrencyTextBox110.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox111
//
this.solvencyCurrencyTextBox111.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox111.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox111.Location = new System.Drawing.Point(1187,23);
this.solvencyCurrencyTextBox111.Name = "solvencyCurrencyTextBox111";
this.solvencyCurrencyTextBox111.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox111.TabIndex = 111;
this.solvencyCurrencyTextBox111.ColName = "R0050C0130";
this.solvencyCurrencyTextBox111.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox112
//
this.solvencyCurrencyTextBox112.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox112.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox112.Location = new System.Drawing.Point(1294,23);
this.solvencyCurrencyTextBox112.Name = "solvencyCurrencyTextBox112";
this.solvencyCurrencyTextBox112.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox112.TabIndex = 112;
this.solvencyCurrencyTextBox112.ColName = "R0050C0140";
this.solvencyCurrencyTextBox112.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox113
//
this.solvencyCurrencyTextBox113.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox113.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox113.Location = new System.Drawing.Point(1401,23);
this.solvencyCurrencyTextBox113.Name = "solvencyCurrencyTextBox113";
this.solvencyCurrencyTextBox113.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox113.TabIndex = 113;
this.solvencyCurrencyTextBox113.ColName = "R0050C0150";
this.solvencyCurrencyTextBox113.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox114
//
this.solvencyCurrencyTextBox114.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox114.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox114.Location = new System.Drawing.Point(1508,23);
this.solvencyCurrencyTextBox114.Name = "solvencyCurrencyTextBox114";
this.solvencyCurrencyTextBox114.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox114.TabIndex = 114;
this.solvencyCurrencyTextBox114.ColName = "R0050C0160";
this.solvencyCurrencyTextBox114.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox115
//
this.solvencyCurrencyTextBox115.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox115.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox115.Location = new System.Drawing.Point(1615,23);
this.solvencyCurrencyTextBox115.Name = "solvencyCurrencyTextBox115";
this.solvencyCurrencyTextBox115.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox115.TabIndex = 115;
this.solvencyCurrencyTextBox115.ColName = "R0050C0170";
this.solvencyCurrencyTextBox115.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox116
//
this.solvencyCurrencyTextBox116.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox116.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox116.Location = new System.Drawing.Point(1722,23);
this.solvencyCurrencyTextBox116.Name = "solvencyCurrencyTextBox116";
this.solvencyCurrencyTextBox116.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox116.TabIndex = 116;
this.solvencyCurrencyTextBox116.ColName = "R0050C0180";
this.solvencyCurrencyTextBox116.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox117
//
this.solvencyCurrencyTextBox117.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox117.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox117.Location = new System.Drawing.Point(10,144);
this.solvencyCurrencyTextBox117.Name = "solvencyCurrencyTextBox117";
this.solvencyCurrencyTextBox117.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox117.TabIndex = 117;
this.solvencyCurrencyTextBox117.ColName = "R0060C0020";
this.solvencyCurrencyTextBox117.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox118
//
this.solvencyCurrencyTextBox118.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox118.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox118.Location = new System.Drawing.Point(117,144);
this.solvencyCurrencyTextBox118.Name = "solvencyCurrencyTextBox118";
this.solvencyCurrencyTextBox118.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox118.TabIndex = 118;
this.solvencyCurrencyTextBox118.ColName = "R0060C0030";
this.solvencyCurrencyTextBox118.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox119
//
this.solvencyCurrencyTextBox119.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox119.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox119.Location = new System.Drawing.Point(224,144);
this.solvencyCurrencyTextBox119.Name = "solvencyCurrencyTextBox119";
this.solvencyCurrencyTextBox119.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox119.TabIndex = 119;
this.solvencyCurrencyTextBox119.ColName = "R0060C0040";
this.solvencyCurrencyTextBox119.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox120
//
this.solvencyCurrencyTextBox120.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox120.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox120.Location = new System.Drawing.Point(331,144);
this.solvencyCurrencyTextBox120.Name = "solvencyCurrencyTextBox120";
this.solvencyCurrencyTextBox120.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox120.TabIndex = 120;
this.solvencyCurrencyTextBox120.ColName = "R0060C0050";
this.solvencyCurrencyTextBox120.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox121
//
this.solvencyCurrencyTextBox121.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox121.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox121.Location = new System.Drawing.Point(438,144);
this.solvencyCurrencyTextBox121.Name = "solvencyCurrencyTextBox121";
this.solvencyCurrencyTextBox121.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox121.TabIndex = 121;
this.solvencyCurrencyTextBox121.ColName = "R0060C0060";
this.solvencyCurrencyTextBox121.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox122
//
this.solvencyCurrencyTextBox122.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox122.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox122.Location = new System.Drawing.Point(545,144);
this.solvencyCurrencyTextBox122.Name = "solvencyCurrencyTextBox122";
this.solvencyCurrencyTextBox122.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox122.TabIndex = 122;
this.solvencyCurrencyTextBox122.ColName = "R0060C0070";
this.solvencyCurrencyTextBox122.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox123
//
this.solvencyCurrencyTextBox123.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox123.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox123.Location = new System.Drawing.Point(652,144);
this.solvencyCurrencyTextBox123.Name = "solvencyCurrencyTextBox123";
this.solvencyCurrencyTextBox123.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox123.TabIndex = 123;
this.solvencyCurrencyTextBox123.ColName = "R0060C0080";
this.solvencyCurrencyTextBox123.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox124
//
this.solvencyCurrencyTextBox124.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox124.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox124.Location = new System.Drawing.Point(759,144);
this.solvencyCurrencyTextBox124.Name = "solvencyCurrencyTextBox124";
this.solvencyCurrencyTextBox124.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox124.TabIndex = 124;
this.solvencyCurrencyTextBox124.ColName = "R0060C0090";
this.solvencyCurrencyTextBox124.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox125
//
this.solvencyCurrencyTextBox125.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox125.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox125.Location = new System.Drawing.Point(866,144);
this.solvencyCurrencyTextBox125.Name = "solvencyCurrencyTextBox125";
this.solvencyCurrencyTextBox125.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox125.TabIndex = 125;
this.solvencyCurrencyTextBox125.ColName = "R0060C0100";
this.solvencyCurrencyTextBox125.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox126
//
this.solvencyCurrencyTextBox126.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox126.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox126.Location = new System.Drawing.Point(973,144);
this.solvencyCurrencyTextBox126.Name = "solvencyCurrencyTextBox126";
this.solvencyCurrencyTextBox126.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox126.TabIndex = 126;
this.solvencyCurrencyTextBox126.ColName = "R0060C0110";
this.solvencyCurrencyTextBox126.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox127
//
this.solvencyCurrencyTextBox127.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox127.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox127.Location = new System.Drawing.Point(1080,144);
this.solvencyCurrencyTextBox127.Name = "solvencyCurrencyTextBox127";
this.solvencyCurrencyTextBox127.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox127.TabIndex = 127;
this.solvencyCurrencyTextBox127.ColName = "R0060C0120";
this.solvencyCurrencyTextBox127.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox128
//
this.solvencyCurrencyTextBox128.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox128.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox128.Location = new System.Drawing.Point(1187,144);
this.solvencyCurrencyTextBox128.Name = "solvencyCurrencyTextBox128";
this.solvencyCurrencyTextBox128.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox128.TabIndex = 128;
this.solvencyCurrencyTextBox128.ColName = "R0060C0130";
this.solvencyCurrencyTextBox128.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox129
//
this.solvencyCurrencyTextBox129.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox129.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox129.Location = new System.Drawing.Point(1294,144);
this.solvencyCurrencyTextBox129.Name = "solvencyCurrencyTextBox129";
this.solvencyCurrencyTextBox129.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox129.TabIndex = 129;
this.solvencyCurrencyTextBox129.ColName = "R0060C0140";
this.solvencyCurrencyTextBox129.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox130
//
this.solvencyCurrencyTextBox130.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox130.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox130.Location = new System.Drawing.Point(1401,144);
this.solvencyCurrencyTextBox130.Name = "solvencyCurrencyTextBox130";
this.solvencyCurrencyTextBox130.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox130.TabIndex = 130;
this.solvencyCurrencyTextBox130.ColName = "R0060C0150";
this.solvencyCurrencyTextBox130.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox131
//
this.solvencyCurrencyTextBox131.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox131.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox131.Location = new System.Drawing.Point(1508,144);
this.solvencyCurrencyTextBox131.Name = "solvencyCurrencyTextBox131";
this.solvencyCurrencyTextBox131.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox131.TabIndex = 131;
this.solvencyCurrencyTextBox131.ColName = "R0060C0160";
this.solvencyCurrencyTextBox131.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox132
//
this.solvencyCurrencyTextBox132.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox132.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox132.Location = new System.Drawing.Point(1615,144);
this.solvencyCurrencyTextBox132.Name = "solvencyCurrencyTextBox132";
this.solvencyCurrencyTextBox132.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox132.TabIndex = 132;
this.solvencyCurrencyTextBox132.ColName = "R0060C0170";
this.solvencyCurrencyTextBox132.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox133
//
this.solvencyCurrencyTextBox133.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox133.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox133.Location = new System.Drawing.Point(1722,144);
this.solvencyCurrencyTextBox133.Name = "solvencyCurrencyTextBox133";
this.solvencyCurrencyTextBox133.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox133.TabIndex = 133;
this.solvencyCurrencyTextBox133.ColName = "R0060C0180";
this.solvencyCurrencyTextBox133.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox134
//
this.solvencyCurrencyTextBox134.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox134.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox134.Location = new System.Drawing.Point(10,164);
this.solvencyCurrencyTextBox134.Name = "solvencyCurrencyTextBox134";
this.solvencyCurrencyTextBox134.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox134.TabIndex = 134;
this.solvencyCurrencyTextBox134.ColName = "R0140C0020";
this.solvencyCurrencyTextBox134.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox135
//
this.solvencyCurrencyTextBox135.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox135.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox135.Location = new System.Drawing.Point(117,164);
this.solvencyCurrencyTextBox135.Name = "solvencyCurrencyTextBox135";
this.solvencyCurrencyTextBox135.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox135.TabIndex = 135;
this.solvencyCurrencyTextBox135.ColName = "R0140C0030";
this.solvencyCurrencyTextBox135.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox136
//
this.solvencyCurrencyTextBox136.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox136.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox136.Location = new System.Drawing.Point(224,164);
this.solvencyCurrencyTextBox136.Name = "solvencyCurrencyTextBox136";
this.solvencyCurrencyTextBox136.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox136.TabIndex = 136;
this.solvencyCurrencyTextBox136.ColName = "R0140C0040";
this.solvencyCurrencyTextBox136.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox137
//
this.solvencyCurrencyTextBox137.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox137.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox137.Location = new System.Drawing.Point(331,164);
this.solvencyCurrencyTextBox137.Name = "solvencyCurrencyTextBox137";
this.solvencyCurrencyTextBox137.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox137.TabIndex = 137;
this.solvencyCurrencyTextBox137.ColName = "R0140C0050";
this.solvencyCurrencyTextBox137.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox138
//
this.solvencyCurrencyTextBox138.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox138.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox138.Location = new System.Drawing.Point(438,164);
this.solvencyCurrencyTextBox138.Name = "solvencyCurrencyTextBox138";
this.solvencyCurrencyTextBox138.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox138.TabIndex = 138;
this.solvencyCurrencyTextBox138.ColName = "R0140C0060";
this.solvencyCurrencyTextBox138.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox139
//
this.solvencyCurrencyTextBox139.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox139.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox139.Location = new System.Drawing.Point(545,164);
this.solvencyCurrencyTextBox139.Name = "solvencyCurrencyTextBox139";
this.solvencyCurrencyTextBox139.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox139.TabIndex = 139;
this.solvencyCurrencyTextBox139.ColName = "R0140C0070";
this.solvencyCurrencyTextBox139.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox140
//
this.solvencyCurrencyTextBox140.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox140.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox140.Location = new System.Drawing.Point(652,164);
this.solvencyCurrencyTextBox140.Name = "solvencyCurrencyTextBox140";
this.solvencyCurrencyTextBox140.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox140.TabIndex = 140;
this.solvencyCurrencyTextBox140.ColName = "R0140C0080";
this.solvencyCurrencyTextBox140.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox141
//
this.solvencyCurrencyTextBox141.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox141.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox141.Location = new System.Drawing.Point(759,164);
this.solvencyCurrencyTextBox141.Name = "solvencyCurrencyTextBox141";
this.solvencyCurrencyTextBox141.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox141.TabIndex = 141;
this.solvencyCurrencyTextBox141.ColName = "R0140C0090";
this.solvencyCurrencyTextBox141.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox142
//
this.solvencyCurrencyTextBox142.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox142.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox142.Location = new System.Drawing.Point(866,164);
this.solvencyCurrencyTextBox142.Name = "solvencyCurrencyTextBox142";
this.solvencyCurrencyTextBox142.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox142.TabIndex = 142;
this.solvencyCurrencyTextBox142.ColName = "R0140C0100";
this.solvencyCurrencyTextBox142.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox143
//
this.solvencyCurrencyTextBox143.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox143.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox143.Location = new System.Drawing.Point(973,164);
this.solvencyCurrencyTextBox143.Name = "solvencyCurrencyTextBox143";
this.solvencyCurrencyTextBox143.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox143.TabIndex = 143;
this.solvencyCurrencyTextBox143.ColName = "R0140C0110";
this.solvencyCurrencyTextBox143.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox144
//
this.solvencyCurrencyTextBox144.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox144.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox144.Location = new System.Drawing.Point(1080,164);
this.solvencyCurrencyTextBox144.Name = "solvencyCurrencyTextBox144";
this.solvencyCurrencyTextBox144.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox144.TabIndex = 144;
this.solvencyCurrencyTextBox144.ColName = "R0140C0120";
this.solvencyCurrencyTextBox144.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox145
//
this.solvencyCurrencyTextBox145.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox145.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox145.Location = new System.Drawing.Point(1187,164);
this.solvencyCurrencyTextBox145.Name = "solvencyCurrencyTextBox145";
this.solvencyCurrencyTextBox145.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox145.TabIndex = 145;
this.solvencyCurrencyTextBox145.ColName = "R0140C0130";
this.solvencyCurrencyTextBox145.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox146
//
this.solvencyCurrencyTextBox146.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox146.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox146.Location = new System.Drawing.Point(1294,164);
this.solvencyCurrencyTextBox146.Name = "solvencyCurrencyTextBox146";
this.solvencyCurrencyTextBox146.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox146.TabIndex = 146;
this.solvencyCurrencyTextBox146.ColName = "R0140C0140";
this.solvencyCurrencyTextBox146.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox147
//
this.solvencyCurrencyTextBox147.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox147.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox147.Location = new System.Drawing.Point(1401,164);
this.solvencyCurrencyTextBox147.Name = "solvencyCurrencyTextBox147";
this.solvencyCurrencyTextBox147.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox147.TabIndex = 147;
this.solvencyCurrencyTextBox147.ColName = "R0140C0150";
this.solvencyCurrencyTextBox147.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox148
//
this.solvencyCurrencyTextBox148.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox148.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox148.Location = new System.Drawing.Point(1508,164);
this.solvencyCurrencyTextBox148.Name = "solvencyCurrencyTextBox148";
this.solvencyCurrencyTextBox148.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox148.TabIndex = 148;
this.solvencyCurrencyTextBox148.ColName = "R0140C0160";
this.solvencyCurrencyTextBox148.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox149
//
this.solvencyCurrencyTextBox149.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox149.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox149.Location = new System.Drawing.Point(1615,164);
this.solvencyCurrencyTextBox149.Name = "solvencyCurrencyTextBox149";
this.solvencyCurrencyTextBox149.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox149.TabIndex = 149;
this.solvencyCurrencyTextBox149.ColName = "R0140C0170";
this.solvencyCurrencyTextBox149.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox150
//
this.solvencyCurrencyTextBox150.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox150.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox150.Location = new System.Drawing.Point(1722,164);
this.solvencyCurrencyTextBox150.Name = "solvencyCurrencyTextBox150";
this.solvencyCurrencyTextBox150.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox150.TabIndex = 150;
this.solvencyCurrencyTextBox150.ColName = "R0140C0180";
this.solvencyCurrencyTextBox150.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox151
//
this.solvencyCurrencyTextBox151.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox151.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox151.Location = new System.Drawing.Point(10,212);
this.solvencyCurrencyTextBox151.Name = "solvencyCurrencyTextBox151";
this.solvencyCurrencyTextBox151.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox151.TabIndex = 151;
this.solvencyCurrencyTextBox151.ColName = "R0150C0020";
this.solvencyCurrencyTextBox151.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox152
//
this.solvencyCurrencyTextBox152.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox152.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox152.Location = new System.Drawing.Point(117,212);
this.solvencyCurrencyTextBox152.Name = "solvencyCurrencyTextBox152";
this.solvencyCurrencyTextBox152.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox152.TabIndex = 152;
this.solvencyCurrencyTextBox152.ColName = "R0150C0030";
this.solvencyCurrencyTextBox152.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox153
//
this.solvencyCurrencyTextBox153.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox153.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox153.Location = new System.Drawing.Point(224,212);
this.solvencyCurrencyTextBox153.Name = "solvencyCurrencyTextBox153";
this.solvencyCurrencyTextBox153.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox153.TabIndex = 153;
this.solvencyCurrencyTextBox153.ColName = "R0150C0040";
this.solvencyCurrencyTextBox153.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox154
//
this.solvencyCurrencyTextBox154.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox154.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox154.Location = new System.Drawing.Point(331,212);
this.solvencyCurrencyTextBox154.Name = "solvencyCurrencyTextBox154";
this.solvencyCurrencyTextBox154.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox154.TabIndex = 154;
this.solvencyCurrencyTextBox154.ColName = "R0150C0050";
this.solvencyCurrencyTextBox154.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox155
//
this.solvencyCurrencyTextBox155.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox155.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox155.Location = new System.Drawing.Point(438,212);
this.solvencyCurrencyTextBox155.Name = "solvencyCurrencyTextBox155";
this.solvencyCurrencyTextBox155.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox155.TabIndex = 155;
this.solvencyCurrencyTextBox155.ColName = "R0150C0060";
this.solvencyCurrencyTextBox155.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox156
//
this.solvencyCurrencyTextBox156.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox156.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox156.Location = new System.Drawing.Point(545,212);
this.solvencyCurrencyTextBox156.Name = "solvencyCurrencyTextBox156";
this.solvencyCurrencyTextBox156.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox156.TabIndex = 156;
this.solvencyCurrencyTextBox156.ColName = "R0150C0070";
this.solvencyCurrencyTextBox156.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox157
//
this.solvencyCurrencyTextBox157.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox157.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox157.Location = new System.Drawing.Point(652,212);
this.solvencyCurrencyTextBox157.Name = "solvencyCurrencyTextBox157";
this.solvencyCurrencyTextBox157.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox157.TabIndex = 157;
this.solvencyCurrencyTextBox157.ColName = "R0150C0080";
this.solvencyCurrencyTextBox157.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox158
//
this.solvencyCurrencyTextBox158.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox158.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox158.Location = new System.Drawing.Point(759,212);
this.solvencyCurrencyTextBox158.Name = "solvencyCurrencyTextBox158";
this.solvencyCurrencyTextBox158.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox158.TabIndex = 158;
this.solvencyCurrencyTextBox158.ColName = "R0150C0090";
this.solvencyCurrencyTextBox158.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox159
//
this.solvencyCurrencyTextBox159.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox159.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox159.Location = new System.Drawing.Point(866,212);
this.solvencyCurrencyTextBox159.Name = "solvencyCurrencyTextBox159";
this.solvencyCurrencyTextBox159.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox159.TabIndex = 159;
this.solvencyCurrencyTextBox159.ColName = "R0150C0100";
this.solvencyCurrencyTextBox159.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox160
//
this.solvencyCurrencyTextBox160.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox160.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox160.Location = new System.Drawing.Point(973,212);
this.solvencyCurrencyTextBox160.Name = "solvencyCurrencyTextBox160";
this.solvencyCurrencyTextBox160.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox160.TabIndex = 160;
this.solvencyCurrencyTextBox160.ColName = "R0150C0110";
this.solvencyCurrencyTextBox160.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox161
//
this.solvencyCurrencyTextBox161.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox161.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox161.Location = new System.Drawing.Point(1080,212);
this.solvencyCurrencyTextBox161.Name = "solvencyCurrencyTextBox161";
this.solvencyCurrencyTextBox161.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox161.TabIndex = 161;
this.solvencyCurrencyTextBox161.ColName = "R0150C0120";
this.solvencyCurrencyTextBox161.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox162
//
this.solvencyCurrencyTextBox162.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox162.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox162.Location = new System.Drawing.Point(1187,212);
this.solvencyCurrencyTextBox162.Name = "solvencyCurrencyTextBox162";
this.solvencyCurrencyTextBox162.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox162.TabIndex = 162;
this.solvencyCurrencyTextBox162.ColName = "R0150C0130";
this.solvencyCurrencyTextBox162.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox163
//
this.solvencyCurrencyTextBox163.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox163.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox163.Location = new System.Drawing.Point(1294,212);
this.solvencyCurrencyTextBox163.Name = "solvencyCurrencyTextBox163";
this.solvencyCurrencyTextBox163.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox163.TabIndex = 163;
this.solvencyCurrencyTextBox163.ColName = "R0150C0140";
this.solvencyCurrencyTextBox163.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox164
//
this.solvencyCurrencyTextBox164.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox164.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox164.Location = new System.Drawing.Point(1401,212);
this.solvencyCurrencyTextBox164.Name = "solvencyCurrencyTextBox164";
this.solvencyCurrencyTextBox164.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox164.TabIndex = 164;
this.solvencyCurrencyTextBox164.ColName = "R0150C0150";
this.solvencyCurrencyTextBox164.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox165
//
this.solvencyCurrencyTextBox165.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox165.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox165.Location = new System.Drawing.Point(1508,212);
this.solvencyCurrencyTextBox165.Name = "solvencyCurrencyTextBox165";
this.solvencyCurrencyTextBox165.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox165.TabIndex = 165;
this.solvencyCurrencyTextBox165.ColName = "R0150C0160";
this.solvencyCurrencyTextBox165.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox166
//
this.solvencyCurrencyTextBox166.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox166.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox166.Location = new System.Drawing.Point(1615,212);
this.solvencyCurrencyTextBox166.Name = "solvencyCurrencyTextBox166";
this.solvencyCurrencyTextBox166.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox166.TabIndex = 166;
this.solvencyCurrencyTextBox166.ColName = "R0150C0170";
this.solvencyCurrencyTextBox166.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox167
//
this.solvencyCurrencyTextBox167.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox167.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox167.Location = new System.Drawing.Point(1722,212);
this.solvencyCurrencyTextBox167.Name = "solvencyCurrencyTextBox167";
this.solvencyCurrencyTextBox167.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox167.TabIndex = 167;
this.solvencyCurrencyTextBox167.ColName = "R0150C0180";
this.solvencyCurrencyTextBox167.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox168
//
this.solvencyCurrencyTextBox168.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox168.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox168.Location = new System.Drawing.Point(10,252);
this.solvencyCurrencyTextBox168.Name = "solvencyCurrencyTextBox168";
this.solvencyCurrencyTextBox168.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox168.TabIndex = 168;
this.solvencyCurrencyTextBox168.ColName = "R0160C0020";
this.solvencyCurrencyTextBox168.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox169
//
this.solvencyCurrencyTextBox169.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox169.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox169.Location = new System.Drawing.Point(117,252);
this.solvencyCurrencyTextBox169.Name = "solvencyCurrencyTextBox169";
this.solvencyCurrencyTextBox169.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox169.TabIndex = 169;
this.solvencyCurrencyTextBox169.ColName = "R0160C0030";
this.solvencyCurrencyTextBox169.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox170
//
this.solvencyCurrencyTextBox170.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox170.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox170.Location = new System.Drawing.Point(224,252);
this.solvencyCurrencyTextBox170.Name = "solvencyCurrencyTextBox170";
this.solvencyCurrencyTextBox170.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox170.TabIndex = 170;
this.solvencyCurrencyTextBox170.ColName = "R0160C0040";
this.solvencyCurrencyTextBox170.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox171
//
this.solvencyCurrencyTextBox171.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox171.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox171.Location = new System.Drawing.Point(331,252);
this.solvencyCurrencyTextBox171.Name = "solvencyCurrencyTextBox171";
this.solvencyCurrencyTextBox171.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox171.TabIndex = 171;
this.solvencyCurrencyTextBox171.ColName = "R0160C0050";
this.solvencyCurrencyTextBox171.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox172
//
this.solvencyCurrencyTextBox172.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox172.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox172.Location = new System.Drawing.Point(438,252);
this.solvencyCurrencyTextBox172.Name = "solvencyCurrencyTextBox172";
this.solvencyCurrencyTextBox172.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox172.TabIndex = 172;
this.solvencyCurrencyTextBox172.ColName = "R0160C0060";
this.solvencyCurrencyTextBox172.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox173
//
this.solvencyCurrencyTextBox173.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox173.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox173.Location = new System.Drawing.Point(545,252);
this.solvencyCurrencyTextBox173.Name = "solvencyCurrencyTextBox173";
this.solvencyCurrencyTextBox173.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox173.TabIndex = 173;
this.solvencyCurrencyTextBox173.ColName = "R0160C0070";
this.solvencyCurrencyTextBox173.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox174
//
this.solvencyCurrencyTextBox174.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox174.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox174.Location = new System.Drawing.Point(652,252);
this.solvencyCurrencyTextBox174.Name = "solvencyCurrencyTextBox174";
this.solvencyCurrencyTextBox174.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox174.TabIndex = 174;
this.solvencyCurrencyTextBox174.ColName = "R0160C0080";
this.solvencyCurrencyTextBox174.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox175
//
this.solvencyCurrencyTextBox175.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox175.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox175.Location = new System.Drawing.Point(759,252);
this.solvencyCurrencyTextBox175.Name = "solvencyCurrencyTextBox175";
this.solvencyCurrencyTextBox175.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox175.TabIndex = 175;
this.solvencyCurrencyTextBox175.ColName = "R0160C0090";
this.solvencyCurrencyTextBox175.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox176
//
this.solvencyCurrencyTextBox176.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox176.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox176.Location = new System.Drawing.Point(866,252);
this.solvencyCurrencyTextBox176.Name = "solvencyCurrencyTextBox176";
this.solvencyCurrencyTextBox176.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox176.TabIndex = 176;
this.solvencyCurrencyTextBox176.ColName = "R0160C0100";
this.solvencyCurrencyTextBox176.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox177
//
this.solvencyCurrencyTextBox177.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox177.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox177.Location = new System.Drawing.Point(973,252);
this.solvencyCurrencyTextBox177.Name = "solvencyCurrencyTextBox177";
this.solvencyCurrencyTextBox177.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox177.TabIndex = 177;
this.solvencyCurrencyTextBox177.ColName = "R0160C0110";
this.solvencyCurrencyTextBox177.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox178
//
this.solvencyCurrencyTextBox178.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox178.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox178.Location = new System.Drawing.Point(1080,252);
this.solvencyCurrencyTextBox178.Name = "solvencyCurrencyTextBox178";
this.solvencyCurrencyTextBox178.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox178.TabIndex = 178;
this.solvencyCurrencyTextBox178.ColName = "R0160C0120";
this.solvencyCurrencyTextBox178.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox179
//
this.solvencyCurrencyTextBox179.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox179.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox179.Location = new System.Drawing.Point(1187,252);
this.solvencyCurrencyTextBox179.Name = "solvencyCurrencyTextBox179";
this.solvencyCurrencyTextBox179.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox179.TabIndex = 179;
this.solvencyCurrencyTextBox179.ColName = "R0160C0130";
this.solvencyCurrencyTextBox179.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox180
//
this.solvencyCurrencyTextBox180.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox180.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox180.Location = new System.Drawing.Point(1294,252);
this.solvencyCurrencyTextBox180.Name = "solvencyCurrencyTextBox180";
this.solvencyCurrencyTextBox180.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox180.TabIndex = 180;
this.solvencyCurrencyTextBox180.ColName = "R0160C0140";
this.solvencyCurrencyTextBox180.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox181
//
this.solvencyCurrencyTextBox181.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox181.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox181.Location = new System.Drawing.Point(1401,252);
this.solvencyCurrencyTextBox181.Name = "solvencyCurrencyTextBox181";
this.solvencyCurrencyTextBox181.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox181.TabIndex = 181;
this.solvencyCurrencyTextBox181.ColName = "R0160C0150";
this.solvencyCurrencyTextBox181.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox182
//
this.solvencyCurrencyTextBox182.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox182.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox182.Location = new System.Drawing.Point(1508,252);
this.solvencyCurrencyTextBox182.Name = "solvencyCurrencyTextBox182";
this.solvencyCurrencyTextBox182.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox182.TabIndex = 182;
this.solvencyCurrencyTextBox182.ColName = "R0160C0160";
this.solvencyCurrencyTextBox182.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox183
//
this.solvencyCurrencyTextBox183.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox183.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox183.Location = new System.Drawing.Point(1615,252);
this.solvencyCurrencyTextBox183.Name = "solvencyCurrencyTextBox183";
this.solvencyCurrencyTextBox183.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox183.TabIndex = 183;
this.solvencyCurrencyTextBox183.ColName = "R0160C0170";
this.solvencyCurrencyTextBox183.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox184
//
this.solvencyCurrencyTextBox184.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox184.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox184.Location = new System.Drawing.Point(1722,252);
this.solvencyCurrencyTextBox184.Name = "solvencyCurrencyTextBox184";
this.solvencyCurrencyTextBox184.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox184.TabIndex = 184;
this.solvencyCurrencyTextBox184.ColName = "R0160C0180";
this.solvencyCurrencyTextBox184.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox185
//
this.solvencyCurrencyTextBox185.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox185.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox185.Location = new System.Drawing.Point(10,272);
this.solvencyCurrencyTextBox185.Name = "solvencyCurrencyTextBox185";
this.solvencyCurrencyTextBox185.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox185.TabIndex = 185;
this.solvencyCurrencyTextBox185.ColName = "R0240C0020";
this.solvencyCurrencyTextBox185.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox186
//
this.solvencyCurrencyTextBox186.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox186.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox186.Location = new System.Drawing.Point(117,272);
this.solvencyCurrencyTextBox186.Name = "solvencyCurrencyTextBox186";
this.solvencyCurrencyTextBox186.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox186.TabIndex = 186;
this.solvencyCurrencyTextBox186.ColName = "R0240C0030";
this.solvencyCurrencyTextBox186.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox187
//
this.solvencyCurrencyTextBox187.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox187.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox187.Location = new System.Drawing.Point(224,272);
this.solvencyCurrencyTextBox187.Name = "solvencyCurrencyTextBox187";
this.solvencyCurrencyTextBox187.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox187.TabIndex = 187;
this.solvencyCurrencyTextBox187.ColName = "R0240C0040";
this.solvencyCurrencyTextBox187.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox188
//
this.solvencyCurrencyTextBox188.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox188.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox188.Location = new System.Drawing.Point(331,272);
this.solvencyCurrencyTextBox188.Name = "solvencyCurrencyTextBox188";
this.solvencyCurrencyTextBox188.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox188.TabIndex = 188;
this.solvencyCurrencyTextBox188.ColName = "R0240C0050";
this.solvencyCurrencyTextBox188.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox189
//
this.solvencyCurrencyTextBox189.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox189.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox189.Location = new System.Drawing.Point(438,272);
this.solvencyCurrencyTextBox189.Name = "solvencyCurrencyTextBox189";
this.solvencyCurrencyTextBox189.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox189.TabIndex = 189;
this.solvencyCurrencyTextBox189.ColName = "R0240C0060";
this.solvencyCurrencyTextBox189.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox190
//
this.solvencyCurrencyTextBox190.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox190.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox190.Location = new System.Drawing.Point(545,272);
this.solvencyCurrencyTextBox190.Name = "solvencyCurrencyTextBox190";
this.solvencyCurrencyTextBox190.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox190.TabIndex = 190;
this.solvencyCurrencyTextBox190.ColName = "R0240C0070";
this.solvencyCurrencyTextBox190.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox191
//
this.solvencyCurrencyTextBox191.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox191.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox191.Location = new System.Drawing.Point(652,272);
this.solvencyCurrencyTextBox191.Name = "solvencyCurrencyTextBox191";
this.solvencyCurrencyTextBox191.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox191.TabIndex = 191;
this.solvencyCurrencyTextBox191.ColName = "R0240C0080";
this.solvencyCurrencyTextBox191.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox192
//
this.solvencyCurrencyTextBox192.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox192.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox192.Location = new System.Drawing.Point(759,272);
this.solvencyCurrencyTextBox192.Name = "solvencyCurrencyTextBox192";
this.solvencyCurrencyTextBox192.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox192.TabIndex = 192;
this.solvencyCurrencyTextBox192.ColName = "R0240C0090";
this.solvencyCurrencyTextBox192.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox193
//
this.solvencyCurrencyTextBox193.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox193.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox193.Location = new System.Drawing.Point(866,272);
this.solvencyCurrencyTextBox193.Name = "solvencyCurrencyTextBox193";
this.solvencyCurrencyTextBox193.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox193.TabIndex = 193;
this.solvencyCurrencyTextBox193.ColName = "R0240C0100";
this.solvencyCurrencyTextBox193.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox194
//
this.solvencyCurrencyTextBox194.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox194.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox194.Location = new System.Drawing.Point(973,272);
this.solvencyCurrencyTextBox194.Name = "solvencyCurrencyTextBox194";
this.solvencyCurrencyTextBox194.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox194.TabIndex = 194;
this.solvencyCurrencyTextBox194.ColName = "R0240C0110";
this.solvencyCurrencyTextBox194.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox195
//
this.solvencyCurrencyTextBox195.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox195.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox195.Location = new System.Drawing.Point(1080,272);
this.solvencyCurrencyTextBox195.Name = "solvencyCurrencyTextBox195";
this.solvencyCurrencyTextBox195.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox195.TabIndex = 195;
this.solvencyCurrencyTextBox195.ColName = "R0240C0120";
this.solvencyCurrencyTextBox195.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox196
//
this.solvencyCurrencyTextBox196.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox196.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox196.Location = new System.Drawing.Point(1187,272);
this.solvencyCurrencyTextBox196.Name = "solvencyCurrencyTextBox196";
this.solvencyCurrencyTextBox196.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox196.TabIndex = 196;
this.solvencyCurrencyTextBox196.ColName = "R0240C0130";
this.solvencyCurrencyTextBox196.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox197
//
this.solvencyCurrencyTextBox197.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox197.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox197.Location = new System.Drawing.Point(1294,272);
this.solvencyCurrencyTextBox197.Name = "solvencyCurrencyTextBox197";
this.solvencyCurrencyTextBox197.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox197.TabIndex = 197;
this.solvencyCurrencyTextBox197.ColName = "R0240C0140";
this.solvencyCurrencyTextBox197.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox198
//
this.solvencyCurrencyTextBox198.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox198.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox198.Location = new System.Drawing.Point(1401,272);
this.solvencyCurrencyTextBox198.Name = "solvencyCurrencyTextBox198";
this.solvencyCurrencyTextBox198.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox198.TabIndex = 198;
this.solvencyCurrencyTextBox198.ColName = "R0240C0150";
this.solvencyCurrencyTextBox198.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox199
//
this.solvencyCurrencyTextBox199.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox199.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox199.Location = new System.Drawing.Point(1508,272);
this.solvencyCurrencyTextBox199.Name = "solvencyCurrencyTextBox199";
this.solvencyCurrencyTextBox199.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox199.TabIndex = 199;
this.solvencyCurrencyTextBox199.ColName = "R0240C0160";
this.solvencyCurrencyTextBox199.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox200
//
this.solvencyCurrencyTextBox200.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox200.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox200.Location = new System.Drawing.Point(1615,272);
this.solvencyCurrencyTextBox200.Name = "solvencyCurrencyTextBox200";
this.solvencyCurrencyTextBox200.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox200.TabIndex = 200;
this.solvencyCurrencyTextBox200.ColName = "R0240C0170";
this.solvencyCurrencyTextBox200.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox201
//
this.solvencyCurrencyTextBox201.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox201.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox201.Location = new System.Drawing.Point(1722,272);
this.solvencyCurrencyTextBox201.Name = "solvencyCurrencyTextBox201";
this.solvencyCurrencyTextBox201.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox201.TabIndex = 201;
this.solvencyCurrencyTextBox201.ColName = "R0240C0180";
this.solvencyCurrencyTextBox201.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox202
//
this.solvencyCurrencyTextBox202.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox202.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox202.Location = new System.Drawing.Point(10,320);
this.solvencyCurrencyTextBox202.Name = "solvencyCurrencyTextBox202";
this.solvencyCurrencyTextBox202.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox202.TabIndex = 202;
this.solvencyCurrencyTextBox202.ColName = "R0250C0020";
this.solvencyCurrencyTextBox202.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox203
//
this.solvencyCurrencyTextBox203.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox203.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox203.Location = new System.Drawing.Point(117,320);
this.solvencyCurrencyTextBox203.Name = "solvencyCurrencyTextBox203";
this.solvencyCurrencyTextBox203.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox203.TabIndex = 203;
this.solvencyCurrencyTextBox203.ColName = "R0250C0030";
this.solvencyCurrencyTextBox203.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox204
//
this.solvencyCurrencyTextBox204.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox204.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox204.Location = new System.Drawing.Point(224,320);
this.solvencyCurrencyTextBox204.Name = "solvencyCurrencyTextBox204";
this.solvencyCurrencyTextBox204.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox204.TabIndex = 204;
this.solvencyCurrencyTextBox204.ColName = "R0250C0040";
this.solvencyCurrencyTextBox204.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox205
//
this.solvencyCurrencyTextBox205.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox205.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox205.Location = new System.Drawing.Point(331,320);
this.solvencyCurrencyTextBox205.Name = "solvencyCurrencyTextBox205";
this.solvencyCurrencyTextBox205.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox205.TabIndex = 205;
this.solvencyCurrencyTextBox205.ColName = "R0250C0050";
this.solvencyCurrencyTextBox205.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox206
//
this.solvencyCurrencyTextBox206.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox206.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox206.Location = new System.Drawing.Point(438,320);
this.solvencyCurrencyTextBox206.Name = "solvencyCurrencyTextBox206";
this.solvencyCurrencyTextBox206.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox206.TabIndex = 206;
this.solvencyCurrencyTextBox206.ColName = "R0250C0060";
this.solvencyCurrencyTextBox206.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox207
//
this.solvencyCurrencyTextBox207.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox207.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox207.Location = new System.Drawing.Point(545,320);
this.solvencyCurrencyTextBox207.Name = "solvencyCurrencyTextBox207";
this.solvencyCurrencyTextBox207.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox207.TabIndex = 207;
this.solvencyCurrencyTextBox207.ColName = "R0250C0070";
this.solvencyCurrencyTextBox207.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox208
//
this.solvencyCurrencyTextBox208.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox208.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox208.Location = new System.Drawing.Point(652,320);
this.solvencyCurrencyTextBox208.Name = "solvencyCurrencyTextBox208";
this.solvencyCurrencyTextBox208.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox208.TabIndex = 208;
this.solvencyCurrencyTextBox208.ColName = "R0250C0080";
this.solvencyCurrencyTextBox208.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox209
//
this.solvencyCurrencyTextBox209.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox209.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox209.Location = new System.Drawing.Point(759,320);
this.solvencyCurrencyTextBox209.Name = "solvencyCurrencyTextBox209";
this.solvencyCurrencyTextBox209.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox209.TabIndex = 209;
this.solvencyCurrencyTextBox209.ColName = "R0250C0090";
this.solvencyCurrencyTextBox209.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox210
//
this.solvencyCurrencyTextBox210.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox210.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox210.Location = new System.Drawing.Point(866,320);
this.solvencyCurrencyTextBox210.Name = "solvencyCurrencyTextBox210";
this.solvencyCurrencyTextBox210.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox210.TabIndex = 210;
this.solvencyCurrencyTextBox210.ColName = "R0250C0100";
this.solvencyCurrencyTextBox210.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox211
//
this.solvencyCurrencyTextBox211.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox211.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox211.Location = new System.Drawing.Point(973,320);
this.solvencyCurrencyTextBox211.Name = "solvencyCurrencyTextBox211";
this.solvencyCurrencyTextBox211.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox211.TabIndex = 211;
this.solvencyCurrencyTextBox211.ColName = "R0250C0110";
this.solvencyCurrencyTextBox211.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox212
//
this.solvencyCurrencyTextBox212.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox212.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox212.Location = new System.Drawing.Point(1080,320);
this.solvencyCurrencyTextBox212.Name = "solvencyCurrencyTextBox212";
this.solvencyCurrencyTextBox212.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox212.TabIndex = 212;
this.solvencyCurrencyTextBox212.ColName = "R0250C0120";
this.solvencyCurrencyTextBox212.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox213
//
this.solvencyCurrencyTextBox213.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox213.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox213.Location = new System.Drawing.Point(1187,320);
this.solvencyCurrencyTextBox213.Name = "solvencyCurrencyTextBox213";
this.solvencyCurrencyTextBox213.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox213.TabIndex = 213;
this.solvencyCurrencyTextBox213.ColName = "R0250C0130";
this.solvencyCurrencyTextBox213.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox214
//
this.solvencyCurrencyTextBox214.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox214.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox214.Location = new System.Drawing.Point(1294,320);
this.solvencyCurrencyTextBox214.Name = "solvencyCurrencyTextBox214";
this.solvencyCurrencyTextBox214.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox214.TabIndex = 214;
this.solvencyCurrencyTextBox214.ColName = "R0250C0140";
this.solvencyCurrencyTextBox214.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox215
//
this.solvencyCurrencyTextBox215.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox215.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox215.Location = new System.Drawing.Point(1401,320);
this.solvencyCurrencyTextBox215.Name = "solvencyCurrencyTextBox215";
this.solvencyCurrencyTextBox215.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox215.TabIndex = 215;
this.solvencyCurrencyTextBox215.ColName = "R0250C0150";
this.solvencyCurrencyTextBox215.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox216
//
this.solvencyCurrencyTextBox216.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox216.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox216.Location = new System.Drawing.Point(1508,320);
this.solvencyCurrencyTextBox216.Name = "solvencyCurrencyTextBox216";
this.solvencyCurrencyTextBox216.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox216.TabIndex = 216;
this.solvencyCurrencyTextBox216.ColName = "R0250C0160";
this.solvencyCurrencyTextBox216.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox217
//
this.solvencyCurrencyTextBox217.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox217.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox217.Location = new System.Drawing.Point(1615,320);
this.solvencyCurrencyTextBox217.Name = "solvencyCurrencyTextBox217";
this.solvencyCurrencyTextBox217.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox217.TabIndex = 217;
this.solvencyCurrencyTextBox217.ColName = "R0250C0170";
this.solvencyCurrencyTextBox217.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox218
//
this.solvencyCurrencyTextBox218.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox218.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox218.Location = new System.Drawing.Point(1722,320);
this.solvencyCurrencyTextBox218.Name = "solvencyCurrencyTextBox218";
this.solvencyCurrencyTextBox218.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox218.TabIndex = 218;
this.solvencyCurrencyTextBox218.ColName = "R0250C0180";
this.solvencyCurrencyTextBox218.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox219
//
this.solvencyCurrencyTextBox219.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox219.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox219.Location = new System.Drawing.Point(10,340);
this.solvencyCurrencyTextBox219.Name = "solvencyCurrencyTextBox219";
this.solvencyCurrencyTextBox219.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox219.TabIndex = 219;
this.solvencyCurrencyTextBox219.ColName = "R0260C0020";
this.solvencyCurrencyTextBox219.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox220
//
this.solvencyCurrencyTextBox220.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox220.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox220.Location = new System.Drawing.Point(117,340);
this.solvencyCurrencyTextBox220.Name = "solvencyCurrencyTextBox220";
this.solvencyCurrencyTextBox220.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox220.TabIndex = 220;
this.solvencyCurrencyTextBox220.ColName = "R0260C0030";
this.solvencyCurrencyTextBox220.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox221
//
this.solvencyCurrencyTextBox221.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox221.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox221.Location = new System.Drawing.Point(224,340);
this.solvencyCurrencyTextBox221.Name = "solvencyCurrencyTextBox221";
this.solvencyCurrencyTextBox221.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox221.TabIndex = 221;
this.solvencyCurrencyTextBox221.ColName = "R0260C0040";
this.solvencyCurrencyTextBox221.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox222
//
this.solvencyCurrencyTextBox222.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox222.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox222.Location = new System.Drawing.Point(331,340);
this.solvencyCurrencyTextBox222.Name = "solvencyCurrencyTextBox222";
this.solvencyCurrencyTextBox222.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox222.TabIndex = 222;
this.solvencyCurrencyTextBox222.ColName = "R0260C0050";
this.solvencyCurrencyTextBox222.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox223
//
this.solvencyCurrencyTextBox223.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox223.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox223.Location = new System.Drawing.Point(438,340);
this.solvencyCurrencyTextBox223.Name = "solvencyCurrencyTextBox223";
this.solvencyCurrencyTextBox223.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox223.TabIndex = 223;
this.solvencyCurrencyTextBox223.ColName = "R0260C0060";
this.solvencyCurrencyTextBox223.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox224
//
this.solvencyCurrencyTextBox224.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox224.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox224.Location = new System.Drawing.Point(545,340);
this.solvencyCurrencyTextBox224.Name = "solvencyCurrencyTextBox224";
this.solvencyCurrencyTextBox224.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox224.TabIndex = 224;
this.solvencyCurrencyTextBox224.ColName = "R0260C0070";
this.solvencyCurrencyTextBox224.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox225
//
this.solvencyCurrencyTextBox225.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox225.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox225.Location = new System.Drawing.Point(652,340);
this.solvencyCurrencyTextBox225.Name = "solvencyCurrencyTextBox225";
this.solvencyCurrencyTextBox225.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox225.TabIndex = 225;
this.solvencyCurrencyTextBox225.ColName = "R0260C0080";
this.solvencyCurrencyTextBox225.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox226
//
this.solvencyCurrencyTextBox226.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox226.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox226.Location = new System.Drawing.Point(759,340);
this.solvencyCurrencyTextBox226.Name = "solvencyCurrencyTextBox226";
this.solvencyCurrencyTextBox226.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox226.TabIndex = 226;
this.solvencyCurrencyTextBox226.ColName = "R0260C0090";
this.solvencyCurrencyTextBox226.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox227
//
this.solvencyCurrencyTextBox227.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox227.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox227.Location = new System.Drawing.Point(866,340);
this.solvencyCurrencyTextBox227.Name = "solvencyCurrencyTextBox227";
this.solvencyCurrencyTextBox227.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox227.TabIndex = 227;
this.solvencyCurrencyTextBox227.ColName = "R0260C0100";
this.solvencyCurrencyTextBox227.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox228
//
this.solvencyCurrencyTextBox228.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox228.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox228.Location = new System.Drawing.Point(973,340);
this.solvencyCurrencyTextBox228.Name = "solvencyCurrencyTextBox228";
this.solvencyCurrencyTextBox228.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox228.TabIndex = 228;
this.solvencyCurrencyTextBox228.ColName = "R0260C0110";
this.solvencyCurrencyTextBox228.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox229
//
this.solvencyCurrencyTextBox229.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox229.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox229.Location = new System.Drawing.Point(1080,340);
this.solvencyCurrencyTextBox229.Name = "solvencyCurrencyTextBox229";
this.solvencyCurrencyTextBox229.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox229.TabIndex = 229;
this.solvencyCurrencyTextBox229.ColName = "R0260C0120";
this.solvencyCurrencyTextBox229.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox230
//
this.solvencyCurrencyTextBox230.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox230.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox230.Location = new System.Drawing.Point(1187,340);
this.solvencyCurrencyTextBox230.Name = "solvencyCurrencyTextBox230";
this.solvencyCurrencyTextBox230.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox230.TabIndex = 230;
this.solvencyCurrencyTextBox230.ColName = "R0260C0130";
this.solvencyCurrencyTextBox230.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox231
//
this.solvencyCurrencyTextBox231.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox231.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox231.Location = new System.Drawing.Point(1294,340);
this.solvencyCurrencyTextBox231.Name = "solvencyCurrencyTextBox231";
this.solvencyCurrencyTextBox231.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox231.TabIndex = 231;
this.solvencyCurrencyTextBox231.ColName = "R0260C0140";
this.solvencyCurrencyTextBox231.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox232
//
this.solvencyCurrencyTextBox232.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox232.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox232.Location = new System.Drawing.Point(1401,340);
this.solvencyCurrencyTextBox232.Name = "solvencyCurrencyTextBox232";
this.solvencyCurrencyTextBox232.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox232.TabIndex = 232;
this.solvencyCurrencyTextBox232.ColName = "R0260C0150";
this.solvencyCurrencyTextBox232.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox233
//
this.solvencyCurrencyTextBox233.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox233.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox233.Location = new System.Drawing.Point(1508,340);
this.solvencyCurrencyTextBox233.Name = "solvencyCurrencyTextBox233";
this.solvencyCurrencyTextBox233.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox233.TabIndex = 233;
this.solvencyCurrencyTextBox233.ColName = "R0260C0160";
this.solvencyCurrencyTextBox233.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox234
//
this.solvencyCurrencyTextBox234.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox234.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox234.Location = new System.Drawing.Point(1615,340);
this.solvencyCurrencyTextBox234.Name = "solvencyCurrencyTextBox234";
this.solvencyCurrencyTextBox234.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox234.TabIndex = 234;
this.solvencyCurrencyTextBox234.ColName = "R0260C0170";
this.solvencyCurrencyTextBox234.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox235
//
this.solvencyCurrencyTextBox235.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox235.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox235.Location = new System.Drawing.Point(1722,340);
this.solvencyCurrencyTextBox235.Name = "solvencyCurrencyTextBox235";
this.solvencyCurrencyTextBox235.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox235.TabIndex = 235;
this.solvencyCurrencyTextBox235.ColName = "R0260C0180";
this.solvencyCurrencyTextBox235.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox236
//
this.solvencyCurrencyTextBox236.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox236.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox236.Location = new System.Drawing.Point(10,360);
this.solvencyCurrencyTextBox236.Name = "solvencyCurrencyTextBox236";
this.solvencyCurrencyTextBox236.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox236.TabIndex = 236;
this.solvencyCurrencyTextBox236.ColName = "R0270C0020";
this.solvencyCurrencyTextBox236.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox237
//
this.solvencyCurrencyTextBox237.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox237.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox237.Location = new System.Drawing.Point(117,360);
this.solvencyCurrencyTextBox237.Name = "solvencyCurrencyTextBox237";
this.solvencyCurrencyTextBox237.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox237.TabIndex = 237;
this.solvencyCurrencyTextBox237.ColName = "R0270C0030";
this.solvencyCurrencyTextBox237.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox238
//
this.solvencyCurrencyTextBox238.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox238.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox238.Location = new System.Drawing.Point(224,360);
this.solvencyCurrencyTextBox238.Name = "solvencyCurrencyTextBox238";
this.solvencyCurrencyTextBox238.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox238.TabIndex = 238;
this.solvencyCurrencyTextBox238.ColName = "R0270C0040";
this.solvencyCurrencyTextBox238.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox239
//
this.solvencyCurrencyTextBox239.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox239.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox239.Location = new System.Drawing.Point(331,360);
this.solvencyCurrencyTextBox239.Name = "solvencyCurrencyTextBox239";
this.solvencyCurrencyTextBox239.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox239.TabIndex = 239;
this.solvencyCurrencyTextBox239.ColName = "R0270C0050";
this.solvencyCurrencyTextBox239.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox240
//
this.solvencyCurrencyTextBox240.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox240.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox240.Location = new System.Drawing.Point(438,360);
this.solvencyCurrencyTextBox240.Name = "solvencyCurrencyTextBox240";
this.solvencyCurrencyTextBox240.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox240.TabIndex = 240;
this.solvencyCurrencyTextBox240.ColName = "R0270C0060";
this.solvencyCurrencyTextBox240.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox241
//
this.solvencyCurrencyTextBox241.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox241.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox241.Location = new System.Drawing.Point(545,360);
this.solvencyCurrencyTextBox241.Name = "solvencyCurrencyTextBox241";
this.solvencyCurrencyTextBox241.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox241.TabIndex = 241;
this.solvencyCurrencyTextBox241.ColName = "R0270C0070";
this.solvencyCurrencyTextBox241.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox242
//
this.solvencyCurrencyTextBox242.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox242.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox242.Location = new System.Drawing.Point(652,360);
this.solvencyCurrencyTextBox242.Name = "solvencyCurrencyTextBox242";
this.solvencyCurrencyTextBox242.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox242.TabIndex = 242;
this.solvencyCurrencyTextBox242.ColName = "R0270C0080";
this.solvencyCurrencyTextBox242.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox243
//
this.solvencyCurrencyTextBox243.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox243.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox243.Location = new System.Drawing.Point(759,360);
this.solvencyCurrencyTextBox243.Name = "solvencyCurrencyTextBox243";
this.solvencyCurrencyTextBox243.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox243.TabIndex = 243;
this.solvencyCurrencyTextBox243.ColName = "R0270C0090";
this.solvencyCurrencyTextBox243.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox244
//
this.solvencyCurrencyTextBox244.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox244.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox244.Location = new System.Drawing.Point(866,360);
this.solvencyCurrencyTextBox244.Name = "solvencyCurrencyTextBox244";
this.solvencyCurrencyTextBox244.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox244.TabIndex = 244;
this.solvencyCurrencyTextBox244.ColName = "R0270C0100";
this.solvencyCurrencyTextBox244.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox245
//
this.solvencyCurrencyTextBox245.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox245.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox245.Location = new System.Drawing.Point(973,360);
this.solvencyCurrencyTextBox245.Name = "solvencyCurrencyTextBox245";
this.solvencyCurrencyTextBox245.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox245.TabIndex = 245;
this.solvencyCurrencyTextBox245.ColName = "R0270C0110";
this.solvencyCurrencyTextBox245.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox246
//
this.solvencyCurrencyTextBox246.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox246.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox246.Location = new System.Drawing.Point(1080,360);
this.solvencyCurrencyTextBox246.Name = "solvencyCurrencyTextBox246";
this.solvencyCurrencyTextBox246.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox246.TabIndex = 246;
this.solvencyCurrencyTextBox246.ColName = "R0270C0120";
this.solvencyCurrencyTextBox246.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox247
//
this.solvencyCurrencyTextBox247.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox247.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox247.Location = new System.Drawing.Point(1187,360);
this.solvencyCurrencyTextBox247.Name = "solvencyCurrencyTextBox247";
this.solvencyCurrencyTextBox247.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox247.TabIndex = 247;
this.solvencyCurrencyTextBox247.ColName = "R0270C0130";
this.solvencyCurrencyTextBox247.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox248
//
this.solvencyCurrencyTextBox248.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox248.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox248.Location = new System.Drawing.Point(1294,360);
this.solvencyCurrencyTextBox248.Name = "solvencyCurrencyTextBox248";
this.solvencyCurrencyTextBox248.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox248.TabIndex = 248;
this.solvencyCurrencyTextBox248.ColName = "R0270C0140";
this.solvencyCurrencyTextBox248.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox249
//
this.solvencyCurrencyTextBox249.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox249.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox249.Location = new System.Drawing.Point(1401,360);
this.solvencyCurrencyTextBox249.Name = "solvencyCurrencyTextBox249";
this.solvencyCurrencyTextBox249.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox249.TabIndex = 249;
this.solvencyCurrencyTextBox249.ColName = "R0270C0150";
this.solvencyCurrencyTextBox249.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox250
//
this.solvencyCurrencyTextBox250.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox250.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox250.Location = new System.Drawing.Point(1508,360);
this.solvencyCurrencyTextBox250.Name = "solvencyCurrencyTextBox250";
this.solvencyCurrencyTextBox250.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox250.TabIndex = 250;
this.solvencyCurrencyTextBox250.ColName = "R0270C0160";
this.solvencyCurrencyTextBox250.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox251
//
this.solvencyCurrencyTextBox251.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox251.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox251.Location = new System.Drawing.Point(1615,360);
this.solvencyCurrencyTextBox251.Name = "solvencyCurrencyTextBox251";
this.solvencyCurrencyTextBox251.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox251.TabIndex = 251;
this.solvencyCurrencyTextBox251.ColName = "R0270C0170";
this.solvencyCurrencyTextBox251.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox252
//
this.solvencyCurrencyTextBox252.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox252.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox252.Location = new System.Drawing.Point(1722,360);
this.solvencyCurrencyTextBox252.Name = "solvencyCurrencyTextBox252";
this.solvencyCurrencyTextBox252.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox252.TabIndex = 252;
this.solvencyCurrencyTextBox252.ColName = "R0270C0180";
this.solvencyCurrencyTextBox252.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox253
//
this.solvencyCurrencyTextBox253.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox253.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox253.Location = new System.Drawing.Point(10,380);
this.solvencyCurrencyTextBox253.Name = "solvencyCurrencyTextBox253";
this.solvencyCurrencyTextBox253.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox253.TabIndex = 253;
this.solvencyCurrencyTextBox253.ColName = "R0280C0020";
this.solvencyCurrencyTextBox253.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox254
//
this.solvencyCurrencyTextBox254.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox254.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox254.Location = new System.Drawing.Point(117,380);
this.solvencyCurrencyTextBox254.Name = "solvencyCurrencyTextBox254";
this.solvencyCurrencyTextBox254.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox254.TabIndex = 254;
this.solvencyCurrencyTextBox254.ColName = "R0280C0030";
this.solvencyCurrencyTextBox254.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox255
//
this.solvencyCurrencyTextBox255.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox255.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox255.Location = new System.Drawing.Point(224,380);
this.solvencyCurrencyTextBox255.Name = "solvencyCurrencyTextBox255";
this.solvencyCurrencyTextBox255.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox255.TabIndex = 255;
this.solvencyCurrencyTextBox255.ColName = "R0280C0040";
this.solvencyCurrencyTextBox255.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox256
//
this.solvencyCurrencyTextBox256.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox256.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox256.Location = new System.Drawing.Point(331,380);
this.solvencyCurrencyTextBox256.Name = "solvencyCurrencyTextBox256";
this.solvencyCurrencyTextBox256.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox256.TabIndex = 256;
this.solvencyCurrencyTextBox256.ColName = "R0280C0050";
this.solvencyCurrencyTextBox256.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox257
//
this.solvencyCurrencyTextBox257.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox257.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox257.Location = new System.Drawing.Point(438,380);
this.solvencyCurrencyTextBox257.Name = "solvencyCurrencyTextBox257";
this.solvencyCurrencyTextBox257.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox257.TabIndex = 257;
this.solvencyCurrencyTextBox257.ColName = "R0280C0060";
this.solvencyCurrencyTextBox257.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox258
//
this.solvencyCurrencyTextBox258.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox258.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox258.Location = new System.Drawing.Point(545,380);
this.solvencyCurrencyTextBox258.Name = "solvencyCurrencyTextBox258";
this.solvencyCurrencyTextBox258.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox258.TabIndex = 258;
this.solvencyCurrencyTextBox258.ColName = "R0280C0070";
this.solvencyCurrencyTextBox258.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox259
//
this.solvencyCurrencyTextBox259.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox259.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox259.Location = new System.Drawing.Point(652,380);
this.solvencyCurrencyTextBox259.Name = "solvencyCurrencyTextBox259";
this.solvencyCurrencyTextBox259.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox259.TabIndex = 259;
this.solvencyCurrencyTextBox259.ColName = "R0280C0080";
this.solvencyCurrencyTextBox259.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox260
//
this.solvencyCurrencyTextBox260.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox260.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox260.Location = new System.Drawing.Point(759,380);
this.solvencyCurrencyTextBox260.Name = "solvencyCurrencyTextBox260";
this.solvencyCurrencyTextBox260.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox260.TabIndex = 260;
this.solvencyCurrencyTextBox260.ColName = "R0280C0090";
this.solvencyCurrencyTextBox260.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox261
//
this.solvencyCurrencyTextBox261.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox261.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox261.Location = new System.Drawing.Point(866,380);
this.solvencyCurrencyTextBox261.Name = "solvencyCurrencyTextBox261";
this.solvencyCurrencyTextBox261.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox261.TabIndex = 261;
this.solvencyCurrencyTextBox261.ColName = "R0280C0100";
this.solvencyCurrencyTextBox261.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox262
//
this.solvencyCurrencyTextBox262.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox262.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox262.Location = new System.Drawing.Point(973,380);
this.solvencyCurrencyTextBox262.Name = "solvencyCurrencyTextBox262";
this.solvencyCurrencyTextBox262.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox262.TabIndex = 262;
this.solvencyCurrencyTextBox262.ColName = "R0280C0110";
this.solvencyCurrencyTextBox262.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox263
//
this.solvencyCurrencyTextBox263.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox263.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox263.Location = new System.Drawing.Point(1080,380);
this.solvencyCurrencyTextBox263.Name = "solvencyCurrencyTextBox263";
this.solvencyCurrencyTextBox263.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox263.TabIndex = 263;
this.solvencyCurrencyTextBox263.ColName = "R0280C0120";
this.solvencyCurrencyTextBox263.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox264
//
this.solvencyCurrencyTextBox264.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox264.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox264.Location = new System.Drawing.Point(1187,380);
this.solvencyCurrencyTextBox264.Name = "solvencyCurrencyTextBox264";
this.solvencyCurrencyTextBox264.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox264.TabIndex = 264;
this.solvencyCurrencyTextBox264.ColName = "R0280C0130";
this.solvencyCurrencyTextBox264.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox265
//
this.solvencyCurrencyTextBox265.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox265.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox265.Location = new System.Drawing.Point(1294,380);
this.solvencyCurrencyTextBox265.Name = "solvencyCurrencyTextBox265";
this.solvencyCurrencyTextBox265.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox265.TabIndex = 265;
this.solvencyCurrencyTextBox265.ColName = "R0280C0140";
this.solvencyCurrencyTextBox265.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox266
//
this.solvencyCurrencyTextBox266.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox266.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox266.Location = new System.Drawing.Point(1401,380);
this.solvencyCurrencyTextBox266.Name = "solvencyCurrencyTextBox266";
this.solvencyCurrencyTextBox266.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox266.TabIndex = 266;
this.solvencyCurrencyTextBox266.ColName = "R0280C0150";
this.solvencyCurrencyTextBox266.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox267
//
this.solvencyCurrencyTextBox267.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox267.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox267.Location = new System.Drawing.Point(1508,380);
this.solvencyCurrencyTextBox267.Name = "solvencyCurrencyTextBox267";
this.solvencyCurrencyTextBox267.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox267.TabIndex = 267;
this.solvencyCurrencyTextBox267.ColName = "R0280C0160";
this.solvencyCurrencyTextBox267.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox268
//
this.solvencyCurrencyTextBox268.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox268.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox268.Location = new System.Drawing.Point(1615,380);
this.solvencyCurrencyTextBox268.Name = "solvencyCurrencyTextBox268";
this.solvencyCurrencyTextBox268.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox268.TabIndex = 268;
this.solvencyCurrencyTextBox268.ColName = "R0280C0170";
this.solvencyCurrencyTextBox268.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox269
//
this.solvencyCurrencyTextBox269.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox269.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox269.Location = new System.Drawing.Point(1722,380);
this.solvencyCurrencyTextBox269.Name = "solvencyCurrencyTextBox269";
this.solvencyCurrencyTextBox269.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox269.TabIndex = 269;
this.solvencyCurrencyTextBox269.ColName = "R0280C0180";
this.solvencyCurrencyTextBox269.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox270
//
this.solvencyCurrencyTextBox270.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox270.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox270.Location = new System.Drawing.Point(10,420);
this.solvencyCurrencyTextBox270.Name = "solvencyCurrencyTextBox270";
this.solvencyCurrencyTextBox270.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox270.TabIndex = 270;
this.solvencyCurrencyTextBox270.ColName = "R0290C0020";
this.solvencyCurrencyTextBox270.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox271
//
this.solvencyCurrencyTextBox271.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox271.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox271.Location = new System.Drawing.Point(117,420);
this.solvencyCurrencyTextBox271.Name = "solvencyCurrencyTextBox271";
this.solvencyCurrencyTextBox271.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox271.TabIndex = 271;
this.solvencyCurrencyTextBox271.ColName = "R0290C0030";
this.solvencyCurrencyTextBox271.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox272
//
this.solvencyCurrencyTextBox272.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox272.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox272.Location = new System.Drawing.Point(224,420);
this.solvencyCurrencyTextBox272.Name = "solvencyCurrencyTextBox272";
this.solvencyCurrencyTextBox272.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox272.TabIndex = 272;
this.solvencyCurrencyTextBox272.ColName = "R0290C0040";
this.solvencyCurrencyTextBox272.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox273
//
this.solvencyCurrencyTextBox273.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox273.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox273.Location = new System.Drawing.Point(331,420);
this.solvencyCurrencyTextBox273.Name = "solvencyCurrencyTextBox273";
this.solvencyCurrencyTextBox273.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox273.TabIndex = 273;
this.solvencyCurrencyTextBox273.ColName = "R0290C0050";
this.solvencyCurrencyTextBox273.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox274
//
this.solvencyCurrencyTextBox274.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox274.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox274.Location = new System.Drawing.Point(438,420);
this.solvencyCurrencyTextBox274.Name = "solvencyCurrencyTextBox274";
this.solvencyCurrencyTextBox274.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox274.TabIndex = 274;
this.solvencyCurrencyTextBox274.ColName = "R0290C0060";
this.solvencyCurrencyTextBox274.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox275
//
this.solvencyCurrencyTextBox275.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox275.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox275.Location = new System.Drawing.Point(545,420);
this.solvencyCurrencyTextBox275.Name = "solvencyCurrencyTextBox275";
this.solvencyCurrencyTextBox275.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox275.TabIndex = 275;
this.solvencyCurrencyTextBox275.ColName = "R0290C0070";
this.solvencyCurrencyTextBox275.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox276
//
this.solvencyCurrencyTextBox276.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox276.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox276.Location = new System.Drawing.Point(652,420);
this.solvencyCurrencyTextBox276.Name = "solvencyCurrencyTextBox276";
this.solvencyCurrencyTextBox276.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox276.TabIndex = 276;
this.solvencyCurrencyTextBox276.ColName = "R0290C0080";
this.solvencyCurrencyTextBox276.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox277
//
this.solvencyCurrencyTextBox277.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox277.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox277.Location = new System.Drawing.Point(759,420);
this.solvencyCurrencyTextBox277.Name = "solvencyCurrencyTextBox277";
this.solvencyCurrencyTextBox277.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox277.TabIndex = 277;
this.solvencyCurrencyTextBox277.ColName = "R0290C0090";
this.solvencyCurrencyTextBox277.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox278
//
this.solvencyCurrencyTextBox278.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox278.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox278.Location = new System.Drawing.Point(866,420);
this.solvencyCurrencyTextBox278.Name = "solvencyCurrencyTextBox278";
this.solvencyCurrencyTextBox278.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox278.TabIndex = 278;
this.solvencyCurrencyTextBox278.ColName = "R0290C0100";
this.solvencyCurrencyTextBox278.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox279
//
this.solvencyCurrencyTextBox279.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox279.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox279.Location = new System.Drawing.Point(973,420);
this.solvencyCurrencyTextBox279.Name = "solvencyCurrencyTextBox279";
this.solvencyCurrencyTextBox279.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox279.TabIndex = 279;
this.solvencyCurrencyTextBox279.ColName = "R0290C0110";
this.solvencyCurrencyTextBox279.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox280
//
this.solvencyCurrencyTextBox280.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox280.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox280.Location = new System.Drawing.Point(1080,420);
this.solvencyCurrencyTextBox280.Name = "solvencyCurrencyTextBox280";
this.solvencyCurrencyTextBox280.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox280.TabIndex = 280;
this.solvencyCurrencyTextBox280.ColName = "R0290C0120";
this.solvencyCurrencyTextBox280.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox281
//
this.solvencyCurrencyTextBox281.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox281.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox281.Location = new System.Drawing.Point(1187,420);
this.solvencyCurrencyTextBox281.Name = "solvencyCurrencyTextBox281";
this.solvencyCurrencyTextBox281.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox281.TabIndex = 281;
this.solvencyCurrencyTextBox281.ColName = "R0290C0130";
this.solvencyCurrencyTextBox281.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox282
//
this.solvencyCurrencyTextBox282.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox282.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox282.Location = new System.Drawing.Point(1294,420);
this.solvencyCurrencyTextBox282.Name = "solvencyCurrencyTextBox282";
this.solvencyCurrencyTextBox282.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox282.TabIndex = 282;
this.solvencyCurrencyTextBox282.ColName = "R0290C0140";
this.solvencyCurrencyTextBox282.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox283
//
this.solvencyCurrencyTextBox283.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox283.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox283.Location = new System.Drawing.Point(1401,420);
this.solvencyCurrencyTextBox283.Name = "solvencyCurrencyTextBox283";
this.solvencyCurrencyTextBox283.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox283.TabIndex = 283;
this.solvencyCurrencyTextBox283.ColName = "R0290C0150";
this.solvencyCurrencyTextBox283.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox284
//
this.solvencyCurrencyTextBox284.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox284.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox284.Location = new System.Drawing.Point(1508,420);
this.solvencyCurrencyTextBox284.Name = "solvencyCurrencyTextBox284";
this.solvencyCurrencyTextBox284.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox284.TabIndex = 284;
this.solvencyCurrencyTextBox284.ColName = "R0290C0160";
this.solvencyCurrencyTextBox284.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox285
//
this.solvencyCurrencyTextBox285.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox285.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox285.Location = new System.Drawing.Point(1615,420);
this.solvencyCurrencyTextBox285.Name = "solvencyCurrencyTextBox285";
this.solvencyCurrencyTextBox285.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox285.TabIndex = 285;
this.solvencyCurrencyTextBox285.ColName = "R0290C0170";
this.solvencyCurrencyTextBox285.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox286
//
this.solvencyCurrencyTextBox286.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox286.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox286.Location = new System.Drawing.Point(1722,420);
this.solvencyCurrencyTextBox286.Name = "solvencyCurrencyTextBox286";
this.solvencyCurrencyTextBox286.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox286.TabIndex = 286;
this.solvencyCurrencyTextBox286.ColName = "R0290C0180";
this.solvencyCurrencyTextBox286.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox287
//
this.solvencyCurrencyTextBox287.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox287.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox287.Location = new System.Drawing.Point(10,440);
this.solvencyCurrencyTextBox287.Name = "solvencyCurrencyTextBox287";
this.solvencyCurrencyTextBox287.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox287.TabIndex = 287;
this.solvencyCurrencyTextBox287.ColName = "R0300C0020";
this.solvencyCurrencyTextBox287.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox288
//
this.solvencyCurrencyTextBox288.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox288.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox288.Location = new System.Drawing.Point(117,440);
this.solvencyCurrencyTextBox288.Name = "solvencyCurrencyTextBox288";
this.solvencyCurrencyTextBox288.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox288.TabIndex = 288;
this.solvencyCurrencyTextBox288.ColName = "R0300C0030";
this.solvencyCurrencyTextBox288.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox289
//
this.solvencyCurrencyTextBox289.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox289.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox289.Location = new System.Drawing.Point(224,440);
this.solvencyCurrencyTextBox289.Name = "solvencyCurrencyTextBox289";
this.solvencyCurrencyTextBox289.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox289.TabIndex = 289;
this.solvencyCurrencyTextBox289.ColName = "R0300C0040";
this.solvencyCurrencyTextBox289.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox290
//
this.solvencyCurrencyTextBox290.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox290.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox290.Location = new System.Drawing.Point(331,440);
this.solvencyCurrencyTextBox290.Name = "solvencyCurrencyTextBox290";
this.solvencyCurrencyTextBox290.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox290.TabIndex = 290;
this.solvencyCurrencyTextBox290.ColName = "R0300C0050";
this.solvencyCurrencyTextBox290.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox291
//
this.solvencyCurrencyTextBox291.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox291.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox291.Location = new System.Drawing.Point(438,440);
this.solvencyCurrencyTextBox291.Name = "solvencyCurrencyTextBox291";
this.solvencyCurrencyTextBox291.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox291.TabIndex = 291;
this.solvencyCurrencyTextBox291.ColName = "R0300C0060";
this.solvencyCurrencyTextBox291.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox292
//
this.solvencyCurrencyTextBox292.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox292.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox292.Location = new System.Drawing.Point(545,440);
this.solvencyCurrencyTextBox292.Name = "solvencyCurrencyTextBox292";
this.solvencyCurrencyTextBox292.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox292.TabIndex = 292;
this.solvencyCurrencyTextBox292.ColName = "R0300C0070";
this.solvencyCurrencyTextBox292.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox293
//
this.solvencyCurrencyTextBox293.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox293.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox293.Location = new System.Drawing.Point(652,440);
this.solvencyCurrencyTextBox293.Name = "solvencyCurrencyTextBox293";
this.solvencyCurrencyTextBox293.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox293.TabIndex = 293;
this.solvencyCurrencyTextBox293.ColName = "R0300C0080";
this.solvencyCurrencyTextBox293.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox294
//
this.solvencyCurrencyTextBox294.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox294.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox294.Location = new System.Drawing.Point(759,440);
this.solvencyCurrencyTextBox294.Name = "solvencyCurrencyTextBox294";
this.solvencyCurrencyTextBox294.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox294.TabIndex = 294;
this.solvencyCurrencyTextBox294.ColName = "R0300C0090";
this.solvencyCurrencyTextBox294.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox295
//
this.solvencyCurrencyTextBox295.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox295.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox295.Location = new System.Drawing.Point(866,440);
this.solvencyCurrencyTextBox295.Name = "solvencyCurrencyTextBox295";
this.solvencyCurrencyTextBox295.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox295.TabIndex = 295;
this.solvencyCurrencyTextBox295.ColName = "R0300C0100";
this.solvencyCurrencyTextBox295.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox296
//
this.solvencyCurrencyTextBox296.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox296.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox296.Location = new System.Drawing.Point(973,440);
this.solvencyCurrencyTextBox296.Name = "solvencyCurrencyTextBox296";
this.solvencyCurrencyTextBox296.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox296.TabIndex = 296;
this.solvencyCurrencyTextBox296.ColName = "R0300C0110";
this.solvencyCurrencyTextBox296.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox297
//
this.solvencyCurrencyTextBox297.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox297.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox297.Location = new System.Drawing.Point(1080,440);
this.solvencyCurrencyTextBox297.Name = "solvencyCurrencyTextBox297";
this.solvencyCurrencyTextBox297.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox297.TabIndex = 297;
this.solvencyCurrencyTextBox297.ColName = "R0300C0120";
this.solvencyCurrencyTextBox297.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox298
//
this.solvencyCurrencyTextBox298.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox298.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox298.Location = new System.Drawing.Point(1187,440);
this.solvencyCurrencyTextBox298.Name = "solvencyCurrencyTextBox298";
this.solvencyCurrencyTextBox298.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox298.TabIndex = 298;
this.solvencyCurrencyTextBox298.ColName = "R0300C0130";
this.solvencyCurrencyTextBox298.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox299
//
this.solvencyCurrencyTextBox299.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox299.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox299.Location = new System.Drawing.Point(1294,440);
this.solvencyCurrencyTextBox299.Name = "solvencyCurrencyTextBox299";
this.solvencyCurrencyTextBox299.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox299.TabIndex = 299;
this.solvencyCurrencyTextBox299.ColName = "R0300C0140";
this.solvencyCurrencyTextBox299.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox300
//
this.solvencyCurrencyTextBox300.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox300.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox300.Location = new System.Drawing.Point(1401,440);
this.solvencyCurrencyTextBox300.Name = "solvencyCurrencyTextBox300";
this.solvencyCurrencyTextBox300.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox300.TabIndex = 300;
this.solvencyCurrencyTextBox300.ColName = "R0300C0150";
this.solvencyCurrencyTextBox300.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox301
//
this.solvencyCurrencyTextBox301.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox301.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox301.Location = new System.Drawing.Point(1508,440);
this.solvencyCurrencyTextBox301.Name = "solvencyCurrencyTextBox301";
this.solvencyCurrencyTextBox301.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox301.TabIndex = 301;
this.solvencyCurrencyTextBox301.ColName = "R0300C0160";
this.solvencyCurrencyTextBox301.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox302
//
this.solvencyCurrencyTextBox302.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox302.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox302.Location = new System.Drawing.Point(1615,440);
this.solvencyCurrencyTextBox302.Name = "solvencyCurrencyTextBox302";
this.solvencyCurrencyTextBox302.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox302.TabIndex = 302;
this.solvencyCurrencyTextBox302.ColName = "R0300C0170";
this.solvencyCurrencyTextBox302.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox303
//
this.solvencyCurrencyTextBox303.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox303.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox303.Location = new System.Drawing.Point(1722,440);
this.solvencyCurrencyTextBox303.Name = "solvencyCurrencyTextBox303";
this.solvencyCurrencyTextBox303.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox303.TabIndex = 303;
this.solvencyCurrencyTextBox303.ColName = "R0300C0180";
this.solvencyCurrencyTextBox303.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox304
//
this.solvencyCurrencyTextBox304.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox304.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox304.Location = new System.Drawing.Point(10,460);
this.solvencyCurrencyTextBox304.Name = "solvencyCurrencyTextBox304";
this.solvencyCurrencyTextBox304.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox304.TabIndex = 304;
this.solvencyCurrencyTextBox304.ColName = "R0310C0020";
this.solvencyCurrencyTextBox304.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox305
//
this.solvencyCurrencyTextBox305.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox305.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox305.Location = new System.Drawing.Point(117,460);
this.solvencyCurrencyTextBox305.Name = "solvencyCurrencyTextBox305";
this.solvencyCurrencyTextBox305.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox305.TabIndex = 305;
this.solvencyCurrencyTextBox305.ColName = "R0310C0030";
this.solvencyCurrencyTextBox305.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox306
//
this.solvencyCurrencyTextBox306.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox306.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox306.Location = new System.Drawing.Point(224,460);
this.solvencyCurrencyTextBox306.Name = "solvencyCurrencyTextBox306";
this.solvencyCurrencyTextBox306.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox306.TabIndex = 306;
this.solvencyCurrencyTextBox306.ColName = "R0310C0040";
this.solvencyCurrencyTextBox306.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox307
//
this.solvencyCurrencyTextBox307.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox307.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox307.Location = new System.Drawing.Point(331,460);
this.solvencyCurrencyTextBox307.Name = "solvencyCurrencyTextBox307";
this.solvencyCurrencyTextBox307.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox307.TabIndex = 307;
this.solvencyCurrencyTextBox307.ColName = "R0310C0050";
this.solvencyCurrencyTextBox307.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox308
//
this.solvencyCurrencyTextBox308.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox308.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox308.Location = new System.Drawing.Point(438,460);
this.solvencyCurrencyTextBox308.Name = "solvencyCurrencyTextBox308";
this.solvencyCurrencyTextBox308.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox308.TabIndex = 308;
this.solvencyCurrencyTextBox308.ColName = "R0310C0060";
this.solvencyCurrencyTextBox308.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox309
//
this.solvencyCurrencyTextBox309.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox309.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox309.Location = new System.Drawing.Point(545,460);
this.solvencyCurrencyTextBox309.Name = "solvencyCurrencyTextBox309";
this.solvencyCurrencyTextBox309.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox309.TabIndex = 309;
this.solvencyCurrencyTextBox309.ColName = "R0310C0070";
this.solvencyCurrencyTextBox309.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox310
//
this.solvencyCurrencyTextBox310.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox310.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox310.Location = new System.Drawing.Point(652,460);
this.solvencyCurrencyTextBox310.Name = "solvencyCurrencyTextBox310";
this.solvencyCurrencyTextBox310.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox310.TabIndex = 310;
this.solvencyCurrencyTextBox310.ColName = "R0310C0080";
this.solvencyCurrencyTextBox310.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox311
//
this.solvencyCurrencyTextBox311.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox311.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox311.Location = new System.Drawing.Point(759,460);
this.solvencyCurrencyTextBox311.Name = "solvencyCurrencyTextBox311";
this.solvencyCurrencyTextBox311.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox311.TabIndex = 311;
this.solvencyCurrencyTextBox311.ColName = "R0310C0090";
this.solvencyCurrencyTextBox311.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox312
//
this.solvencyCurrencyTextBox312.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox312.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox312.Location = new System.Drawing.Point(866,460);
this.solvencyCurrencyTextBox312.Name = "solvencyCurrencyTextBox312";
this.solvencyCurrencyTextBox312.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox312.TabIndex = 312;
this.solvencyCurrencyTextBox312.ColName = "R0310C0100";
this.solvencyCurrencyTextBox312.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox313
//
this.solvencyCurrencyTextBox313.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox313.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox313.Location = new System.Drawing.Point(973,460);
this.solvencyCurrencyTextBox313.Name = "solvencyCurrencyTextBox313";
this.solvencyCurrencyTextBox313.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox313.TabIndex = 313;
this.solvencyCurrencyTextBox313.ColName = "R0310C0110";
this.solvencyCurrencyTextBox313.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox314
//
this.solvencyCurrencyTextBox314.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox314.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox314.Location = new System.Drawing.Point(1080,460);
this.solvencyCurrencyTextBox314.Name = "solvencyCurrencyTextBox314";
this.solvencyCurrencyTextBox314.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox314.TabIndex = 314;
this.solvencyCurrencyTextBox314.ColName = "R0310C0120";
this.solvencyCurrencyTextBox314.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox315
//
this.solvencyCurrencyTextBox315.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox315.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox315.Location = new System.Drawing.Point(1187,460);
this.solvencyCurrencyTextBox315.Name = "solvencyCurrencyTextBox315";
this.solvencyCurrencyTextBox315.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox315.TabIndex = 315;
this.solvencyCurrencyTextBox315.ColName = "R0310C0130";
this.solvencyCurrencyTextBox315.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox316
//
this.solvencyCurrencyTextBox316.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox316.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox316.Location = new System.Drawing.Point(1294,460);
this.solvencyCurrencyTextBox316.Name = "solvencyCurrencyTextBox316";
this.solvencyCurrencyTextBox316.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox316.TabIndex = 316;
this.solvencyCurrencyTextBox316.ColName = "R0310C0140";
this.solvencyCurrencyTextBox316.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox317
//
this.solvencyCurrencyTextBox317.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox317.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox317.Location = new System.Drawing.Point(1401,460);
this.solvencyCurrencyTextBox317.Name = "solvencyCurrencyTextBox317";
this.solvencyCurrencyTextBox317.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox317.TabIndex = 317;
this.solvencyCurrencyTextBox317.ColName = "R0310C0150";
this.solvencyCurrencyTextBox317.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox318
//
this.solvencyCurrencyTextBox318.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox318.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox318.Location = new System.Drawing.Point(1508,460);
this.solvencyCurrencyTextBox318.Name = "solvencyCurrencyTextBox318";
this.solvencyCurrencyTextBox318.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox318.TabIndex = 318;
this.solvencyCurrencyTextBox318.ColName = "R0310C0160";
this.solvencyCurrencyTextBox318.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox319
//
this.solvencyCurrencyTextBox319.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox319.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox319.Location = new System.Drawing.Point(1615,460);
this.solvencyCurrencyTextBox319.Name = "solvencyCurrencyTextBox319";
this.solvencyCurrencyTextBox319.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox319.TabIndex = 319;
this.solvencyCurrencyTextBox319.ColName = "R0310C0170";
this.solvencyCurrencyTextBox319.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox320
//
this.solvencyCurrencyTextBox320.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox320.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox320.Location = new System.Drawing.Point(1722,460);
this.solvencyCurrencyTextBox320.Name = "solvencyCurrencyTextBox320";
this.solvencyCurrencyTextBox320.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox320.TabIndex = 320;
this.solvencyCurrencyTextBox320.ColName = "R0310C0180";
this.solvencyCurrencyTextBox320.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox321
//
this.solvencyCurrencyTextBox321.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox321.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox321.Location = new System.Drawing.Point(10,500);
this.solvencyCurrencyTextBox321.Name = "solvencyCurrencyTextBox321";
this.solvencyCurrencyTextBox321.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox321.TabIndex = 321;
this.solvencyCurrencyTextBox321.ColName = "R0320C0020";
this.solvencyCurrencyTextBox321.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox322
//
this.solvencyCurrencyTextBox322.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox322.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox322.Location = new System.Drawing.Point(117,500);
this.solvencyCurrencyTextBox322.Name = "solvencyCurrencyTextBox322";
this.solvencyCurrencyTextBox322.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox322.TabIndex = 322;
this.solvencyCurrencyTextBox322.ColName = "R0320C0030";
this.solvencyCurrencyTextBox322.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox323
//
this.solvencyCurrencyTextBox323.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox323.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox323.Location = new System.Drawing.Point(224,500);
this.solvencyCurrencyTextBox323.Name = "solvencyCurrencyTextBox323";
this.solvencyCurrencyTextBox323.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox323.TabIndex = 323;
this.solvencyCurrencyTextBox323.ColName = "R0320C0040";
this.solvencyCurrencyTextBox323.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox324
//
this.solvencyCurrencyTextBox324.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox324.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox324.Location = new System.Drawing.Point(331,500);
this.solvencyCurrencyTextBox324.Name = "solvencyCurrencyTextBox324";
this.solvencyCurrencyTextBox324.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox324.TabIndex = 324;
this.solvencyCurrencyTextBox324.ColName = "R0320C0050";
this.solvencyCurrencyTextBox324.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox325
//
this.solvencyCurrencyTextBox325.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox325.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox325.Location = new System.Drawing.Point(438,500);
this.solvencyCurrencyTextBox325.Name = "solvencyCurrencyTextBox325";
this.solvencyCurrencyTextBox325.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox325.TabIndex = 325;
this.solvencyCurrencyTextBox325.ColName = "R0320C0060";
this.solvencyCurrencyTextBox325.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox326
//
this.solvencyCurrencyTextBox326.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox326.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox326.Location = new System.Drawing.Point(545,500);
this.solvencyCurrencyTextBox326.Name = "solvencyCurrencyTextBox326";
this.solvencyCurrencyTextBox326.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox326.TabIndex = 326;
this.solvencyCurrencyTextBox326.ColName = "R0320C0070";
this.solvencyCurrencyTextBox326.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox327
//
this.solvencyCurrencyTextBox327.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox327.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox327.Location = new System.Drawing.Point(652,500);
this.solvencyCurrencyTextBox327.Name = "solvencyCurrencyTextBox327";
this.solvencyCurrencyTextBox327.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox327.TabIndex = 327;
this.solvencyCurrencyTextBox327.ColName = "R0320C0080";
this.solvencyCurrencyTextBox327.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox328
//
this.solvencyCurrencyTextBox328.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox328.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox328.Location = new System.Drawing.Point(759,500);
this.solvencyCurrencyTextBox328.Name = "solvencyCurrencyTextBox328";
this.solvencyCurrencyTextBox328.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox328.TabIndex = 328;
this.solvencyCurrencyTextBox328.ColName = "R0320C0090";
this.solvencyCurrencyTextBox328.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox329
//
this.solvencyCurrencyTextBox329.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox329.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox329.Location = new System.Drawing.Point(866,500);
this.solvencyCurrencyTextBox329.Name = "solvencyCurrencyTextBox329";
this.solvencyCurrencyTextBox329.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox329.TabIndex = 329;
this.solvencyCurrencyTextBox329.ColName = "R0320C0100";
this.solvencyCurrencyTextBox329.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox330
//
this.solvencyCurrencyTextBox330.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox330.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox330.Location = new System.Drawing.Point(973,500);
this.solvencyCurrencyTextBox330.Name = "solvencyCurrencyTextBox330";
this.solvencyCurrencyTextBox330.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox330.TabIndex = 330;
this.solvencyCurrencyTextBox330.ColName = "R0320C0110";
this.solvencyCurrencyTextBox330.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox331
//
this.solvencyCurrencyTextBox331.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox331.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox331.Location = new System.Drawing.Point(1080,500);
this.solvencyCurrencyTextBox331.Name = "solvencyCurrencyTextBox331";
this.solvencyCurrencyTextBox331.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox331.TabIndex = 331;
this.solvencyCurrencyTextBox331.ColName = "R0320C0120";
this.solvencyCurrencyTextBox331.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox332
//
this.solvencyCurrencyTextBox332.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox332.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox332.Location = new System.Drawing.Point(1187,500);
this.solvencyCurrencyTextBox332.Name = "solvencyCurrencyTextBox332";
this.solvencyCurrencyTextBox332.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox332.TabIndex = 332;
this.solvencyCurrencyTextBox332.ColName = "R0320C0130";
this.solvencyCurrencyTextBox332.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox333
//
this.solvencyCurrencyTextBox333.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox333.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox333.Location = new System.Drawing.Point(1294,500);
this.solvencyCurrencyTextBox333.Name = "solvencyCurrencyTextBox333";
this.solvencyCurrencyTextBox333.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox333.TabIndex = 333;
this.solvencyCurrencyTextBox333.ColName = "R0320C0140";
this.solvencyCurrencyTextBox333.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox334
//
this.solvencyCurrencyTextBox334.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox334.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox334.Location = new System.Drawing.Point(1401,500);
this.solvencyCurrencyTextBox334.Name = "solvencyCurrencyTextBox334";
this.solvencyCurrencyTextBox334.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox334.TabIndex = 334;
this.solvencyCurrencyTextBox334.ColName = "R0320C0150";
this.solvencyCurrencyTextBox334.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox335
//
this.solvencyCurrencyTextBox335.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox335.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox335.Location = new System.Drawing.Point(1508,500);
this.solvencyCurrencyTextBox335.Name = "solvencyCurrencyTextBox335";
this.solvencyCurrencyTextBox335.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox335.TabIndex = 335;
this.solvencyCurrencyTextBox335.ColName = "R0320C0160";
this.solvencyCurrencyTextBox335.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox336
//
this.solvencyCurrencyTextBox336.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox336.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox336.Location = new System.Drawing.Point(1615,500);
this.solvencyCurrencyTextBox336.Name = "solvencyCurrencyTextBox336";
this.solvencyCurrencyTextBox336.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox336.TabIndex = 336;
this.solvencyCurrencyTextBox336.ColName = "R0320C0170";
this.solvencyCurrencyTextBox336.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox337
//
this.solvencyCurrencyTextBox337.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox337.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox337.Location = new System.Drawing.Point(1722,500);
this.solvencyCurrencyTextBox337.Name = "solvencyCurrencyTextBox337";
this.solvencyCurrencyTextBox337.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox337.TabIndex = 337;
this.solvencyCurrencyTextBox337.ColName = "R0320C0180";
this.solvencyCurrencyTextBox337.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox338
//
this.solvencyCurrencyTextBox338.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox338.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox338.Location = new System.Drawing.Point(10,520);
this.solvencyCurrencyTextBox338.Name = "solvencyCurrencyTextBox338";
this.solvencyCurrencyTextBox338.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox338.TabIndex = 338;
this.solvencyCurrencyTextBox338.ColName = "R0330C0020";
this.solvencyCurrencyTextBox338.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox339
//
this.solvencyCurrencyTextBox339.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox339.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox339.Location = new System.Drawing.Point(117,520);
this.solvencyCurrencyTextBox339.Name = "solvencyCurrencyTextBox339";
this.solvencyCurrencyTextBox339.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox339.TabIndex = 339;
this.solvencyCurrencyTextBox339.ColName = "R0330C0030";
this.solvencyCurrencyTextBox339.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox340
//
this.solvencyCurrencyTextBox340.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox340.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox340.Location = new System.Drawing.Point(224,520);
this.solvencyCurrencyTextBox340.Name = "solvencyCurrencyTextBox340";
this.solvencyCurrencyTextBox340.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox340.TabIndex = 340;
this.solvencyCurrencyTextBox340.ColName = "R0330C0040";
this.solvencyCurrencyTextBox340.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox341
//
this.solvencyCurrencyTextBox341.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox341.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox341.Location = new System.Drawing.Point(331,520);
this.solvencyCurrencyTextBox341.Name = "solvencyCurrencyTextBox341";
this.solvencyCurrencyTextBox341.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox341.TabIndex = 341;
this.solvencyCurrencyTextBox341.ColName = "R0330C0050";
this.solvencyCurrencyTextBox341.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox342
//
this.solvencyCurrencyTextBox342.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox342.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox342.Location = new System.Drawing.Point(438,520);
this.solvencyCurrencyTextBox342.Name = "solvencyCurrencyTextBox342";
this.solvencyCurrencyTextBox342.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox342.TabIndex = 342;
this.solvencyCurrencyTextBox342.ColName = "R0330C0060";
this.solvencyCurrencyTextBox342.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox343
//
this.solvencyCurrencyTextBox343.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox343.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox343.Location = new System.Drawing.Point(545,520);
this.solvencyCurrencyTextBox343.Name = "solvencyCurrencyTextBox343";
this.solvencyCurrencyTextBox343.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox343.TabIndex = 343;
this.solvencyCurrencyTextBox343.ColName = "R0330C0070";
this.solvencyCurrencyTextBox343.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox344
//
this.solvencyCurrencyTextBox344.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox344.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox344.Location = new System.Drawing.Point(652,520);
this.solvencyCurrencyTextBox344.Name = "solvencyCurrencyTextBox344";
this.solvencyCurrencyTextBox344.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox344.TabIndex = 344;
this.solvencyCurrencyTextBox344.ColName = "R0330C0080";
this.solvencyCurrencyTextBox344.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox345
//
this.solvencyCurrencyTextBox345.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox345.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox345.Location = new System.Drawing.Point(759,520);
this.solvencyCurrencyTextBox345.Name = "solvencyCurrencyTextBox345";
this.solvencyCurrencyTextBox345.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox345.TabIndex = 345;
this.solvencyCurrencyTextBox345.ColName = "R0330C0090";
this.solvencyCurrencyTextBox345.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox346
//
this.solvencyCurrencyTextBox346.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox346.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox346.Location = new System.Drawing.Point(866,520);
this.solvencyCurrencyTextBox346.Name = "solvencyCurrencyTextBox346";
this.solvencyCurrencyTextBox346.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox346.TabIndex = 346;
this.solvencyCurrencyTextBox346.ColName = "R0330C0100";
this.solvencyCurrencyTextBox346.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox347
//
this.solvencyCurrencyTextBox347.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox347.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox347.Location = new System.Drawing.Point(973,520);
this.solvencyCurrencyTextBox347.Name = "solvencyCurrencyTextBox347";
this.solvencyCurrencyTextBox347.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox347.TabIndex = 347;
this.solvencyCurrencyTextBox347.ColName = "R0330C0110";
this.solvencyCurrencyTextBox347.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox348
//
this.solvencyCurrencyTextBox348.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox348.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox348.Location = new System.Drawing.Point(1080,520);
this.solvencyCurrencyTextBox348.Name = "solvencyCurrencyTextBox348";
this.solvencyCurrencyTextBox348.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox348.TabIndex = 348;
this.solvencyCurrencyTextBox348.ColName = "R0330C0120";
this.solvencyCurrencyTextBox348.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox349
//
this.solvencyCurrencyTextBox349.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox349.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox349.Location = new System.Drawing.Point(1187,520);
this.solvencyCurrencyTextBox349.Name = "solvencyCurrencyTextBox349";
this.solvencyCurrencyTextBox349.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox349.TabIndex = 349;
this.solvencyCurrencyTextBox349.ColName = "R0330C0130";
this.solvencyCurrencyTextBox349.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox350
//
this.solvencyCurrencyTextBox350.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox350.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox350.Location = new System.Drawing.Point(1294,520);
this.solvencyCurrencyTextBox350.Name = "solvencyCurrencyTextBox350";
this.solvencyCurrencyTextBox350.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox350.TabIndex = 350;
this.solvencyCurrencyTextBox350.ColName = "R0330C0140";
this.solvencyCurrencyTextBox350.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox351
//
this.solvencyCurrencyTextBox351.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox351.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox351.Location = new System.Drawing.Point(1401,520);
this.solvencyCurrencyTextBox351.Name = "solvencyCurrencyTextBox351";
this.solvencyCurrencyTextBox351.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox351.TabIndex = 351;
this.solvencyCurrencyTextBox351.ColName = "R0330C0150";
this.solvencyCurrencyTextBox351.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox352
//
this.solvencyCurrencyTextBox352.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox352.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox352.Location = new System.Drawing.Point(1508,520);
this.solvencyCurrencyTextBox352.Name = "solvencyCurrencyTextBox352";
this.solvencyCurrencyTextBox352.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox352.TabIndex = 352;
this.solvencyCurrencyTextBox352.ColName = "R0330C0160";
this.solvencyCurrencyTextBox352.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox353
//
this.solvencyCurrencyTextBox353.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox353.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox353.Location = new System.Drawing.Point(1615,520);
this.solvencyCurrencyTextBox353.Name = "solvencyCurrencyTextBox353";
this.solvencyCurrencyTextBox353.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox353.TabIndex = 353;
this.solvencyCurrencyTextBox353.ColName = "R0330C0170";
this.solvencyCurrencyTextBox353.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox354
//
this.solvencyCurrencyTextBox354.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox354.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox354.Location = new System.Drawing.Point(1722,520);
this.solvencyCurrencyTextBox354.Name = "solvencyCurrencyTextBox354";
this.solvencyCurrencyTextBox354.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox354.TabIndex = 354;
this.solvencyCurrencyTextBox354.ColName = "R0330C0180";
this.solvencyCurrencyTextBox354.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox355
//
this.solvencyCurrencyTextBox355.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox355.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox355.Location = new System.Drawing.Point(10,568);
this.solvencyCurrencyTextBox355.Name = "solvencyCurrencyTextBox355";
this.solvencyCurrencyTextBox355.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox355.TabIndex = 355;
this.solvencyCurrencyTextBox355.ColName = "R0340C0020";
this.solvencyCurrencyTextBox355.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox356
//
this.solvencyCurrencyTextBox356.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox356.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox356.Location = new System.Drawing.Point(117,568);
this.solvencyCurrencyTextBox356.Name = "solvencyCurrencyTextBox356";
this.solvencyCurrencyTextBox356.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox356.TabIndex = 356;
this.solvencyCurrencyTextBox356.ColName = "R0340C0030";
this.solvencyCurrencyTextBox356.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox357
//
this.solvencyCurrencyTextBox357.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox357.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox357.Location = new System.Drawing.Point(224,568);
this.solvencyCurrencyTextBox357.Name = "solvencyCurrencyTextBox357";
this.solvencyCurrencyTextBox357.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox357.TabIndex = 357;
this.solvencyCurrencyTextBox357.ColName = "R0340C0040";
this.solvencyCurrencyTextBox357.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox358
//
this.solvencyCurrencyTextBox358.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox358.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox358.Location = new System.Drawing.Point(331,568);
this.solvencyCurrencyTextBox358.Name = "solvencyCurrencyTextBox358";
this.solvencyCurrencyTextBox358.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox358.TabIndex = 358;
this.solvencyCurrencyTextBox358.ColName = "R0340C0050";
this.solvencyCurrencyTextBox358.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox359
//
this.solvencyCurrencyTextBox359.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox359.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox359.Location = new System.Drawing.Point(438,568);
this.solvencyCurrencyTextBox359.Name = "solvencyCurrencyTextBox359";
this.solvencyCurrencyTextBox359.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox359.TabIndex = 359;
this.solvencyCurrencyTextBox359.ColName = "R0340C0060";
this.solvencyCurrencyTextBox359.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox360
//
this.solvencyCurrencyTextBox360.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox360.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox360.Location = new System.Drawing.Point(545,568);
this.solvencyCurrencyTextBox360.Name = "solvencyCurrencyTextBox360";
this.solvencyCurrencyTextBox360.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox360.TabIndex = 360;
this.solvencyCurrencyTextBox360.ColName = "R0340C0070";
this.solvencyCurrencyTextBox360.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox361
//
this.solvencyCurrencyTextBox361.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox361.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox361.Location = new System.Drawing.Point(652,568);
this.solvencyCurrencyTextBox361.Name = "solvencyCurrencyTextBox361";
this.solvencyCurrencyTextBox361.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox361.TabIndex = 361;
this.solvencyCurrencyTextBox361.ColName = "R0340C0080";
this.solvencyCurrencyTextBox361.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox362
//
this.solvencyCurrencyTextBox362.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox362.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox362.Location = new System.Drawing.Point(759,568);
this.solvencyCurrencyTextBox362.Name = "solvencyCurrencyTextBox362";
this.solvencyCurrencyTextBox362.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox362.TabIndex = 362;
this.solvencyCurrencyTextBox362.ColName = "R0340C0090";
this.solvencyCurrencyTextBox362.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox363
//
this.solvencyCurrencyTextBox363.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox363.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox363.Location = new System.Drawing.Point(866,568);
this.solvencyCurrencyTextBox363.Name = "solvencyCurrencyTextBox363";
this.solvencyCurrencyTextBox363.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox363.TabIndex = 363;
this.solvencyCurrencyTextBox363.ColName = "R0340C0100";
this.solvencyCurrencyTextBox363.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox364
//
this.solvencyCurrencyTextBox364.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox364.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox364.Location = new System.Drawing.Point(973,568);
this.solvencyCurrencyTextBox364.Name = "solvencyCurrencyTextBox364";
this.solvencyCurrencyTextBox364.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox364.TabIndex = 364;
this.solvencyCurrencyTextBox364.ColName = "R0340C0110";
this.solvencyCurrencyTextBox364.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox365
//
this.solvencyCurrencyTextBox365.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox365.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox365.Location = new System.Drawing.Point(1080,568);
this.solvencyCurrencyTextBox365.Name = "solvencyCurrencyTextBox365";
this.solvencyCurrencyTextBox365.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox365.TabIndex = 365;
this.solvencyCurrencyTextBox365.ColName = "R0340C0120";
this.solvencyCurrencyTextBox365.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox366
//
this.solvencyCurrencyTextBox366.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox366.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox366.Location = new System.Drawing.Point(1187,568);
this.solvencyCurrencyTextBox366.Name = "solvencyCurrencyTextBox366";
this.solvencyCurrencyTextBox366.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox366.TabIndex = 366;
this.solvencyCurrencyTextBox366.ColName = "R0340C0130";
this.solvencyCurrencyTextBox366.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox367
//
this.solvencyCurrencyTextBox367.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox367.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox367.Location = new System.Drawing.Point(1294,568);
this.solvencyCurrencyTextBox367.Name = "solvencyCurrencyTextBox367";
this.solvencyCurrencyTextBox367.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox367.TabIndex = 367;
this.solvencyCurrencyTextBox367.ColName = "R0340C0140";
this.solvencyCurrencyTextBox367.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox368
//
this.solvencyCurrencyTextBox368.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox368.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox368.Location = new System.Drawing.Point(1401,568);
this.solvencyCurrencyTextBox368.Name = "solvencyCurrencyTextBox368";
this.solvencyCurrencyTextBox368.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox368.TabIndex = 368;
this.solvencyCurrencyTextBox368.ColName = "R0340C0150";
this.solvencyCurrencyTextBox368.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox369
//
this.solvencyCurrencyTextBox369.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox369.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox369.Location = new System.Drawing.Point(1508,568);
this.solvencyCurrencyTextBox369.Name = "solvencyCurrencyTextBox369";
this.solvencyCurrencyTextBox369.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox369.TabIndex = 369;
this.solvencyCurrencyTextBox369.ColName = "R0340C0160";
this.solvencyCurrencyTextBox369.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox370
//
this.solvencyCurrencyTextBox370.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox370.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox370.Location = new System.Drawing.Point(1615,568);
this.solvencyCurrencyTextBox370.Name = "solvencyCurrencyTextBox370";
this.solvencyCurrencyTextBox370.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox370.TabIndex = 370;
this.solvencyCurrencyTextBox370.ColName = "R0340C0170";
this.solvencyCurrencyTextBox370.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox371
//
this.solvencyCurrencyTextBox371.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox371.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox371.Location = new System.Drawing.Point(1722,568);
this.solvencyCurrencyTextBox371.Name = "solvencyCurrencyTextBox371";
this.solvencyCurrencyTextBox371.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox371.TabIndex = 371;
this.solvencyCurrencyTextBox371.ColName = "R0340C0180";
this.solvencyCurrencyTextBox371.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// splitContainerColTitles
//
this.splitContainerColTitles.Dock = System.Windows.Forms.DockStyle.Fill;
this.splitContainerColTitles.Location = new System.Drawing.Point(0,0);
this.splitContainerColTitles.Name = "splitContainerColTitles";
this.splitContainerColTitles.Orientation = System.Windows.Forms.Orientation.Vertical;
this.splitContainerColTitles.Panel1MinSize = 0;
//
// splitContainerColTitles.Panel1
//
//
// splitContainerColTitles.Panel2
//
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel0);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel1);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel2);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel3);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel4);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel5);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel6);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel7);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel8);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel9);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel10);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel11);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel12);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel13);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel14);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel15);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel16);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel17);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel18);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel19);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel20);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel21);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel22);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel23);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel24);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel25);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel26);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel27);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel28);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel29);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel30);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel31);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel32);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel33);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel34);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel35);
this.splitContainerColTitles.Size = new System.Drawing.Size(2268, 427);
this.splitContainerColTitles.SplitterDistance = 332;
//
// splitContainerRowTitles
//
this.splitContainerRowTitles.Dock = System.Windows.Forms.DockStyle.Fill;
this.splitContainerRowTitles.Location = new System.Drawing.Point(0,0);
this.splitContainerRowTitles.Name = "splitContainerRowTitles";
this.splitContainerRowTitles.Orientation = System.Windows.Forms.Orientation.Vertical;
this.splitContainerRowTitles.Panel1MinSize = 0;
//
// splitContainerRowTitles.Panel1
//
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel36);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel37);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel38);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel39);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel40);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel41);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel42);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel43);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel44);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel45);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel46);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel47);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel48);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel49);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel50);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel51);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel52);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel53);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel54);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel55);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel56);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel57);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel58);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel59);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel60);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel61);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel62);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel63);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel64);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel65);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel66);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel67);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel68);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel69);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel70);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel71);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel72);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel73);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel74);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel75);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel76);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel77);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel78);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel79);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel80);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel81);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel82);
//
// splitContainerRowTitles.Panel2
//
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox83);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox84);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox85);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox86);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox87);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox88);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox89);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox90);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox91);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox92);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox93);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox94);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox95);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox96);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox97);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox98);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox99);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox100);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox101);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox102);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox103);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox104);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox105);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox106);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox107);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox108);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox109);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox110);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox111);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox112);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox113);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox114);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox115);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox116);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox117);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox118);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox119);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox120);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox121);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox122);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox123);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox124);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox125);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox126);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox127);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox128);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox129);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox130);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox131);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox132);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox133);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox134);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox135);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox136);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox137);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox138);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox139);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox140);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox141);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox142);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox143);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox144);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox145);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox146);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox147);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox148);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox149);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox150);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox151);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox152);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox153);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox154);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox155);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox156);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox157);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox158);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox159);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox160);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox161);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox162);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox163);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox164);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox165);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox166);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox167);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox168);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox169);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox170);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox171);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox172);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox173);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox174);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox175);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox176);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox177);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox178);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox179);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox180);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox181);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox182);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox183);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox184);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox185);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox186);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox187);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox188);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox189);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox190);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox191);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox192);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox193);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox194);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox195);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox196);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox197);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox198);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox199);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox200);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox201);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox202);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox203);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox204);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox205);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox206);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox207);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox208);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox209);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox210);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox211);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox212);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox213);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox214);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox215);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox216);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox217);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox218);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox219);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox220);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox221);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox222);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox223);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox224);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox225);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox226);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox227);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox228);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox229);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox230);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox231);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox232);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox233);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox234);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox235);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox236);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox237);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox238);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox239);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox240);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox241);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox242);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox243);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox244);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox245);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox246);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox247);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox248);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox249);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox250);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox251);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox252);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox253);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox254);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox255);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox256);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox257);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox258);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox259);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox260);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox261);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox262);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox263);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox264);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox265);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox266);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox267);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox268);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox269);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox270);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox271);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox272);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox273);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox274);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox275);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox276);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox277);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox278);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox279);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox280);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox281);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox282);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox283);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox284);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox285);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox286);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox287);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox288);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox289);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox290);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox291);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox292);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox293);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox294);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox295);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox296);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox297);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox298);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox299);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox300);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox301);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox302);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox303);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox304);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox305);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox306);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox307);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox308);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox309);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox310);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox311);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox312);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox313);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox314);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox315);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox316);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox317);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox318);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox319);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox320);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox321);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox322);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox323);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox324);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox325);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox326);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox327);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox328);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox329);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox330);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox331);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox332);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox333);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox334);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox335);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox336);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox337);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox338);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox339);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox340);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox341);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox342);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox343);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox344);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox345);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox346);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox347);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox348);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox349);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox350);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox351);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox352);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox353);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox354);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox355);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox356);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox357);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox358);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox359);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox360);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox361);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox362);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox363);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox364);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox365);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox366);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox367);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox368);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox369);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox370);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox371);
this.splitContainerRowTitles.Panel2.AutoScroll = true;
this.splitContainerRowTitles.Size = new System.Drawing.Size(2268, 427);
this.splitContainerRowTitles.SplitterDistance = 332;
//
// spltMain
//
this.spltMain.Dock = System.Windows.Forms.DockStyle.Fill;
this.spltMain.Location = new System.Drawing.Point(0,0);
this.spltMain.Name = "spltMain";
this.spltMain.Orientation = System.Windows.Forms.Orientation.Horizontal;
this.spltMain.Panel1MinSize = 0;
//
// spltMain.Panel1
//
this.spltMain.Panel1.Controls.Add(this.splitContainerColTitles);
//
// spltMain.Panel2
//
this.spltMain.Panel2.Controls.Add(this.splitContainerRowTitles);
this.spltMain.Panel2.AutoScroll = true;
this.spltMain.Size = new System.Drawing.Size(2268, 781);
this.spltMain.SplitterDistance = 95;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F); 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font; 
this.Controls.Add(this.spltMain);
            this.Name = "S_17_01_02_01__sol2__2_0_1_ctrl"; 
            this.Size = new System.Drawing.Size(2268, 686); 
            this.Load += new System.EventHandler(this.BoundControl_Load);
            this.ResumeLayout(false); 
            this.PerformLayout(); 

      } 
private SolvencyLabel solvencyLabel0;
private SolvencyLabel solvencyLabel1;
private SolvencyLabel solvencyLabel2;
private SolvencyLabel solvencyLabel3;
private SolvencyLabel solvencyLabel4;
private SolvencyLabel solvencyLabel5;
private SolvencyLabel solvencyLabel6;
private SolvencyLabel solvencyLabel7;
private SolvencyLabel solvencyLabel8;
private SolvencyLabel solvencyLabel9;
private SolvencyLabel solvencyLabel10;
private SolvencyLabel solvencyLabel11;
private SolvencyLabel solvencyLabel12;
private SolvencyLabel solvencyLabel13;
private SolvencyLabel solvencyLabel14;
private SolvencyLabel solvencyLabel15;
private SolvencyLabel solvencyLabel16;
private SolvencyLabel solvencyLabel17;
private SolvencyLabel solvencyLabel18;
private SolvencyLabel solvencyLabel19;
private SolvencyLabel solvencyLabel20;
private SolvencyLabel solvencyLabel21;
private SolvencyLabel solvencyLabel22;
private SolvencyLabel solvencyLabel23;
private SolvencyLabel solvencyLabel24;
private SolvencyLabel solvencyLabel25;
private SolvencyLabel solvencyLabel26;
private SolvencyLabel solvencyLabel27;
private SolvencyLabel solvencyLabel28;
private SolvencyLabel solvencyLabel29;
private SolvencyLabel solvencyLabel30;
private SolvencyLabel solvencyLabel31;
private SolvencyLabel solvencyLabel32;
private SolvencyLabel solvencyLabel33;
private SolvencyLabel solvencyLabel34;
private SolvencyLabel solvencyLabel35;
private SolvencyLabel solvencyLabel36;
private SolvencyLabel solvencyLabel37;
private SolvencyLabel solvencyLabel38;
private SolvencyLabel solvencyLabel39;
private SolvencyLabel solvencyLabel40;
private SolvencyLabel solvencyLabel41;
private SolvencyLabel solvencyLabel42;
private SolvencyLabel solvencyLabel43;
private SolvencyLabel solvencyLabel44;
private SolvencyLabel solvencyLabel45;
private SolvencyLabel solvencyLabel46;
private SolvencyLabel solvencyLabel47;
private SolvencyLabel solvencyLabel48;
private SolvencyLabel solvencyLabel49;
private SolvencyLabel solvencyLabel50;
private SolvencyLabel solvencyLabel51;
private SolvencyLabel solvencyLabel52;
private SolvencyLabel solvencyLabel53;
private SolvencyLabel solvencyLabel54;
private SolvencyLabel solvencyLabel55;
private SolvencyLabel solvencyLabel56;
private SolvencyLabel solvencyLabel57;
private SolvencyLabel solvencyLabel58;
private SolvencyLabel solvencyLabel59;
private SolvencyLabel solvencyLabel60;
private SolvencyLabel solvencyLabel61;
private SolvencyLabel solvencyLabel62;
private SolvencyLabel solvencyLabel63;
private SolvencyLabel solvencyLabel64;
private SolvencyLabel solvencyLabel65;
private SolvencyLabel solvencyLabel66;
private SolvencyLabel solvencyLabel67;
private SolvencyLabel solvencyLabel68;
private SolvencyLabel solvencyLabel69;
private SolvencyLabel solvencyLabel70;
private SolvencyLabel solvencyLabel71;
private SolvencyLabel solvencyLabel72;
private SolvencyLabel solvencyLabel73;
private SolvencyLabel solvencyLabel74;
private SolvencyLabel solvencyLabel75;
private SolvencyLabel solvencyLabel76;
private SolvencyLabel solvencyLabel77;
private SolvencyLabel solvencyLabel78;
private SolvencyLabel solvencyLabel79;
private SolvencyLabel solvencyLabel80;
private SolvencyLabel solvencyLabel81;
private SolvencyLabel solvencyLabel82;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox83;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox84;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox85;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox86;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox87;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox88;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox89;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox90;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox91;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox92;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox93;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox94;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox95;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox96;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox97;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox98;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox99;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox100;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox101;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox102;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox103;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox104;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox105;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox106;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox107;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox108;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox109;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox110;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox111;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox112;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox113;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox114;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox115;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox116;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox117;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox118;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox119;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox120;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox121;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox122;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox123;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox124;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox125;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox126;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox127;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox128;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox129;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox130;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox131;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox132;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox133;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox134;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox135;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox136;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox137;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox138;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox139;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox140;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox141;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox142;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox143;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox144;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox145;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox146;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox147;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox148;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox149;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox150;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox151;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox152;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox153;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox154;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox155;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox156;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox157;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox158;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox159;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox160;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox161;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox162;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox163;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox164;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox165;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox166;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox167;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox168;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox169;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox170;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox171;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox172;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox173;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox174;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox175;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox176;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox177;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox178;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox179;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox180;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox181;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox182;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox183;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox184;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox185;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox186;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox187;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox188;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox189;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox190;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox191;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox192;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox193;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox194;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox195;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox196;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox197;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox198;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox199;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox200;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox201;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox202;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox203;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox204;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox205;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox206;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox207;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox208;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox209;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox210;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox211;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox212;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox213;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox214;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox215;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox216;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox217;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox218;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox219;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox220;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox221;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox222;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox223;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox224;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox225;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox226;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox227;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox228;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox229;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox230;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox231;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox232;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox233;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox234;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox235;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox236;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox237;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox238;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox239;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox240;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox241;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox242;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox243;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox244;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox245;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox246;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox247;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox248;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox249;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox250;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox251;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox252;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox253;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox254;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox255;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox256;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox257;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox258;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox259;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox260;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox261;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox262;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox263;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox264;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox265;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox266;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox267;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox268;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox269;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox270;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox271;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox272;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox273;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox274;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox275;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox276;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox277;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox278;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox279;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox280;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox281;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox282;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox283;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox284;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox285;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox286;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox287;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox288;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox289;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox290;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox291;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox292;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox293;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox294;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox295;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox296;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox297;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox298;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox299;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox300;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox301;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox302;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox303;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox304;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox305;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox306;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox307;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox308;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox309;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox310;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox311;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox312;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox313;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox314;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox315;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox316;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox317;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox318;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox319;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox320;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox321;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox322;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox323;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox324;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox325;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox326;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox327;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox328;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox329;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox330;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox331;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox332;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox333;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox334;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox335;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox336;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox337;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox338;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox339;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox340;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox341;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox342;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox343;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox344;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox345;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox346;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox347;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox348;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox349;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox350;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox351;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox352;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox353;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox354;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox355;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox356;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox357;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox358;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox359;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox360;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox361;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox362;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox363;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox364;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox365;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox366;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox367;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox368;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox369;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox370;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox371;
private SolvencySplitContainer splitContainerColTitles;
private SolvencySplitContainer splitContainerRowTitles;
private SolvencySplitContainer spltMain;

   }
}

