using SolvencyII.Domain.ENumerators; 
using SolvencyII.UI.Shared.Controls; 

namespace SolvencyII.UI.UserControls 
{ 
   partial class S_19_01_01_19__sol2__2_0_1_ctrl 
   { 
      private void InitializeComponent() 
      { 
this.solvencyLabel0 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel1 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel2 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel3 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel4 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel5 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel6 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel7 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel8 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel9 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel10 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel11 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel12 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel13 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel14 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel15 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel16 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel17 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel18 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel19 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel20 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel21 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel22 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel23 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel24 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel25 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel26 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel27 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel28 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel29 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel30 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel31 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel32 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel33 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel34 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel35 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel36 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyCurrencyTextBox37 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox38 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox39 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox40 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox41 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox42 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox43 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox44 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox45 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox46 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox47 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox48 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox49 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox50 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox51 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox52 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox53 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox54 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox55 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox56 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox57 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox58 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox59 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox60 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox61 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox62 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox63 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox64 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox65 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox66 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox67 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox68 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox69 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox70 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox71 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox72 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox73 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox74 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox75 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox76 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox77 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox78 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox79 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox80 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox81 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.splitContainerColTitles = new SolvencyII.UI.Shared.Controls.SolvencySplitContainer();
this.splitContainerRowTitles = new SolvencyII.UI.Shared.Controls.SolvencySplitContainer();
this.spltMain = new SolvencyII.UI.Shared.Controls.SolvencySplitContainer();
            this.SuspendLayout(); 

//
// solvencyLabel0
//
this.solvencyLabel0.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel0.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel0.Location = new System.Drawing.Point(1508,10);
this.solvencyLabel0.Name = "solvencyLabel0";
this.solvencyLabel0.OrdinateID_Label = 3796;
this.solvencyLabel0.Size = new System.Drawing.Size(108, 20);
this.solvencyLabel0.TabIndex = 0;
this.solvencyLabel0.Text = "N" ;
this.solvencyLabel0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel0.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel1
//
this.solvencyLabel1.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel1.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel1.Location = new System.Drawing.Point(1508,30);
this.solvencyLabel1.Name = "solvencyLabel1";
this.solvencyLabel1.OrdinateID_Label = 0;
this.solvencyLabel1.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel1.TabIndex = 1;
this.solvencyLabel1.Text = "C1940" ;
this.solvencyLabel1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel2
//
this.solvencyLabel2.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel2.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel2.Location = new System.Drawing.Point(1401,10);
this.solvencyLabel2.Name = "solvencyLabel2";
this.solvencyLabel2.OrdinateID_Label = 3795;
this.solvencyLabel2.Size = new System.Drawing.Size(108, 20);
this.solvencyLabel2.TabIndex = 2;
this.solvencyLabel2.Text = "N-1" ;
this.solvencyLabel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel3
//
this.solvencyLabel3.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel3.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel3.Location = new System.Drawing.Point(1401,30);
this.solvencyLabel3.Name = "solvencyLabel3";
this.solvencyLabel3.OrdinateID_Label = 0;
this.solvencyLabel3.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel3.TabIndex = 3;
this.solvencyLabel3.Text = "C1930" ;
this.solvencyLabel3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel4
//
this.solvencyLabel4.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel4.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel4.Location = new System.Drawing.Point(1294,10);
this.solvencyLabel4.Name = "solvencyLabel4";
this.solvencyLabel4.OrdinateID_Label = 3794;
this.solvencyLabel4.Size = new System.Drawing.Size(108, 20);
this.solvencyLabel4.TabIndex = 4;
this.solvencyLabel4.Text = "N-2" ;
this.solvencyLabel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel5
//
this.solvencyLabel5.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel5.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel5.Location = new System.Drawing.Point(1294,30);
this.solvencyLabel5.Name = "solvencyLabel5";
this.solvencyLabel5.OrdinateID_Label = 0;
this.solvencyLabel5.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel5.TabIndex = 5;
this.solvencyLabel5.Text = "C1920" ;
this.solvencyLabel5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel6
//
this.solvencyLabel6.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel6.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel6.Location = new System.Drawing.Point(1187,10);
this.solvencyLabel6.Name = "solvencyLabel6";
this.solvencyLabel6.OrdinateID_Label = 3793;
this.solvencyLabel6.Size = new System.Drawing.Size(108, 20);
this.solvencyLabel6.TabIndex = 6;
this.solvencyLabel6.Text = "N-3" ;
this.solvencyLabel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel6.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel7
//
this.solvencyLabel7.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel7.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel7.Location = new System.Drawing.Point(1187,30);
this.solvencyLabel7.Name = "solvencyLabel7";
this.solvencyLabel7.OrdinateID_Label = 0;
this.solvencyLabel7.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel7.TabIndex = 7;
this.solvencyLabel7.Text = "C1910" ;
this.solvencyLabel7.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel8
//
this.solvencyLabel8.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel8.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel8.Location = new System.Drawing.Point(1080,10);
this.solvencyLabel8.Name = "solvencyLabel8";
this.solvencyLabel8.OrdinateID_Label = 3792;
this.solvencyLabel8.Size = new System.Drawing.Size(108, 20);
this.solvencyLabel8.TabIndex = 8;
this.solvencyLabel8.Text = "N-4" ;
this.solvencyLabel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel8.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel9
//
this.solvencyLabel9.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel9.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel9.Location = new System.Drawing.Point(1080,30);
this.solvencyLabel9.Name = "solvencyLabel9";
this.solvencyLabel9.OrdinateID_Label = 0;
this.solvencyLabel9.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel9.TabIndex = 9;
this.solvencyLabel9.Text = "C1900" ;
this.solvencyLabel9.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel10
//
this.solvencyLabel10.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel10.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel10.Location = new System.Drawing.Point(973,10);
this.solvencyLabel10.Name = "solvencyLabel10";
this.solvencyLabel10.OrdinateID_Label = 3791;
this.solvencyLabel10.Size = new System.Drawing.Size(108, 20);
this.solvencyLabel10.TabIndex = 10;
this.solvencyLabel10.Text = "N-5" ;
this.solvencyLabel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel10.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel11
//
this.solvencyLabel11.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel11.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel11.Location = new System.Drawing.Point(973,30);
this.solvencyLabel11.Name = "solvencyLabel11";
this.solvencyLabel11.OrdinateID_Label = 0;
this.solvencyLabel11.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel11.TabIndex = 11;
this.solvencyLabel11.Text = "C1890" ;
this.solvencyLabel11.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel12
//
this.solvencyLabel12.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel12.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel12.Location = new System.Drawing.Point(866,10);
this.solvencyLabel12.Name = "solvencyLabel12";
this.solvencyLabel12.OrdinateID_Label = 3790;
this.solvencyLabel12.Size = new System.Drawing.Size(108, 20);
this.solvencyLabel12.TabIndex = 12;
this.solvencyLabel12.Text = "N-6" ;
this.solvencyLabel12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel12.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel13
//
this.solvencyLabel13.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel13.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel13.Location = new System.Drawing.Point(866,30);
this.solvencyLabel13.Name = "solvencyLabel13";
this.solvencyLabel13.OrdinateID_Label = 0;
this.solvencyLabel13.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel13.TabIndex = 13;
this.solvencyLabel13.Text = "C1880" ;
this.solvencyLabel13.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel14
//
this.solvencyLabel14.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel14.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel14.Location = new System.Drawing.Point(759,10);
this.solvencyLabel14.Name = "solvencyLabel14";
this.solvencyLabel14.OrdinateID_Label = 3789;
this.solvencyLabel14.Size = new System.Drawing.Size(108, 20);
this.solvencyLabel14.TabIndex = 14;
this.solvencyLabel14.Text = "N-7" ;
this.solvencyLabel14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel14.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel15
//
this.solvencyLabel15.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel15.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel15.Location = new System.Drawing.Point(759,30);
this.solvencyLabel15.Name = "solvencyLabel15";
this.solvencyLabel15.OrdinateID_Label = 0;
this.solvencyLabel15.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel15.TabIndex = 15;
this.solvencyLabel15.Text = "C1870" ;
this.solvencyLabel15.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel16
//
this.solvencyLabel16.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel16.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel16.Location = new System.Drawing.Point(652,10);
this.solvencyLabel16.Name = "solvencyLabel16";
this.solvencyLabel16.OrdinateID_Label = 3788;
this.solvencyLabel16.Size = new System.Drawing.Size(108, 20);
this.solvencyLabel16.TabIndex = 16;
this.solvencyLabel16.Text = "N-8" ;
this.solvencyLabel16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel16.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel17
//
this.solvencyLabel17.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel17.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel17.Location = new System.Drawing.Point(652,30);
this.solvencyLabel17.Name = "solvencyLabel17";
this.solvencyLabel17.OrdinateID_Label = 0;
this.solvencyLabel17.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel17.TabIndex = 17;
this.solvencyLabel17.Text = "C1860" ;
this.solvencyLabel17.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel18
//
this.solvencyLabel18.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel18.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel18.Location = new System.Drawing.Point(545,10);
this.solvencyLabel18.Name = "solvencyLabel18";
this.solvencyLabel18.OrdinateID_Label = 3787;
this.solvencyLabel18.Size = new System.Drawing.Size(108, 20);
this.solvencyLabel18.TabIndex = 18;
this.solvencyLabel18.Text = "N-9" ;
this.solvencyLabel18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel18.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel19
//
this.solvencyLabel19.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel19.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel19.Location = new System.Drawing.Point(545,30);
this.solvencyLabel19.Name = "solvencyLabel19";
this.solvencyLabel19.OrdinateID_Label = 0;
this.solvencyLabel19.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel19.TabIndex = 19;
this.solvencyLabel19.Text = "C1850" ;
this.solvencyLabel19.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel20
//
this.solvencyLabel20.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel20.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel20.Location = new System.Drawing.Point(438,10);
this.solvencyLabel20.Name = "solvencyLabel20";
this.solvencyLabel20.OrdinateID_Label = 3786;
this.solvencyLabel20.Size = new System.Drawing.Size(108, 20);
this.solvencyLabel20.TabIndex = 20;
this.solvencyLabel20.Text = "N-10" ;
this.solvencyLabel20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel20.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel21
//
this.solvencyLabel21.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel21.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel21.Location = new System.Drawing.Point(438,30);
this.solvencyLabel21.Name = "solvencyLabel21";
this.solvencyLabel21.OrdinateID_Label = 0;
this.solvencyLabel21.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel21.TabIndex = 21;
this.solvencyLabel21.Text = "C1840" ;
this.solvencyLabel21.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel22
//
this.solvencyLabel22.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel22.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel22.Location = new System.Drawing.Point(331,10);
this.solvencyLabel22.Name = "solvencyLabel22";
this.solvencyLabel22.OrdinateID_Label = 3785;
this.solvencyLabel22.Size = new System.Drawing.Size(108, 20);
this.solvencyLabel22.TabIndex = 22;
this.solvencyLabel22.Text = "N-11" ;
this.solvencyLabel22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel22.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel23
//
this.solvencyLabel23.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel23.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel23.Location = new System.Drawing.Point(331,30);
this.solvencyLabel23.Name = "solvencyLabel23";
this.solvencyLabel23.OrdinateID_Label = 0;
this.solvencyLabel23.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel23.TabIndex = 23;
this.solvencyLabel23.Text = "C1830" ;
this.solvencyLabel23.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel24
//
this.solvencyLabel24.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel24.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel24.Location = new System.Drawing.Point(224,10);
this.solvencyLabel24.Name = "solvencyLabel24";
this.solvencyLabel24.OrdinateID_Label = 3784;
this.solvencyLabel24.Size = new System.Drawing.Size(108, 20);
this.solvencyLabel24.TabIndex = 24;
this.solvencyLabel24.Text = "N-12" ;
this.solvencyLabel24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel24.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel25
//
this.solvencyLabel25.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel25.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel25.Location = new System.Drawing.Point(224,30);
this.solvencyLabel25.Name = "solvencyLabel25";
this.solvencyLabel25.OrdinateID_Label = 0;
this.solvencyLabel25.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel25.TabIndex = 25;
this.solvencyLabel25.Text = "C1820" ;
this.solvencyLabel25.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel26
//
this.solvencyLabel26.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel26.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel26.Location = new System.Drawing.Point(117,10);
this.solvencyLabel26.Name = "solvencyLabel26";
this.solvencyLabel26.OrdinateID_Label = 3783;
this.solvencyLabel26.Size = new System.Drawing.Size(108, 20);
this.solvencyLabel26.TabIndex = 26;
this.solvencyLabel26.Text = "N-13" ;
this.solvencyLabel26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel26.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel27
//
this.solvencyLabel27.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel27.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel27.Location = new System.Drawing.Point(117,30);
this.solvencyLabel27.Name = "solvencyLabel27";
this.solvencyLabel27.OrdinateID_Label = 0;
this.solvencyLabel27.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel27.TabIndex = 27;
this.solvencyLabel27.Text = "C1810" ;
this.solvencyLabel27.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel28
//
this.solvencyLabel28.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel28.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel28.Location = new System.Drawing.Point(10,10);
this.solvencyLabel28.Name = "solvencyLabel28";
this.solvencyLabel28.OrdinateID_Label = 3782;
this.solvencyLabel28.Size = new System.Drawing.Size(108, 20);
this.solvencyLabel28.TabIndex = 28;
this.solvencyLabel28.Text = "N-14" ;
this.solvencyLabel28.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel28.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel29
//
this.solvencyLabel29.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel29.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel29.Location = new System.Drawing.Point(10,30);
this.solvencyLabel29.Name = "solvencyLabel29";
this.solvencyLabel29.OrdinateID_Label = 0;
this.solvencyLabel29.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel29.TabIndex = 29;
this.solvencyLabel29.Text = "C1800" ;
this.solvencyLabel29.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel30
//
this.solvencyLabel30.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel30.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel30.Location = new System.Drawing.Point(10,3);
this.solvencyLabel30.Name = "solvencyLabel30";
this.solvencyLabel30.OrdinateID_Label = 3797;
this.solvencyLabel30.Size = new System.Drawing.Size(220, 15);
this.solvencyLabel30.TabIndex = 30;
this.solvencyLabel30.Text = "Historic inflation rate - total" ;
this.solvencyLabel30.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel31
//
this.solvencyLabel31.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel31.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel31.Location = new System.Drawing.Point(244,3);
this.solvencyLabel31.Name = "solvencyLabel31";
this.solvencyLabel31.OrdinateID_Label = 0;
this.solvencyLabel31.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel31.TabIndex = 31;
this.solvencyLabel31.Text = "R0700" ;
this.solvencyLabel31.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel32
//
this.solvencyLabel32.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel32.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel32.Location = new System.Drawing.Point(10,23);
this.solvencyLabel32.Name = "solvencyLabel32";
this.solvencyLabel32.OrdinateID_Label = 3798;
this.solvencyLabel32.Size = new System.Drawing.Size(220, 15);
this.solvencyLabel32.TabIndex = 32;
this.solvencyLabel32.Text = "Historic inflation rate: external inflation" ;
this.solvencyLabel32.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel33
//
this.solvencyLabel33.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel33.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel33.Location = new System.Drawing.Point(244,23);
this.solvencyLabel33.Name = "solvencyLabel33";
this.solvencyLabel33.OrdinateID_Label = 0;
this.solvencyLabel33.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel33.TabIndex = 33;
this.solvencyLabel33.Text = "R0710" ;
this.solvencyLabel33.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel34
//
this.solvencyLabel34.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel34.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel34.Location = new System.Drawing.Point(10,43);
this.solvencyLabel34.Name = "solvencyLabel34";
this.solvencyLabel34.OrdinateID_Label = 3799;
this.solvencyLabel34.Size = new System.Drawing.Size(220, 15);
this.solvencyLabel34.TabIndex = 34;
this.solvencyLabel34.Text = "Historic inflation rate: endogenous inflation" ;
this.solvencyLabel34.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel35
//
this.solvencyLabel35.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel35.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel35.Location = new System.Drawing.Point(244,43);
this.solvencyLabel35.Name = "solvencyLabel35";
this.solvencyLabel35.OrdinateID_Label = 0;
this.solvencyLabel35.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel35.TabIndex = 35;
this.solvencyLabel35.Text = "R0720" ;
this.solvencyLabel35.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel36
//
this.solvencyLabel36.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel36.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel36.Location = new System.Drawing.Point(244,63);
this.solvencyLabel36.Name = "solvencyLabel36";
this.solvencyLabel36.OrdinateID_Label = 0;
this.solvencyLabel36.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel36.TabIndex = 36;
this.solvencyLabel36.Text = "." ;
this.solvencyLabel36.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyCurrencyTextBox37
//
this.solvencyCurrencyTextBox37.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox37.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox37.Location = new System.Drawing.Point(10,3);
this.solvencyCurrencyTextBox37.Name = "solvencyCurrencyTextBox37";
this.solvencyCurrencyTextBox37.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox37.TabIndex = 37;
this.solvencyCurrencyTextBox37.ColName = "R0700C1800";
this.solvencyCurrencyTextBox37.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox38
//
this.solvencyCurrencyTextBox38.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox38.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox38.Location = new System.Drawing.Point(117,3);
this.solvencyCurrencyTextBox38.Name = "solvencyCurrencyTextBox38";
this.solvencyCurrencyTextBox38.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox38.TabIndex = 38;
this.solvencyCurrencyTextBox38.ColName = "R0700C1810";
this.solvencyCurrencyTextBox38.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox39
//
this.solvencyCurrencyTextBox39.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox39.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox39.Location = new System.Drawing.Point(224,3);
this.solvencyCurrencyTextBox39.Name = "solvencyCurrencyTextBox39";
this.solvencyCurrencyTextBox39.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox39.TabIndex = 39;
this.solvencyCurrencyTextBox39.ColName = "R0700C1820";
this.solvencyCurrencyTextBox39.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox40
//
this.solvencyCurrencyTextBox40.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox40.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox40.Location = new System.Drawing.Point(331,3);
this.solvencyCurrencyTextBox40.Name = "solvencyCurrencyTextBox40";
this.solvencyCurrencyTextBox40.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox40.TabIndex = 40;
this.solvencyCurrencyTextBox40.ColName = "R0700C1830";
this.solvencyCurrencyTextBox40.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox41
//
this.solvencyCurrencyTextBox41.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox41.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox41.Location = new System.Drawing.Point(438,3);
this.solvencyCurrencyTextBox41.Name = "solvencyCurrencyTextBox41";
this.solvencyCurrencyTextBox41.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox41.TabIndex = 41;
this.solvencyCurrencyTextBox41.ColName = "R0700C1840";
this.solvencyCurrencyTextBox41.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox42
//
this.solvencyCurrencyTextBox42.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox42.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox42.Location = new System.Drawing.Point(545,3);
this.solvencyCurrencyTextBox42.Name = "solvencyCurrencyTextBox42";
this.solvencyCurrencyTextBox42.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox42.TabIndex = 42;
this.solvencyCurrencyTextBox42.ColName = "R0700C1850";
this.solvencyCurrencyTextBox42.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox43
//
this.solvencyCurrencyTextBox43.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox43.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox43.Location = new System.Drawing.Point(652,3);
this.solvencyCurrencyTextBox43.Name = "solvencyCurrencyTextBox43";
this.solvencyCurrencyTextBox43.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox43.TabIndex = 43;
this.solvencyCurrencyTextBox43.ColName = "R0700C1860";
this.solvencyCurrencyTextBox43.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox44
//
this.solvencyCurrencyTextBox44.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox44.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox44.Location = new System.Drawing.Point(759,3);
this.solvencyCurrencyTextBox44.Name = "solvencyCurrencyTextBox44";
this.solvencyCurrencyTextBox44.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox44.TabIndex = 44;
this.solvencyCurrencyTextBox44.ColName = "R0700C1870";
this.solvencyCurrencyTextBox44.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox45
//
this.solvencyCurrencyTextBox45.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox45.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox45.Location = new System.Drawing.Point(866,3);
this.solvencyCurrencyTextBox45.Name = "solvencyCurrencyTextBox45";
this.solvencyCurrencyTextBox45.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox45.TabIndex = 45;
this.solvencyCurrencyTextBox45.ColName = "R0700C1880";
this.solvencyCurrencyTextBox45.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox46
//
this.solvencyCurrencyTextBox46.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox46.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox46.Location = new System.Drawing.Point(973,3);
this.solvencyCurrencyTextBox46.Name = "solvencyCurrencyTextBox46";
this.solvencyCurrencyTextBox46.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox46.TabIndex = 46;
this.solvencyCurrencyTextBox46.ColName = "R0700C1890";
this.solvencyCurrencyTextBox46.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox47
//
this.solvencyCurrencyTextBox47.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox47.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox47.Location = new System.Drawing.Point(1080,3);
this.solvencyCurrencyTextBox47.Name = "solvencyCurrencyTextBox47";
this.solvencyCurrencyTextBox47.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox47.TabIndex = 47;
this.solvencyCurrencyTextBox47.ColName = "R0700C1900";
this.solvencyCurrencyTextBox47.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox48
//
this.solvencyCurrencyTextBox48.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox48.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox48.Location = new System.Drawing.Point(1187,3);
this.solvencyCurrencyTextBox48.Name = "solvencyCurrencyTextBox48";
this.solvencyCurrencyTextBox48.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox48.TabIndex = 48;
this.solvencyCurrencyTextBox48.ColName = "R0700C1910";
this.solvencyCurrencyTextBox48.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox49
//
this.solvencyCurrencyTextBox49.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox49.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox49.Location = new System.Drawing.Point(1294,3);
this.solvencyCurrencyTextBox49.Name = "solvencyCurrencyTextBox49";
this.solvencyCurrencyTextBox49.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox49.TabIndex = 49;
this.solvencyCurrencyTextBox49.ColName = "R0700C1920";
this.solvencyCurrencyTextBox49.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox50
//
this.solvencyCurrencyTextBox50.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox50.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox50.Location = new System.Drawing.Point(1401,3);
this.solvencyCurrencyTextBox50.Name = "solvencyCurrencyTextBox50";
this.solvencyCurrencyTextBox50.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox50.TabIndex = 50;
this.solvencyCurrencyTextBox50.ColName = "R0700C1930";
this.solvencyCurrencyTextBox50.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox51
//
this.solvencyCurrencyTextBox51.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox51.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox51.Location = new System.Drawing.Point(1508,3);
this.solvencyCurrencyTextBox51.Name = "solvencyCurrencyTextBox51";
this.solvencyCurrencyTextBox51.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox51.TabIndex = 51;
this.solvencyCurrencyTextBox51.ColName = "R0700C1940";
this.solvencyCurrencyTextBox51.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox52
//
this.solvencyCurrencyTextBox52.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox52.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox52.Location = new System.Drawing.Point(10,23);
this.solvencyCurrencyTextBox52.Name = "solvencyCurrencyTextBox52";
this.solvencyCurrencyTextBox52.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox52.TabIndex = 52;
this.solvencyCurrencyTextBox52.ColName = "R0710C1800";
this.solvencyCurrencyTextBox52.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox53
//
this.solvencyCurrencyTextBox53.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox53.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox53.Location = new System.Drawing.Point(117,23);
this.solvencyCurrencyTextBox53.Name = "solvencyCurrencyTextBox53";
this.solvencyCurrencyTextBox53.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox53.TabIndex = 53;
this.solvencyCurrencyTextBox53.ColName = "R0710C1810";
this.solvencyCurrencyTextBox53.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox54
//
this.solvencyCurrencyTextBox54.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox54.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox54.Location = new System.Drawing.Point(224,23);
this.solvencyCurrencyTextBox54.Name = "solvencyCurrencyTextBox54";
this.solvencyCurrencyTextBox54.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox54.TabIndex = 54;
this.solvencyCurrencyTextBox54.ColName = "R0710C1820";
this.solvencyCurrencyTextBox54.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox55
//
this.solvencyCurrencyTextBox55.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox55.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox55.Location = new System.Drawing.Point(331,23);
this.solvencyCurrencyTextBox55.Name = "solvencyCurrencyTextBox55";
this.solvencyCurrencyTextBox55.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox55.TabIndex = 55;
this.solvencyCurrencyTextBox55.ColName = "R0710C1830";
this.solvencyCurrencyTextBox55.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox56
//
this.solvencyCurrencyTextBox56.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox56.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox56.Location = new System.Drawing.Point(438,23);
this.solvencyCurrencyTextBox56.Name = "solvencyCurrencyTextBox56";
this.solvencyCurrencyTextBox56.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox56.TabIndex = 56;
this.solvencyCurrencyTextBox56.ColName = "R0710C1840";
this.solvencyCurrencyTextBox56.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox57
//
this.solvencyCurrencyTextBox57.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox57.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox57.Location = new System.Drawing.Point(545,23);
this.solvencyCurrencyTextBox57.Name = "solvencyCurrencyTextBox57";
this.solvencyCurrencyTextBox57.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox57.TabIndex = 57;
this.solvencyCurrencyTextBox57.ColName = "R0710C1850";
this.solvencyCurrencyTextBox57.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox58
//
this.solvencyCurrencyTextBox58.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox58.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox58.Location = new System.Drawing.Point(652,23);
this.solvencyCurrencyTextBox58.Name = "solvencyCurrencyTextBox58";
this.solvencyCurrencyTextBox58.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox58.TabIndex = 58;
this.solvencyCurrencyTextBox58.ColName = "R0710C1860";
this.solvencyCurrencyTextBox58.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox59
//
this.solvencyCurrencyTextBox59.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox59.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox59.Location = new System.Drawing.Point(759,23);
this.solvencyCurrencyTextBox59.Name = "solvencyCurrencyTextBox59";
this.solvencyCurrencyTextBox59.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox59.TabIndex = 59;
this.solvencyCurrencyTextBox59.ColName = "R0710C1870";
this.solvencyCurrencyTextBox59.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox60
//
this.solvencyCurrencyTextBox60.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox60.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox60.Location = new System.Drawing.Point(866,23);
this.solvencyCurrencyTextBox60.Name = "solvencyCurrencyTextBox60";
this.solvencyCurrencyTextBox60.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox60.TabIndex = 60;
this.solvencyCurrencyTextBox60.ColName = "R0710C1880";
this.solvencyCurrencyTextBox60.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox61
//
this.solvencyCurrencyTextBox61.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox61.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox61.Location = new System.Drawing.Point(973,23);
this.solvencyCurrencyTextBox61.Name = "solvencyCurrencyTextBox61";
this.solvencyCurrencyTextBox61.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox61.TabIndex = 61;
this.solvencyCurrencyTextBox61.ColName = "R0710C1890";
this.solvencyCurrencyTextBox61.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox62
//
this.solvencyCurrencyTextBox62.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox62.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox62.Location = new System.Drawing.Point(1080,23);
this.solvencyCurrencyTextBox62.Name = "solvencyCurrencyTextBox62";
this.solvencyCurrencyTextBox62.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox62.TabIndex = 62;
this.solvencyCurrencyTextBox62.ColName = "R0710C1900";
this.solvencyCurrencyTextBox62.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox63
//
this.solvencyCurrencyTextBox63.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox63.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox63.Location = new System.Drawing.Point(1187,23);
this.solvencyCurrencyTextBox63.Name = "solvencyCurrencyTextBox63";
this.solvencyCurrencyTextBox63.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox63.TabIndex = 63;
this.solvencyCurrencyTextBox63.ColName = "R0710C1910";
this.solvencyCurrencyTextBox63.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox64
//
this.solvencyCurrencyTextBox64.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox64.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox64.Location = new System.Drawing.Point(1294,23);
this.solvencyCurrencyTextBox64.Name = "solvencyCurrencyTextBox64";
this.solvencyCurrencyTextBox64.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox64.TabIndex = 64;
this.solvencyCurrencyTextBox64.ColName = "R0710C1920";
this.solvencyCurrencyTextBox64.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox65
//
this.solvencyCurrencyTextBox65.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox65.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox65.Location = new System.Drawing.Point(1401,23);
this.solvencyCurrencyTextBox65.Name = "solvencyCurrencyTextBox65";
this.solvencyCurrencyTextBox65.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox65.TabIndex = 65;
this.solvencyCurrencyTextBox65.ColName = "R0710C1930";
this.solvencyCurrencyTextBox65.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox66
//
this.solvencyCurrencyTextBox66.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox66.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox66.Location = new System.Drawing.Point(1508,23);
this.solvencyCurrencyTextBox66.Name = "solvencyCurrencyTextBox66";
this.solvencyCurrencyTextBox66.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox66.TabIndex = 66;
this.solvencyCurrencyTextBox66.ColName = "R0710C1940";
this.solvencyCurrencyTextBox66.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox67
//
this.solvencyCurrencyTextBox67.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox67.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox67.Location = new System.Drawing.Point(10,43);
this.solvencyCurrencyTextBox67.Name = "solvencyCurrencyTextBox67";
this.solvencyCurrencyTextBox67.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox67.TabIndex = 67;
this.solvencyCurrencyTextBox67.ColName = "R0720C1800";
this.solvencyCurrencyTextBox67.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox68
//
this.solvencyCurrencyTextBox68.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox68.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox68.Location = new System.Drawing.Point(117,43);
this.solvencyCurrencyTextBox68.Name = "solvencyCurrencyTextBox68";
this.solvencyCurrencyTextBox68.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox68.TabIndex = 68;
this.solvencyCurrencyTextBox68.ColName = "R0720C1810";
this.solvencyCurrencyTextBox68.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox69
//
this.solvencyCurrencyTextBox69.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox69.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox69.Location = new System.Drawing.Point(224,43);
this.solvencyCurrencyTextBox69.Name = "solvencyCurrencyTextBox69";
this.solvencyCurrencyTextBox69.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox69.TabIndex = 69;
this.solvencyCurrencyTextBox69.ColName = "R0720C1820";
this.solvencyCurrencyTextBox69.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox70
//
this.solvencyCurrencyTextBox70.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox70.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox70.Location = new System.Drawing.Point(331,43);
this.solvencyCurrencyTextBox70.Name = "solvencyCurrencyTextBox70";
this.solvencyCurrencyTextBox70.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox70.TabIndex = 70;
this.solvencyCurrencyTextBox70.ColName = "R0720C1830";
this.solvencyCurrencyTextBox70.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox71
//
this.solvencyCurrencyTextBox71.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox71.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox71.Location = new System.Drawing.Point(438,43);
this.solvencyCurrencyTextBox71.Name = "solvencyCurrencyTextBox71";
this.solvencyCurrencyTextBox71.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox71.TabIndex = 71;
this.solvencyCurrencyTextBox71.ColName = "R0720C1840";
this.solvencyCurrencyTextBox71.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox72
//
this.solvencyCurrencyTextBox72.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox72.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox72.Location = new System.Drawing.Point(545,43);
this.solvencyCurrencyTextBox72.Name = "solvencyCurrencyTextBox72";
this.solvencyCurrencyTextBox72.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox72.TabIndex = 72;
this.solvencyCurrencyTextBox72.ColName = "R0720C1850";
this.solvencyCurrencyTextBox72.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox73
//
this.solvencyCurrencyTextBox73.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox73.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox73.Location = new System.Drawing.Point(652,43);
this.solvencyCurrencyTextBox73.Name = "solvencyCurrencyTextBox73";
this.solvencyCurrencyTextBox73.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox73.TabIndex = 73;
this.solvencyCurrencyTextBox73.ColName = "R0720C1860";
this.solvencyCurrencyTextBox73.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox74
//
this.solvencyCurrencyTextBox74.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox74.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox74.Location = new System.Drawing.Point(759,43);
this.solvencyCurrencyTextBox74.Name = "solvencyCurrencyTextBox74";
this.solvencyCurrencyTextBox74.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox74.TabIndex = 74;
this.solvencyCurrencyTextBox74.ColName = "R0720C1870";
this.solvencyCurrencyTextBox74.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox75
//
this.solvencyCurrencyTextBox75.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox75.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox75.Location = new System.Drawing.Point(866,43);
this.solvencyCurrencyTextBox75.Name = "solvencyCurrencyTextBox75";
this.solvencyCurrencyTextBox75.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox75.TabIndex = 75;
this.solvencyCurrencyTextBox75.ColName = "R0720C1880";
this.solvencyCurrencyTextBox75.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox76
//
this.solvencyCurrencyTextBox76.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox76.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox76.Location = new System.Drawing.Point(973,43);
this.solvencyCurrencyTextBox76.Name = "solvencyCurrencyTextBox76";
this.solvencyCurrencyTextBox76.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox76.TabIndex = 76;
this.solvencyCurrencyTextBox76.ColName = "R0720C1890";
this.solvencyCurrencyTextBox76.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox77
//
this.solvencyCurrencyTextBox77.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox77.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox77.Location = new System.Drawing.Point(1080,43);
this.solvencyCurrencyTextBox77.Name = "solvencyCurrencyTextBox77";
this.solvencyCurrencyTextBox77.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox77.TabIndex = 77;
this.solvencyCurrencyTextBox77.ColName = "R0720C1900";
this.solvencyCurrencyTextBox77.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox78
//
this.solvencyCurrencyTextBox78.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox78.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox78.Location = new System.Drawing.Point(1187,43);
this.solvencyCurrencyTextBox78.Name = "solvencyCurrencyTextBox78";
this.solvencyCurrencyTextBox78.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox78.TabIndex = 78;
this.solvencyCurrencyTextBox78.ColName = "R0720C1910";
this.solvencyCurrencyTextBox78.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox79
//
this.solvencyCurrencyTextBox79.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox79.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox79.Location = new System.Drawing.Point(1294,43);
this.solvencyCurrencyTextBox79.Name = "solvencyCurrencyTextBox79";
this.solvencyCurrencyTextBox79.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox79.TabIndex = 79;
this.solvencyCurrencyTextBox79.ColName = "R0720C1920";
this.solvencyCurrencyTextBox79.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox80
//
this.solvencyCurrencyTextBox80.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox80.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox80.Location = new System.Drawing.Point(1401,43);
this.solvencyCurrencyTextBox80.Name = "solvencyCurrencyTextBox80";
this.solvencyCurrencyTextBox80.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox80.TabIndex = 80;
this.solvencyCurrencyTextBox80.ColName = "R0720C1930";
this.solvencyCurrencyTextBox80.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox81
//
this.solvencyCurrencyTextBox81.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox81.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox81.Location = new System.Drawing.Point(1508,43);
this.solvencyCurrencyTextBox81.Name = "solvencyCurrencyTextBox81";
this.solvencyCurrencyTextBox81.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox81.TabIndex = 81;
this.solvencyCurrencyTextBox81.ColName = "R0720C1940";
this.solvencyCurrencyTextBox81.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// splitContainerColTitles
//
this.splitContainerColTitles.Dock = System.Windows.Forms.DockStyle.Fill;
this.splitContainerColTitles.Location = new System.Drawing.Point(0,0);
this.splitContainerColTitles.Name = "splitContainerColTitles";
this.splitContainerColTitles.Orientation = System.Windows.Forms.Orientation.Vertical;
this.splitContainerColTitles.Panel1MinSize = 0;
//
// splitContainerColTitles.Panel1
//
//
// splitContainerColTitles.Panel2
//
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel0);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel1);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel2);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel3);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel4);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel5);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel6);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel7);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel8);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel9);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel10);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel11);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel12);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel13);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel14);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel15);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel16);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel17);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel18);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel19);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel20);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel21);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel22);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel23);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel24);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel25);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel26);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel27);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel28);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel29);
this.splitContainerColTitles.Size = new System.Drawing.Size(2013, 341);
this.splitContainerColTitles.SplitterDistance = 291;
//
// splitContainerRowTitles
//
this.splitContainerRowTitles.Dock = System.Windows.Forms.DockStyle.Fill;
this.splitContainerRowTitles.Location = new System.Drawing.Point(0,0);
this.splitContainerRowTitles.Name = "splitContainerRowTitles";
this.splitContainerRowTitles.Orientation = System.Windows.Forms.Orientation.Vertical;
this.splitContainerRowTitles.Panel1MinSize = 0;
//
// splitContainerRowTitles.Panel1
//
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel30);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel31);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel32);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel33);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel34);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel35);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel36);
//
// splitContainerRowTitles.Panel2
//
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox37);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox38);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox39);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox40);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox41);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox42);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox43);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox44);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox45);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox46);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox47);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox48);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox49);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox50);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox51);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox52);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox53);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox54);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox55);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox56);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox57);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox58);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox59);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox60);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox61);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox62);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox63);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox64);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox65);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox66);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox67);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox68);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox69);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox70);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox71);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox72);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox73);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox74);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox75);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox76);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox77);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox78);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox79);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox80);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox81);
this.splitContainerRowTitles.Panel2.AutoScroll = true;
this.splitContainerRowTitles.Size = new System.Drawing.Size(2013, 341);
this.splitContainerRowTitles.SplitterDistance = 291;
//
// spltMain
//
this.spltMain.Dock = System.Windows.Forms.DockStyle.Fill;
this.spltMain.Location = new System.Drawing.Point(0,0);
this.spltMain.Name = "spltMain";
this.spltMain.Orientation = System.Windows.Forms.Orientation.Horizontal;
this.spltMain.Panel1MinSize = 0;
//
// spltMain.Panel1
//
this.spltMain.Panel1.Controls.Add(this.splitContainerColTitles);
//
// spltMain.Panel2
//
this.spltMain.Panel2.Controls.Add(this.splitContainerRowTitles);
this.spltMain.Panel2.AutoScroll = true;
this.spltMain.Size = new System.Drawing.Size(2013, 166);
this.spltMain.SplitterDistance = 50;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F); 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font; 
this.Controls.Add(this.spltMain);
            this.Name = "S_19_01_01_19__sol2__2_0_1_ctrl"; 
            this.Size = new System.Drawing.Size(2013, 116); 
            this.Load += new System.EventHandler(this.BoundControl_Load);
            this.ResumeLayout(false); 
            this.PerformLayout(); 

      } 
private SolvencyLabel solvencyLabel0;
private SolvencyLabel solvencyLabel1;
private SolvencyLabel solvencyLabel2;
private SolvencyLabel solvencyLabel3;
private SolvencyLabel solvencyLabel4;
private SolvencyLabel solvencyLabel5;
private SolvencyLabel solvencyLabel6;
private SolvencyLabel solvencyLabel7;
private SolvencyLabel solvencyLabel8;
private SolvencyLabel solvencyLabel9;
private SolvencyLabel solvencyLabel10;
private SolvencyLabel solvencyLabel11;
private SolvencyLabel solvencyLabel12;
private SolvencyLabel solvencyLabel13;
private SolvencyLabel solvencyLabel14;
private SolvencyLabel solvencyLabel15;
private SolvencyLabel solvencyLabel16;
private SolvencyLabel solvencyLabel17;
private SolvencyLabel solvencyLabel18;
private SolvencyLabel solvencyLabel19;
private SolvencyLabel solvencyLabel20;
private SolvencyLabel solvencyLabel21;
private SolvencyLabel solvencyLabel22;
private SolvencyLabel solvencyLabel23;
private SolvencyLabel solvencyLabel24;
private SolvencyLabel solvencyLabel25;
private SolvencyLabel solvencyLabel26;
private SolvencyLabel solvencyLabel27;
private SolvencyLabel solvencyLabel28;
private SolvencyLabel solvencyLabel29;
private SolvencyLabel solvencyLabel30;
private SolvencyLabel solvencyLabel31;
private SolvencyLabel solvencyLabel32;
private SolvencyLabel solvencyLabel33;
private SolvencyLabel solvencyLabel34;
private SolvencyLabel solvencyLabel35;
private SolvencyLabel solvencyLabel36;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox37;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox38;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox39;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox40;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox41;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox42;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox43;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox44;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox45;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox46;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox47;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox48;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox49;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox50;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox51;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox52;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox53;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox54;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox55;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox56;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox57;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox58;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox59;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox60;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox61;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox62;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox63;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox64;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox65;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox66;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox67;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox68;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox69;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox70;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox71;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox72;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox73;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox74;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox75;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox76;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox77;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox78;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox79;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox80;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox81;
private SolvencySplitContainer splitContainerColTitles;
private SolvencySplitContainer splitContainerRowTitles;
private SolvencySplitContainer spltMain;

   }
}

