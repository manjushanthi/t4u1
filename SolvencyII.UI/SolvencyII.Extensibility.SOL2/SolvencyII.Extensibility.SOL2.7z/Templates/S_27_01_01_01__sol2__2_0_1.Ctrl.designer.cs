using SolvencyII.Domain.ENumerators; 
using SolvencyII.UI.Shared.Controls; 

namespace SolvencyII.UI.UserControls 
{ 
   partial class S_27_01_01_01__sol2__2_0_1_ctrl 
   { 
      private void InitializeComponent() 
      { 
this.solvencyLabel0 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel1 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel2 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel3 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel4 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel5 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel6 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel7 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel8 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel9 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel10 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel11 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel12 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel13 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel14 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel15 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel16 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel17 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel18 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel19 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel20 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel21 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel22 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel23 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel24 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel25 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel26 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel27 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel28 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel29 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel30 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel31 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel32 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel33 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel34 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel35 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel36 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel37 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel38 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel39 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel40 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel41 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel42 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel43 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel44 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel45 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel46 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel47 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel48 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel49 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel50 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel51 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel52 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel53 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel54 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel55 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel56 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel57 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel58 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel59 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel60 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel61 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel62 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyCurrencyTextBox63 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox64 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox65 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox66 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox67 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox68 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox69 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox70 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox71 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox72 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox73 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox74 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox75 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox76 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox77 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox78 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox79 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox80 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox81 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox82 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox83 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox84 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox85 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox86 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox87 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox88 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox89 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox90 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox91 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox92 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox93 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox94 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox95 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox96 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox97 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox98 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox99 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox100 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox101 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox102 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox103 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox104 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox105 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox106 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox107 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox108 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox109 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox110 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox111 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox112 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox113 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox114 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox115 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox116 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox117 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox118 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox119 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox120 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox121 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox122 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox123 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox124 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox125 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox126 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox127 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox128 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox129 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox130 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox131 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox132 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox133 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox134 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox135 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox136 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox137 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox138 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox139 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox140 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.splitContainerColTitles = new SolvencyII.UI.Shared.Controls.SolvencySplitContainer();
this.splitContainerRowTitles = new SolvencyII.UI.Shared.Controls.SolvencySplitContainer();
this.spltMain = new SolvencyII.UI.Shared.Controls.SolvencySplitContainer();
            this.SuspendLayout(); 

//
// solvencyLabel0
//
this.solvencyLabel0.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel0.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel0.Location = new System.Drawing.Point(224,10);
this.solvencyLabel0.Name = "solvencyLabel0";
this.solvencyLabel0.OrdinateID_Label = 6310;
this.solvencyLabel0.Size = new System.Drawing.Size(108, 30);
this.solvencyLabel0.TabIndex = 0;
this.solvencyLabel0.Text = "SCR after risk mitigation" ;
this.solvencyLabel0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel0.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel1
//
this.solvencyLabel1.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel1.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel1.Location = new System.Drawing.Point(224,40);
this.solvencyLabel1.Name = "solvencyLabel1";
this.solvencyLabel1.OrdinateID_Label = 0;
this.solvencyLabel1.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel1.TabIndex = 1;
this.solvencyLabel1.Text = "C0030" ;
this.solvencyLabel1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel2
//
this.solvencyLabel2.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel2.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel2.Location = new System.Drawing.Point(117,10);
this.solvencyLabel2.Name = "solvencyLabel2";
this.solvencyLabel2.OrdinateID_Label = 6309;
this.solvencyLabel2.Size = new System.Drawing.Size(108, 30);
this.solvencyLabel2.TabIndex = 2;
this.solvencyLabel2.Text = "Total risk mitigation" ;
this.solvencyLabel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel3
//
this.solvencyLabel3.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel3.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel3.Location = new System.Drawing.Point(117,40);
this.solvencyLabel3.Name = "solvencyLabel3";
this.solvencyLabel3.OrdinateID_Label = 0;
this.solvencyLabel3.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel3.TabIndex = 3;
this.solvencyLabel3.Text = "C0020" ;
this.solvencyLabel3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel4
//
this.solvencyLabel4.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel4.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel4.Location = new System.Drawing.Point(10,10);
this.solvencyLabel4.Name = "solvencyLabel4";
this.solvencyLabel4.OrdinateID_Label = 6308;
this.solvencyLabel4.Size = new System.Drawing.Size(108, 30);
this.solvencyLabel4.TabIndex = 4;
this.solvencyLabel4.Text = "SCR before risk mitigation" ;
this.solvencyLabel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel5
//
this.solvencyLabel5.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel5.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel5.Location = new System.Drawing.Point(10,40);
this.solvencyLabel5.Name = "solvencyLabel5";
this.solvencyLabel5.OrdinateID_Label = 0;
this.solvencyLabel5.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel5.TabIndex = 5;
this.solvencyLabel5.Text = "C0010" ;
this.solvencyLabel5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel6
//
this.solvencyLabel6.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel6.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel6.Location = new System.Drawing.Point(10,3);
this.solvencyLabel6.Name = "solvencyLabel6";
this.solvencyLabel6.OrdinateID_Label = 6311;
this.solvencyLabel6.Size = new System.Drawing.Size(261, 15);
this.solvencyLabel6.TabIndex = 6;
this.solvencyLabel6.Text = "Non-life catastrophe risk - Summary" ;
this.solvencyLabel6.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel7
//
this.solvencyLabel7.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel7.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel7.Location = new System.Drawing.Point(285,3);
this.solvencyLabel7.Name = "solvencyLabel7";
this.solvencyLabel7.OrdinateID_Label = 0;
this.solvencyLabel7.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel7.TabIndex = 7;
this.solvencyLabel7.Text = "" ;
this.solvencyLabel7.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel8
//
this.solvencyLabel8.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel8.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel8.Location = new System.Drawing.Point(17,23);
this.solvencyLabel8.Name = "solvencyLabel8";
this.solvencyLabel8.OrdinateID_Label = 6312;
this.solvencyLabel8.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel8.TabIndex = 8;
this.solvencyLabel8.Text = "Natural catastrophe risk" ;
this.solvencyLabel8.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel9
//
this.solvencyLabel9.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel9.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel9.Location = new System.Drawing.Point(285,23);
this.solvencyLabel9.Name = "solvencyLabel9";
this.solvencyLabel9.OrdinateID_Label = 0;
this.solvencyLabel9.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel9.TabIndex = 9;
this.solvencyLabel9.Text = "R0010" ;
this.solvencyLabel9.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel10
//
this.solvencyLabel10.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel10.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel10.Location = new System.Drawing.Point(24,43);
this.solvencyLabel10.Name = "solvencyLabel10";
this.solvencyLabel10.OrdinateID_Label = 6313;
this.solvencyLabel10.Size = new System.Drawing.Size(247, 15);
this.solvencyLabel10.TabIndex = 10;
this.solvencyLabel10.Text = "Windstorm" ;
this.solvencyLabel10.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel11
//
this.solvencyLabel11.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel11.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel11.Location = new System.Drawing.Point(285,43);
this.solvencyLabel11.Name = "solvencyLabel11";
this.solvencyLabel11.OrdinateID_Label = 0;
this.solvencyLabel11.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel11.TabIndex = 11;
this.solvencyLabel11.Text = "R0020" ;
this.solvencyLabel11.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel12
//
this.solvencyLabel12.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel12.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel12.Location = new System.Drawing.Point(24,63);
this.solvencyLabel12.Name = "solvencyLabel12";
this.solvencyLabel12.OrdinateID_Label = 6314;
this.solvencyLabel12.Size = new System.Drawing.Size(247, 15);
this.solvencyLabel12.TabIndex = 12;
this.solvencyLabel12.Text = "Earthquake" ;
this.solvencyLabel12.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel13
//
this.solvencyLabel13.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel13.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel13.Location = new System.Drawing.Point(285,63);
this.solvencyLabel13.Name = "solvencyLabel13";
this.solvencyLabel13.OrdinateID_Label = 0;
this.solvencyLabel13.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel13.TabIndex = 13;
this.solvencyLabel13.Text = "R0030" ;
this.solvencyLabel13.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel14
//
this.solvencyLabel14.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel14.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel14.Location = new System.Drawing.Point(24,83);
this.solvencyLabel14.Name = "solvencyLabel14";
this.solvencyLabel14.OrdinateID_Label = 6315;
this.solvencyLabel14.Size = new System.Drawing.Size(247, 15);
this.solvencyLabel14.TabIndex = 14;
this.solvencyLabel14.Text = "Flood" ;
this.solvencyLabel14.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel15
//
this.solvencyLabel15.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel15.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel15.Location = new System.Drawing.Point(285,83);
this.solvencyLabel15.Name = "solvencyLabel15";
this.solvencyLabel15.OrdinateID_Label = 0;
this.solvencyLabel15.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel15.TabIndex = 15;
this.solvencyLabel15.Text = "R0040" ;
this.solvencyLabel15.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel16
//
this.solvencyLabel16.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel16.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel16.Location = new System.Drawing.Point(24,103);
this.solvencyLabel16.Name = "solvencyLabel16";
this.solvencyLabel16.OrdinateID_Label = 6316;
this.solvencyLabel16.Size = new System.Drawing.Size(247, 15);
this.solvencyLabel16.TabIndex = 16;
this.solvencyLabel16.Text = "Hail" ;
this.solvencyLabel16.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel17
//
this.solvencyLabel17.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel17.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel17.Location = new System.Drawing.Point(285,103);
this.solvencyLabel17.Name = "solvencyLabel17";
this.solvencyLabel17.OrdinateID_Label = 0;
this.solvencyLabel17.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel17.TabIndex = 17;
this.solvencyLabel17.Text = "R0050" ;
this.solvencyLabel17.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel18
//
this.solvencyLabel18.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel18.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel18.Location = new System.Drawing.Point(24,123);
this.solvencyLabel18.Name = "solvencyLabel18";
this.solvencyLabel18.OrdinateID_Label = 6317;
this.solvencyLabel18.Size = new System.Drawing.Size(247, 15);
this.solvencyLabel18.TabIndex = 18;
this.solvencyLabel18.Text = "Subsidence" ;
this.solvencyLabel18.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel19
//
this.solvencyLabel19.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel19.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel19.Location = new System.Drawing.Point(285,123);
this.solvencyLabel19.Name = "solvencyLabel19";
this.solvencyLabel19.OrdinateID_Label = 0;
this.solvencyLabel19.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel19.TabIndex = 19;
this.solvencyLabel19.Text = "R0060" ;
this.solvencyLabel19.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel20
//
this.solvencyLabel20.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel20.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel20.Location = new System.Drawing.Point(24,143);
this.solvencyLabel20.Name = "solvencyLabel20";
this.solvencyLabel20.OrdinateID_Label = 6318;
this.solvencyLabel20.Size = new System.Drawing.Size(247, 15);
this.solvencyLabel20.TabIndex = 20;
this.solvencyLabel20.Text = "Diversification between perils" ;
this.solvencyLabel20.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel21
//
this.solvencyLabel21.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel21.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel21.Location = new System.Drawing.Point(285,143);
this.solvencyLabel21.Name = "solvencyLabel21";
this.solvencyLabel21.OrdinateID_Label = 0;
this.solvencyLabel21.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel21.TabIndex = 21;
this.solvencyLabel21.Text = "R0070" ;
this.solvencyLabel21.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel22
//
this.solvencyLabel22.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel22.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel22.Location = new System.Drawing.Point(17,163);
this.solvencyLabel22.Name = "solvencyLabel22";
this.solvencyLabel22.OrdinateID_Label = 6319;
this.solvencyLabel22.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel22.TabIndex = 22;
this.solvencyLabel22.Text = "Catastrophe risk non-proportional property reinsurance" ;
this.solvencyLabel22.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel23
//
this.solvencyLabel23.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel23.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel23.Location = new System.Drawing.Point(285,163);
this.solvencyLabel23.Name = "solvencyLabel23";
this.solvencyLabel23.OrdinateID_Label = 0;
this.solvencyLabel23.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel23.TabIndex = 23;
this.solvencyLabel23.Text = "R0080" ;
this.solvencyLabel23.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel24
//
this.solvencyLabel24.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel24.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel24.Location = new System.Drawing.Point(17,196);
this.solvencyLabel24.Name = "solvencyLabel24";
this.solvencyLabel24.OrdinateID_Label = 6320;
this.solvencyLabel24.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel24.TabIndex = 24;
this.solvencyLabel24.Text = "Man-made catastrophe risk" ;
this.solvencyLabel24.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel25
//
this.solvencyLabel25.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel25.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel25.Location = new System.Drawing.Point(285,196);
this.solvencyLabel25.Name = "solvencyLabel25";
this.solvencyLabel25.OrdinateID_Label = 0;
this.solvencyLabel25.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel25.TabIndex = 25;
this.solvencyLabel25.Text = "R0090" ;
this.solvencyLabel25.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel26
//
this.solvencyLabel26.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel26.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel26.Location = new System.Drawing.Point(24,216);
this.solvencyLabel26.Name = "solvencyLabel26";
this.solvencyLabel26.OrdinateID_Label = 6321;
this.solvencyLabel26.Size = new System.Drawing.Size(247, 15);
this.solvencyLabel26.TabIndex = 26;
this.solvencyLabel26.Text = "Motor vehicle liability" ;
this.solvencyLabel26.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel27
//
this.solvencyLabel27.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel27.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel27.Location = new System.Drawing.Point(285,216);
this.solvencyLabel27.Name = "solvencyLabel27";
this.solvencyLabel27.OrdinateID_Label = 0;
this.solvencyLabel27.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel27.TabIndex = 27;
this.solvencyLabel27.Text = "R0100" ;
this.solvencyLabel27.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel28
//
this.solvencyLabel28.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel28.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel28.Location = new System.Drawing.Point(24,236);
this.solvencyLabel28.Name = "solvencyLabel28";
this.solvencyLabel28.OrdinateID_Label = 6322;
this.solvencyLabel28.Size = new System.Drawing.Size(247, 15);
this.solvencyLabel28.TabIndex = 28;
this.solvencyLabel28.Text = "Marine" ;
this.solvencyLabel28.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel29
//
this.solvencyLabel29.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel29.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel29.Location = new System.Drawing.Point(285,236);
this.solvencyLabel29.Name = "solvencyLabel29";
this.solvencyLabel29.OrdinateID_Label = 0;
this.solvencyLabel29.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel29.TabIndex = 29;
this.solvencyLabel29.Text = "R0110" ;
this.solvencyLabel29.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel30
//
this.solvencyLabel30.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel30.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel30.Location = new System.Drawing.Point(24,256);
this.solvencyLabel30.Name = "solvencyLabel30";
this.solvencyLabel30.OrdinateID_Label = 6323;
this.solvencyLabel30.Size = new System.Drawing.Size(247, 15);
this.solvencyLabel30.TabIndex = 30;
this.solvencyLabel30.Text = "Aviation" ;
this.solvencyLabel30.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel31
//
this.solvencyLabel31.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel31.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel31.Location = new System.Drawing.Point(285,256);
this.solvencyLabel31.Name = "solvencyLabel31";
this.solvencyLabel31.OrdinateID_Label = 0;
this.solvencyLabel31.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel31.TabIndex = 31;
this.solvencyLabel31.Text = "R0120" ;
this.solvencyLabel31.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel32
//
this.solvencyLabel32.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel32.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel32.Location = new System.Drawing.Point(24,276);
this.solvencyLabel32.Name = "solvencyLabel32";
this.solvencyLabel32.OrdinateID_Label = 6324;
this.solvencyLabel32.Size = new System.Drawing.Size(247, 15);
this.solvencyLabel32.TabIndex = 32;
this.solvencyLabel32.Text = "Fire" ;
this.solvencyLabel32.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel33
//
this.solvencyLabel33.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel33.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel33.Location = new System.Drawing.Point(285,276);
this.solvencyLabel33.Name = "solvencyLabel33";
this.solvencyLabel33.OrdinateID_Label = 0;
this.solvencyLabel33.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel33.TabIndex = 33;
this.solvencyLabel33.Text = "R0130" ;
this.solvencyLabel33.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel34
//
this.solvencyLabel34.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel34.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel34.Location = new System.Drawing.Point(24,296);
this.solvencyLabel34.Name = "solvencyLabel34";
this.solvencyLabel34.OrdinateID_Label = 6325;
this.solvencyLabel34.Size = new System.Drawing.Size(247, 15);
this.solvencyLabel34.TabIndex = 34;
this.solvencyLabel34.Text = "Liability" ;
this.solvencyLabel34.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel35
//
this.solvencyLabel35.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel35.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel35.Location = new System.Drawing.Point(285,296);
this.solvencyLabel35.Name = "solvencyLabel35";
this.solvencyLabel35.OrdinateID_Label = 0;
this.solvencyLabel35.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel35.TabIndex = 35;
this.solvencyLabel35.Text = "R0140" ;
this.solvencyLabel35.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel36
//
this.solvencyLabel36.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel36.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel36.Location = new System.Drawing.Point(24,316);
this.solvencyLabel36.Name = "solvencyLabel36";
this.solvencyLabel36.OrdinateID_Label = 6326;
this.solvencyLabel36.Size = new System.Drawing.Size(247, 15);
this.solvencyLabel36.TabIndex = 36;
this.solvencyLabel36.Text = "Credit & Suretyship" ;
this.solvencyLabel36.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel37
//
this.solvencyLabel37.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel37.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel37.Location = new System.Drawing.Point(285,316);
this.solvencyLabel37.Name = "solvencyLabel37";
this.solvencyLabel37.OrdinateID_Label = 0;
this.solvencyLabel37.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel37.TabIndex = 37;
this.solvencyLabel37.Text = "R0150" ;
this.solvencyLabel37.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel38
//
this.solvencyLabel38.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel38.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel38.Location = new System.Drawing.Point(24,336);
this.solvencyLabel38.Name = "solvencyLabel38";
this.solvencyLabel38.OrdinateID_Label = 6327;
this.solvencyLabel38.Size = new System.Drawing.Size(247, 15);
this.solvencyLabel38.TabIndex = 38;
this.solvencyLabel38.Text = "Diversification between perils" ;
this.solvencyLabel38.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel39
//
this.solvencyLabel39.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel39.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel39.Location = new System.Drawing.Point(285,336);
this.solvencyLabel39.Name = "solvencyLabel39";
this.solvencyLabel39.OrdinateID_Label = 0;
this.solvencyLabel39.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel39.TabIndex = 39;
this.solvencyLabel39.Text = "R0160" ;
this.solvencyLabel39.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel40
//
this.solvencyLabel40.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel40.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel40.Location = new System.Drawing.Point(17,356);
this.solvencyLabel40.Name = "solvencyLabel40";
this.solvencyLabel40.OrdinateID_Label = 6328;
this.solvencyLabel40.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel40.TabIndex = 40;
this.solvencyLabel40.Text = "Other non-life catastrophe risk" ;
this.solvencyLabel40.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel41
//
this.solvencyLabel41.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel41.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel41.Location = new System.Drawing.Point(285,356);
this.solvencyLabel41.Name = "solvencyLabel41";
this.solvencyLabel41.OrdinateID_Label = 0;
this.solvencyLabel41.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel41.TabIndex = 41;
this.solvencyLabel41.Text = "R0170" ;
this.solvencyLabel41.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel42
//
this.solvencyLabel42.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel42.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel42.Location = new System.Drawing.Point(24,376);
this.solvencyLabel42.Name = "solvencyLabel42";
this.solvencyLabel42.OrdinateID_Label = 6329;
this.solvencyLabel42.Size = new System.Drawing.Size(247, 15);
this.solvencyLabel42.TabIndex = 42;
this.solvencyLabel42.Text = "Diversification between perils" ;
this.solvencyLabel42.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel43
//
this.solvencyLabel43.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel43.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel43.Location = new System.Drawing.Point(285,376);
this.solvencyLabel43.Name = "solvencyLabel43";
this.solvencyLabel43.OrdinateID_Label = 0;
this.solvencyLabel43.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel43.TabIndex = 43;
this.solvencyLabel43.Text = "R0180" ;
this.solvencyLabel43.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel44
//
this.solvencyLabel44.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel44.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel44.Location = new System.Drawing.Point(17,396);
this.solvencyLabel44.Name = "solvencyLabel44";
this.solvencyLabel44.OrdinateID_Label = 6330;
this.solvencyLabel44.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel44.TabIndex = 44;
this.solvencyLabel44.Text = "Total Non-life catastrophe risk before diversification" ;
this.solvencyLabel44.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel45
//
this.solvencyLabel45.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel45.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel45.Location = new System.Drawing.Point(285,396);
this.solvencyLabel45.Name = "solvencyLabel45";
this.solvencyLabel45.OrdinateID_Label = 0;
this.solvencyLabel45.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel45.TabIndex = 45;
this.solvencyLabel45.Text = "R0190" ;
this.solvencyLabel45.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel46
//
this.solvencyLabel46.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel46.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel46.Location = new System.Drawing.Point(24,416);
this.solvencyLabel46.Name = "solvencyLabel46";
this.solvencyLabel46.OrdinateID_Label = 6331;
this.solvencyLabel46.Size = new System.Drawing.Size(247, 15);
this.solvencyLabel46.TabIndex = 46;
this.solvencyLabel46.Text = "Diversification between sub-modules" ;
this.solvencyLabel46.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel47
//
this.solvencyLabel47.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel47.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel47.Location = new System.Drawing.Point(285,416);
this.solvencyLabel47.Name = "solvencyLabel47";
this.solvencyLabel47.OrdinateID_Label = 0;
this.solvencyLabel47.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel47.TabIndex = 47;
this.solvencyLabel47.Text = "R0200" ;
this.solvencyLabel47.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel48
//
this.solvencyLabel48.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel48.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel48.Location = new System.Drawing.Point(17,436);
this.solvencyLabel48.Name = "solvencyLabel48";
this.solvencyLabel48.OrdinateID_Label = 6332;
this.solvencyLabel48.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel48.TabIndex = 48;
this.solvencyLabel48.Text = "Total Non-life catastrophe risk after diversification" ;
this.solvencyLabel48.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel49
//
this.solvencyLabel49.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel49.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel49.Location = new System.Drawing.Point(285,436);
this.solvencyLabel49.Name = "solvencyLabel49";
this.solvencyLabel49.OrdinateID_Label = 0;
this.solvencyLabel49.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel49.TabIndex = 49;
this.solvencyLabel49.Text = "R0210" ;
this.solvencyLabel49.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel50
//
this.solvencyLabel50.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel50.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel50.Location = new System.Drawing.Point(10,456);
this.solvencyLabel50.Name = "solvencyLabel50";
this.solvencyLabel50.OrdinateID_Label = 6333;
this.solvencyLabel50.Size = new System.Drawing.Size(261, 15);
this.solvencyLabel50.TabIndex = 50;
this.solvencyLabel50.Text = "Health catastrophe risk - Summary" ;
this.solvencyLabel50.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel51
//
this.solvencyLabel51.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel51.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel51.Location = new System.Drawing.Point(285,456);
this.solvencyLabel51.Name = "solvencyLabel51";
this.solvencyLabel51.OrdinateID_Label = 0;
this.solvencyLabel51.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel51.TabIndex = 51;
this.solvencyLabel51.Text = "" ;
this.solvencyLabel51.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel52
//
this.solvencyLabel52.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel52.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel52.Location = new System.Drawing.Point(17,476);
this.solvencyLabel52.Name = "solvencyLabel52";
this.solvencyLabel52.OrdinateID_Label = 6334;
this.solvencyLabel52.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel52.TabIndex = 52;
this.solvencyLabel52.Text = "Health catastrophe risk" ;
this.solvencyLabel52.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel53
//
this.solvencyLabel53.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel53.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel53.Location = new System.Drawing.Point(285,476);
this.solvencyLabel53.Name = "solvencyLabel53";
this.solvencyLabel53.OrdinateID_Label = 0;
this.solvencyLabel53.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel53.TabIndex = 53;
this.solvencyLabel53.Text = "R0300" ;
this.solvencyLabel53.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel54
//
this.solvencyLabel54.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel54.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel54.Location = new System.Drawing.Point(24,496);
this.solvencyLabel54.Name = "solvencyLabel54";
this.solvencyLabel54.OrdinateID_Label = 6335;
this.solvencyLabel54.Size = new System.Drawing.Size(247, 15);
this.solvencyLabel54.TabIndex = 54;
this.solvencyLabel54.Text = "Mass accident" ;
this.solvencyLabel54.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel55
//
this.solvencyLabel55.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel55.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel55.Location = new System.Drawing.Point(285,496);
this.solvencyLabel55.Name = "solvencyLabel55";
this.solvencyLabel55.OrdinateID_Label = 0;
this.solvencyLabel55.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel55.TabIndex = 55;
this.solvencyLabel55.Text = "R0310" ;
this.solvencyLabel55.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel56
//
this.solvencyLabel56.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel56.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel56.Location = new System.Drawing.Point(24,516);
this.solvencyLabel56.Name = "solvencyLabel56";
this.solvencyLabel56.OrdinateID_Label = 6336;
this.solvencyLabel56.Size = new System.Drawing.Size(247, 15);
this.solvencyLabel56.TabIndex = 56;
this.solvencyLabel56.Text = "Accident concentration" ;
this.solvencyLabel56.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel57
//
this.solvencyLabel57.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel57.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel57.Location = new System.Drawing.Point(285,516);
this.solvencyLabel57.Name = "solvencyLabel57";
this.solvencyLabel57.OrdinateID_Label = 0;
this.solvencyLabel57.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel57.TabIndex = 57;
this.solvencyLabel57.Text = "R0320" ;
this.solvencyLabel57.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel58
//
this.solvencyLabel58.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel58.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel58.Location = new System.Drawing.Point(24,536);
this.solvencyLabel58.Name = "solvencyLabel58";
this.solvencyLabel58.OrdinateID_Label = 6337;
this.solvencyLabel58.Size = new System.Drawing.Size(247, 15);
this.solvencyLabel58.TabIndex = 58;
this.solvencyLabel58.Text = "Pandemic" ;
this.solvencyLabel58.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel59
//
this.solvencyLabel59.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel59.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel59.Location = new System.Drawing.Point(285,536);
this.solvencyLabel59.Name = "solvencyLabel59";
this.solvencyLabel59.OrdinateID_Label = 0;
this.solvencyLabel59.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel59.TabIndex = 59;
this.solvencyLabel59.Text = "R0330" ;
this.solvencyLabel59.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel60
//
this.solvencyLabel60.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel60.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel60.Location = new System.Drawing.Point(24,556);
this.solvencyLabel60.Name = "solvencyLabel60";
this.solvencyLabel60.OrdinateID_Label = 6338;
this.solvencyLabel60.Size = new System.Drawing.Size(247, 15);
this.solvencyLabel60.TabIndex = 60;
this.solvencyLabel60.Text = "Diversification between sub-modules" ;
this.solvencyLabel60.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel61
//
this.solvencyLabel61.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel61.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel61.Location = new System.Drawing.Point(285,556);
this.solvencyLabel61.Name = "solvencyLabel61";
this.solvencyLabel61.OrdinateID_Label = 0;
this.solvencyLabel61.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel61.TabIndex = 61;
this.solvencyLabel61.Text = "R0340" ;
this.solvencyLabel61.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel62
//
this.solvencyLabel62.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel62.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel62.Location = new System.Drawing.Point(285,576);
this.solvencyLabel62.Name = "solvencyLabel62";
this.solvencyLabel62.OrdinateID_Label = 0;
this.solvencyLabel62.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel62.TabIndex = 62;
this.solvencyLabel62.Text = "." ;
this.solvencyLabel62.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyCurrencyTextBox63
//
this.solvencyCurrencyTextBox63.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox63.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox63.Location = new System.Drawing.Point(10,23);
this.solvencyCurrencyTextBox63.Name = "solvencyCurrencyTextBox63";
this.solvencyCurrencyTextBox63.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox63.TabIndex = 63;
this.solvencyCurrencyTextBox63.ColName = "R0010C0010";
this.solvencyCurrencyTextBox63.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox64
//
this.solvencyCurrencyTextBox64.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox64.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox64.Location = new System.Drawing.Point(117,23);
this.solvencyCurrencyTextBox64.Name = "solvencyCurrencyTextBox64";
this.solvencyCurrencyTextBox64.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox64.TabIndex = 64;
this.solvencyCurrencyTextBox64.ColName = "R0010C0020";
this.solvencyCurrencyTextBox64.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox65
//
this.solvencyCurrencyTextBox65.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox65.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox65.Location = new System.Drawing.Point(224,23);
this.solvencyCurrencyTextBox65.Name = "solvencyCurrencyTextBox65";
this.solvencyCurrencyTextBox65.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox65.TabIndex = 65;
this.solvencyCurrencyTextBox65.ColName = "R0010C0030";
this.solvencyCurrencyTextBox65.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox66
//
this.solvencyCurrencyTextBox66.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox66.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox66.Location = new System.Drawing.Point(10,43);
this.solvencyCurrencyTextBox66.Name = "solvencyCurrencyTextBox66";
this.solvencyCurrencyTextBox66.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox66.TabIndex = 66;
this.solvencyCurrencyTextBox66.ColName = "R0020C0010";
this.solvencyCurrencyTextBox66.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox67
//
this.solvencyCurrencyTextBox67.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox67.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox67.Location = new System.Drawing.Point(117,43);
this.solvencyCurrencyTextBox67.Name = "solvencyCurrencyTextBox67";
this.solvencyCurrencyTextBox67.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox67.TabIndex = 67;
this.solvencyCurrencyTextBox67.ColName = "R0020C0020";
this.solvencyCurrencyTextBox67.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox68
//
this.solvencyCurrencyTextBox68.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox68.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox68.Location = new System.Drawing.Point(224,43);
this.solvencyCurrencyTextBox68.Name = "solvencyCurrencyTextBox68";
this.solvencyCurrencyTextBox68.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox68.TabIndex = 68;
this.solvencyCurrencyTextBox68.ColName = "R0020C0030";
this.solvencyCurrencyTextBox68.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox69
//
this.solvencyCurrencyTextBox69.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox69.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox69.Location = new System.Drawing.Point(10,63);
this.solvencyCurrencyTextBox69.Name = "solvencyCurrencyTextBox69";
this.solvencyCurrencyTextBox69.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox69.TabIndex = 69;
this.solvencyCurrencyTextBox69.ColName = "R0030C0010";
this.solvencyCurrencyTextBox69.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox70
//
this.solvencyCurrencyTextBox70.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox70.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox70.Location = new System.Drawing.Point(117,63);
this.solvencyCurrencyTextBox70.Name = "solvencyCurrencyTextBox70";
this.solvencyCurrencyTextBox70.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox70.TabIndex = 70;
this.solvencyCurrencyTextBox70.ColName = "R0030C0020";
this.solvencyCurrencyTextBox70.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox71
//
this.solvencyCurrencyTextBox71.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox71.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox71.Location = new System.Drawing.Point(224,63);
this.solvencyCurrencyTextBox71.Name = "solvencyCurrencyTextBox71";
this.solvencyCurrencyTextBox71.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox71.TabIndex = 71;
this.solvencyCurrencyTextBox71.ColName = "R0030C0030";
this.solvencyCurrencyTextBox71.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox72
//
this.solvencyCurrencyTextBox72.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox72.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox72.Location = new System.Drawing.Point(10,83);
this.solvencyCurrencyTextBox72.Name = "solvencyCurrencyTextBox72";
this.solvencyCurrencyTextBox72.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox72.TabIndex = 72;
this.solvencyCurrencyTextBox72.ColName = "R0040C0010";
this.solvencyCurrencyTextBox72.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox73
//
this.solvencyCurrencyTextBox73.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox73.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox73.Location = new System.Drawing.Point(117,83);
this.solvencyCurrencyTextBox73.Name = "solvencyCurrencyTextBox73";
this.solvencyCurrencyTextBox73.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox73.TabIndex = 73;
this.solvencyCurrencyTextBox73.ColName = "R0040C0020";
this.solvencyCurrencyTextBox73.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox74
//
this.solvencyCurrencyTextBox74.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox74.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox74.Location = new System.Drawing.Point(224,83);
this.solvencyCurrencyTextBox74.Name = "solvencyCurrencyTextBox74";
this.solvencyCurrencyTextBox74.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox74.TabIndex = 74;
this.solvencyCurrencyTextBox74.ColName = "R0040C0030";
this.solvencyCurrencyTextBox74.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox75
//
this.solvencyCurrencyTextBox75.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox75.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox75.Location = new System.Drawing.Point(10,103);
this.solvencyCurrencyTextBox75.Name = "solvencyCurrencyTextBox75";
this.solvencyCurrencyTextBox75.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox75.TabIndex = 75;
this.solvencyCurrencyTextBox75.ColName = "R0050C0010";
this.solvencyCurrencyTextBox75.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox76
//
this.solvencyCurrencyTextBox76.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox76.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox76.Location = new System.Drawing.Point(117,103);
this.solvencyCurrencyTextBox76.Name = "solvencyCurrencyTextBox76";
this.solvencyCurrencyTextBox76.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox76.TabIndex = 76;
this.solvencyCurrencyTextBox76.ColName = "R0050C0020";
this.solvencyCurrencyTextBox76.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox77
//
this.solvencyCurrencyTextBox77.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox77.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox77.Location = new System.Drawing.Point(224,103);
this.solvencyCurrencyTextBox77.Name = "solvencyCurrencyTextBox77";
this.solvencyCurrencyTextBox77.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox77.TabIndex = 77;
this.solvencyCurrencyTextBox77.ColName = "R0050C0030";
this.solvencyCurrencyTextBox77.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox78
//
this.solvencyCurrencyTextBox78.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox78.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox78.Location = new System.Drawing.Point(10,123);
this.solvencyCurrencyTextBox78.Name = "solvencyCurrencyTextBox78";
this.solvencyCurrencyTextBox78.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox78.TabIndex = 78;
this.solvencyCurrencyTextBox78.ColName = "R0060C0010";
this.solvencyCurrencyTextBox78.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox79
//
this.solvencyCurrencyTextBox79.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox79.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox79.Location = new System.Drawing.Point(117,123);
this.solvencyCurrencyTextBox79.Name = "solvencyCurrencyTextBox79";
this.solvencyCurrencyTextBox79.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox79.TabIndex = 79;
this.solvencyCurrencyTextBox79.ColName = "R0060C0020";
this.solvencyCurrencyTextBox79.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox80
//
this.solvencyCurrencyTextBox80.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox80.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox80.Location = new System.Drawing.Point(224,123);
this.solvencyCurrencyTextBox80.Name = "solvencyCurrencyTextBox80";
this.solvencyCurrencyTextBox80.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox80.TabIndex = 80;
this.solvencyCurrencyTextBox80.ColName = "R0060C0030";
this.solvencyCurrencyTextBox80.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox81
//
this.solvencyCurrencyTextBox81.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox81.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox81.Location = new System.Drawing.Point(10,143);
this.solvencyCurrencyTextBox81.Name = "solvencyCurrencyTextBox81";
this.solvencyCurrencyTextBox81.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox81.TabIndex = 81;
this.solvencyCurrencyTextBox81.ColName = "R0070C0010";
this.solvencyCurrencyTextBox81.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox82
//
this.solvencyCurrencyTextBox82.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox82.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox82.Location = new System.Drawing.Point(117,143);
this.solvencyCurrencyTextBox82.Name = "solvencyCurrencyTextBox82";
this.solvencyCurrencyTextBox82.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox82.TabIndex = 82;
this.solvencyCurrencyTextBox82.ColName = "R0070C0020";
this.solvencyCurrencyTextBox82.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox83
//
this.solvencyCurrencyTextBox83.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox83.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox83.Location = new System.Drawing.Point(224,143);
this.solvencyCurrencyTextBox83.Name = "solvencyCurrencyTextBox83";
this.solvencyCurrencyTextBox83.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox83.TabIndex = 83;
this.solvencyCurrencyTextBox83.ColName = "R0070C0030";
this.solvencyCurrencyTextBox83.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox84
//
this.solvencyCurrencyTextBox84.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox84.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox84.Location = new System.Drawing.Point(10,163);
this.solvencyCurrencyTextBox84.Name = "solvencyCurrencyTextBox84";
this.solvencyCurrencyTextBox84.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox84.TabIndex = 84;
this.solvencyCurrencyTextBox84.ColName = "R0080C0010";
this.solvencyCurrencyTextBox84.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox85
//
this.solvencyCurrencyTextBox85.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox85.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox85.Location = new System.Drawing.Point(117,163);
this.solvencyCurrencyTextBox85.Name = "solvencyCurrencyTextBox85";
this.solvencyCurrencyTextBox85.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox85.TabIndex = 85;
this.solvencyCurrencyTextBox85.ColName = "R0080C0020";
this.solvencyCurrencyTextBox85.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox86
//
this.solvencyCurrencyTextBox86.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox86.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox86.Location = new System.Drawing.Point(224,163);
this.solvencyCurrencyTextBox86.Name = "solvencyCurrencyTextBox86";
this.solvencyCurrencyTextBox86.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox86.TabIndex = 86;
this.solvencyCurrencyTextBox86.ColName = "R0080C0030";
this.solvencyCurrencyTextBox86.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox87
//
this.solvencyCurrencyTextBox87.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox87.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox87.Location = new System.Drawing.Point(10,196);
this.solvencyCurrencyTextBox87.Name = "solvencyCurrencyTextBox87";
this.solvencyCurrencyTextBox87.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox87.TabIndex = 87;
this.solvencyCurrencyTextBox87.ColName = "R0090C0010";
this.solvencyCurrencyTextBox87.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox88
//
this.solvencyCurrencyTextBox88.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox88.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox88.Location = new System.Drawing.Point(117,196);
this.solvencyCurrencyTextBox88.Name = "solvencyCurrencyTextBox88";
this.solvencyCurrencyTextBox88.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox88.TabIndex = 88;
this.solvencyCurrencyTextBox88.ColName = "R0090C0020";
this.solvencyCurrencyTextBox88.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox89
//
this.solvencyCurrencyTextBox89.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox89.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox89.Location = new System.Drawing.Point(224,196);
this.solvencyCurrencyTextBox89.Name = "solvencyCurrencyTextBox89";
this.solvencyCurrencyTextBox89.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox89.TabIndex = 89;
this.solvencyCurrencyTextBox89.ColName = "R0090C0030";
this.solvencyCurrencyTextBox89.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox90
//
this.solvencyCurrencyTextBox90.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox90.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox90.Location = new System.Drawing.Point(10,216);
this.solvencyCurrencyTextBox90.Name = "solvencyCurrencyTextBox90";
this.solvencyCurrencyTextBox90.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox90.TabIndex = 90;
this.solvencyCurrencyTextBox90.ColName = "R0100C0010";
this.solvencyCurrencyTextBox90.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox91
//
this.solvencyCurrencyTextBox91.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox91.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox91.Location = new System.Drawing.Point(117,216);
this.solvencyCurrencyTextBox91.Name = "solvencyCurrencyTextBox91";
this.solvencyCurrencyTextBox91.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox91.TabIndex = 91;
this.solvencyCurrencyTextBox91.ColName = "R0100C0020";
this.solvencyCurrencyTextBox91.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox92
//
this.solvencyCurrencyTextBox92.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox92.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox92.Location = new System.Drawing.Point(224,216);
this.solvencyCurrencyTextBox92.Name = "solvencyCurrencyTextBox92";
this.solvencyCurrencyTextBox92.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox92.TabIndex = 92;
this.solvencyCurrencyTextBox92.ColName = "R0100C0030";
this.solvencyCurrencyTextBox92.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox93
//
this.solvencyCurrencyTextBox93.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox93.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox93.Location = new System.Drawing.Point(10,236);
this.solvencyCurrencyTextBox93.Name = "solvencyCurrencyTextBox93";
this.solvencyCurrencyTextBox93.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox93.TabIndex = 93;
this.solvencyCurrencyTextBox93.ColName = "R0110C0010";
this.solvencyCurrencyTextBox93.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox94
//
this.solvencyCurrencyTextBox94.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox94.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox94.Location = new System.Drawing.Point(117,236);
this.solvencyCurrencyTextBox94.Name = "solvencyCurrencyTextBox94";
this.solvencyCurrencyTextBox94.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox94.TabIndex = 94;
this.solvencyCurrencyTextBox94.ColName = "R0110C0020";
this.solvencyCurrencyTextBox94.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox95
//
this.solvencyCurrencyTextBox95.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox95.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox95.Location = new System.Drawing.Point(224,236);
this.solvencyCurrencyTextBox95.Name = "solvencyCurrencyTextBox95";
this.solvencyCurrencyTextBox95.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox95.TabIndex = 95;
this.solvencyCurrencyTextBox95.ColName = "R0110C0030";
this.solvencyCurrencyTextBox95.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox96
//
this.solvencyCurrencyTextBox96.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox96.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox96.Location = new System.Drawing.Point(10,256);
this.solvencyCurrencyTextBox96.Name = "solvencyCurrencyTextBox96";
this.solvencyCurrencyTextBox96.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox96.TabIndex = 96;
this.solvencyCurrencyTextBox96.ColName = "R0120C0010";
this.solvencyCurrencyTextBox96.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox97
//
this.solvencyCurrencyTextBox97.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox97.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox97.Location = new System.Drawing.Point(117,256);
this.solvencyCurrencyTextBox97.Name = "solvencyCurrencyTextBox97";
this.solvencyCurrencyTextBox97.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox97.TabIndex = 97;
this.solvencyCurrencyTextBox97.ColName = "R0120C0020";
this.solvencyCurrencyTextBox97.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox98
//
this.solvencyCurrencyTextBox98.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox98.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox98.Location = new System.Drawing.Point(224,256);
this.solvencyCurrencyTextBox98.Name = "solvencyCurrencyTextBox98";
this.solvencyCurrencyTextBox98.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox98.TabIndex = 98;
this.solvencyCurrencyTextBox98.ColName = "R0120C0030";
this.solvencyCurrencyTextBox98.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox99
//
this.solvencyCurrencyTextBox99.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox99.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox99.Location = new System.Drawing.Point(10,276);
this.solvencyCurrencyTextBox99.Name = "solvencyCurrencyTextBox99";
this.solvencyCurrencyTextBox99.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox99.TabIndex = 99;
this.solvencyCurrencyTextBox99.ColName = "R0130C0010";
this.solvencyCurrencyTextBox99.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox100
//
this.solvencyCurrencyTextBox100.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox100.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox100.Location = new System.Drawing.Point(117,276);
this.solvencyCurrencyTextBox100.Name = "solvencyCurrencyTextBox100";
this.solvencyCurrencyTextBox100.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox100.TabIndex = 100;
this.solvencyCurrencyTextBox100.ColName = "R0130C0020";
this.solvencyCurrencyTextBox100.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox101
//
this.solvencyCurrencyTextBox101.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox101.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox101.Location = new System.Drawing.Point(224,276);
this.solvencyCurrencyTextBox101.Name = "solvencyCurrencyTextBox101";
this.solvencyCurrencyTextBox101.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox101.TabIndex = 101;
this.solvencyCurrencyTextBox101.ColName = "R0130C0030";
this.solvencyCurrencyTextBox101.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox102
//
this.solvencyCurrencyTextBox102.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox102.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox102.Location = new System.Drawing.Point(10,296);
this.solvencyCurrencyTextBox102.Name = "solvencyCurrencyTextBox102";
this.solvencyCurrencyTextBox102.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox102.TabIndex = 102;
this.solvencyCurrencyTextBox102.ColName = "R0140C0010";
this.solvencyCurrencyTextBox102.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox103
//
this.solvencyCurrencyTextBox103.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox103.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox103.Location = new System.Drawing.Point(117,296);
this.solvencyCurrencyTextBox103.Name = "solvencyCurrencyTextBox103";
this.solvencyCurrencyTextBox103.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox103.TabIndex = 103;
this.solvencyCurrencyTextBox103.ColName = "R0140C0020";
this.solvencyCurrencyTextBox103.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox104
//
this.solvencyCurrencyTextBox104.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox104.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox104.Location = new System.Drawing.Point(224,296);
this.solvencyCurrencyTextBox104.Name = "solvencyCurrencyTextBox104";
this.solvencyCurrencyTextBox104.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox104.TabIndex = 104;
this.solvencyCurrencyTextBox104.ColName = "R0140C0030";
this.solvencyCurrencyTextBox104.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox105
//
this.solvencyCurrencyTextBox105.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox105.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox105.Location = new System.Drawing.Point(10,316);
this.solvencyCurrencyTextBox105.Name = "solvencyCurrencyTextBox105";
this.solvencyCurrencyTextBox105.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox105.TabIndex = 105;
this.solvencyCurrencyTextBox105.ColName = "R0150C0010";
this.solvencyCurrencyTextBox105.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox106
//
this.solvencyCurrencyTextBox106.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox106.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox106.Location = new System.Drawing.Point(117,316);
this.solvencyCurrencyTextBox106.Name = "solvencyCurrencyTextBox106";
this.solvencyCurrencyTextBox106.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox106.TabIndex = 106;
this.solvencyCurrencyTextBox106.ColName = "R0150C0020";
this.solvencyCurrencyTextBox106.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox107
//
this.solvencyCurrencyTextBox107.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox107.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox107.Location = new System.Drawing.Point(224,316);
this.solvencyCurrencyTextBox107.Name = "solvencyCurrencyTextBox107";
this.solvencyCurrencyTextBox107.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox107.TabIndex = 107;
this.solvencyCurrencyTextBox107.ColName = "R0150C0030";
this.solvencyCurrencyTextBox107.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox108
//
this.solvencyCurrencyTextBox108.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox108.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox108.Location = new System.Drawing.Point(10,336);
this.solvencyCurrencyTextBox108.Name = "solvencyCurrencyTextBox108";
this.solvencyCurrencyTextBox108.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox108.TabIndex = 108;
this.solvencyCurrencyTextBox108.ColName = "R0160C0010";
this.solvencyCurrencyTextBox108.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox109
//
this.solvencyCurrencyTextBox109.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox109.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox109.Location = new System.Drawing.Point(117,336);
this.solvencyCurrencyTextBox109.Name = "solvencyCurrencyTextBox109";
this.solvencyCurrencyTextBox109.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox109.TabIndex = 109;
this.solvencyCurrencyTextBox109.ColName = "R0160C0020";
this.solvencyCurrencyTextBox109.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox110
//
this.solvencyCurrencyTextBox110.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox110.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox110.Location = new System.Drawing.Point(224,336);
this.solvencyCurrencyTextBox110.Name = "solvencyCurrencyTextBox110";
this.solvencyCurrencyTextBox110.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox110.TabIndex = 110;
this.solvencyCurrencyTextBox110.ColName = "R0160C0030";
this.solvencyCurrencyTextBox110.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox111
//
this.solvencyCurrencyTextBox111.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox111.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox111.Location = new System.Drawing.Point(10,356);
this.solvencyCurrencyTextBox111.Name = "solvencyCurrencyTextBox111";
this.solvencyCurrencyTextBox111.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox111.TabIndex = 111;
this.solvencyCurrencyTextBox111.ColName = "R0170C0010";
this.solvencyCurrencyTextBox111.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox112
//
this.solvencyCurrencyTextBox112.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox112.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox112.Location = new System.Drawing.Point(117,356);
this.solvencyCurrencyTextBox112.Name = "solvencyCurrencyTextBox112";
this.solvencyCurrencyTextBox112.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox112.TabIndex = 112;
this.solvencyCurrencyTextBox112.ColName = "R0170C0020";
this.solvencyCurrencyTextBox112.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox113
//
this.solvencyCurrencyTextBox113.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox113.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox113.Location = new System.Drawing.Point(224,356);
this.solvencyCurrencyTextBox113.Name = "solvencyCurrencyTextBox113";
this.solvencyCurrencyTextBox113.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox113.TabIndex = 113;
this.solvencyCurrencyTextBox113.ColName = "R0170C0030";
this.solvencyCurrencyTextBox113.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox114
//
this.solvencyCurrencyTextBox114.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox114.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox114.Location = new System.Drawing.Point(10,376);
this.solvencyCurrencyTextBox114.Name = "solvencyCurrencyTextBox114";
this.solvencyCurrencyTextBox114.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox114.TabIndex = 114;
this.solvencyCurrencyTextBox114.ColName = "R0180C0010";
this.solvencyCurrencyTextBox114.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox115
//
this.solvencyCurrencyTextBox115.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox115.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox115.Location = new System.Drawing.Point(117,376);
this.solvencyCurrencyTextBox115.Name = "solvencyCurrencyTextBox115";
this.solvencyCurrencyTextBox115.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox115.TabIndex = 115;
this.solvencyCurrencyTextBox115.ColName = "R0180C0020";
this.solvencyCurrencyTextBox115.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox116
//
this.solvencyCurrencyTextBox116.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox116.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox116.Location = new System.Drawing.Point(224,376);
this.solvencyCurrencyTextBox116.Name = "solvencyCurrencyTextBox116";
this.solvencyCurrencyTextBox116.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox116.TabIndex = 116;
this.solvencyCurrencyTextBox116.ColName = "R0180C0030";
this.solvencyCurrencyTextBox116.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox117
//
this.solvencyCurrencyTextBox117.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox117.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox117.Location = new System.Drawing.Point(10,396);
this.solvencyCurrencyTextBox117.Name = "solvencyCurrencyTextBox117";
this.solvencyCurrencyTextBox117.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox117.TabIndex = 117;
this.solvencyCurrencyTextBox117.ColName = "R0190C0010";
this.solvencyCurrencyTextBox117.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox118
//
this.solvencyCurrencyTextBox118.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox118.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox118.Location = new System.Drawing.Point(117,396);
this.solvencyCurrencyTextBox118.Name = "solvencyCurrencyTextBox118";
this.solvencyCurrencyTextBox118.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox118.TabIndex = 118;
this.solvencyCurrencyTextBox118.ColName = "R0190C0020";
this.solvencyCurrencyTextBox118.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox119
//
this.solvencyCurrencyTextBox119.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox119.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox119.Location = new System.Drawing.Point(224,396);
this.solvencyCurrencyTextBox119.Name = "solvencyCurrencyTextBox119";
this.solvencyCurrencyTextBox119.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox119.TabIndex = 119;
this.solvencyCurrencyTextBox119.ColName = "R0190C0030";
this.solvencyCurrencyTextBox119.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox120
//
this.solvencyCurrencyTextBox120.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox120.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox120.Location = new System.Drawing.Point(10,416);
this.solvencyCurrencyTextBox120.Name = "solvencyCurrencyTextBox120";
this.solvencyCurrencyTextBox120.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox120.TabIndex = 120;
this.solvencyCurrencyTextBox120.ColName = "R0200C0010";
this.solvencyCurrencyTextBox120.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox121
//
this.solvencyCurrencyTextBox121.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox121.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox121.Location = new System.Drawing.Point(117,416);
this.solvencyCurrencyTextBox121.Name = "solvencyCurrencyTextBox121";
this.solvencyCurrencyTextBox121.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox121.TabIndex = 121;
this.solvencyCurrencyTextBox121.ColName = "R0200C0020";
this.solvencyCurrencyTextBox121.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox122
//
this.solvencyCurrencyTextBox122.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox122.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox122.Location = new System.Drawing.Point(224,416);
this.solvencyCurrencyTextBox122.Name = "solvencyCurrencyTextBox122";
this.solvencyCurrencyTextBox122.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox122.TabIndex = 122;
this.solvencyCurrencyTextBox122.ColName = "R0200C0030";
this.solvencyCurrencyTextBox122.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox123
//
this.solvencyCurrencyTextBox123.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox123.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox123.Location = new System.Drawing.Point(10,436);
this.solvencyCurrencyTextBox123.Name = "solvencyCurrencyTextBox123";
this.solvencyCurrencyTextBox123.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox123.TabIndex = 123;
this.solvencyCurrencyTextBox123.ColName = "R0210C0010";
this.solvencyCurrencyTextBox123.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox124
//
this.solvencyCurrencyTextBox124.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox124.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox124.Location = new System.Drawing.Point(117,436);
this.solvencyCurrencyTextBox124.Name = "solvencyCurrencyTextBox124";
this.solvencyCurrencyTextBox124.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox124.TabIndex = 124;
this.solvencyCurrencyTextBox124.ColName = "R0210C0020";
this.solvencyCurrencyTextBox124.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox125
//
this.solvencyCurrencyTextBox125.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox125.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox125.Location = new System.Drawing.Point(224,436);
this.solvencyCurrencyTextBox125.Name = "solvencyCurrencyTextBox125";
this.solvencyCurrencyTextBox125.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox125.TabIndex = 125;
this.solvencyCurrencyTextBox125.ColName = "R0210C0030";
this.solvencyCurrencyTextBox125.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox126
//
this.solvencyCurrencyTextBox126.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox126.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox126.Location = new System.Drawing.Point(10,476);
this.solvencyCurrencyTextBox126.Name = "solvencyCurrencyTextBox126";
this.solvencyCurrencyTextBox126.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox126.TabIndex = 126;
this.solvencyCurrencyTextBox126.ColName = "R0300C0010";
this.solvencyCurrencyTextBox126.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox127
//
this.solvencyCurrencyTextBox127.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox127.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox127.Location = new System.Drawing.Point(117,476);
this.solvencyCurrencyTextBox127.Name = "solvencyCurrencyTextBox127";
this.solvencyCurrencyTextBox127.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox127.TabIndex = 127;
this.solvencyCurrencyTextBox127.ColName = "R0300C0020";
this.solvencyCurrencyTextBox127.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox128
//
this.solvencyCurrencyTextBox128.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox128.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox128.Location = new System.Drawing.Point(224,476);
this.solvencyCurrencyTextBox128.Name = "solvencyCurrencyTextBox128";
this.solvencyCurrencyTextBox128.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox128.TabIndex = 128;
this.solvencyCurrencyTextBox128.ColName = "R0300C0030";
this.solvencyCurrencyTextBox128.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox129
//
this.solvencyCurrencyTextBox129.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox129.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox129.Location = new System.Drawing.Point(10,496);
this.solvencyCurrencyTextBox129.Name = "solvencyCurrencyTextBox129";
this.solvencyCurrencyTextBox129.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox129.TabIndex = 129;
this.solvencyCurrencyTextBox129.ColName = "R0310C0010";
this.solvencyCurrencyTextBox129.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox130
//
this.solvencyCurrencyTextBox130.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox130.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox130.Location = new System.Drawing.Point(117,496);
this.solvencyCurrencyTextBox130.Name = "solvencyCurrencyTextBox130";
this.solvencyCurrencyTextBox130.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox130.TabIndex = 130;
this.solvencyCurrencyTextBox130.ColName = "R0310C0020";
this.solvencyCurrencyTextBox130.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox131
//
this.solvencyCurrencyTextBox131.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox131.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox131.Location = new System.Drawing.Point(224,496);
this.solvencyCurrencyTextBox131.Name = "solvencyCurrencyTextBox131";
this.solvencyCurrencyTextBox131.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox131.TabIndex = 131;
this.solvencyCurrencyTextBox131.ColName = "R0310C0030";
this.solvencyCurrencyTextBox131.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox132
//
this.solvencyCurrencyTextBox132.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox132.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox132.Location = new System.Drawing.Point(10,516);
this.solvencyCurrencyTextBox132.Name = "solvencyCurrencyTextBox132";
this.solvencyCurrencyTextBox132.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox132.TabIndex = 132;
this.solvencyCurrencyTextBox132.ColName = "R0320C0010";
this.solvencyCurrencyTextBox132.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox133
//
this.solvencyCurrencyTextBox133.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox133.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox133.Location = new System.Drawing.Point(117,516);
this.solvencyCurrencyTextBox133.Name = "solvencyCurrencyTextBox133";
this.solvencyCurrencyTextBox133.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox133.TabIndex = 133;
this.solvencyCurrencyTextBox133.ColName = "R0320C0020";
this.solvencyCurrencyTextBox133.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox134
//
this.solvencyCurrencyTextBox134.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox134.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox134.Location = new System.Drawing.Point(224,516);
this.solvencyCurrencyTextBox134.Name = "solvencyCurrencyTextBox134";
this.solvencyCurrencyTextBox134.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox134.TabIndex = 134;
this.solvencyCurrencyTextBox134.ColName = "R0320C0030";
this.solvencyCurrencyTextBox134.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox135
//
this.solvencyCurrencyTextBox135.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox135.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox135.Location = new System.Drawing.Point(10,536);
this.solvencyCurrencyTextBox135.Name = "solvencyCurrencyTextBox135";
this.solvencyCurrencyTextBox135.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox135.TabIndex = 135;
this.solvencyCurrencyTextBox135.ColName = "R0330C0010";
this.solvencyCurrencyTextBox135.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox136
//
this.solvencyCurrencyTextBox136.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox136.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox136.Location = new System.Drawing.Point(117,536);
this.solvencyCurrencyTextBox136.Name = "solvencyCurrencyTextBox136";
this.solvencyCurrencyTextBox136.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox136.TabIndex = 136;
this.solvencyCurrencyTextBox136.ColName = "R0330C0020";
this.solvencyCurrencyTextBox136.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox137
//
this.solvencyCurrencyTextBox137.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox137.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox137.Location = new System.Drawing.Point(224,536);
this.solvencyCurrencyTextBox137.Name = "solvencyCurrencyTextBox137";
this.solvencyCurrencyTextBox137.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox137.TabIndex = 137;
this.solvencyCurrencyTextBox137.ColName = "R0330C0030";
this.solvencyCurrencyTextBox137.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox138
//
this.solvencyCurrencyTextBox138.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox138.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox138.Location = new System.Drawing.Point(10,556);
this.solvencyCurrencyTextBox138.Name = "solvencyCurrencyTextBox138";
this.solvencyCurrencyTextBox138.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox138.TabIndex = 138;
this.solvencyCurrencyTextBox138.ColName = "R0340C0010";
this.solvencyCurrencyTextBox138.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox139
//
this.solvencyCurrencyTextBox139.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox139.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox139.Location = new System.Drawing.Point(117,556);
this.solvencyCurrencyTextBox139.Name = "solvencyCurrencyTextBox139";
this.solvencyCurrencyTextBox139.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox139.TabIndex = 139;
this.solvencyCurrencyTextBox139.ColName = "R0340C0020";
this.solvencyCurrencyTextBox139.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox140
//
this.solvencyCurrencyTextBox140.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox140.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox140.Location = new System.Drawing.Point(224,556);
this.solvencyCurrencyTextBox140.Name = "solvencyCurrencyTextBox140";
this.solvencyCurrencyTextBox140.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox140.TabIndex = 140;
this.solvencyCurrencyTextBox140.ColName = "R0340C0030";
this.solvencyCurrencyTextBox140.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// splitContainerColTitles
//
this.splitContainerColTitles.Dock = System.Windows.Forms.DockStyle.Fill;
this.splitContainerColTitles.Location = new System.Drawing.Point(0,0);
this.splitContainerColTitles.Name = "splitContainerColTitles";
this.splitContainerColTitles.Orientation = System.Windows.Forms.Orientation.Vertical;
this.splitContainerColTitles.Panel1MinSize = 0;
//
// splitContainerColTitles.Panel1
//
//
// splitContainerColTitles.Panel2
//
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel0);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel1);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel2);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel3);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel4);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel5);
this.splitContainerColTitles.Size = new System.Drawing.Size(770, 392);
this.splitContainerColTitles.SplitterDistance = 332;
//
// splitContainerRowTitles
//
this.splitContainerRowTitles.Dock = System.Windows.Forms.DockStyle.Fill;
this.splitContainerRowTitles.Location = new System.Drawing.Point(0,0);
this.splitContainerRowTitles.Name = "splitContainerRowTitles";
this.splitContainerRowTitles.Orientation = System.Windows.Forms.Orientation.Vertical;
this.splitContainerRowTitles.Panel1MinSize = 0;
//
// splitContainerRowTitles.Panel1
//
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel6);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel7);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel8);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel9);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel10);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel11);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel12);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel13);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel14);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel15);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel16);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel17);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel18);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel19);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel20);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel21);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel22);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel23);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel24);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel25);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel26);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel27);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel28);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel29);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel30);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel31);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel32);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel33);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel34);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel35);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel36);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel37);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel38);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel39);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel40);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel41);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel42);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel43);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel44);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel45);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel46);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel47);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel48);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel49);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel50);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel51);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel52);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel53);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel54);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel55);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel56);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel57);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel58);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel59);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel60);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel61);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel62);
//
// splitContainerRowTitles.Panel2
//
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox63);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox64);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox65);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox66);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox67);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox68);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox69);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox70);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox71);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox72);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox73);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox74);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox75);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox76);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox77);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox78);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox79);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox80);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox81);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox82);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox83);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox84);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox85);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox86);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox87);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox88);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox89);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox90);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox91);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox92);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox93);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox94);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox95);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox96);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox97);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox98);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox99);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox100);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox101);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox102);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox103);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox104);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox105);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox106);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox107);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox108);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox109);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox110);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox111);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox112);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox113);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox114);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox115);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox116);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox117);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox118);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox119);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox120);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox121);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox122);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox123);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox124);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox125);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox126);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox127);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox128);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox129);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox130);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox131);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox132);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox133);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox134);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox135);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox136);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox137);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox138);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox139);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox140);
this.splitContainerRowTitles.Panel2.AutoScroll = true;
this.splitContainerRowTitles.Size = new System.Drawing.Size(770, 392);
this.splitContainerRowTitles.SplitterDistance = 332;
//
// spltMain
//
this.spltMain.Dock = System.Windows.Forms.DockStyle.Fill;
this.spltMain.Location = new System.Drawing.Point(0,0);
this.spltMain.Name = "spltMain";
this.spltMain.Orientation = System.Windows.Forms.Orientation.Horizontal;
this.spltMain.Panel1MinSize = 0;
//
// spltMain.Panel1
//
this.spltMain.Panel1.Controls.Add(this.splitContainerColTitles);
//
// spltMain.Panel2
//
this.spltMain.Panel2.Controls.Add(this.splitContainerRowTitles);
this.spltMain.Panel2.AutoScroll = true;
this.spltMain.Size = new System.Drawing.Size(770, 699);
this.spltMain.SplitterDistance = 60;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F); 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font; 
this.Controls.Add(this.spltMain);
            this.Name = "S_27_01_01_01__sol2__2_0_1_ctrl"; 
            this.Size = new System.Drawing.Size(770, 639); 
            this.Load += new System.EventHandler(this.BoundControl_Load);
            this.ResumeLayout(false); 
            this.PerformLayout(); 

      } 
private SolvencyLabel solvencyLabel0;
private SolvencyLabel solvencyLabel1;
private SolvencyLabel solvencyLabel2;
private SolvencyLabel solvencyLabel3;
private SolvencyLabel solvencyLabel4;
private SolvencyLabel solvencyLabel5;
private SolvencyLabel solvencyLabel6;
private SolvencyLabel solvencyLabel7;
private SolvencyLabel solvencyLabel8;
private SolvencyLabel solvencyLabel9;
private SolvencyLabel solvencyLabel10;
private SolvencyLabel solvencyLabel11;
private SolvencyLabel solvencyLabel12;
private SolvencyLabel solvencyLabel13;
private SolvencyLabel solvencyLabel14;
private SolvencyLabel solvencyLabel15;
private SolvencyLabel solvencyLabel16;
private SolvencyLabel solvencyLabel17;
private SolvencyLabel solvencyLabel18;
private SolvencyLabel solvencyLabel19;
private SolvencyLabel solvencyLabel20;
private SolvencyLabel solvencyLabel21;
private SolvencyLabel solvencyLabel22;
private SolvencyLabel solvencyLabel23;
private SolvencyLabel solvencyLabel24;
private SolvencyLabel solvencyLabel25;
private SolvencyLabel solvencyLabel26;
private SolvencyLabel solvencyLabel27;
private SolvencyLabel solvencyLabel28;
private SolvencyLabel solvencyLabel29;
private SolvencyLabel solvencyLabel30;
private SolvencyLabel solvencyLabel31;
private SolvencyLabel solvencyLabel32;
private SolvencyLabel solvencyLabel33;
private SolvencyLabel solvencyLabel34;
private SolvencyLabel solvencyLabel35;
private SolvencyLabel solvencyLabel36;
private SolvencyLabel solvencyLabel37;
private SolvencyLabel solvencyLabel38;
private SolvencyLabel solvencyLabel39;
private SolvencyLabel solvencyLabel40;
private SolvencyLabel solvencyLabel41;
private SolvencyLabel solvencyLabel42;
private SolvencyLabel solvencyLabel43;
private SolvencyLabel solvencyLabel44;
private SolvencyLabel solvencyLabel45;
private SolvencyLabel solvencyLabel46;
private SolvencyLabel solvencyLabel47;
private SolvencyLabel solvencyLabel48;
private SolvencyLabel solvencyLabel49;
private SolvencyLabel solvencyLabel50;
private SolvencyLabel solvencyLabel51;
private SolvencyLabel solvencyLabel52;
private SolvencyLabel solvencyLabel53;
private SolvencyLabel solvencyLabel54;
private SolvencyLabel solvencyLabel55;
private SolvencyLabel solvencyLabel56;
private SolvencyLabel solvencyLabel57;
private SolvencyLabel solvencyLabel58;
private SolvencyLabel solvencyLabel59;
private SolvencyLabel solvencyLabel60;
private SolvencyLabel solvencyLabel61;
private SolvencyLabel solvencyLabel62;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox63;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox64;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox65;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox66;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox67;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox68;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox69;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox70;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox71;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox72;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox73;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox74;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox75;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox76;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox77;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox78;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox79;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox80;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox81;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox82;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox83;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox84;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox85;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox86;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox87;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox88;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox89;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox90;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox91;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox92;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox93;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox94;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox95;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox96;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox97;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox98;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox99;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox100;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox101;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox102;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox103;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox104;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox105;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox106;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox107;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox108;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox109;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox110;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox111;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox112;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox113;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox114;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox115;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox116;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox117;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox118;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox119;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox120;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox121;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox122;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox123;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox124;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox125;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox126;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox127;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox128;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox129;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox130;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox131;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox132;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox133;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox134;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox135;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox136;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox137;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox138;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox139;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox140;
private SolvencySplitContainer splitContainerColTitles;
private SolvencySplitContainer splitContainerRowTitles;
private SolvencySplitContainer spltMain;

   }
}

