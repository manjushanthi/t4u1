using SolvencyII.Domain.ENumerators; 
using SolvencyII.UI.Shared.Controls; 

namespace SolvencyII.UI.UserControls 
{ 
   partial class S_01_01_09_01__sol2__2_0_1_ctrl 
   { 
      private void InitializeComponent() 
      { 
this.solvencyLabel1 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel2 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel3 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel4 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel5 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel6 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel7 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel8 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel9 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel10 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel11 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel12 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel13 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel14 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel15 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel16 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel17 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel18 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel19 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel20 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel21 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel22 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.SolvencyDataComboBox23 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox24 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox25 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox26 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox27 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox28 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox29 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox30 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox31 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.splitContainerColTitles = new SolvencyII.UI.Shared.Controls.SolvencySplitContainer();
this.splitContainerRowTitles = new SolvencyII.UI.Shared.Controls.SolvencySplitContainer();
this.spltMain = new SolvencyII.UI.Shared.Controls.SolvencySplitContainer();
            this.SuspendLayout(); 

//
// solvencyLabel1
//
this.solvencyLabel1.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel1.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel1.Location = new System.Drawing.Point(10,30);
this.solvencyLabel1.Name = "solvencyLabel1";
this.solvencyLabel1.OrdinateID_Label = 0;
this.solvencyLabel1.Size = new System.Drawing.Size(208, 13);
this.solvencyLabel1.TabIndex = 1;
this.solvencyLabel1.Text = "C0010" ;
this.solvencyLabel1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel2
//
this.solvencyLabel2.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel2.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel2.Location = new System.Drawing.Point(10,3);
this.solvencyLabel2.Name = "solvencyLabel2";
this.solvencyLabel2.OrdinateID_Label = 250;
this.solvencyLabel2.Size = new System.Drawing.Size(261, 15);
this.solvencyLabel2.TabIndex = 2;
this.solvencyLabel2.Text = "Template Code - Template name" ;
this.solvencyLabel2.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel3
//
this.solvencyLabel3.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel3.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel3.Location = new System.Drawing.Point(285,3);
this.solvencyLabel3.Name = "solvencyLabel3";
this.solvencyLabel3.OrdinateID_Label = 0;
this.solvencyLabel3.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel3.TabIndex = 3;
this.solvencyLabel3.Text = "" ;
this.solvencyLabel3.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel4
//
this.solvencyLabel4.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel4.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel4.Location = new System.Drawing.Point(17,23);
this.solvencyLabel4.Name = "solvencyLabel4";
this.solvencyLabel4.OrdinateID_Label = 251;
this.solvencyLabel4.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel4.TabIndex = 4;
this.solvencyLabel4.Text = "S.01.02.07 - Basic Information - General" ;
this.solvencyLabel4.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel5
//
this.solvencyLabel5.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel5.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel5.Location = new System.Drawing.Point(285,23);
this.solvencyLabel5.Name = "solvencyLabel5";
this.solvencyLabel5.OrdinateID_Label = 0;
this.solvencyLabel5.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel5.TabIndex = 5;
this.solvencyLabel5.Text = "R0010" ;
this.solvencyLabel5.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel6
//
this.solvencyLabel6.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel6.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel6.Location = new System.Drawing.Point(17,43);
this.solvencyLabel6.Name = "solvencyLabel6";
this.solvencyLabel6.OrdinateID_Label = 252;
this.solvencyLabel6.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel6.TabIndex = 6;
this.solvencyLabel6.Text = "S.01.03.01 - Basic Information - RFF and matching adjustment portfolios" ;
this.solvencyLabel6.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel7
//
this.solvencyLabel7.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel7.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel7.Location = new System.Drawing.Point(285,43);
this.solvencyLabel7.Name = "solvencyLabel7";
this.solvencyLabel7.OrdinateID_Label = 0;
this.solvencyLabel7.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel7.TabIndex = 7;
this.solvencyLabel7.Text = "R0020" ;
this.solvencyLabel7.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel8
//
this.solvencyLabel8.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel8.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel8.Location = new System.Drawing.Point(17,76);
this.solvencyLabel8.Name = "solvencyLabel8";
this.solvencyLabel8.OrdinateID_Label = 253;
this.solvencyLabel8.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel8.TabIndex = 8;
this.solvencyLabel8.Text = "S.02.01.08 - Balance Sheet" ;
this.solvencyLabel8.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel9
//
this.solvencyLabel9.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel9.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel9.Location = new System.Drawing.Point(285,76);
this.solvencyLabel9.Name = "solvencyLabel9";
this.solvencyLabel9.OrdinateID_Label = 0;
this.solvencyLabel9.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel9.TabIndex = 9;
this.solvencyLabel9.Text = "R0030" ;
this.solvencyLabel9.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel10
//
this.solvencyLabel10.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel10.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel10.Location = new System.Drawing.Point(17,96);
this.solvencyLabel10.Name = "solvencyLabel10";
this.solvencyLabel10.OrdinateID_Label = 254;
this.solvencyLabel10.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel10.TabIndex = 10;
this.solvencyLabel10.Text = "S.23.01.07 - Own funds" ;
this.solvencyLabel10.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel11
//
this.solvencyLabel11.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel11.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel11.Location = new System.Drawing.Point(285,96);
this.solvencyLabel11.Name = "solvencyLabel11";
this.solvencyLabel11.OrdinateID_Label = 0;
this.solvencyLabel11.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel11.TabIndex = 11;
this.solvencyLabel11.Text = "R0410" ;
this.solvencyLabel11.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel12
//
this.solvencyLabel12.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel12.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel12.Location = new System.Drawing.Point(17,116);
this.solvencyLabel12.Name = "solvencyLabel12";
this.solvencyLabel12.OrdinateID_Label = 255;
this.solvencyLabel12.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel12.TabIndex = 12;
this.solvencyLabel12.Text = "S.25.01.01 - Solvency Capital Requirement - for undertakings on Standard Formula" ;
this.solvencyLabel12.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel13
//
this.solvencyLabel13.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel13.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel13.Location = new System.Drawing.Point(285,116);
this.solvencyLabel13.Name = "solvencyLabel13";
this.solvencyLabel13.OrdinateID_Label = 0;
this.solvencyLabel13.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel13.TabIndex = 13;
this.solvencyLabel13.Text = "R0460" ;
this.solvencyLabel13.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel14
//
this.solvencyLabel14.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel14.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel14.Location = new System.Drawing.Point(17,149);
this.solvencyLabel14.Name = "solvencyLabel14";
this.solvencyLabel14.OrdinateID_Label = 256;
this.solvencyLabel14.Size = new System.Drawing.Size(254, 45);
this.solvencyLabel14.TabIndex = 14;
this.solvencyLabel14.Text = "S.25.02.01 - Solvency Capital Requirement - for undertakings using the standard formula and partial internal model" ;
this.solvencyLabel14.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel15
//
this.solvencyLabel15.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel15.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel15.Location = new System.Drawing.Point(285,149);
this.solvencyLabel15.Name = "solvencyLabel15";
this.solvencyLabel15.OrdinateID_Label = 0;
this.solvencyLabel15.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel15.TabIndex = 15;
this.solvencyLabel15.Text = "R0470" ;
this.solvencyLabel15.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel16
//
this.solvencyLabel16.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel16.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel16.Location = new System.Drawing.Point(17,197);
this.solvencyLabel16.Name = "solvencyLabel16";
this.solvencyLabel16.OrdinateID_Label = 257;
this.solvencyLabel16.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel16.TabIndex = 16;
this.solvencyLabel16.Text = "S.25.03.01 - Solvency Capital Requirement - for undertakings on Full Internal Models" ;
this.solvencyLabel16.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel17
//
this.solvencyLabel17.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel17.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel17.Location = new System.Drawing.Point(285,197);
this.solvencyLabel17.Name = "solvencyLabel17";
this.solvencyLabel17.OrdinateID_Label = 0;
this.solvencyLabel17.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel17.TabIndex = 17;
this.solvencyLabel17.Text = "R0480" ;
this.solvencyLabel17.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel18
//
this.solvencyLabel18.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel18.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel18.Location = new System.Drawing.Point(17,230);
this.solvencyLabel18.Name = "solvencyLabel18";
this.solvencyLabel18.OrdinateID_Label = 258;
this.solvencyLabel18.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel18.TabIndex = 18;
this.solvencyLabel18.Text = "S.28.01.01 - Minimum Capital Requirement - Only life or only non-life insurance or reinsurance activity" ;
this.solvencyLabel18.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel19
//
this.solvencyLabel19.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel19.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel19.Location = new System.Drawing.Point(285,230);
this.solvencyLabel19.Name = "solvencyLabel19";
this.solvencyLabel19.OrdinateID_Label = 0;
this.solvencyLabel19.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel19.TabIndex = 19;
this.solvencyLabel19.Text = "R0580" ;
this.solvencyLabel19.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel20
//
this.solvencyLabel20.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel20.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel20.Location = new System.Drawing.Point(17,263);
this.solvencyLabel20.Name = "solvencyLabel20";
this.solvencyLabel20.OrdinateID_Label = 259;
this.solvencyLabel20.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel20.TabIndex = 20;
this.solvencyLabel20.Text = "S.28.02.01 - Minimum Capital Requirement - Both life and non-life insurance activity" ;
this.solvencyLabel20.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel21
//
this.solvencyLabel21.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel21.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel21.Location = new System.Drawing.Point(285,263);
this.solvencyLabel21.Name = "solvencyLabel21";
this.solvencyLabel21.OrdinateID_Label = 0;
this.solvencyLabel21.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel21.TabIndex = 21;
this.solvencyLabel21.Text = "R0590" ;
this.solvencyLabel21.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel22
//
this.solvencyLabel22.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel22.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel22.Location = new System.Drawing.Point(285,283);
this.solvencyLabel22.Name = "solvencyLabel22";
this.solvencyLabel22.OrdinateID_Label = 0;
this.solvencyLabel22.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel22.TabIndex = 22;
this.solvencyLabel22.Text = "." ;
this.solvencyLabel22.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// SolvencyDataComboBox23
//
this.SolvencyDataComboBox23.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox23.Location = new System.Drawing.Point(10,23);
this.SolvencyDataComboBox23.Name = "SolvencyDataComboBox23";
this.SolvencyDataComboBox23.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox23.TabIndex = 23;
this.SolvencyDataComboBox23.ColName = "R0010C0010";
this.SolvencyDataComboBox23.AxisID = 18;
this.SolvencyDataComboBox23.OrdinateID = 251;
this.SolvencyDataComboBox23.StartOrder = 0;
this.SolvencyDataComboBox23.NextOrder = 0;
//
// SolvencyDataComboBox24
//
this.SolvencyDataComboBox24.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox24.Location = new System.Drawing.Point(10,43);
this.SolvencyDataComboBox24.Name = "SolvencyDataComboBox24";
this.SolvencyDataComboBox24.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox24.TabIndex = 24;
this.SolvencyDataComboBox24.ColName = "R0020C0010";
this.SolvencyDataComboBox24.AxisID = 18;
this.SolvencyDataComboBox24.OrdinateID = 252;
this.SolvencyDataComboBox24.StartOrder = 0;
this.SolvencyDataComboBox24.NextOrder = 0;
//
// SolvencyDataComboBox25
//
this.SolvencyDataComboBox25.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox25.Location = new System.Drawing.Point(10,76);
this.SolvencyDataComboBox25.Name = "SolvencyDataComboBox25";
this.SolvencyDataComboBox25.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox25.TabIndex = 25;
this.SolvencyDataComboBox25.ColName = "R0030C0010";
this.SolvencyDataComboBox25.AxisID = 18;
this.SolvencyDataComboBox25.OrdinateID = 253;
this.SolvencyDataComboBox25.StartOrder = 0;
this.SolvencyDataComboBox25.NextOrder = 0;
//
// SolvencyDataComboBox26
//
this.SolvencyDataComboBox26.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox26.Location = new System.Drawing.Point(10,96);
this.SolvencyDataComboBox26.Name = "SolvencyDataComboBox26";
this.SolvencyDataComboBox26.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox26.TabIndex = 26;
this.SolvencyDataComboBox26.ColName = "R0410C0010";
this.SolvencyDataComboBox26.AxisID = 18;
this.SolvencyDataComboBox26.OrdinateID = 254;
this.SolvencyDataComboBox26.StartOrder = 0;
this.SolvencyDataComboBox26.NextOrder = 0;
//
// SolvencyDataComboBox27
//
this.SolvencyDataComboBox27.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox27.Location = new System.Drawing.Point(10,116);
this.SolvencyDataComboBox27.Name = "SolvencyDataComboBox27";
this.SolvencyDataComboBox27.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox27.TabIndex = 27;
this.SolvencyDataComboBox27.ColName = "R0460C0010";
this.SolvencyDataComboBox27.AxisID = 18;
this.SolvencyDataComboBox27.OrdinateID = 255;
this.SolvencyDataComboBox27.StartOrder = 0;
this.SolvencyDataComboBox27.NextOrder = 0;
//
// SolvencyDataComboBox28
//
this.SolvencyDataComboBox28.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox28.Location = new System.Drawing.Point(10,149);
this.SolvencyDataComboBox28.Name = "SolvencyDataComboBox28";
this.SolvencyDataComboBox28.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox28.TabIndex = 28;
this.SolvencyDataComboBox28.ColName = "R0470C0010";
this.SolvencyDataComboBox28.AxisID = 18;
this.SolvencyDataComboBox28.OrdinateID = 256;
this.SolvencyDataComboBox28.StartOrder = 0;
this.SolvencyDataComboBox28.NextOrder = 0;
//
// SolvencyDataComboBox29
//
this.SolvencyDataComboBox29.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox29.Location = new System.Drawing.Point(10,197);
this.SolvencyDataComboBox29.Name = "SolvencyDataComboBox29";
this.SolvencyDataComboBox29.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox29.TabIndex = 29;
this.SolvencyDataComboBox29.ColName = "R0480C0010";
this.SolvencyDataComboBox29.AxisID = 18;
this.SolvencyDataComboBox29.OrdinateID = 257;
this.SolvencyDataComboBox29.StartOrder = 0;
this.SolvencyDataComboBox29.NextOrder = 0;
//
// SolvencyDataComboBox30
//
this.SolvencyDataComboBox30.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox30.Location = new System.Drawing.Point(10,230);
this.SolvencyDataComboBox30.Name = "SolvencyDataComboBox30";
this.SolvencyDataComboBox30.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox30.TabIndex = 30;
this.SolvencyDataComboBox30.ColName = "R0580C0010";
this.SolvencyDataComboBox30.AxisID = 18;
this.SolvencyDataComboBox30.OrdinateID = 258;
this.SolvencyDataComboBox30.StartOrder = 0;
this.SolvencyDataComboBox30.NextOrder = 0;
//
// SolvencyDataComboBox31
//
this.SolvencyDataComboBox31.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox31.Location = new System.Drawing.Point(10,263);
this.SolvencyDataComboBox31.Name = "SolvencyDataComboBox31";
this.SolvencyDataComboBox31.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox31.TabIndex = 31;
this.SolvencyDataComboBox31.ColName = "R0590C0010";
this.SolvencyDataComboBox31.AxisID = 18;
this.SolvencyDataComboBox31.OrdinateID = 259;
this.SolvencyDataComboBox31.StartOrder = 0;
this.SolvencyDataComboBox31.NextOrder = 0;
//
// splitContainerColTitles
//
this.splitContainerColTitles.Dock = System.Windows.Forms.DockStyle.Fill;
this.splitContainerColTitles.Location = new System.Drawing.Point(0,0);
this.splitContainerColTitles.Name = "splitContainerColTitles";
this.splitContainerColTitles.Orientation = System.Windows.Forms.Orientation.Vertical;
this.splitContainerColTitles.Panel1MinSize = 0;
//
// splitContainerColTitles.Panel1
//
//
// splitContainerColTitles.Panel2
//
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel1);
this.splitContainerColTitles.Size = new System.Drawing.Size(756, 382);
this.splitContainerColTitles.SplitterDistance = 332;
//
// splitContainerRowTitles
//
this.splitContainerRowTitles.Dock = System.Windows.Forms.DockStyle.Fill;
this.splitContainerRowTitles.Location = new System.Drawing.Point(0,0);
this.splitContainerRowTitles.Name = "splitContainerRowTitles";
this.splitContainerRowTitles.Orientation = System.Windows.Forms.Orientation.Vertical;
this.splitContainerRowTitles.Panel1MinSize = 0;
//
// splitContainerRowTitles.Panel1
//
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel2);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel3);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel4);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel5);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel6);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel7);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel8);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel9);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel10);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel11);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel12);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel13);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel14);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel15);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel16);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel17);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel18);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel19);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel20);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel21);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel22);
//
// splitContainerRowTitles.Panel2
//
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox23);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox24);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox25);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox26);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox27);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox28);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox29);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox30);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox31);
this.splitContainerRowTitles.Panel2.AutoScroll = true;
this.splitContainerRowTitles.Size = new System.Drawing.Size(756, 382);
this.splitContainerRowTitles.SplitterDistance = 332;
//
// spltMain
//
this.spltMain.Dock = System.Windows.Forms.DockStyle.Fill;
this.spltMain.Location = new System.Drawing.Point(0,0);
this.spltMain.Name = "spltMain";
this.spltMain.Orientation = System.Windows.Forms.Orientation.Horizontal;
this.spltMain.Panel1MinSize = 0;
//
// spltMain.Panel1
//
this.spltMain.Panel1.Controls.Add(this.splitContainerColTitles);
//
// spltMain.Panel2
//
this.spltMain.Panel2.Controls.Add(this.splitContainerRowTitles);
this.spltMain.Panel2.AutoScroll = true;
this.spltMain.Size = new System.Drawing.Size(756, 386);
this.spltMain.SplitterDistance = 50;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F); 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font; 
this.Controls.Add(this.spltMain);
            this.Name = "S_01_01_09_01__sol2__2_0_1_ctrl"; 
            this.Size = new System.Drawing.Size(756, 336); 
            this.Load += new System.EventHandler(this.BoundControl_Load);
            this.ResumeLayout(false); 
            this.PerformLayout(); 

      } 
private SolvencyLabel solvencyLabel1;
private SolvencyLabel solvencyLabel2;
private SolvencyLabel solvencyLabel3;
private SolvencyLabel solvencyLabel4;
private SolvencyLabel solvencyLabel5;
private SolvencyLabel solvencyLabel6;
private SolvencyLabel solvencyLabel7;
private SolvencyLabel solvencyLabel8;
private SolvencyLabel solvencyLabel9;
private SolvencyLabel solvencyLabel10;
private SolvencyLabel solvencyLabel11;
private SolvencyLabel solvencyLabel12;
private SolvencyLabel solvencyLabel13;
private SolvencyLabel solvencyLabel14;
private SolvencyLabel solvencyLabel15;
private SolvencyLabel solvencyLabel16;
private SolvencyLabel solvencyLabel17;
private SolvencyLabel solvencyLabel18;
private SolvencyLabel solvencyLabel19;
private SolvencyLabel solvencyLabel20;
private SolvencyLabel solvencyLabel21;
private SolvencyLabel solvencyLabel22;
private SolvencyDataComboBox SolvencyDataComboBox23;
private SolvencyDataComboBox SolvencyDataComboBox24;
private SolvencyDataComboBox SolvencyDataComboBox25;
private SolvencyDataComboBox SolvencyDataComboBox26;
private SolvencyDataComboBox SolvencyDataComboBox27;
private SolvencyDataComboBox SolvencyDataComboBox28;
private SolvencyDataComboBox SolvencyDataComboBox29;
private SolvencyDataComboBox SolvencyDataComboBox30;
private SolvencyDataComboBox SolvencyDataComboBox31;
private SolvencySplitContainer splitContainerColTitles;
private SolvencySplitContainer splitContainerRowTitles;
private SolvencySplitContainer spltMain;

   }
}

