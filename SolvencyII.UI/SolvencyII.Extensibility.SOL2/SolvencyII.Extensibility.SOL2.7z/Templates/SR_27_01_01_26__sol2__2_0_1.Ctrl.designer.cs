using SolvencyII.Domain.ENumerators; 
using SolvencyII.UI.Shared.Controls; 

namespace SolvencyII.UI.UserControls 
{ 
   partial class SR_27_01_01_26__sol2__2_0_1_ctrl 
   { 
      private void InitializeComponent() 
      { 
this.solvencyLabel0 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel1 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel2 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel3 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel4 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel5 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel6 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel7 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel8 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel9 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel10 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel11 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel12 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel13 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel14 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel15 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel16 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel17 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel18 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel19 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel20 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel21 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel22 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel23 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel24 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel25 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel26 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel27 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel28 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel29 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyCurrencyTextBox30 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox31 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox32 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox33 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox34 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox35 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox36 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox37 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox38 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox39 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox40 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox41 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox42 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox43 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox44 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox45 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox46 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox47 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox48 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox49 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox50 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox51 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox52 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox53 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox54 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox55 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox56 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox57 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox58 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox59 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.splitContainerColTitles = new SolvencyII.UI.Shared.Controls.SolvencySplitContainer();
this.splitContainerRowTitles = new SolvencyII.UI.Shared.Controls.SolvencySplitContainer();
this.spltMain = new SolvencyII.UI.Shared.Controls.SolvencySplitContainer();
            this.SuspendLayout(); 

//
// solvencyLabel0
//
this.solvencyLabel0.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel0.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel0.Location = new System.Drawing.Point(973,10);
this.solvencyLabel0.Name = "solvencyLabel0";
this.solvencyLabel0.OrdinateID_Label = 8125;
this.solvencyLabel0.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel0.TabIndex = 0;
this.solvencyLabel0.Text = "Catastrophe Risk Charge after risk mitigation" ;
this.solvencyLabel0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel0.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel1
//
this.solvencyLabel1.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel1.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel1.Location = new System.Drawing.Point(973,55);
this.solvencyLabel1.Name = "solvencyLabel1";
this.solvencyLabel1.OrdinateID_Label = 0;
this.solvencyLabel1.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel1.TabIndex = 1;
this.solvencyLabel1.Text = "C1400" ;
this.solvencyLabel1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel2
//
this.solvencyLabel2.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel2.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel2.Location = new System.Drawing.Point(866,10);
this.solvencyLabel2.Name = "solvencyLabel2";
this.solvencyLabel2.OrdinateID_Label = 8124;
this.solvencyLabel2.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel2.TabIndex = 2;
this.solvencyLabel2.Text = "Estimated Reinstatement Premiums" ;
this.solvencyLabel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel3
//
this.solvencyLabel3.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel3.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel3.Location = new System.Drawing.Point(866,55);
this.solvencyLabel3.Name = "solvencyLabel3";
this.solvencyLabel3.OrdinateID_Label = 0;
this.solvencyLabel3.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel3.TabIndex = 3;
this.solvencyLabel3.Text = "C1390" ;
this.solvencyLabel3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel4
//
this.solvencyLabel4.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel4.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel4.Location = new System.Drawing.Point(759,10);
this.solvencyLabel4.Name = "solvencyLabel4";
this.solvencyLabel4.OrdinateID_Label = 8123;
this.solvencyLabel4.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel4.TabIndex = 4;
this.solvencyLabel4.Text = "Estimated Risk Mitigation" ;
this.solvencyLabel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel5
//
this.solvencyLabel5.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel5.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel5.Location = new System.Drawing.Point(759,55);
this.solvencyLabel5.Name = "solvencyLabel5";
this.solvencyLabel5.OrdinateID_Label = 0;
this.solvencyLabel5.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel5.TabIndex = 5;
this.solvencyLabel5.Text = "C1380" ;
this.solvencyLabel5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel6
//
this.solvencyLabel6.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel6.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel6.Location = new System.Drawing.Point(652,10);
this.solvencyLabel6.Name = "solvencyLabel6";
this.solvencyLabel6.OrdinateID_Label = 8122;
this.solvencyLabel6.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel6.TabIndex = 6;
this.solvencyLabel6.Text = "Catastrophe Risk Charge before risk mitigation" ;
this.solvencyLabel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel6.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel7
//
this.solvencyLabel7.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel7.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel7.Location = new System.Drawing.Point(652,55);
this.solvencyLabel7.Name = "solvencyLabel7";
this.solvencyLabel7.OrdinateID_Label = 0;
this.solvencyLabel7.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel7.TabIndex = 7;
this.solvencyLabel7.Text = "C1370" ;
this.solvencyLabel7.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel8
//
this.solvencyLabel8.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel8.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel8.Location = new System.Drawing.Point(545,30);
this.solvencyLabel8.Name = "solvencyLabel8";
this.solvencyLabel8.OrdinateID_Label = 8121;
this.solvencyLabel8.Size = new System.Drawing.Size(108, 25);
this.solvencyLabel8.TabIndex = 8;
this.solvencyLabel8.Text = "Medical treatment" ;
this.solvencyLabel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel8.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel9
//
this.solvencyLabel9.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel9.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel9.Location = new System.Drawing.Point(545,55);
this.solvencyLabel9.Name = "solvencyLabel9";
this.solvencyLabel9.OrdinateID_Label = 0;
this.solvencyLabel9.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel9.TabIndex = 9;
this.solvencyLabel9.Text = "C1360" ;
this.solvencyLabel9.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel10
//
this.solvencyLabel10.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel10.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel10.Location = new System.Drawing.Point(438,30);
this.solvencyLabel10.Name = "solvencyLabel10";
this.solvencyLabel10.OrdinateID_Label = 8120;
this.solvencyLabel10.Size = new System.Drawing.Size(108, 25);
this.solvencyLabel10.TabIndex = 10;
this.solvencyLabel10.Text = "Disability 12 months" ;
this.solvencyLabel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel10.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel11
//
this.solvencyLabel11.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel11.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel11.Location = new System.Drawing.Point(438,55);
this.solvencyLabel11.Name = "solvencyLabel11";
this.solvencyLabel11.OrdinateID_Label = 0;
this.solvencyLabel11.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel11.TabIndex = 11;
this.solvencyLabel11.Text = "C1350" ;
this.solvencyLabel11.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel12
//
this.solvencyLabel12.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel12.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel12.Location = new System.Drawing.Point(331,30);
this.solvencyLabel12.Name = "solvencyLabel12";
this.solvencyLabel12.OrdinateID_Label = 8119;
this.solvencyLabel12.Size = new System.Drawing.Size(108, 25);
this.solvencyLabel12.TabIndex = 12;
this.solvencyLabel12.Text = "Disability 10 years" ;
this.solvencyLabel12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel12.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel13
//
this.solvencyLabel13.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel13.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel13.Location = new System.Drawing.Point(331,55);
this.solvencyLabel13.Name = "solvencyLabel13";
this.solvencyLabel13.OrdinateID_Label = 0;
this.solvencyLabel13.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel13.TabIndex = 13;
this.solvencyLabel13.Text = "C1340" ;
this.solvencyLabel13.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel14
//
this.solvencyLabel14.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel14.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel14.Location = new System.Drawing.Point(224,30);
this.solvencyLabel14.Name = "solvencyLabel14";
this.solvencyLabel14.OrdinateID_Label = 8118;
this.solvencyLabel14.Size = new System.Drawing.Size(108, 25);
this.solvencyLabel14.TabIndex = 14;
this.solvencyLabel14.Text = "Permanent disability" ;
this.solvencyLabel14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel14.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel15
//
this.solvencyLabel15.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel15.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel15.Location = new System.Drawing.Point(224,55);
this.solvencyLabel15.Name = "solvencyLabel15";
this.solvencyLabel15.OrdinateID_Label = 0;
this.solvencyLabel15.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel15.TabIndex = 15;
this.solvencyLabel15.Text = "C1330" ;
this.solvencyLabel15.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel16
//
this.solvencyLabel16.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel16.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel16.Location = new System.Drawing.Point(117,30);
this.solvencyLabel16.Name = "solvencyLabel16";
this.solvencyLabel16.OrdinateID_Label = 8117;
this.solvencyLabel16.Size = new System.Drawing.Size(108, 25);
this.solvencyLabel16.TabIndex = 16;
this.solvencyLabel16.Text = "Accidental death" ;
this.solvencyLabel16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel16.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel17
//
this.solvencyLabel17.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel17.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel17.Location = new System.Drawing.Point(117,55);
this.solvencyLabel17.Name = "solvencyLabel17";
this.solvencyLabel17.OrdinateID_Label = 0;
this.solvencyLabel17.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel17.TabIndex = 17;
this.solvencyLabel17.Text = "C1320" ;
this.solvencyLabel17.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel18
//
this.solvencyLabel18.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel18.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel18.Location = new System.Drawing.Point(117,10);
this.solvencyLabel18.Name = "solvencyLabel18";
this.solvencyLabel18.OrdinateID_Label = 8116;
this.solvencyLabel18.Size = new System.Drawing.Size(536, 45);
this.solvencyLabel18.TabIndex = 18;
this.solvencyLabel18.Text = "Average sum insured" ;
this.solvencyLabel18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel18.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel19
//
this.solvencyLabel19.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel19.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel19.Location = new System.Drawing.Point(10,10);
this.solvencyLabel19.Name = "solvencyLabel19";
this.solvencyLabel19.OrdinateID_Label = 8115;
this.solvencyLabel19.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel19.TabIndex = 19;
this.solvencyLabel19.Text = "Largest known accident risk concentration" ;
this.solvencyLabel19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel19.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel20
//
this.solvencyLabel20.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel20.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel20.Location = new System.Drawing.Point(10,55);
this.solvencyLabel20.Name = "solvencyLabel20";
this.solvencyLabel20.OrdinateID_Label = 0;
this.solvencyLabel20.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel20.TabIndex = 20;
this.solvencyLabel20.Text = "C1310" ;
this.solvencyLabel20.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel21
//
this.solvencyLabel21.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel21.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel21.Location = new System.Drawing.Point(10,3);
this.solvencyLabel21.Name = "solvencyLabel21";
this.solvencyLabel21.OrdinateID_Label = 8126;
this.solvencyLabel21.Size = new System.Drawing.Size(261, 15);
this.solvencyLabel21.TabIndex = 21;
this.solvencyLabel21.Text = "Health Catastrophe risk - Concentration accident" ;
this.solvencyLabel21.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel22
//
this.solvencyLabel22.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel22.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel22.Location = new System.Drawing.Point(285,3);
this.solvencyLabel22.Name = "solvencyLabel22";
this.solvencyLabel22.OrdinateID_Label = 0;
this.solvencyLabel22.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel22.TabIndex = 22;
this.solvencyLabel22.Text = "" ;
this.solvencyLabel22.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel23
//
this.solvencyLabel23.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel23.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel23.Location = new System.Drawing.Point(17,23);
this.solvencyLabel23.Name = "solvencyLabel23";
this.solvencyLabel23.OrdinateID_Label = 8127;
this.solvencyLabel23.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel23.TabIndex = 23;
this.solvencyLabel23.Text = "Total Concentration accident all countries before diversification" ;
this.solvencyLabel23.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel24
//
this.solvencyLabel24.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel24.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel24.Location = new System.Drawing.Point(285,23);
this.solvencyLabel24.Name = "solvencyLabel24";
this.solvencyLabel24.OrdinateID_Label = 0;
this.solvencyLabel24.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel24.TabIndex = 24;
this.solvencyLabel24.Text = "R4020" ;
this.solvencyLabel24.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel25
//
this.solvencyLabel25.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel25.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel25.Location = new System.Drawing.Point(17,56);
this.solvencyLabel25.Name = "solvencyLabel25";
this.solvencyLabel25.OrdinateID_Label = 8128;
this.solvencyLabel25.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel25.TabIndex = 25;
this.solvencyLabel25.Text = "Diversification effect between countries" ;
this.solvencyLabel25.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel26
//
this.solvencyLabel26.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel26.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel26.Location = new System.Drawing.Point(285,56);
this.solvencyLabel26.Name = "solvencyLabel26";
this.solvencyLabel26.OrdinateID_Label = 0;
this.solvencyLabel26.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel26.TabIndex = 26;
this.solvencyLabel26.Text = "R4030" ;
this.solvencyLabel26.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel27
//
this.solvencyLabel27.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel27.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel27.Location = new System.Drawing.Point(17,76);
this.solvencyLabel27.Name = "solvencyLabel27";
this.solvencyLabel27.OrdinateID_Label = 8129;
this.solvencyLabel27.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel27.TabIndex = 27;
this.solvencyLabel27.Text = "Total Concentration accident all countries after diversification" ;
this.solvencyLabel27.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel28
//
this.solvencyLabel28.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel28.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel28.Location = new System.Drawing.Point(285,76);
this.solvencyLabel28.Name = "solvencyLabel28";
this.solvencyLabel28.OrdinateID_Label = 0;
this.solvencyLabel28.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel28.TabIndex = 28;
this.solvencyLabel28.Text = "R4040" ;
this.solvencyLabel28.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel29
//
this.solvencyLabel29.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel29.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel29.Location = new System.Drawing.Point(285,96);
this.solvencyLabel29.Name = "solvencyLabel29";
this.solvencyLabel29.OrdinateID_Label = 0;
this.solvencyLabel29.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel29.TabIndex = 29;
this.solvencyLabel29.Text = "." ;
this.solvencyLabel29.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyCurrencyTextBox30
//
this.solvencyCurrencyTextBox30.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox30.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox30.Location = new System.Drawing.Point(10,23);
this.solvencyCurrencyTextBox30.Name = "solvencyCurrencyTextBox30";
this.solvencyCurrencyTextBox30.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox30.TabIndex = 30;
this.solvencyCurrencyTextBox30.ColName = "R4020C1310";
this.solvencyCurrencyTextBox30.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox30.Enabled = false;
this.solvencyCurrencyTextBox30.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox31
//
this.solvencyCurrencyTextBox31.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox31.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox31.Location = new System.Drawing.Point(117,23);
this.solvencyCurrencyTextBox31.Name = "solvencyCurrencyTextBox31";
this.solvencyCurrencyTextBox31.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox31.TabIndex = 31;
this.solvencyCurrencyTextBox31.ColName = "R4020C1320";
this.solvencyCurrencyTextBox31.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox31.Enabled = false;
this.solvencyCurrencyTextBox31.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox32
//
this.solvencyCurrencyTextBox32.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox32.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox32.Location = new System.Drawing.Point(224,23);
this.solvencyCurrencyTextBox32.Name = "solvencyCurrencyTextBox32";
this.solvencyCurrencyTextBox32.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox32.TabIndex = 32;
this.solvencyCurrencyTextBox32.ColName = "R4020C1330";
this.solvencyCurrencyTextBox32.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox32.Enabled = false;
this.solvencyCurrencyTextBox32.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox33
//
this.solvencyCurrencyTextBox33.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox33.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox33.Location = new System.Drawing.Point(331,23);
this.solvencyCurrencyTextBox33.Name = "solvencyCurrencyTextBox33";
this.solvencyCurrencyTextBox33.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox33.TabIndex = 33;
this.solvencyCurrencyTextBox33.ColName = "R4020C1340";
this.solvencyCurrencyTextBox33.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox33.Enabled = false;
this.solvencyCurrencyTextBox33.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox34
//
this.solvencyCurrencyTextBox34.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox34.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox34.Location = new System.Drawing.Point(438,23);
this.solvencyCurrencyTextBox34.Name = "solvencyCurrencyTextBox34";
this.solvencyCurrencyTextBox34.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox34.TabIndex = 34;
this.solvencyCurrencyTextBox34.ColName = "R4020C1350";
this.solvencyCurrencyTextBox34.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox34.Enabled = false;
this.solvencyCurrencyTextBox34.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox35
//
this.solvencyCurrencyTextBox35.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox35.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox35.Location = new System.Drawing.Point(545,23);
this.solvencyCurrencyTextBox35.Name = "solvencyCurrencyTextBox35";
this.solvencyCurrencyTextBox35.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox35.TabIndex = 35;
this.solvencyCurrencyTextBox35.ColName = "R4020C1360";
this.solvencyCurrencyTextBox35.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox35.Enabled = false;
this.solvencyCurrencyTextBox35.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox36
//
this.solvencyCurrencyTextBox36.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox36.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox36.Location = new System.Drawing.Point(652,23);
this.solvencyCurrencyTextBox36.Name = "solvencyCurrencyTextBox36";
this.solvencyCurrencyTextBox36.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox36.TabIndex = 36;
this.solvencyCurrencyTextBox36.ColName = "R4020C1370";
this.solvencyCurrencyTextBox36.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox37
//
this.solvencyCurrencyTextBox37.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox37.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox37.Location = new System.Drawing.Point(759,23);
this.solvencyCurrencyTextBox37.Name = "solvencyCurrencyTextBox37";
this.solvencyCurrencyTextBox37.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox37.TabIndex = 37;
this.solvencyCurrencyTextBox37.ColName = "R4020C1380";
this.solvencyCurrencyTextBox37.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox38
//
this.solvencyCurrencyTextBox38.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox38.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox38.Location = new System.Drawing.Point(866,23);
this.solvencyCurrencyTextBox38.Name = "solvencyCurrencyTextBox38";
this.solvencyCurrencyTextBox38.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox38.TabIndex = 38;
this.solvencyCurrencyTextBox38.ColName = "R4020C1390";
this.solvencyCurrencyTextBox38.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox39
//
this.solvencyCurrencyTextBox39.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox39.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox39.Location = new System.Drawing.Point(973,23);
this.solvencyCurrencyTextBox39.Name = "solvencyCurrencyTextBox39";
this.solvencyCurrencyTextBox39.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox39.TabIndex = 39;
this.solvencyCurrencyTextBox39.ColName = "R4020C1400";
this.solvencyCurrencyTextBox39.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox40
//
this.solvencyCurrencyTextBox40.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox40.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox40.Location = new System.Drawing.Point(10,56);
this.solvencyCurrencyTextBox40.Name = "solvencyCurrencyTextBox40";
this.solvencyCurrencyTextBox40.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox40.TabIndex = 40;
this.solvencyCurrencyTextBox40.ColName = "R4030C1310";
this.solvencyCurrencyTextBox40.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox40.Enabled = false;
this.solvencyCurrencyTextBox40.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox41
//
this.solvencyCurrencyTextBox41.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox41.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox41.Location = new System.Drawing.Point(117,56);
this.solvencyCurrencyTextBox41.Name = "solvencyCurrencyTextBox41";
this.solvencyCurrencyTextBox41.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox41.TabIndex = 41;
this.solvencyCurrencyTextBox41.ColName = "R4030C1320";
this.solvencyCurrencyTextBox41.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox41.Enabled = false;
this.solvencyCurrencyTextBox41.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox42
//
this.solvencyCurrencyTextBox42.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox42.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox42.Location = new System.Drawing.Point(224,56);
this.solvencyCurrencyTextBox42.Name = "solvencyCurrencyTextBox42";
this.solvencyCurrencyTextBox42.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox42.TabIndex = 42;
this.solvencyCurrencyTextBox42.ColName = "R4030C1330";
this.solvencyCurrencyTextBox42.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox42.Enabled = false;
this.solvencyCurrencyTextBox42.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox43
//
this.solvencyCurrencyTextBox43.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox43.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox43.Location = new System.Drawing.Point(331,56);
this.solvencyCurrencyTextBox43.Name = "solvencyCurrencyTextBox43";
this.solvencyCurrencyTextBox43.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox43.TabIndex = 43;
this.solvencyCurrencyTextBox43.ColName = "R4030C1340";
this.solvencyCurrencyTextBox43.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox43.Enabled = false;
this.solvencyCurrencyTextBox43.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox44
//
this.solvencyCurrencyTextBox44.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox44.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox44.Location = new System.Drawing.Point(438,56);
this.solvencyCurrencyTextBox44.Name = "solvencyCurrencyTextBox44";
this.solvencyCurrencyTextBox44.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox44.TabIndex = 44;
this.solvencyCurrencyTextBox44.ColName = "R4030C1350";
this.solvencyCurrencyTextBox44.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox44.Enabled = false;
this.solvencyCurrencyTextBox44.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox45
//
this.solvencyCurrencyTextBox45.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox45.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox45.Location = new System.Drawing.Point(545,56);
this.solvencyCurrencyTextBox45.Name = "solvencyCurrencyTextBox45";
this.solvencyCurrencyTextBox45.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox45.TabIndex = 45;
this.solvencyCurrencyTextBox45.ColName = "R4030C1360";
this.solvencyCurrencyTextBox45.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox45.Enabled = false;
this.solvencyCurrencyTextBox45.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox46
//
this.solvencyCurrencyTextBox46.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox46.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox46.Location = new System.Drawing.Point(652,56);
this.solvencyCurrencyTextBox46.Name = "solvencyCurrencyTextBox46";
this.solvencyCurrencyTextBox46.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox46.TabIndex = 46;
this.solvencyCurrencyTextBox46.ColName = "R4030C1370";
this.solvencyCurrencyTextBox46.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox47
//
this.solvencyCurrencyTextBox47.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox47.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox47.Location = new System.Drawing.Point(759,56);
this.solvencyCurrencyTextBox47.Name = "solvencyCurrencyTextBox47";
this.solvencyCurrencyTextBox47.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox47.TabIndex = 47;
this.solvencyCurrencyTextBox47.ColName = "R4030C1380";
this.solvencyCurrencyTextBox47.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox47.Enabled = false;
this.solvencyCurrencyTextBox47.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox48
//
this.solvencyCurrencyTextBox48.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox48.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox48.Location = new System.Drawing.Point(866,56);
this.solvencyCurrencyTextBox48.Name = "solvencyCurrencyTextBox48";
this.solvencyCurrencyTextBox48.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox48.TabIndex = 48;
this.solvencyCurrencyTextBox48.ColName = "R4030C1390";
this.solvencyCurrencyTextBox48.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox48.Enabled = false;
this.solvencyCurrencyTextBox48.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox49
//
this.solvencyCurrencyTextBox49.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox49.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox49.Location = new System.Drawing.Point(973,56);
this.solvencyCurrencyTextBox49.Name = "solvencyCurrencyTextBox49";
this.solvencyCurrencyTextBox49.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox49.TabIndex = 49;
this.solvencyCurrencyTextBox49.ColName = "R4030C1400";
this.solvencyCurrencyTextBox49.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox50
//
this.solvencyCurrencyTextBox50.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox50.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox50.Location = new System.Drawing.Point(10,76);
this.solvencyCurrencyTextBox50.Name = "solvencyCurrencyTextBox50";
this.solvencyCurrencyTextBox50.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox50.TabIndex = 50;
this.solvencyCurrencyTextBox50.ColName = "R4040C1310";
this.solvencyCurrencyTextBox50.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox50.Enabled = false;
this.solvencyCurrencyTextBox50.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox51
//
this.solvencyCurrencyTextBox51.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox51.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox51.Location = new System.Drawing.Point(117,76);
this.solvencyCurrencyTextBox51.Name = "solvencyCurrencyTextBox51";
this.solvencyCurrencyTextBox51.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox51.TabIndex = 51;
this.solvencyCurrencyTextBox51.ColName = "R4040C1320";
this.solvencyCurrencyTextBox51.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox51.Enabled = false;
this.solvencyCurrencyTextBox51.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox52
//
this.solvencyCurrencyTextBox52.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox52.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox52.Location = new System.Drawing.Point(224,76);
this.solvencyCurrencyTextBox52.Name = "solvencyCurrencyTextBox52";
this.solvencyCurrencyTextBox52.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox52.TabIndex = 52;
this.solvencyCurrencyTextBox52.ColName = "R4040C1330";
this.solvencyCurrencyTextBox52.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox52.Enabled = false;
this.solvencyCurrencyTextBox52.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox53
//
this.solvencyCurrencyTextBox53.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox53.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox53.Location = new System.Drawing.Point(331,76);
this.solvencyCurrencyTextBox53.Name = "solvencyCurrencyTextBox53";
this.solvencyCurrencyTextBox53.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox53.TabIndex = 53;
this.solvencyCurrencyTextBox53.ColName = "R4040C1340";
this.solvencyCurrencyTextBox53.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox53.Enabled = false;
this.solvencyCurrencyTextBox53.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox54
//
this.solvencyCurrencyTextBox54.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox54.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox54.Location = new System.Drawing.Point(438,76);
this.solvencyCurrencyTextBox54.Name = "solvencyCurrencyTextBox54";
this.solvencyCurrencyTextBox54.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox54.TabIndex = 54;
this.solvencyCurrencyTextBox54.ColName = "R4040C1350";
this.solvencyCurrencyTextBox54.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox54.Enabled = false;
this.solvencyCurrencyTextBox54.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox55
//
this.solvencyCurrencyTextBox55.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox55.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox55.Location = new System.Drawing.Point(545,76);
this.solvencyCurrencyTextBox55.Name = "solvencyCurrencyTextBox55";
this.solvencyCurrencyTextBox55.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox55.TabIndex = 55;
this.solvencyCurrencyTextBox55.ColName = "R4040C1360";
this.solvencyCurrencyTextBox55.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox55.Enabled = false;
this.solvencyCurrencyTextBox55.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox56
//
this.solvencyCurrencyTextBox56.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox56.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox56.Location = new System.Drawing.Point(652,76);
this.solvencyCurrencyTextBox56.Name = "solvencyCurrencyTextBox56";
this.solvencyCurrencyTextBox56.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox56.TabIndex = 56;
this.solvencyCurrencyTextBox56.ColName = "R4040C1370";
this.solvencyCurrencyTextBox56.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox57
//
this.solvencyCurrencyTextBox57.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox57.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox57.Location = new System.Drawing.Point(759,76);
this.solvencyCurrencyTextBox57.Name = "solvencyCurrencyTextBox57";
this.solvencyCurrencyTextBox57.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox57.TabIndex = 57;
this.solvencyCurrencyTextBox57.ColName = "R4040C1380";
this.solvencyCurrencyTextBox57.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox57.Enabled = false;
this.solvencyCurrencyTextBox57.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox58
//
this.solvencyCurrencyTextBox58.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox58.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox58.Location = new System.Drawing.Point(866,76);
this.solvencyCurrencyTextBox58.Name = "solvencyCurrencyTextBox58";
this.solvencyCurrencyTextBox58.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox58.TabIndex = 58;
this.solvencyCurrencyTextBox58.ColName = "R4040C1390";
this.solvencyCurrencyTextBox58.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox58.Enabled = false;
this.solvencyCurrencyTextBox58.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox59
//
this.solvencyCurrencyTextBox59.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox59.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox59.Location = new System.Drawing.Point(973,76);
this.solvencyCurrencyTextBox59.Name = "solvencyCurrencyTextBox59";
this.solvencyCurrencyTextBox59.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox59.TabIndex = 59;
this.solvencyCurrencyTextBox59.ColName = "R4040C1400";
this.solvencyCurrencyTextBox59.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// splitContainerColTitles
//
this.splitContainerColTitles.Dock = System.Windows.Forms.DockStyle.Fill;
this.splitContainerColTitles.Location = new System.Drawing.Point(0,0);
this.splitContainerColTitles.Name = "splitContainerColTitles";
this.splitContainerColTitles.Orientation = System.Windows.Forms.Orientation.Vertical;
this.splitContainerColTitles.Panel1MinSize = 0;
//
// splitContainerColTitles.Panel1
//
//
// splitContainerColTitles.Panel2
//
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel0);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel1);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel2);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel3);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel4);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel5);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel6);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel7);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel8);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel9);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel10);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel11);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel12);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel13);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel14);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel15);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel16);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel17);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel18);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel19);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel20);
this.splitContainerColTitles.Size = new System.Drawing.Size(1519, 407);
this.splitContainerColTitles.SplitterDistance = 332;
//
// splitContainerRowTitles
//
this.splitContainerRowTitles.Dock = System.Windows.Forms.DockStyle.Fill;
this.splitContainerRowTitles.Location = new System.Drawing.Point(0,0);
this.splitContainerRowTitles.Name = "splitContainerRowTitles";
this.splitContainerRowTitles.Orientation = System.Windows.Forms.Orientation.Vertical;
this.splitContainerRowTitles.Panel1MinSize = 0;
//
// splitContainerRowTitles.Panel1
//
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel21);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel22);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel23);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel24);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel25);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel26);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel27);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel28);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel29);
//
// splitContainerRowTitles.Panel2
//
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox30);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox31);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox32);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox33);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox34);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox35);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox36);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox37);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox38);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox39);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox40);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox41);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox42);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox43);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox44);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox45);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox46);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox47);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox48);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox49);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox50);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox51);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox52);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox53);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox54);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox55);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox56);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox57);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox58);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox59);
this.splitContainerRowTitles.Panel2.AutoScroll = true;
this.splitContainerRowTitles.Size = new System.Drawing.Size(1519, 407);
this.splitContainerRowTitles.SplitterDistance = 332;
//
// spltMain
//
this.spltMain.Dock = System.Windows.Forms.DockStyle.Fill;
this.spltMain.Location = new System.Drawing.Point(0,0);
this.spltMain.Name = "spltMain";
this.spltMain.Orientation = System.Windows.Forms.Orientation.Horizontal;
this.spltMain.Panel1MinSize = 0;
//
// spltMain.Panel1
//
this.spltMain.Panel1.Controls.Add(this.splitContainerColTitles);
//
// spltMain.Panel2
//
this.spltMain.Panel2.Controls.Add(this.splitContainerRowTitles);
this.spltMain.Panel2.AutoScroll = true;
this.spltMain.Size = new System.Drawing.Size(1519, 249);
this.spltMain.SplitterDistance = 75;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F); 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font; 
this.Controls.Add(this.spltMain);
            this.Name = "SR_27_01_01_26__sol2__2_0_1_ctrl"; 
            this.Size = new System.Drawing.Size(1519, 174); 
            this.Load += new System.EventHandler(this.BoundControl_Load);
            this.ResumeLayout(false); 
            this.PerformLayout(); 

      } 
private SolvencyLabel solvencyLabel0;
private SolvencyLabel solvencyLabel1;
private SolvencyLabel solvencyLabel2;
private SolvencyLabel solvencyLabel3;
private SolvencyLabel solvencyLabel4;
private SolvencyLabel solvencyLabel5;
private SolvencyLabel solvencyLabel6;
private SolvencyLabel solvencyLabel7;
private SolvencyLabel solvencyLabel8;
private SolvencyLabel solvencyLabel9;
private SolvencyLabel solvencyLabel10;
private SolvencyLabel solvencyLabel11;
private SolvencyLabel solvencyLabel12;
private SolvencyLabel solvencyLabel13;
private SolvencyLabel solvencyLabel14;
private SolvencyLabel solvencyLabel15;
private SolvencyLabel solvencyLabel16;
private SolvencyLabel solvencyLabel17;
private SolvencyLabel solvencyLabel18;
private SolvencyLabel solvencyLabel19;
private SolvencyLabel solvencyLabel20;
private SolvencyLabel solvencyLabel21;
private SolvencyLabel solvencyLabel22;
private SolvencyLabel solvencyLabel23;
private SolvencyLabel solvencyLabel24;
private SolvencyLabel solvencyLabel25;
private SolvencyLabel solvencyLabel26;
private SolvencyLabel solvencyLabel27;
private SolvencyLabel solvencyLabel28;
private SolvencyLabel solvencyLabel29;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox30;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox31;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox32;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox33;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox34;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox35;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox36;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox37;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox38;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox39;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox40;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox41;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox42;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox43;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox44;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox45;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox46;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox47;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox48;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox49;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox50;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox51;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox52;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox53;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox54;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox55;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox56;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox57;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox58;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox59;
private SolvencySplitContainer splitContainerColTitles;
private SolvencySplitContainer splitContainerRowTitles;
private SolvencySplitContainer spltMain;

   }
}

