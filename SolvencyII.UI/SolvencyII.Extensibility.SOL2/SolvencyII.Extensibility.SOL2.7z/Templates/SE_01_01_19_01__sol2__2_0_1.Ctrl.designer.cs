using SolvencyII.Domain.ENumerators; 
using SolvencyII.UI.Shared.Controls; 

namespace SolvencyII.UI.UserControls 
{ 
   partial class SE_01_01_19_01__sol2__2_0_1_ctrl 
   { 
      private void InitializeComponent() 
      { 
this.solvencyLabel1 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel2 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel3 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel4 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel5 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel6 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel7 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel8 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel9 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel10 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel11 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel12 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel13 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel14 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel15 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel16 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel17 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel18 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel19 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel20 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel21 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel22 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel23 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel24 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel25 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel26 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel27 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel28 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel29 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel30 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.SolvencyDataComboBox31 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox32 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox33 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox34 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox35 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox36 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox37 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox38 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox39 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox40 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox41 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox42 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox43 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.splitContainerColTitles = new SolvencyII.UI.Shared.Controls.SolvencySplitContainer();
this.splitContainerRowTitles = new SolvencyII.UI.Shared.Controls.SolvencySplitContainer();
this.spltMain = new SolvencyII.UI.Shared.Controls.SolvencySplitContainer();
            this.SuspendLayout(); 

//
// solvencyLabel1
//
this.solvencyLabel1.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel1.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel1.Location = new System.Drawing.Point(10,30);
this.solvencyLabel1.Name = "solvencyLabel1";
this.solvencyLabel1.OrdinateID_Label = 0;
this.solvencyLabel1.Size = new System.Drawing.Size(208, 13);
this.solvencyLabel1.TabIndex = 1;
this.solvencyLabel1.Text = "C0010" ;
this.solvencyLabel1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel2
//
this.solvencyLabel2.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel2.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel2.Location = new System.Drawing.Point(10,3);
this.solvencyLabel2.Name = "solvencyLabel2";
this.solvencyLabel2.OrdinateID_Label = 518;
this.solvencyLabel2.Size = new System.Drawing.Size(261, 15);
this.solvencyLabel2.TabIndex = 2;
this.solvencyLabel2.Text = "Template Code - Template name" ;
this.solvencyLabel2.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel3
//
this.solvencyLabel3.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel3.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel3.Location = new System.Drawing.Point(285,3);
this.solvencyLabel3.Name = "solvencyLabel3";
this.solvencyLabel3.OrdinateID_Label = 0;
this.solvencyLabel3.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel3.TabIndex = 3;
this.solvencyLabel3.Text = "" ;
this.solvencyLabel3.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel4
//
this.solvencyLabel4.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel4.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel4.Location = new System.Drawing.Point(17,23);
this.solvencyLabel4.Name = "solvencyLabel4";
this.solvencyLabel4.OrdinateID_Label = 519;
this.solvencyLabel4.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel4.TabIndex = 4;
this.solvencyLabel4.Text = "S.01.02.07 - Basic Information - General" ;
this.solvencyLabel4.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel5
//
this.solvencyLabel5.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel5.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel5.Location = new System.Drawing.Point(285,23);
this.solvencyLabel5.Name = "solvencyLabel5";
this.solvencyLabel5.OrdinateID_Label = 0;
this.solvencyLabel5.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel5.TabIndex = 5;
this.solvencyLabel5.Text = "R0010" ;
this.solvencyLabel5.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel6
//
this.solvencyLabel6.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel6.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel6.Location = new System.Drawing.Point(17,43);
this.solvencyLabel6.Name = "solvencyLabel6";
this.solvencyLabel6.OrdinateID_Label = 520;
this.solvencyLabel6.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel6.TabIndex = 6;
this.solvencyLabel6.Text = "SE.02.01.19 - Balance Sheet" ;
this.solvencyLabel6.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel7
//
this.solvencyLabel7.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel7.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel7.Location = new System.Drawing.Point(285,43);
this.solvencyLabel7.Name = "solvencyLabel7";
this.solvencyLabel7.OrdinateID_Label = 0;
this.solvencyLabel7.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel7.TabIndex = 7;
this.solvencyLabel7.Text = "ER0030" ;
this.solvencyLabel7.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel8
//
this.solvencyLabel8.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel8.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel8.Location = new System.Drawing.Point(17,63);
this.solvencyLabel8.Name = "solvencyLabel8";
this.solvencyLabel8.OrdinateID_Label = 521;
this.solvencyLabel8.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel8.TabIndex = 8;
this.solvencyLabel8.Text = "S.05.01.01 - Premiums, claims and expenses by line of business" ;
this.solvencyLabel8.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel9
//
this.solvencyLabel9.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel9.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel9.Location = new System.Drawing.Point(285,63);
this.solvencyLabel9.Name = "solvencyLabel9";
this.solvencyLabel9.OrdinateID_Label = 0;
this.solvencyLabel9.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel9.TabIndex = 9;
this.solvencyLabel9.Text = "R0110" ;
this.solvencyLabel9.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel10
//
this.solvencyLabel10.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel10.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel10.Location = new System.Drawing.Point(17,96);
this.solvencyLabel10.Name = "solvencyLabel10";
this.solvencyLabel10.OrdinateID_Label = 522;
this.solvencyLabel10.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel10.TabIndex = 10;
this.solvencyLabel10.Text = "SE.06.02.18 - List of assets" ;
this.solvencyLabel10.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel11
//
this.solvencyLabel11.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel11.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel11.Location = new System.Drawing.Point(285,96);
this.solvencyLabel11.Name = "solvencyLabel11";
this.solvencyLabel11.OrdinateID_Label = 0;
this.solvencyLabel11.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel11.TabIndex = 11;
this.solvencyLabel11.Text = "ER0140" ;
this.solvencyLabel11.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel12
//
this.solvencyLabel12.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel12.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel12.Location = new System.Drawing.Point(17,116);
this.solvencyLabel12.Name = "solvencyLabel12";
this.solvencyLabel12.OrdinateID_Label = 523;
this.solvencyLabel12.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel12.TabIndex = 12;
this.solvencyLabel12.Text = "S.06.03.01 - Collective investment undertakings - look-through approach" ;
this.solvencyLabel12.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel13
//
this.solvencyLabel13.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel13.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel13.Location = new System.Drawing.Point(285,116);
this.solvencyLabel13.Name = "solvencyLabel13";
this.solvencyLabel13.OrdinateID_Label = 0;
this.solvencyLabel13.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel13.TabIndex = 13;
this.solvencyLabel13.Text = "R0150" ;
this.solvencyLabel13.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel14
//
this.solvencyLabel14.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel14.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel14.Location = new System.Drawing.Point(17,149);
this.solvencyLabel14.Name = "solvencyLabel14";
this.solvencyLabel14.OrdinateID_Label = 524;
this.solvencyLabel14.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel14.TabIndex = 14;
this.solvencyLabel14.Text = "S.08.01.01 - Open derivatives" ;
this.solvencyLabel14.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel15
//
this.solvencyLabel15.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel15.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel15.Location = new System.Drawing.Point(285,149);
this.solvencyLabel15.Name = "solvencyLabel15";
this.solvencyLabel15.OrdinateID_Label = 0;
this.solvencyLabel15.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel15.TabIndex = 15;
this.solvencyLabel15.Text = "R0170" ;
this.solvencyLabel15.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel16
//
this.solvencyLabel16.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel16.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel16.Location = new System.Drawing.Point(17,169);
this.solvencyLabel16.Name = "solvencyLabel16";
this.solvencyLabel16.OrdinateID_Label = 525;
this.solvencyLabel16.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel16.TabIndex = 16;
this.solvencyLabel16.Text = "S.08.02.01 - Derivatives Transactions" ;
this.solvencyLabel16.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel17
//
this.solvencyLabel17.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel17.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel17.Location = new System.Drawing.Point(285,169);
this.solvencyLabel17.Name = "solvencyLabel17";
this.solvencyLabel17.OrdinateID_Label = 0;
this.solvencyLabel17.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel17.TabIndex = 17;
this.solvencyLabel17.Text = "R0180" ;
this.solvencyLabel17.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel18
//
this.solvencyLabel18.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel18.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel18.Location = new System.Drawing.Point(17,189);
this.solvencyLabel18.Name = "solvencyLabel18";
this.solvencyLabel18.OrdinateID_Label = 526;
this.solvencyLabel18.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel18.TabIndex = 18;
this.solvencyLabel18.Text = "S.12.01.02 - Life and Health SLT Technical Provisions" ;
this.solvencyLabel18.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel19
//
this.solvencyLabel19.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel19.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel19.Location = new System.Drawing.Point(285,189);
this.solvencyLabel19.Name = "solvencyLabel19";
this.solvencyLabel19.OrdinateID_Label = 0;
this.solvencyLabel19.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel19.TabIndex = 19;
this.solvencyLabel19.Text = "R0220" ;
this.solvencyLabel19.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel20
//
this.solvencyLabel20.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel20.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel20.Location = new System.Drawing.Point(17,222);
this.solvencyLabel20.Name = "solvencyLabel20";
this.solvencyLabel20.OrdinateID_Label = 527;
this.solvencyLabel20.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel20.TabIndex = 20;
this.solvencyLabel20.Text = "S.17.01.02 - Non-Life Technical Provisions" ;
this.solvencyLabel20.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel21
//
this.solvencyLabel21.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel21.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel21.Location = new System.Drawing.Point(285,222);
this.solvencyLabel21.Name = "solvencyLabel21";
this.solvencyLabel21.OrdinateID_Label = 0;
this.solvencyLabel21.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel21.TabIndex = 21;
this.solvencyLabel21.Text = "R0290" ;
this.solvencyLabel21.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel22
//
this.solvencyLabel22.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel22.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel22.Location = new System.Drawing.Point(17,242);
this.solvencyLabel22.Name = "solvencyLabel22";
this.solvencyLabel22.OrdinateID_Label = 528;
this.solvencyLabel22.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel22.TabIndex = 22;
this.solvencyLabel22.Text = "S.23.01.07 - Own funds" ;
this.solvencyLabel22.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel23
//
this.solvencyLabel23.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel23.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel23.Location = new System.Drawing.Point(285,242);
this.solvencyLabel23.Name = "solvencyLabel23";
this.solvencyLabel23.OrdinateID_Label = 0;
this.solvencyLabel23.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel23.TabIndex = 23;
this.solvencyLabel23.Text = "R0410" ;
this.solvencyLabel23.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel24
//
this.solvencyLabel24.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel24.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel24.Location = new System.Drawing.Point(17,262);
this.solvencyLabel24.Name = "solvencyLabel24";
this.solvencyLabel24.OrdinateID_Label = 529;
this.solvencyLabel24.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel24.TabIndex = 24;
this.solvencyLabel24.Text = "S.28.01.01 - Minimum Capital Requirement - Only life or only non-life insurance or reinsurance activity" ;
this.solvencyLabel24.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel25
//
this.solvencyLabel25.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel25.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel25.Location = new System.Drawing.Point(285,262);
this.solvencyLabel25.Name = "solvencyLabel25";
this.solvencyLabel25.OrdinateID_Label = 0;
this.solvencyLabel25.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel25.TabIndex = 25;
this.solvencyLabel25.Text = "R0580" ;
this.solvencyLabel25.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel26
//
this.solvencyLabel26.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel26.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel26.Location = new System.Drawing.Point(17,295);
this.solvencyLabel26.Name = "solvencyLabel26";
this.solvencyLabel26.OrdinateID_Label = 530;
this.solvencyLabel26.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel26.TabIndex = 26;
this.solvencyLabel26.Text = "S.28.02.01 - Minimum Capital Requirement - Both life and non-life insurance activity" ;
this.solvencyLabel26.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel27
//
this.solvencyLabel27.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel27.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel27.Location = new System.Drawing.Point(285,295);
this.solvencyLabel27.Name = "solvencyLabel27";
this.solvencyLabel27.OrdinateID_Label = 0;
this.solvencyLabel27.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel27.TabIndex = 27;
this.solvencyLabel27.Text = "R0590" ;
this.solvencyLabel27.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel28
//
this.solvencyLabel28.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel28.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel28.Location = new System.Drawing.Point(17,328);
this.solvencyLabel28.Name = "solvencyLabel28";
this.solvencyLabel28.OrdinateID_Label = 531;
this.solvencyLabel28.Size = new System.Drawing.Size(254, 30);
this.solvencyLabel28.TabIndex = 28;
this.solvencyLabel28.Text = "E.01.01.16 - Deposits to cedants - line-by-line reporting" ;
this.solvencyLabel28.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel29
//
this.solvencyLabel29.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel29.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel29.Location = new System.Drawing.Point(285,328);
this.solvencyLabel29.Name = "solvencyLabel29";
this.solvencyLabel29.OrdinateID_Label = 0;
this.solvencyLabel29.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel29.TabIndex = 29;
this.solvencyLabel29.Text = "ER1000" ;
this.solvencyLabel29.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel30
//
this.solvencyLabel30.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel30.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel30.Location = new System.Drawing.Point(285,348);
this.solvencyLabel30.Name = "solvencyLabel30";
this.solvencyLabel30.OrdinateID_Label = 0;
this.solvencyLabel30.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel30.TabIndex = 30;
this.solvencyLabel30.Text = "." ;
this.solvencyLabel30.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// SolvencyDataComboBox31
//
this.SolvencyDataComboBox31.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox31.Location = new System.Drawing.Point(10,23);
this.SolvencyDataComboBox31.Name = "SolvencyDataComboBox31";
this.SolvencyDataComboBox31.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox31.TabIndex = 31;
this.SolvencyDataComboBox31.ColName = "R0010C0010";
this.SolvencyDataComboBox31.AxisID = 53;
this.SolvencyDataComboBox31.OrdinateID = 519;
this.SolvencyDataComboBox31.StartOrder = 0;
this.SolvencyDataComboBox31.NextOrder = 0;
//
// SolvencyDataComboBox32
//
this.SolvencyDataComboBox32.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox32.Location = new System.Drawing.Point(10,43);
this.SolvencyDataComboBox32.Name = "SolvencyDataComboBox32";
this.SolvencyDataComboBox32.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox32.TabIndex = 32;
this.SolvencyDataComboBox32.ColName = "ER0030C0010";
this.SolvencyDataComboBox32.AxisID = 53;
this.SolvencyDataComboBox32.OrdinateID = 520;
this.SolvencyDataComboBox32.StartOrder = 0;
this.SolvencyDataComboBox32.NextOrder = 0;
//
// SolvencyDataComboBox33
//
this.SolvencyDataComboBox33.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox33.Location = new System.Drawing.Point(10,63);
this.SolvencyDataComboBox33.Name = "SolvencyDataComboBox33";
this.SolvencyDataComboBox33.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox33.TabIndex = 33;
this.SolvencyDataComboBox33.ColName = "R0110C0010";
this.SolvencyDataComboBox33.AxisID = 53;
this.SolvencyDataComboBox33.OrdinateID = 521;
this.SolvencyDataComboBox33.StartOrder = 0;
this.SolvencyDataComboBox33.NextOrder = 0;
//
// SolvencyDataComboBox34
//
this.SolvencyDataComboBox34.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox34.Location = new System.Drawing.Point(10,96);
this.SolvencyDataComboBox34.Name = "SolvencyDataComboBox34";
this.SolvencyDataComboBox34.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox34.TabIndex = 34;
this.SolvencyDataComboBox34.ColName = "ER0140C0010";
this.SolvencyDataComboBox34.AxisID = 53;
this.SolvencyDataComboBox34.OrdinateID = 522;
this.SolvencyDataComboBox34.StartOrder = 0;
this.SolvencyDataComboBox34.NextOrder = 0;
//
// SolvencyDataComboBox35
//
this.SolvencyDataComboBox35.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox35.Location = new System.Drawing.Point(10,116);
this.SolvencyDataComboBox35.Name = "SolvencyDataComboBox35";
this.SolvencyDataComboBox35.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox35.TabIndex = 35;
this.SolvencyDataComboBox35.ColName = "R0150C0010";
this.SolvencyDataComboBox35.AxisID = 53;
this.SolvencyDataComboBox35.OrdinateID = 523;
this.SolvencyDataComboBox35.StartOrder = 0;
this.SolvencyDataComboBox35.NextOrder = 0;
//
// SolvencyDataComboBox36
//
this.SolvencyDataComboBox36.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox36.Location = new System.Drawing.Point(10,149);
this.SolvencyDataComboBox36.Name = "SolvencyDataComboBox36";
this.SolvencyDataComboBox36.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox36.TabIndex = 36;
this.SolvencyDataComboBox36.ColName = "R0170C0010";
this.SolvencyDataComboBox36.AxisID = 53;
this.SolvencyDataComboBox36.OrdinateID = 524;
this.SolvencyDataComboBox36.StartOrder = 0;
this.SolvencyDataComboBox36.NextOrder = 0;
//
// SolvencyDataComboBox37
//
this.SolvencyDataComboBox37.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox37.Location = new System.Drawing.Point(10,169);
this.SolvencyDataComboBox37.Name = "SolvencyDataComboBox37";
this.SolvencyDataComboBox37.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox37.TabIndex = 37;
this.SolvencyDataComboBox37.ColName = "R0180C0010";
this.SolvencyDataComboBox37.AxisID = 53;
this.SolvencyDataComboBox37.OrdinateID = 525;
this.SolvencyDataComboBox37.StartOrder = 0;
this.SolvencyDataComboBox37.NextOrder = 0;
//
// SolvencyDataComboBox38
//
this.SolvencyDataComboBox38.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox38.Location = new System.Drawing.Point(10,189);
this.SolvencyDataComboBox38.Name = "SolvencyDataComboBox38";
this.SolvencyDataComboBox38.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox38.TabIndex = 38;
this.SolvencyDataComboBox38.ColName = "R0220C0010";
this.SolvencyDataComboBox38.AxisID = 53;
this.SolvencyDataComboBox38.OrdinateID = 526;
this.SolvencyDataComboBox38.StartOrder = 0;
this.SolvencyDataComboBox38.NextOrder = 0;
//
// SolvencyDataComboBox39
//
this.SolvencyDataComboBox39.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox39.Location = new System.Drawing.Point(10,222);
this.SolvencyDataComboBox39.Name = "SolvencyDataComboBox39";
this.SolvencyDataComboBox39.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox39.TabIndex = 39;
this.SolvencyDataComboBox39.ColName = "R0290C0010";
this.SolvencyDataComboBox39.AxisID = 53;
this.SolvencyDataComboBox39.OrdinateID = 527;
this.SolvencyDataComboBox39.StartOrder = 0;
this.SolvencyDataComboBox39.NextOrder = 0;
//
// SolvencyDataComboBox40
//
this.SolvencyDataComboBox40.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox40.Location = new System.Drawing.Point(10,242);
this.SolvencyDataComboBox40.Name = "SolvencyDataComboBox40";
this.SolvencyDataComboBox40.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox40.TabIndex = 40;
this.SolvencyDataComboBox40.ColName = "R0410C0010";
this.SolvencyDataComboBox40.AxisID = 53;
this.SolvencyDataComboBox40.OrdinateID = 528;
this.SolvencyDataComboBox40.StartOrder = 0;
this.SolvencyDataComboBox40.NextOrder = 0;
//
// SolvencyDataComboBox41
//
this.SolvencyDataComboBox41.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox41.Location = new System.Drawing.Point(10,262);
this.SolvencyDataComboBox41.Name = "SolvencyDataComboBox41";
this.SolvencyDataComboBox41.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox41.TabIndex = 41;
this.SolvencyDataComboBox41.ColName = "R0580C0010";
this.SolvencyDataComboBox41.AxisID = 53;
this.SolvencyDataComboBox41.OrdinateID = 529;
this.SolvencyDataComboBox41.StartOrder = 0;
this.SolvencyDataComboBox41.NextOrder = 0;
//
// SolvencyDataComboBox42
//
this.SolvencyDataComboBox42.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox42.Location = new System.Drawing.Point(10,295);
this.SolvencyDataComboBox42.Name = "SolvencyDataComboBox42";
this.SolvencyDataComboBox42.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox42.TabIndex = 42;
this.SolvencyDataComboBox42.ColName = "R0590C0010";
this.SolvencyDataComboBox42.AxisID = 53;
this.SolvencyDataComboBox42.OrdinateID = 530;
this.SolvencyDataComboBox42.StartOrder = 0;
this.SolvencyDataComboBox42.NextOrder = 0;
//
// SolvencyDataComboBox43
//
this.SolvencyDataComboBox43.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox43.Location = new System.Drawing.Point(10,328);
this.SolvencyDataComboBox43.Name = "SolvencyDataComboBox43";
this.SolvencyDataComboBox43.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox43.TabIndex = 43;
this.SolvencyDataComboBox43.ColName = "ER1000C0010";
this.SolvencyDataComboBox43.AxisID = 53;
this.SolvencyDataComboBox43.OrdinateID = 531;
this.SolvencyDataComboBox43.StartOrder = 0;
this.SolvencyDataComboBox43.NextOrder = 0;
//
// splitContainerColTitles
//
this.splitContainerColTitles.Dock = System.Windows.Forms.DockStyle.Fill;
this.splitContainerColTitles.Location = new System.Drawing.Point(0,0);
this.splitContainerColTitles.Name = "splitContainerColTitles";
this.splitContainerColTitles.Orientation = System.Windows.Forms.Orientation.Vertical;
this.splitContainerColTitles.Panel1MinSize = 0;
//
// splitContainerColTitles.Panel1
//
//
// splitContainerColTitles.Panel2
//
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel1);
this.splitContainerColTitles.Size = new System.Drawing.Size(756, 382);
this.splitContainerColTitles.SplitterDistance = 332;
//
// splitContainerRowTitles
//
this.splitContainerRowTitles.Dock = System.Windows.Forms.DockStyle.Fill;
this.splitContainerRowTitles.Location = new System.Drawing.Point(0,0);
this.splitContainerRowTitles.Name = "splitContainerRowTitles";
this.splitContainerRowTitles.Orientation = System.Windows.Forms.Orientation.Vertical;
this.splitContainerRowTitles.Panel1MinSize = 0;
//
// splitContainerRowTitles.Panel1
//
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel2);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel3);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel4);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel5);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel6);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel7);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel8);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel9);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel10);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel11);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel12);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel13);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel14);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel15);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel16);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel17);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel18);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel19);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel20);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel21);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel22);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel23);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel24);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel25);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel26);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel27);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel28);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel29);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel30);
//
// splitContainerRowTitles.Panel2
//
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox31);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox32);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox33);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox34);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox35);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox36);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox37);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox38);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox39);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox40);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox41);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox42);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox43);
this.splitContainerRowTitles.Panel2.AutoScroll = true;
this.splitContainerRowTitles.Size = new System.Drawing.Size(756, 382);
this.splitContainerRowTitles.SplitterDistance = 332;
//
// spltMain
//
this.spltMain.Dock = System.Windows.Forms.DockStyle.Fill;
this.spltMain.Location = new System.Drawing.Point(0,0);
this.spltMain.Name = "spltMain";
this.spltMain.Orientation = System.Windows.Forms.Orientation.Horizontal;
this.spltMain.Panel1MinSize = 0;
//
// spltMain.Panel1
//
this.spltMain.Panel1.Controls.Add(this.splitContainerColTitles);
//
// spltMain.Panel2
//
this.spltMain.Panel2.Controls.Add(this.splitContainerRowTitles);
this.spltMain.Panel2.AutoScroll = true;
this.spltMain.Size = new System.Drawing.Size(756, 451);
this.spltMain.SplitterDistance = 50;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F); 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font; 
this.Controls.Add(this.spltMain);
            this.Name = "SE_01_01_19_01__sol2__2_0_1_ctrl"; 
            this.Size = new System.Drawing.Size(756, 401); 
            this.Load += new System.EventHandler(this.BoundControl_Load);
            this.ResumeLayout(false); 
            this.PerformLayout(); 

      } 
private SolvencyLabel solvencyLabel1;
private SolvencyLabel solvencyLabel2;
private SolvencyLabel solvencyLabel3;
private SolvencyLabel solvencyLabel4;
private SolvencyLabel solvencyLabel5;
private SolvencyLabel solvencyLabel6;
private SolvencyLabel solvencyLabel7;
private SolvencyLabel solvencyLabel8;
private SolvencyLabel solvencyLabel9;
private SolvencyLabel solvencyLabel10;
private SolvencyLabel solvencyLabel11;
private SolvencyLabel solvencyLabel12;
private SolvencyLabel solvencyLabel13;
private SolvencyLabel solvencyLabel14;
private SolvencyLabel solvencyLabel15;
private SolvencyLabel solvencyLabel16;
private SolvencyLabel solvencyLabel17;
private SolvencyLabel solvencyLabel18;
private SolvencyLabel solvencyLabel19;
private SolvencyLabel solvencyLabel20;
private SolvencyLabel solvencyLabel21;
private SolvencyLabel solvencyLabel22;
private SolvencyLabel solvencyLabel23;
private SolvencyLabel solvencyLabel24;
private SolvencyLabel solvencyLabel25;
private SolvencyLabel solvencyLabel26;
private SolvencyLabel solvencyLabel27;
private SolvencyLabel solvencyLabel28;
private SolvencyLabel solvencyLabel29;
private SolvencyLabel solvencyLabel30;
private SolvencyDataComboBox SolvencyDataComboBox31;
private SolvencyDataComboBox SolvencyDataComboBox32;
private SolvencyDataComboBox SolvencyDataComboBox33;
private SolvencyDataComboBox SolvencyDataComboBox34;
private SolvencyDataComboBox SolvencyDataComboBox35;
private SolvencyDataComboBox SolvencyDataComboBox36;
private SolvencyDataComboBox SolvencyDataComboBox37;
private SolvencyDataComboBox SolvencyDataComboBox38;
private SolvencyDataComboBox SolvencyDataComboBox39;
private SolvencyDataComboBox SolvencyDataComboBox40;
private SolvencyDataComboBox SolvencyDataComboBox41;
private SolvencyDataComboBox SolvencyDataComboBox42;
private SolvencyDataComboBox SolvencyDataComboBox43;
private SolvencySplitContainer splitContainerColTitles;
private SolvencySplitContainer splitContainerRowTitles;
private SolvencySplitContainer spltMain;

   }
}

