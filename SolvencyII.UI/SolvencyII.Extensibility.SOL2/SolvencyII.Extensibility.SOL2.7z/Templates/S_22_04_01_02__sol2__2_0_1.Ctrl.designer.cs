using SolvencyII.Domain.ENumerators; 
using SolvencyII.UI.Shared.Controls; 

namespace SolvencyII.UI.UserControls 
{ 
   partial class S_22_04_01_02__sol2__2_0_1_ctrl 
   { 
      private void InitializeComponent() 
      { 
this.solvencyLabel0 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel1 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel2 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel3 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel4 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel5 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel6 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel7 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel8 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel9 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel10 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel11 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel12 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel13 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel14 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel15 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel16 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel17 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel18 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel19 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel20 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel21 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel22 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel23 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel24 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel25 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel26 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel27 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel28 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyCurrencyTextBox29 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox30 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox31 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox32 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox33 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox34 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox35 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox36 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox37 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox38 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox39 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox40 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox41 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox42 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox43 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox44 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox45 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox46 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox47 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox48 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox49 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox50 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox51 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox52 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.splitContainerColTitles = new SolvencyII.UI.Shared.Controls.SolvencySplitContainer();
this.splitContainerRowTitles = new SolvencyII.UI.Shared.Controls.SolvencySplitContainer();
this.spltMain = new SolvencyII.UI.Shared.Controls.SolvencySplitContainer();
            this.SuspendLayout(); 

//
// solvencyLabel0
//
this.solvencyLabel0.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel0.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel0.Location = new System.Drawing.Point(117,10);
this.solvencyLabel0.Name = "solvencyLabel0";
this.solvencyLabel0.OrdinateID_Label = 4115;
this.solvencyLabel0.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel0.TabIndex = 0;
this.solvencyLabel0.Text = "Average duration of insurance and reinsurance obligations" ;
this.solvencyLabel0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel0.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel1
//
this.solvencyLabel1.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel1.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel1.Location = new System.Drawing.Point(117,55);
this.solvencyLabel1.Name = "solvencyLabel1";
this.solvencyLabel1.OrdinateID_Label = 0;
this.solvencyLabel1.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel1.TabIndex = 1;
this.solvencyLabel1.Text = "C0030" ;
this.solvencyLabel1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel2
//
this.solvencyLabel2.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel2.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel2.Location = new System.Drawing.Point(10,10);
this.solvencyLabel2.Name = "solvencyLabel2";
this.solvencyLabel2.OrdinateID_Label = 4114;
this.solvencyLabel2.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel2.TabIndex = 2;
this.solvencyLabel2.Text = "Best estimate" ;
this.solvencyLabel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel3
//
this.solvencyLabel3.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel3.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel3.Location = new System.Drawing.Point(10,55);
this.solvencyLabel3.Name = "solvencyLabel3";
this.solvencyLabel3.OrdinateID_Label = 0;
this.solvencyLabel3.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel3.TabIndex = 3;
this.solvencyLabel3.Text = "C0020" ;
this.solvencyLabel3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel4
//
this.solvencyLabel4.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel4.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel4.Location = new System.Drawing.Point(10,3);
this.solvencyLabel4.Name = "solvencyLabel4";
this.solvencyLabel4.OrdinateID_Label = 4116;
this.solvencyLabel4.Size = new System.Drawing.Size(152, 15);
this.solvencyLabel4.TabIndex = 4;
this.solvencyLabel4.Text = "Up to 0.5 per cent" ;
this.solvencyLabel4.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel5
//
this.solvencyLabel5.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel5.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel5.Location = new System.Drawing.Point(176,3);
this.solvencyLabel5.Name = "solvencyLabel5";
this.solvencyLabel5.OrdinateID_Label = 0;
this.solvencyLabel5.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel5.TabIndex = 5;
this.solvencyLabel5.Text = "R0100" ;
this.solvencyLabel5.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel6
//
this.solvencyLabel6.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel6.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel6.Location = new System.Drawing.Point(10,23);
this.solvencyLabel6.Name = "solvencyLabel6";
this.solvencyLabel6.OrdinateID_Label = 4117;
this.solvencyLabel6.Size = new System.Drawing.Size(152, 15);
this.solvencyLabel6.TabIndex = 6;
this.solvencyLabel6.Text = "Above 0.5% and up to 1.0%" ;
this.solvencyLabel6.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel7
//
this.solvencyLabel7.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel7.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel7.Location = new System.Drawing.Point(176,23);
this.solvencyLabel7.Name = "solvencyLabel7";
this.solvencyLabel7.OrdinateID_Label = 0;
this.solvencyLabel7.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel7.TabIndex = 7;
this.solvencyLabel7.Text = "R0110" ;
this.solvencyLabel7.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel8
//
this.solvencyLabel8.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel8.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel8.Location = new System.Drawing.Point(10,43);
this.solvencyLabel8.Name = "solvencyLabel8";
this.solvencyLabel8.OrdinateID_Label = 4118;
this.solvencyLabel8.Size = new System.Drawing.Size(152, 15);
this.solvencyLabel8.TabIndex = 8;
this.solvencyLabel8.Text = "Above 1.0% and up to 1.5%" ;
this.solvencyLabel8.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel9
//
this.solvencyLabel9.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel9.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel9.Location = new System.Drawing.Point(176,43);
this.solvencyLabel9.Name = "solvencyLabel9";
this.solvencyLabel9.OrdinateID_Label = 0;
this.solvencyLabel9.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel9.TabIndex = 9;
this.solvencyLabel9.Text = "R0120" ;
this.solvencyLabel9.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel10
//
this.solvencyLabel10.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel10.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel10.Location = new System.Drawing.Point(10,63);
this.solvencyLabel10.Name = "solvencyLabel10";
this.solvencyLabel10.OrdinateID_Label = 4119;
this.solvencyLabel10.Size = new System.Drawing.Size(152, 15);
this.solvencyLabel10.TabIndex = 10;
this.solvencyLabel10.Text = "Above 1.5% and up to 2.0%" ;
this.solvencyLabel10.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel11
//
this.solvencyLabel11.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel11.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel11.Location = new System.Drawing.Point(176,63);
this.solvencyLabel11.Name = "solvencyLabel11";
this.solvencyLabel11.OrdinateID_Label = 0;
this.solvencyLabel11.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel11.TabIndex = 11;
this.solvencyLabel11.Text = "R0130" ;
this.solvencyLabel11.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel12
//
this.solvencyLabel12.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel12.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel12.Location = new System.Drawing.Point(10,83);
this.solvencyLabel12.Name = "solvencyLabel12";
this.solvencyLabel12.OrdinateID_Label = 4120;
this.solvencyLabel12.Size = new System.Drawing.Size(152, 15);
this.solvencyLabel12.TabIndex = 12;
this.solvencyLabel12.Text = "Above 2.0% and up to 2.5%" ;
this.solvencyLabel12.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel13
//
this.solvencyLabel13.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel13.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel13.Location = new System.Drawing.Point(176,83);
this.solvencyLabel13.Name = "solvencyLabel13";
this.solvencyLabel13.OrdinateID_Label = 0;
this.solvencyLabel13.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel13.TabIndex = 13;
this.solvencyLabel13.Text = "R0140" ;
this.solvencyLabel13.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel14
//
this.solvencyLabel14.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel14.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel14.Location = new System.Drawing.Point(10,103);
this.solvencyLabel14.Name = "solvencyLabel14";
this.solvencyLabel14.OrdinateID_Label = 4121;
this.solvencyLabel14.Size = new System.Drawing.Size(152, 15);
this.solvencyLabel14.TabIndex = 14;
this.solvencyLabel14.Text = "Above 2.5% and up to 3.0%" ;
this.solvencyLabel14.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel15
//
this.solvencyLabel15.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel15.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel15.Location = new System.Drawing.Point(176,103);
this.solvencyLabel15.Name = "solvencyLabel15";
this.solvencyLabel15.OrdinateID_Label = 0;
this.solvencyLabel15.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel15.TabIndex = 15;
this.solvencyLabel15.Text = "R0150" ;
this.solvencyLabel15.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel16
//
this.solvencyLabel16.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel16.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel16.Location = new System.Drawing.Point(10,123);
this.solvencyLabel16.Name = "solvencyLabel16";
this.solvencyLabel16.OrdinateID_Label = 4122;
this.solvencyLabel16.Size = new System.Drawing.Size(152, 15);
this.solvencyLabel16.TabIndex = 16;
this.solvencyLabel16.Text = "Above 3.0% and up to 4.0%" ;
this.solvencyLabel16.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel17
//
this.solvencyLabel17.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel17.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel17.Location = new System.Drawing.Point(176,123);
this.solvencyLabel17.Name = "solvencyLabel17";
this.solvencyLabel17.OrdinateID_Label = 0;
this.solvencyLabel17.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel17.TabIndex = 17;
this.solvencyLabel17.Text = "R0160" ;
this.solvencyLabel17.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel18
//
this.solvencyLabel18.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel18.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel18.Location = new System.Drawing.Point(10,143);
this.solvencyLabel18.Name = "solvencyLabel18";
this.solvencyLabel18.OrdinateID_Label = 4123;
this.solvencyLabel18.Size = new System.Drawing.Size(152, 15);
this.solvencyLabel18.TabIndex = 18;
this.solvencyLabel18.Text = "Above 4.0% and up to 5.0%" ;
this.solvencyLabel18.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel19
//
this.solvencyLabel19.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel19.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel19.Location = new System.Drawing.Point(176,143);
this.solvencyLabel19.Name = "solvencyLabel19";
this.solvencyLabel19.OrdinateID_Label = 0;
this.solvencyLabel19.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel19.TabIndex = 19;
this.solvencyLabel19.Text = "R0170" ;
this.solvencyLabel19.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel20
//
this.solvencyLabel20.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel20.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel20.Location = new System.Drawing.Point(10,163);
this.solvencyLabel20.Name = "solvencyLabel20";
this.solvencyLabel20.OrdinateID_Label = 4124;
this.solvencyLabel20.Size = new System.Drawing.Size(152, 15);
this.solvencyLabel20.TabIndex = 20;
this.solvencyLabel20.Text = "Above 5.0% and up to 6.0%" ;
this.solvencyLabel20.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel21
//
this.solvencyLabel21.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel21.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel21.Location = new System.Drawing.Point(176,163);
this.solvencyLabel21.Name = "solvencyLabel21";
this.solvencyLabel21.OrdinateID_Label = 0;
this.solvencyLabel21.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel21.TabIndex = 21;
this.solvencyLabel21.Text = "R0180" ;
this.solvencyLabel21.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel22
//
this.solvencyLabel22.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel22.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel22.Location = new System.Drawing.Point(10,183);
this.solvencyLabel22.Name = "solvencyLabel22";
this.solvencyLabel22.OrdinateID_Label = 4125;
this.solvencyLabel22.Size = new System.Drawing.Size(152, 15);
this.solvencyLabel22.TabIndex = 22;
this.solvencyLabel22.Text = "Above 6.0% and up to 7.0%" ;
this.solvencyLabel22.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel23
//
this.solvencyLabel23.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel23.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel23.Location = new System.Drawing.Point(176,183);
this.solvencyLabel23.Name = "solvencyLabel23";
this.solvencyLabel23.OrdinateID_Label = 0;
this.solvencyLabel23.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel23.TabIndex = 23;
this.solvencyLabel23.Text = "R0190" ;
this.solvencyLabel23.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel24
//
this.solvencyLabel24.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel24.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel24.Location = new System.Drawing.Point(10,203);
this.solvencyLabel24.Name = "solvencyLabel24";
this.solvencyLabel24.OrdinateID_Label = 4126;
this.solvencyLabel24.Size = new System.Drawing.Size(152, 15);
this.solvencyLabel24.TabIndex = 24;
this.solvencyLabel24.Text = "Above 7.0% and up to 8.0%" ;
this.solvencyLabel24.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel25
//
this.solvencyLabel25.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel25.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel25.Location = new System.Drawing.Point(176,203);
this.solvencyLabel25.Name = "solvencyLabel25";
this.solvencyLabel25.OrdinateID_Label = 0;
this.solvencyLabel25.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel25.TabIndex = 25;
this.solvencyLabel25.Text = "R0200" ;
this.solvencyLabel25.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel26
//
this.solvencyLabel26.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel26.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel26.Location = new System.Drawing.Point(10,223);
this.solvencyLabel26.Name = "solvencyLabel26";
this.solvencyLabel26.OrdinateID_Label = 4127;
this.solvencyLabel26.Size = new System.Drawing.Size(152, 15);
this.solvencyLabel26.TabIndex = 26;
this.solvencyLabel26.Text = "Above 8.0%" ;
this.solvencyLabel26.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel27
//
this.solvencyLabel27.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel27.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel27.Location = new System.Drawing.Point(176,223);
this.solvencyLabel27.Name = "solvencyLabel27";
this.solvencyLabel27.OrdinateID_Label = 0;
this.solvencyLabel27.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel27.TabIndex = 27;
this.solvencyLabel27.Text = "R0210" ;
this.solvencyLabel27.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel28
//
this.solvencyLabel28.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel28.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel28.Location = new System.Drawing.Point(176,243);
this.solvencyLabel28.Name = "solvencyLabel28";
this.solvencyLabel28.OrdinateID_Label = 0;
this.solvencyLabel28.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel28.TabIndex = 28;
this.solvencyLabel28.Text = "." ;
this.solvencyLabel28.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyCurrencyTextBox29
//
this.solvencyCurrencyTextBox29.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox29.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox29.Location = new System.Drawing.Point(10,3);
this.solvencyCurrencyTextBox29.Name = "solvencyCurrencyTextBox29";
this.solvencyCurrencyTextBox29.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox29.TabIndex = 29;
this.solvencyCurrencyTextBox29.ColName = "R0100C0020";
this.solvencyCurrencyTextBox29.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox30
//
this.solvencyCurrencyTextBox30.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox30.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Decimal;
this.solvencyCurrencyTextBox30.Location = new System.Drawing.Point(117,3);
this.solvencyCurrencyTextBox30.Name = "solvencyCurrencyTextBox30";
this.solvencyCurrencyTextBox30.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox30.TabIndex = 30;
this.solvencyCurrencyTextBox30.ColName = "R0100C0030";
this.solvencyCurrencyTextBox30.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox31
//
this.solvencyCurrencyTextBox31.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox31.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox31.Location = new System.Drawing.Point(10,23);
this.solvencyCurrencyTextBox31.Name = "solvencyCurrencyTextBox31";
this.solvencyCurrencyTextBox31.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox31.TabIndex = 31;
this.solvencyCurrencyTextBox31.ColName = "R0110C0020";
this.solvencyCurrencyTextBox31.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox32
//
this.solvencyCurrencyTextBox32.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox32.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Decimal;
this.solvencyCurrencyTextBox32.Location = new System.Drawing.Point(117,23);
this.solvencyCurrencyTextBox32.Name = "solvencyCurrencyTextBox32";
this.solvencyCurrencyTextBox32.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox32.TabIndex = 32;
this.solvencyCurrencyTextBox32.ColName = "R0110C0030";
this.solvencyCurrencyTextBox32.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox33
//
this.solvencyCurrencyTextBox33.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox33.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox33.Location = new System.Drawing.Point(10,43);
this.solvencyCurrencyTextBox33.Name = "solvencyCurrencyTextBox33";
this.solvencyCurrencyTextBox33.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox33.TabIndex = 33;
this.solvencyCurrencyTextBox33.ColName = "R0120C0020";
this.solvencyCurrencyTextBox33.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox34
//
this.solvencyCurrencyTextBox34.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox34.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Decimal;
this.solvencyCurrencyTextBox34.Location = new System.Drawing.Point(117,43);
this.solvencyCurrencyTextBox34.Name = "solvencyCurrencyTextBox34";
this.solvencyCurrencyTextBox34.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox34.TabIndex = 34;
this.solvencyCurrencyTextBox34.ColName = "R0120C0030";
this.solvencyCurrencyTextBox34.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox35
//
this.solvencyCurrencyTextBox35.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox35.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox35.Location = new System.Drawing.Point(10,63);
this.solvencyCurrencyTextBox35.Name = "solvencyCurrencyTextBox35";
this.solvencyCurrencyTextBox35.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox35.TabIndex = 35;
this.solvencyCurrencyTextBox35.ColName = "R0130C0020";
this.solvencyCurrencyTextBox35.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox36
//
this.solvencyCurrencyTextBox36.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox36.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Decimal;
this.solvencyCurrencyTextBox36.Location = new System.Drawing.Point(117,63);
this.solvencyCurrencyTextBox36.Name = "solvencyCurrencyTextBox36";
this.solvencyCurrencyTextBox36.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox36.TabIndex = 36;
this.solvencyCurrencyTextBox36.ColName = "R0130C0030";
this.solvencyCurrencyTextBox36.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox37
//
this.solvencyCurrencyTextBox37.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox37.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox37.Location = new System.Drawing.Point(10,83);
this.solvencyCurrencyTextBox37.Name = "solvencyCurrencyTextBox37";
this.solvencyCurrencyTextBox37.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox37.TabIndex = 37;
this.solvencyCurrencyTextBox37.ColName = "R0140C0020";
this.solvencyCurrencyTextBox37.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox38
//
this.solvencyCurrencyTextBox38.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox38.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Decimal;
this.solvencyCurrencyTextBox38.Location = new System.Drawing.Point(117,83);
this.solvencyCurrencyTextBox38.Name = "solvencyCurrencyTextBox38";
this.solvencyCurrencyTextBox38.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox38.TabIndex = 38;
this.solvencyCurrencyTextBox38.ColName = "R0140C0030";
this.solvencyCurrencyTextBox38.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox39
//
this.solvencyCurrencyTextBox39.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox39.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox39.Location = new System.Drawing.Point(10,103);
this.solvencyCurrencyTextBox39.Name = "solvencyCurrencyTextBox39";
this.solvencyCurrencyTextBox39.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox39.TabIndex = 39;
this.solvencyCurrencyTextBox39.ColName = "R0150C0020";
this.solvencyCurrencyTextBox39.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox40
//
this.solvencyCurrencyTextBox40.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox40.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Decimal;
this.solvencyCurrencyTextBox40.Location = new System.Drawing.Point(117,103);
this.solvencyCurrencyTextBox40.Name = "solvencyCurrencyTextBox40";
this.solvencyCurrencyTextBox40.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox40.TabIndex = 40;
this.solvencyCurrencyTextBox40.ColName = "R0150C0030";
this.solvencyCurrencyTextBox40.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox41
//
this.solvencyCurrencyTextBox41.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox41.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox41.Location = new System.Drawing.Point(10,123);
this.solvencyCurrencyTextBox41.Name = "solvencyCurrencyTextBox41";
this.solvencyCurrencyTextBox41.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox41.TabIndex = 41;
this.solvencyCurrencyTextBox41.ColName = "R0160C0020";
this.solvencyCurrencyTextBox41.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox42
//
this.solvencyCurrencyTextBox42.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox42.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Decimal;
this.solvencyCurrencyTextBox42.Location = new System.Drawing.Point(117,123);
this.solvencyCurrencyTextBox42.Name = "solvencyCurrencyTextBox42";
this.solvencyCurrencyTextBox42.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox42.TabIndex = 42;
this.solvencyCurrencyTextBox42.ColName = "R0160C0030";
this.solvencyCurrencyTextBox42.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox43
//
this.solvencyCurrencyTextBox43.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox43.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox43.Location = new System.Drawing.Point(10,143);
this.solvencyCurrencyTextBox43.Name = "solvencyCurrencyTextBox43";
this.solvencyCurrencyTextBox43.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox43.TabIndex = 43;
this.solvencyCurrencyTextBox43.ColName = "R0170C0020";
this.solvencyCurrencyTextBox43.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox44
//
this.solvencyCurrencyTextBox44.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox44.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Decimal;
this.solvencyCurrencyTextBox44.Location = new System.Drawing.Point(117,143);
this.solvencyCurrencyTextBox44.Name = "solvencyCurrencyTextBox44";
this.solvencyCurrencyTextBox44.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox44.TabIndex = 44;
this.solvencyCurrencyTextBox44.ColName = "R0170C0030";
this.solvencyCurrencyTextBox44.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox45
//
this.solvencyCurrencyTextBox45.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox45.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox45.Location = new System.Drawing.Point(10,163);
this.solvencyCurrencyTextBox45.Name = "solvencyCurrencyTextBox45";
this.solvencyCurrencyTextBox45.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox45.TabIndex = 45;
this.solvencyCurrencyTextBox45.ColName = "R0180C0020";
this.solvencyCurrencyTextBox45.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox46
//
this.solvencyCurrencyTextBox46.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox46.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Decimal;
this.solvencyCurrencyTextBox46.Location = new System.Drawing.Point(117,163);
this.solvencyCurrencyTextBox46.Name = "solvencyCurrencyTextBox46";
this.solvencyCurrencyTextBox46.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox46.TabIndex = 46;
this.solvencyCurrencyTextBox46.ColName = "R0180C0030";
this.solvencyCurrencyTextBox46.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox47
//
this.solvencyCurrencyTextBox47.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox47.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox47.Location = new System.Drawing.Point(10,183);
this.solvencyCurrencyTextBox47.Name = "solvencyCurrencyTextBox47";
this.solvencyCurrencyTextBox47.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox47.TabIndex = 47;
this.solvencyCurrencyTextBox47.ColName = "R0190C0020";
this.solvencyCurrencyTextBox47.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox48
//
this.solvencyCurrencyTextBox48.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox48.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Decimal;
this.solvencyCurrencyTextBox48.Location = new System.Drawing.Point(117,183);
this.solvencyCurrencyTextBox48.Name = "solvencyCurrencyTextBox48";
this.solvencyCurrencyTextBox48.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox48.TabIndex = 48;
this.solvencyCurrencyTextBox48.ColName = "R0190C0030";
this.solvencyCurrencyTextBox48.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox49
//
this.solvencyCurrencyTextBox49.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox49.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox49.Location = new System.Drawing.Point(10,203);
this.solvencyCurrencyTextBox49.Name = "solvencyCurrencyTextBox49";
this.solvencyCurrencyTextBox49.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox49.TabIndex = 49;
this.solvencyCurrencyTextBox49.ColName = "R0200C0020";
this.solvencyCurrencyTextBox49.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox50
//
this.solvencyCurrencyTextBox50.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox50.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Decimal;
this.solvencyCurrencyTextBox50.Location = new System.Drawing.Point(117,203);
this.solvencyCurrencyTextBox50.Name = "solvencyCurrencyTextBox50";
this.solvencyCurrencyTextBox50.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox50.TabIndex = 50;
this.solvencyCurrencyTextBox50.ColName = "R0200C0030";
this.solvencyCurrencyTextBox50.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox51
//
this.solvencyCurrencyTextBox51.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox51.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox51.Location = new System.Drawing.Point(10,223);
this.solvencyCurrencyTextBox51.Name = "solvencyCurrencyTextBox51";
this.solvencyCurrencyTextBox51.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox51.TabIndex = 51;
this.solvencyCurrencyTextBox51.ColName = "R0210C0020";
this.solvencyCurrencyTextBox51.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox52
//
this.solvencyCurrencyTextBox52.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox52.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Decimal;
this.solvencyCurrencyTextBox52.Location = new System.Drawing.Point(117,223);
this.solvencyCurrencyTextBox52.Name = "solvencyCurrencyTextBox52";
this.solvencyCurrencyTextBox52.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox52.TabIndex = 52;
this.solvencyCurrencyTextBox52.ColName = "R0210C0030";
this.solvencyCurrencyTextBox52.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// splitContainerColTitles
//
this.splitContainerColTitles.Dock = System.Windows.Forms.DockStyle.Fill;
this.splitContainerColTitles.Location = new System.Drawing.Point(0,0);
this.splitContainerColTitles.Name = "splitContainerColTitles";
this.splitContainerColTitles.Orientation = System.Windows.Forms.Orientation.Vertical;
this.splitContainerColTitles.Panel1MinSize = 0;
//
// splitContainerColTitles.Panel1
//
//
// splitContainerColTitles.Panel2
//
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel0);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel1);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel2);
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel3);
this.splitContainerColTitles.Size = new System.Drawing.Size(554, 298);
this.splitContainerColTitles.SplitterDistance = 223;
//
// splitContainerRowTitles
//
this.splitContainerRowTitles.Dock = System.Windows.Forms.DockStyle.Fill;
this.splitContainerRowTitles.Location = new System.Drawing.Point(0,0);
this.splitContainerRowTitles.Name = "splitContainerRowTitles";
this.splitContainerRowTitles.Orientation = System.Windows.Forms.Orientation.Vertical;
this.splitContainerRowTitles.Panel1MinSize = 0;
//
// splitContainerRowTitles.Panel1
//
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel4);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel5);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel6);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel7);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel8);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel9);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel10);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel11);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel12);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel13);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel14);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel15);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel16);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel17);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel18);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel19);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel20);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel21);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel22);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel23);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel24);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel25);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel26);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel27);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel28);
//
// splitContainerRowTitles.Panel2
//
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox29);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox30);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox31);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox32);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox33);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox34);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox35);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox36);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox37);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox38);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox39);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox40);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox41);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox42);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox43);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox44);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox45);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox46);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox47);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox48);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox49);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox50);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox51);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyCurrencyTextBox52);
this.splitContainerRowTitles.Panel2.AutoScroll = true;
this.splitContainerRowTitles.Size = new System.Drawing.Size(554, 298);
this.splitContainerRowTitles.SplitterDistance = 223;
//
// spltMain
//
this.spltMain.Dock = System.Windows.Forms.DockStyle.Fill;
this.spltMain.Location = new System.Drawing.Point(0,0);
this.spltMain.Name = "spltMain";
this.spltMain.Orientation = System.Windows.Forms.Orientation.Horizontal;
this.spltMain.Panel1MinSize = 0;
//
// spltMain.Panel1
//
this.spltMain.Panel1.Controls.Add(this.splitContainerColTitles);
//
// spltMain.Panel2
//
this.spltMain.Panel2.Controls.Add(this.splitContainerRowTitles);
this.spltMain.Panel2.AutoScroll = true;
this.spltMain.Size = new System.Drawing.Size(554, 396);
this.spltMain.SplitterDistance = 75;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F); 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font; 
this.Controls.Add(this.spltMain);
            this.Name = "S_22_04_01_02__sol2__2_0_1_ctrl"; 
            this.Size = new System.Drawing.Size(554, 321); 
            this.Load += new System.EventHandler(this.BoundControl_Load);
            this.ResumeLayout(false); 
            this.PerformLayout(); 

      } 
private SolvencyLabel solvencyLabel0;
private SolvencyLabel solvencyLabel1;
private SolvencyLabel solvencyLabel2;
private SolvencyLabel solvencyLabel3;
private SolvencyLabel solvencyLabel4;
private SolvencyLabel solvencyLabel5;
private SolvencyLabel solvencyLabel6;
private SolvencyLabel solvencyLabel7;
private SolvencyLabel solvencyLabel8;
private SolvencyLabel solvencyLabel9;
private SolvencyLabel solvencyLabel10;
private SolvencyLabel solvencyLabel11;
private SolvencyLabel solvencyLabel12;
private SolvencyLabel solvencyLabel13;
private SolvencyLabel solvencyLabel14;
private SolvencyLabel solvencyLabel15;
private SolvencyLabel solvencyLabel16;
private SolvencyLabel solvencyLabel17;
private SolvencyLabel solvencyLabel18;
private SolvencyLabel solvencyLabel19;
private SolvencyLabel solvencyLabel20;
private SolvencyLabel solvencyLabel21;
private SolvencyLabel solvencyLabel22;
private SolvencyLabel solvencyLabel23;
private SolvencyLabel solvencyLabel24;
private SolvencyLabel solvencyLabel25;
private SolvencyLabel solvencyLabel26;
private SolvencyLabel solvencyLabel27;
private SolvencyLabel solvencyLabel28;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox29;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox30;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox31;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox32;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox33;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox34;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox35;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox36;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox37;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox38;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox39;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox40;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox41;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox42;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox43;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox44;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox45;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox46;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox47;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox48;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox49;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox50;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox51;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox52;
private SolvencySplitContainer splitContainerColTitles;
private SolvencySplitContainer splitContainerRowTitles;
private SolvencySplitContainer spltMain;

   }
}

