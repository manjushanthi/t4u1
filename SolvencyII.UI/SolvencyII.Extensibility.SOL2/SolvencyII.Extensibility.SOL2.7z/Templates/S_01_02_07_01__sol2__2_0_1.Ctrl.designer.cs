using SolvencyII.Domain.ENumerators; 
using SolvencyII.UI.Shared.Controls; 

namespace SolvencyII.UI.UserControls 
{ 
   partial class S_01_02_07_01__sol2__2_0_1_ctrl 
   { 
      private void InitializeComponent() 
      { 
this.solvencyLabel1 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel2 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel3 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel4 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel5 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel6 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel7 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel8 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel9 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel10 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel11 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel12 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel13 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel14 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel15 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel16 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel17 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel18 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel19 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel20 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel21 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel22 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel23 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel24 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel25 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel26 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel27 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel28 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel29 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel30 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel31 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel32 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel33 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel34 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel35 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel36 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel37 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel38 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel39 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel40 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel41 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel42 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyTextBox43 = new SolvencyII.UI.Shared.Controls.SolvencyTextBox();
this.SolvencyDataComboBox44 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyTextBox45 = new SolvencyII.UI.Shared.Controls.SolvencyTextBox();
this.SolvencyDataComboBox46 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyTextBox47 = new SolvencyII.UI.Shared.Controls.SolvencyTextBox();
this.SolvencyDataComboBox48 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.solvencyDateTimePicker49 = new SolvencyII.UI.Shared.Controls.SolvencyDateTimePicker();
this.solvencyDateTimePicker50 = new SolvencyII.UI.Shared.Controls.SolvencyDateTimePicker();
this.SolvencyDataComboBox51 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox52 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox53 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox54 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox55 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox56 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox57 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox58 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox59 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox60 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox61 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.SolvencyDataComboBox62 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
this.splitContainerColTitles = new SolvencyII.UI.Shared.Controls.SolvencySplitContainer();
this.splitContainerRowTitles = new SolvencyII.UI.Shared.Controls.SolvencySplitContainer();
this.spltMain = new SolvencyII.UI.Shared.Controls.SolvencySplitContainer();
            this.SuspendLayout(); 

//
// solvencyLabel1
//
this.solvencyLabel1.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel1.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel1.Location = new System.Drawing.Point(10,30);
this.solvencyLabel1.Name = "solvencyLabel1";
this.solvencyLabel1.OrdinateID_Label = 0;
this.solvencyLabel1.Size = new System.Drawing.Size(208, 13);
this.solvencyLabel1.TabIndex = 1;
this.solvencyLabel1.Text = "C0010" ;
this.solvencyLabel1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel2
//
this.solvencyLabel2.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel2.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel2.Location = new System.Drawing.Point(10,3);
this.solvencyLabel2.Name = "solvencyLabel2";
this.solvencyLabel2.OrdinateID_Label = 572;
this.solvencyLabel2.Size = new System.Drawing.Size(249, 15);
this.solvencyLabel2.TabIndex = 2;
this.solvencyLabel2.Text = "Name of Third Country Undertaking" ;
this.solvencyLabel2.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel3
//
this.solvencyLabel3.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel3.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel3.Location = new System.Drawing.Point(273,3);
this.solvencyLabel3.Name = "solvencyLabel3";
this.solvencyLabel3.OrdinateID_Label = 0;
this.solvencyLabel3.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel3.TabIndex = 3;
this.solvencyLabel3.Text = "R0010" ;
this.solvencyLabel3.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel4
//
this.solvencyLabel4.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel4.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel4.Location = new System.Drawing.Point(10,23);
this.solvencyLabel4.Name = "solvencyLabel4";
this.solvencyLabel4.OrdinateID_Label = 573;
this.solvencyLabel4.Size = new System.Drawing.Size(249, 15);
this.solvencyLabel4.TabIndex = 4;
this.solvencyLabel4.Text = "Country of third country undertaking" ;
this.solvencyLabel4.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel5
//
this.solvencyLabel5.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel5.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel5.Location = new System.Drawing.Point(273,23);
this.solvencyLabel5.Name = "solvencyLabel5";
this.solvencyLabel5.OrdinateID_Label = 0;
this.solvencyLabel5.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel5.TabIndex = 5;
this.solvencyLabel5.Text = "R0020" ;
this.solvencyLabel5.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel6
//
this.solvencyLabel6.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel6.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel6.Location = new System.Drawing.Point(10,43);
this.solvencyLabel6.Name = "solvencyLabel6";
this.solvencyLabel6.OrdinateID_Label = 574;
this.solvencyLabel6.Size = new System.Drawing.Size(249, 15);
this.solvencyLabel6.TabIndex = 6;
this.solvencyLabel6.Text = "Name of a third country branch" ;
this.solvencyLabel6.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel7
//
this.solvencyLabel7.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel7.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel7.Location = new System.Drawing.Point(273,43);
this.solvencyLabel7.Name = "solvencyLabel7";
this.solvencyLabel7.OrdinateID_Label = 0;
this.solvencyLabel7.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel7.TabIndex = 7;
this.solvencyLabel7.Text = "R0030" ;
this.solvencyLabel7.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel8
//
this.solvencyLabel8.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel8.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel8.Location = new System.Drawing.Point(10,63);
this.solvencyLabel8.Name = "solvencyLabel8";
this.solvencyLabel8.OrdinateID_Label = 575;
this.solvencyLabel8.Size = new System.Drawing.Size(249, 15);
this.solvencyLabel8.TabIndex = 8;
this.solvencyLabel8.Text = "Country of third country branch" ;
this.solvencyLabel8.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel9
//
this.solvencyLabel9.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel9.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel9.Location = new System.Drawing.Point(273,63);
this.solvencyLabel9.Name = "solvencyLabel9";
this.solvencyLabel9.OrdinateID_Label = 0;
this.solvencyLabel9.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel9.TabIndex = 9;
this.solvencyLabel9.Text = "R0040" ;
this.solvencyLabel9.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel10
//
this.solvencyLabel10.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel10.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel10.Location = new System.Drawing.Point(10,83);
this.solvencyLabel10.Name = "solvencyLabel10";
this.solvencyLabel10.OrdinateID_Label = 576;
this.solvencyLabel10.Size = new System.Drawing.Size(249, 15);
this.solvencyLabel10.TabIndex = 10;
this.solvencyLabel10.Text = "Identification code of third country branch" ;
this.solvencyLabel10.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel11
//
this.solvencyLabel11.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel11.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel11.Location = new System.Drawing.Point(273,83);
this.solvencyLabel11.Name = "solvencyLabel11";
this.solvencyLabel11.OrdinateID_Label = 0;
this.solvencyLabel11.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel11.TabIndex = 11;
this.solvencyLabel11.Text = "R0050" ;
this.solvencyLabel11.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel12
//
this.solvencyLabel12.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel12.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel12.Location = new System.Drawing.Point(10,103);
this.solvencyLabel12.Name = "solvencyLabel12";
this.solvencyLabel12.OrdinateID_Label = 577;
this.solvencyLabel12.Size = new System.Drawing.Size(249, 15);
this.solvencyLabel12.TabIndex = 12;
this.solvencyLabel12.Text = "Language of reporting" ;
this.solvencyLabel12.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel13
//
this.solvencyLabel13.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel13.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel13.Location = new System.Drawing.Point(273,103);
this.solvencyLabel13.Name = "solvencyLabel13";
this.solvencyLabel13.OrdinateID_Label = 0;
this.solvencyLabel13.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel13.TabIndex = 13;
this.solvencyLabel13.Text = "R0070" ;
this.solvencyLabel13.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel14
//
this.solvencyLabel14.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel14.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel14.Location = new System.Drawing.Point(10,123);
this.solvencyLabel14.Name = "solvencyLabel14";
this.solvencyLabel14.OrdinateID_Label = 578;
this.solvencyLabel14.Size = new System.Drawing.Size(249, 15);
this.solvencyLabel14.TabIndex = 14;
this.solvencyLabel14.Text = "Reporting submission date" ;
this.solvencyLabel14.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel15
//
this.solvencyLabel15.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel15.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel15.Location = new System.Drawing.Point(273,123);
this.solvencyLabel15.Name = "solvencyLabel15";
this.solvencyLabel15.OrdinateID_Label = 0;
this.solvencyLabel15.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel15.TabIndex = 15;
this.solvencyLabel15.Text = "R0080" ;
this.solvencyLabel15.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel16
//
this.solvencyLabel16.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel16.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel16.Location = new System.Drawing.Point(10,143);
this.solvencyLabel16.Name = "solvencyLabel16";
this.solvencyLabel16.OrdinateID_Label = 579;
this.solvencyLabel16.Size = new System.Drawing.Size(249, 15);
this.solvencyLabel16.TabIndex = 16;
this.solvencyLabel16.Text = "Reporting reference date" ;
this.solvencyLabel16.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel17
//
this.solvencyLabel17.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel17.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel17.Location = new System.Drawing.Point(273,143);
this.solvencyLabel17.Name = "solvencyLabel17";
this.solvencyLabel17.OrdinateID_Label = 0;
this.solvencyLabel17.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel17.TabIndex = 17;
this.solvencyLabel17.Text = "R0090" ;
this.solvencyLabel17.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel18
//
this.solvencyLabel18.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel18.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel18.Location = new System.Drawing.Point(10,163);
this.solvencyLabel18.Name = "solvencyLabel18";
this.solvencyLabel18.OrdinateID_Label = 580;
this.solvencyLabel18.Size = new System.Drawing.Size(249, 15);
this.solvencyLabel18.TabIndex = 18;
this.solvencyLabel18.Text = "Regular/Ad-hoc submission" ;
this.solvencyLabel18.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel19
//
this.solvencyLabel19.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel19.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel19.Location = new System.Drawing.Point(273,163);
this.solvencyLabel19.Name = "solvencyLabel19";
this.solvencyLabel19.OrdinateID_Label = 0;
this.solvencyLabel19.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel19.TabIndex = 19;
this.solvencyLabel19.Text = "R0100" ;
this.solvencyLabel19.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel20
//
this.solvencyLabel20.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel20.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel20.Location = new System.Drawing.Point(10,183);
this.solvencyLabel20.Name = "solvencyLabel20";
this.solvencyLabel20.OrdinateID_Label = 581;
this.solvencyLabel20.Size = new System.Drawing.Size(249, 15);
this.solvencyLabel20.TabIndex = 20;
this.solvencyLabel20.Text = "Currency used for reporting" ;
this.solvencyLabel20.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel21
//
this.solvencyLabel21.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel21.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel21.Location = new System.Drawing.Point(273,183);
this.solvencyLabel21.Name = "solvencyLabel21";
this.solvencyLabel21.OrdinateID_Label = 0;
this.solvencyLabel21.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel21.TabIndex = 21;
this.solvencyLabel21.Text = "R0110" ;
this.solvencyLabel21.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel22
//
this.solvencyLabel22.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel22.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel22.Location = new System.Drawing.Point(10,203);
this.solvencyLabel22.Name = "solvencyLabel22";
this.solvencyLabel22.OrdinateID_Label = 582;
this.solvencyLabel22.Size = new System.Drawing.Size(249, 15);
this.solvencyLabel22.TabIndex = 22;
this.solvencyLabel22.Text = "Accounting standards" ;
this.solvencyLabel22.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel23
//
this.solvencyLabel23.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel23.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel23.Location = new System.Drawing.Point(273,203);
this.solvencyLabel23.Name = "solvencyLabel23";
this.solvencyLabel23.OrdinateID_Label = 0;
this.solvencyLabel23.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel23.TabIndex = 23;
this.solvencyLabel23.Text = "R0120" ;
this.solvencyLabel23.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel24
//
this.solvencyLabel24.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel24.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel24.Location = new System.Drawing.Point(10,223);
this.solvencyLabel24.Name = "solvencyLabel24";
this.solvencyLabel24.OrdinateID_Label = 583;
this.solvencyLabel24.Size = new System.Drawing.Size(249, 15);
this.solvencyLabel24.TabIndex = 24;
this.solvencyLabel24.Text = "Method of Calculation of the SCR" ;
this.solvencyLabel24.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel25
//
this.solvencyLabel25.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel25.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel25.Location = new System.Drawing.Point(273,223);
this.solvencyLabel25.Name = "solvencyLabel25";
this.solvencyLabel25.OrdinateID_Label = 0;
this.solvencyLabel25.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel25.TabIndex = 25;
this.solvencyLabel25.Text = "R0130" ;
this.solvencyLabel25.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel26
//
this.solvencyLabel26.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel26.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel26.Location = new System.Drawing.Point(10,243);
this.solvencyLabel26.Name = "solvencyLabel26";
this.solvencyLabel26.OrdinateID_Label = 584;
this.solvencyLabel26.Size = new System.Drawing.Size(249, 15);
this.solvencyLabel26.TabIndex = 26;
this.solvencyLabel26.Text = "Use of undertaking specific parameters" ;
this.solvencyLabel26.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel27
//
this.solvencyLabel27.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel27.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel27.Location = new System.Drawing.Point(273,243);
this.solvencyLabel27.Name = "solvencyLabel27";
this.solvencyLabel27.OrdinateID_Label = 0;
this.solvencyLabel27.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel27.TabIndex = 27;
this.solvencyLabel27.Text = "R0140" ;
this.solvencyLabel27.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel28
//
this.solvencyLabel28.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel28.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel28.Location = new System.Drawing.Point(10,263);
this.solvencyLabel28.Name = "solvencyLabel28";
this.solvencyLabel28.OrdinateID_Label = 585;
this.solvencyLabel28.Size = new System.Drawing.Size(249, 15);
this.solvencyLabel28.TabIndex = 28;
this.solvencyLabel28.Text = "Ring-fenced funds" ;
this.solvencyLabel28.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel29
//
this.solvencyLabel29.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel29.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel29.Location = new System.Drawing.Point(273,263);
this.solvencyLabel29.Name = "solvencyLabel29";
this.solvencyLabel29.OrdinateID_Label = 0;
this.solvencyLabel29.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel29.TabIndex = 29;
this.solvencyLabel29.Text = "R0150" ;
this.solvencyLabel29.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel30
//
this.solvencyLabel30.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel30.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel30.Location = new System.Drawing.Point(10,283);
this.solvencyLabel30.Name = "solvencyLabel30";
this.solvencyLabel30.OrdinateID_Label = 586;
this.solvencyLabel30.Size = new System.Drawing.Size(249, 15);
this.solvencyLabel30.TabIndex = 30;
this.solvencyLabel30.Text = "Matching adjustment" ;
this.solvencyLabel30.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel31
//
this.solvencyLabel31.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel31.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel31.Location = new System.Drawing.Point(273,283);
this.solvencyLabel31.Name = "solvencyLabel31";
this.solvencyLabel31.OrdinateID_Label = 0;
this.solvencyLabel31.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel31.TabIndex = 31;
this.solvencyLabel31.Text = "R0170" ;
this.solvencyLabel31.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel32
//
this.solvencyLabel32.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel32.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel32.Location = new System.Drawing.Point(10,303);
this.solvencyLabel32.Name = "solvencyLabel32";
this.solvencyLabel32.OrdinateID_Label = 587;
this.solvencyLabel32.Size = new System.Drawing.Size(249, 15);
this.solvencyLabel32.TabIndex = 32;
this.solvencyLabel32.Text = "Volatility adjustment" ;
this.solvencyLabel32.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel33
//
this.solvencyLabel33.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel33.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel33.Location = new System.Drawing.Point(273,303);
this.solvencyLabel33.Name = "solvencyLabel33";
this.solvencyLabel33.OrdinateID_Label = 0;
this.solvencyLabel33.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel33.TabIndex = 33;
this.solvencyLabel33.Text = "R0180" ;
this.solvencyLabel33.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel34
//
this.solvencyLabel34.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel34.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel34.Location = new System.Drawing.Point(10,323);
this.solvencyLabel34.Name = "solvencyLabel34";
this.solvencyLabel34.OrdinateID_Label = 588;
this.solvencyLabel34.Size = new System.Drawing.Size(249, 15);
this.solvencyLabel34.TabIndex = 34;
this.solvencyLabel34.Text = "Transitional measure on the risk-free interest rate" ;
this.solvencyLabel34.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel35
//
this.solvencyLabel35.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel35.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel35.Location = new System.Drawing.Point(273,323);
this.solvencyLabel35.Name = "solvencyLabel35";
this.solvencyLabel35.OrdinateID_Label = 0;
this.solvencyLabel35.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel35.TabIndex = 35;
this.solvencyLabel35.Text = "R0190" ;
this.solvencyLabel35.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel36
//
this.solvencyLabel36.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel36.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel36.Location = new System.Drawing.Point(10,343);
this.solvencyLabel36.Name = "solvencyLabel36";
this.solvencyLabel36.OrdinateID_Label = 589;
this.solvencyLabel36.Size = new System.Drawing.Size(249, 15);
this.solvencyLabel36.TabIndex = 36;
this.solvencyLabel36.Text = "Transitional measure on technical provisions" ;
this.solvencyLabel36.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel37
//
this.solvencyLabel37.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel37.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel37.Location = new System.Drawing.Point(273,343);
this.solvencyLabel37.Name = "solvencyLabel37";
this.solvencyLabel37.OrdinateID_Label = 0;
this.solvencyLabel37.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel37.TabIndex = 37;
this.solvencyLabel37.Text = "R0200" ;
this.solvencyLabel37.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel38
//
this.solvencyLabel38.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel38.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel38.Location = new System.Drawing.Point(10,363);
this.solvencyLabel38.Name = "solvencyLabel38";
this.solvencyLabel38.OrdinateID_Label = 590;
this.solvencyLabel38.Size = new System.Drawing.Size(249, 15);
this.solvencyLabel38.TabIndex = 38;
this.solvencyLabel38.Text = "Initial submission or re-submission" ;
this.solvencyLabel38.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel39
//
this.solvencyLabel39.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel39.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel39.Location = new System.Drawing.Point(273,363);
this.solvencyLabel39.Name = "solvencyLabel39";
this.solvencyLabel39.OrdinateID_Label = 0;
this.solvencyLabel39.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel39.TabIndex = 39;
this.solvencyLabel39.Text = "R0210" ;
this.solvencyLabel39.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel40
//
this.solvencyLabel40.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel40.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel40.Location = new System.Drawing.Point(10,383);
this.solvencyLabel40.Name = "solvencyLabel40";
this.solvencyLabel40.OrdinateID_Label = 591;
this.solvencyLabel40.Size = new System.Drawing.Size(249, 15);
this.solvencyLabel40.TabIndex = 40;
this.solvencyLabel40.Text = "Type of branch" ;
this.solvencyLabel40.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel41
//
this.solvencyLabel41.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel41.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel41.Location = new System.Drawing.Point(273,383);
this.solvencyLabel41.Name = "solvencyLabel41";
this.solvencyLabel41.OrdinateID_Label = 0;
this.solvencyLabel41.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel41.TabIndex = 41;
this.solvencyLabel41.Text = "R0220" ;
this.solvencyLabel41.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel42
//
this.solvencyLabel42.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel42.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel42.Location = new System.Drawing.Point(273,403);
this.solvencyLabel42.Name = "solvencyLabel42";
this.solvencyLabel42.OrdinateID_Label = 0;
this.solvencyLabel42.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel42.TabIndex = 42;
this.solvencyLabel42.Text = "." ;
this.solvencyLabel42.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyTextBox43
//
this.solvencyTextBox43.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyTextBox43.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyTextBox43.Location = new System.Drawing.Point(10,3);
this.solvencyTextBox43.Name = "solvencyTextBox43";
this.solvencyTextBox43.Size = new System.Drawing.Size(200, 13);
this.solvencyTextBox43.TabIndex = 43;
this.solvencyTextBox43.ColName = "R0010C0010";
this.solvencyTextBox43.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
//
// SolvencyDataComboBox44
//
this.SolvencyDataComboBox44.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox44.Location = new System.Drawing.Point(10,23);
this.SolvencyDataComboBox44.Name = "SolvencyDataComboBox44";
this.SolvencyDataComboBox44.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox44.TabIndex = 44;
this.SolvencyDataComboBox44.ColName = "R0020C0010";
this.SolvencyDataComboBox44.AxisID = 59;
this.SolvencyDataComboBox44.OrdinateID = 573;
this.SolvencyDataComboBox44.StartOrder = 0;
this.SolvencyDataComboBox44.NextOrder = 0;
//
// solvencyTextBox45
//
this.solvencyTextBox45.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyTextBox45.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyTextBox45.Location = new System.Drawing.Point(10,43);
this.solvencyTextBox45.Name = "solvencyTextBox45";
this.solvencyTextBox45.Size = new System.Drawing.Size(200, 13);
this.solvencyTextBox45.TabIndex = 45;
this.solvencyTextBox45.ColName = "R0030C0010";
this.solvencyTextBox45.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
//
// SolvencyDataComboBox46
//
this.SolvencyDataComboBox46.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox46.Location = new System.Drawing.Point(10,63);
this.SolvencyDataComboBox46.Name = "SolvencyDataComboBox46";
this.SolvencyDataComboBox46.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox46.TabIndex = 46;
this.SolvencyDataComboBox46.ColName = "R0040C0010";
this.SolvencyDataComboBox46.AxisID = 59;
this.SolvencyDataComboBox46.OrdinateID = 575;
this.SolvencyDataComboBox46.StartOrder = 0;
this.SolvencyDataComboBox46.NextOrder = 0;
//
// solvencyTextBox47
//
this.solvencyTextBox47.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyTextBox47.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyTextBox47.Location = new System.Drawing.Point(10,83);
this.solvencyTextBox47.Name = "solvencyTextBox47";
this.solvencyTextBox47.Size = new System.Drawing.Size(200, 13);
this.solvencyTextBox47.TabIndex = 47;
this.solvencyTextBox47.ColName = "R0050C0010";
this.solvencyTextBox47.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
//
// SolvencyDataComboBox48
//
this.SolvencyDataComboBox48.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox48.Location = new System.Drawing.Point(10,103);
this.SolvencyDataComboBox48.Name = "SolvencyDataComboBox48";
this.SolvencyDataComboBox48.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox48.TabIndex = 48;
this.SolvencyDataComboBox48.ColName = "R0070C0010";
this.SolvencyDataComboBox48.AxisID = 59;
this.SolvencyDataComboBox48.OrdinateID = 577;
this.SolvencyDataComboBox48.StartOrder = 0;
this.SolvencyDataComboBox48.NextOrder = 0;
//
// solvencyDateTimePicker49
//
this.solvencyDateTimePicker49.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Date;
this.solvencyDateTimePicker49.Location = new System.Drawing.Point(10,121);
this.solvencyDateTimePicker49.Name = "solvencyDateTimePicker49";
this.solvencyDateTimePicker49.Size = new System.Drawing.Size(200, 13);
this.solvencyDateTimePicker49.TabIndex = 49;
this.solvencyDateTimePicker49.ColName = "R0080C0010";
//
// solvencyDateTimePicker50
//
this.solvencyDateTimePicker50.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Date;
this.solvencyDateTimePicker50.Location = new System.Drawing.Point(10,141);
this.solvencyDateTimePicker50.Name = "solvencyDateTimePicker50";
this.solvencyDateTimePicker50.Size = new System.Drawing.Size(200, 13);
this.solvencyDateTimePicker50.TabIndex = 50;
this.solvencyDateTimePicker50.ColName = "R0090C0010";
//
// SolvencyDataComboBox51
//
this.SolvencyDataComboBox51.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox51.Location = new System.Drawing.Point(10,163);
this.SolvencyDataComboBox51.Name = "SolvencyDataComboBox51";
this.SolvencyDataComboBox51.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox51.TabIndex = 51;
this.SolvencyDataComboBox51.ColName = "R0100C0010";
this.SolvencyDataComboBox51.AxisID = 59;
this.SolvencyDataComboBox51.OrdinateID = 580;
this.SolvencyDataComboBox51.StartOrder = 0;
this.SolvencyDataComboBox51.NextOrder = 0;
//
// SolvencyDataComboBox52
//
this.SolvencyDataComboBox52.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox52.Location = new System.Drawing.Point(10,183);
this.SolvencyDataComboBox52.Name = "SolvencyDataComboBox52";
this.SolvencyDataComboBox52.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox52.TabIndex = 52;
this.SolvencyDataComboBox52.ColName = "R0110C0010";
this.SolvencyDataComboBox52.AxisID = 59;
this.SolvencyDataComboBox52.OrdinateID = 581;
this.SolvencyDataComboBox52.StartOrder = 0;
this.SolvencyDataComboBox52.NextOrder = 0;
//
// SolvencyDataComboBox53
//
this.SolvencyDataComboBox53.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox53.Location = new System.Drawing.Point(10,203);
this.SolvencyDataComboBox53.Name = "SolvencyDataComboBox53";
this.SolvencyDataComboBox53.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox53.TabIndex = 53;
this.SolvencyDataComboBox53.ColName = "R0120C0010";
this.SolvencyDataComboBox53.AxisID = 59;
this.SolvencyDataComboBox53.OrdinateID = 582;
this.SolvencyDataComboBox53.StartOrder = 0;
this.SolvencyDataComboBox53.NextOrder = 0;
//
// SolvencyDataComboBox54
//
this.SolvencyDataComboBox54.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox54.Location = new System.Drawing.Point(10,223);
this.SolvencyDataComboBox54.Name = "SolvencyDataComboBox54";
this.SolvencyDataComboBox54.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox54.TabIndex = 54;
this.SolvencyDataComboBox54.ColName = "R0130C0010";
this.SolvencyDataComboBox54.AxisID = 59;
this.SolvencyDataComboBox54.OrdinateID = 583;
this.SolvencyDataComboBox54.StartOrder = 0;
this.SolvencyDataComboBox54.NextOrder = 0;
//
// SolvencyDataComboBox55
//
this.SolvencyDataComboBox55.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox55.Location = new System.Drawing.Point(10,243);
this.SolvencyDataComboBox55.Name = "SolvencyDataComboBox55";
this.SolvencyDataComboBox55.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox55.TabIndex = 55;
this.SolvencyDataComboBox55.ColName = "R0140C0010";
this.SolvencyDataComboBox55.AxisID = 59;
this.SolvencyDataComboBox55.OrdinateID = 584;
this.SolvencyDataComboBox55.StartOrder = 0;
this.SolvencyDataComboBox55.NextOrder = 0;
//
// SolvencyDataComboBox56
//
this.SolvencyDataComboBox56.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox56.Location = new System.Drawing.Point(10,263);
this.SolvencyDataComboBox56.Name = "SolvencyDataComboBox56";
this.SolvencyDataComboBox56.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox56.TabIndex = 56;
this.SolvencyDataComboBox56.ColName = "R0150C0010";
this.SolvencyDataComboBox56.AxisID = 59;
this.SolvencyDataComboBox56.OrdinateID = 585;
this.SolvencyDataComboBox56.StartOrder = 0;
this.SolvencyDataComboBox56.NextOrder = 0;
//
// SolvencyDataComboBox57
//
this.SolvencyDataComboBox57.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox57.Location = new System.Drawing.Point(10,283);
this.SolvencyDataComboBox57.Name = "SolvencyDataComboBox57";
this.SolvencyDataComboBox57.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox57.TabIndex = 57;
this.SolvencyDataComboBox57.ColName = "R0170C0010";
this.SolvencyDataComboBox57.AxisID = 59;
this.SolvencyDataComboBox57.OrdinateID = 586;
this.SolvencyDataComboBox57.StartOrder = 0;
this.SolvencyDataComboBox57.NextOrder = 0;
//
// SolvencyDataComboBox58
//
this.SolvencyDataComboBox58.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox58.Location = new System.Drawing.Point(10,303);
this.SolvencyDataComboBox58.Name = "SolvencyDataComboBox58";
this.SolvencyDataComboBox58.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox58.TabIndex = 58;
this.SolvencyDataComboBox58.ColName = "R0180C0010";
this.SolvencyDataComboBox58.AxisID = 59;
this.SolvencyDataComboBox58.OrdinateID = 587;
this.SolvencyDataComboBox58.StartOrder = 0;
this.SolvencyDataComboBox58.NextOrder = 0;
//
// SolvencyDataComboBox59
//
this.SolvencyDataComboBox59.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox59.Location = new System.Drawing.Point(10,323);
this.SolvencyDataComboBox59.Name = "SolvencyDataComboBox59";
this.SolvencyDataComboBox59.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox59.TabIndex = 59;
this.SolvencyDataComboBox59.ColName = "R0190C0010";
this.SolvencyDataComboBox59.AxisID = 59;
this.SolvencyDataComboBox59.OrdinateID = 588;
this.SolvencyDataComboBox59.StartOrder = 0;
this.SolvencyDataComboBox59.NextOrder = 0;
//
// SolvencyDataComboBox60
//
this.SolvencyDataComboBox60.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox60.Location = new System.Drawing.Point(10,343);
this.SolvencyDataComboBox60.Name = "SolvencyDataComboBox60";
this.SolvencyDataComboBox60.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox60.TabIndex = 60;
this.SolvencyDataComboBox60.ColName = "R0200C0010";
this.SolvencyDataComboBox60.AxisID = 59;
this.SolvencyDataComboBox60.OrdinateID = 589;
this.SolvencyDataComboBox60.StartOrder = 0;
this.SolvencyDataComboBox60.NextOrder = 0;
//
// SolvencyDataComboBox61
//
this.SolvencyDataComboBox61.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox61.Location = new System.Drawing.Point(10,363);
this.SolvencyDataComboBox61.Name = "SolvencyDataComboBox61";
this.SolvencyDataComboBox61.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox61.TabIndex = 61;
this.SolvencyDataComboBox61.ColName = "R0210C0010";
this.SolvencyDataComboBox61.AxisID = 59;
this.SolvencyDataComboBox61.OrdinateID = 590;
this.SolvencyDataComboBox61.StartOrder = 0;
this.SolvencyDataComboBox61.NextOrder = 0;
//
// SolvencyDataComboBox62
//
this.SolvencyDataComboBox62.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox62.Location = new System.Drawing.Point(10,383);
this.SolvencyDataComboBox62.Name = "SolvencyDataComboBox62";
this.SolvencyDataComboBox62.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox62.TabIndex = 62;
this.SolvencyDataComboBox62.ColName = "R0220C0010";
this.SolvencyDataComboBox62.AxisID = 59;
this.SolvencyDataComboBox62.OrdinateID = 591;
this.SolvencyDataComboBox62.StartOrder = 0;
this.SolvencyDataComboBox62.NextOrder = 0;
//
// splitContainerColTitles
//
this.splitContainerColTitles.Dock = System.Windows.Forms.DockStyle.Fill;
this.splitContainerColTitles.Location = new System.Drawing.Point(0,0);
this.splitContainerColTitles.Name = "splitContainerColTitles";
this.splitContainerColTitles.Orientation = System.Windows.Forms.Orientation.Vertical;
this.splitContainerColTitles.Panel1MinSize = 0;
//
// splitContainerColTitles.Panel1
//
//
// splitContainerColTitles.Panel2
//
this.splitContainerColTitles.Panel2.Controls.Add(this.solvencyLabel1);
this.splitContainerColTitles.Size = new System.Drawing.Size(744, 370);
this.splitContainerColTitles.SplitterDistance = 320;
//
// splitContainerRowTitles
//
this.splitContainerRowTitles.Dock = System.Windows.Forms.DockStyle.Fill;
this.splitContainerRowTitles.Location = new System.Drawing.Point(0,0);
this.splitContainerRowTitles.Name = "splitContainerRowTitles";
this.splitContainerRowTitles.Orientation = System.Windows.Forms.Orientation.Vertical;
this.splitContainerRowTitles.Panel1MinSize = 0;
//
// splitContainerRowTitles.Panel1
//
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel2);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel3);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel4);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel5);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel6);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel7);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel8);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel9);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel10);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel11);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel12);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel13);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel14);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel15);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel16);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel17);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel18);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel19);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel20);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel21);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel22);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel23);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel24);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel25);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel26);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel27);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel28);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel29);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel30);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel31);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel32);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel33);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel34);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel35);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel36);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel37);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel38);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel39);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel40);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel41);
this.splitContainerRowTitles.Panel1.Controls.Add(this.solvencyLabel42);
//
// splitContainerRowTitles.Panel2
//
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyTextBox43);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox44);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyTextBox45);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox46);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyTextBox47);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox48);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyDateTimePicker49);
this.splitContainerRowTitles.Panel2.Controls.Add(this.solvencyDateTimePicker50);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox51);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox52);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox53);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox54);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox55);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox56);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox57);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox58);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox59);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox60);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox61);
this.splitContainerRowTitles.Panel2.Controls.Add(this.SolvencyDataComboBox62);
this.splitContainerRowTitles.Panel2.AutoScroll = true;
this.splitContainerRowTitles.Size = new System.Drawing.Size(744, 370);
this.splitContainerRowTitles.SplitterDistance = 320;
//
// spltMain
//
this.spltMain.Dock = System.Windows.Forms.DockStyle.Fill;
this.spltMain.Location = new System.Drawing.Point(0,0);
this.spltMain.Name = "spltMain";
this.spltMain.Orientation = System.Windows.Forms.Orientation.Horizontal;
this.spltMain.Panel1MinSize = 0;
//
// spltMain.Panel1
//
this.spltMain.Panel1.Controls.Add(this.splitContainerColTitles);
//
// spltMain.Panel2
//
this.spltMain.Panel2.Controls.Add(this.splitContainerRowTitles);
this.spltMain.Panel2.AutoScroll = true;
this.spltMain.Size = new System.Drawing.Size(744, 506);
this.spltMain.SplitterDistance = 50;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F); 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font; 
this.Controls.Add(this.spltMain);
            this.Name = "S_01_02_07_01__sol2__2_0_1_ctrl"; 
            this.Size = new System.Drawing.Size(744, 456); 
            this.Load += new System.EventHandler(this.BoundControl_Load);
            this.ResumeLayout(false); 
            this.PerformLayout(); 

      } 
private SolvencyLabel solvencyLabel1;
private SolvencyLabel solvencyLabel2;
private SolvencyLabel solvencyLabel3;
private SolvencyLabel solvencyLabel4;
private SolvencyLabel solvencyLabel5;
private SolvencyLabel solvencyLabel6;
private SolvencyLabel solvencyLabel7;
private SolvencyLabel solvencyLabel8;
private SolvencyLabel solvencyLabel9;
private SolvencyLabel solvencyLabel10;
private SolvencyLabel solvencyLabel11;
private SolvencyLabel solvencyLabel12;
private SolvencyLabel solvencyLabel13;
private SolvencyLabel solvencyLabel14;
private SolvencyLabel solvencyLabel15;
private SolvencyLabel solvencyLabel16;
private SolvencyLabel solvencyLabel17;
private SolvencyLabel solvencyLabel18;
private SolvencyLabel solvencyLabel19;
private SolvencyLabel solvencyLabel20;
private SolvencyLabel solvencyLabel21;
private SolvencyLabel solvencyLabel22;
private SolvencyLabel solvencyLabel23;
private SolvencyLabel solvencyLabel24;
private SolvencyLabel solvencyLabel25;
private SolvencyLabel solvencyLabel26;
private SolvencyLabel solvencyLabel27;
private SolvencyLabel solvencyLabel28;
private SolvencyLabel solvencyLabel29;
private SolvencyLabel solvencyLabel30;
private SolvencyLabel solvencyLabel31;
private SolvencyLabel solvencyLabel32;
private SolvencyLabel solvencyLabel33;
private SolvencyLabel solvencyLabel34;
private SolvencyLabel solvencyLabel35;
private SolvencyLabel solvencyLabel36;
private SolvencyLabel solvencyLabel37;
private SolvencyLabel solvencyLabel38;
private SolvencyLabel solvencyLabel39;
private SolvencyLabel solvencyLabel40;
private SolvencyLabel solvencyLabel41;
private SolvencyLabel solvencyLabel42;
private SolvencyTextBox solvencyTextBox43;
private SolvencyDataComboBox SolvencyDataComboBox44;
private SolvencyTextBox solvencyTextBox45;
private SolvencyDataComboBox SolvencyDataComboBox46;
private SolvencyTextBox solvencyTextBox47;
private SolvencyDataComboBox SolvencyDataComboBox48;
private SolvencyDateTimePicker solvencyDateTimePicker49;
private SolvencyDateTimePicker solvencyDateTimePicker50;
private SolvencyDataComboBox SolvencyDataComboBox51;
private SolvencyDataComboBox SolvencyDataComboBox52;
private SolvencyDataComboBox SolvencyDataComboBox53;
private SolvencyDataComboBox SolvencyDataComboBox54;
private SolvencyDataComboBox SolvencyDataComboBox55;
private SolvencyDataComboBox SolvencyDataComboBox56;
private SolvencyDataComboBox SolvencyDataComboBox57;
private SolvencyDataComboBox SolvencyDataComboBox58;
private SolvencyDataComboBox SolvencyDataComboBox59;
private SolvencyDataComboBox SolvencyDataComboBox60;
private SolvencyDataComboBox SolvencyDataComboBox61;
private SolvencyDataComboBox SolvencyDataComboBox62;
private SolvencySplitContainer splitContainerColTitles;
private SolvencySplitContainer splitContainerRowTitles;
private SolvencySplitContainer spltMain;

   }
}

