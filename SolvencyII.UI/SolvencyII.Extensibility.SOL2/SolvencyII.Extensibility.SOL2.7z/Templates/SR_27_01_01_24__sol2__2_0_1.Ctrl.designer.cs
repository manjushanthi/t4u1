using SolvencyII.Domain.ENumerators; 
using SolvencyII.UI.Shared.Controls; 

namespace SolvencyII.UI.UserControls 
{ 
   partial class SR_27_01_01_24__sol2__2_0_1_ctrl 
   { 
      private void InitializeComponent() 
      { 
this.solvencyButton0 = new SolvencyII.UI.Shared.Controls.SolvencyButton();
this.solvencyLabel1 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel2 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel3 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel4 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel5 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel6 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel7 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel8 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel9 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel10 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel11 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel12 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel13 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel14 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel15 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel16 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel17 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel18 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel19 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel20 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel21 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel22 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel23 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel24 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel25 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel26 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel27 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel28 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel29 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel30 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel31 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyLabel32 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.solvencyCurrencyTextBox33 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox34 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox35 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox36 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox37 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox38 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox39 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox40 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox41 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox42 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox43 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox44 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyCurrencyTextBox45 = new SolvencyII.UI.Shared.Controls.SolvencyCurrencyTextBox();
this.solvencyButton46 = new SolvencyII.UI.Shared.Controls.SolvencyButton();
this.solvencyLabel47 = new SolvencyII.UI.Shared.Controls.SolvencyLabel();
this.SolvencyDataComboBox48 = new SolvencyII.UI.Shared.Controls.SolvencyDataComboBox();
            this.SuspendLayout(); 

//
// solvencyButton0
//
this.solvencyButton0.ColName = "";
this.solvencyButton0.TableNames = "";
this.solvencyButton0.Location = new System.Drawing.Point(7,10);
this.solvencyButton0.Name = "solvencyButton0";
this.solvencyButton0.Size = new System.Drawing.Size(50, 20);
this.solvencyButton0.TabIndex = 0;
this.solvencyButton0.Text = "Add";
this.solvencyButton0.UseVisualStyleBackColor = true;
this.solvencyButton0.Click += new System.EventHandler(this.btnAdd_Click);
//
// solvencyLabel1
//
this.solvencyLabel1.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel1.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel1.Location = new System.Drawing.Point(1876,10);
this.solvencyLabel1.Name = "solvencyLabel1";
this.solvencyLabel1.OrdinateID_Label = 8086;
this.solvencyLabel1.Size = new System.Drawing.Size(108, 65);
this.solvencyLabel1.TabIndex = 1;
this.solvencyLabel1.Text = "Catastrophe Risk Charge after risk mitigation" ;
this.solvencyLabel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel2
//
this.solvencyLabel2.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel2.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel2.Location = new System.Drawing.Point(1876,75);
this.solvencyLabel2.Name = "solvencyLabel2";
this.solvencyLabel2.OrdinateID_Label = 0;
this.solvencyLabel2.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel2.TabIndex = 2;
this.solvencyLabel2.Text = "C1540" ;
this.solvencyLabel2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel3
//
this.solvencyLabel3.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel3.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel3.Location = new System.Drawing.Point(1769,10);
this.solvencyLabel3.Name = "solvencyLabel3";
this.solvencyLabel3.OrdinateID_Label = 8085;
this.solvencyLabel3.Size = new System.Drawing.Size(108, 65);
this.solvencyLabel3.TabIndex = 3;
this.solvencyLabel3.Text = "Estimated Reinstatement Premiums" ;
this.solvencyLabel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel4
//
this.solvencyLabel4.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel4.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel4.Location = new System.Drawing.Point(1769,75);
this.solvencyLabel4.Name = "solvencyLabel4";
this.solvencyLabel4.OrdinateID_Label = 0;
this.solvencyLabel4.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel4.TabIndex = 4;
this.solvencyLabel4.Text = "C1530" ;
this.solvencyLabel4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel5
//
this.solvencyLabel5.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel5.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel5.Location = new System.Drawing.Point(1662,10);
this.solvencyLabel5.Name = "solvencyLabel5";
this.solvencyLabel5.OrdinateID_Label = 8084;
this.solvencyLabel5.Size = new System.Drawing.Size(108, 65);
this.solvencyLabel5.TabIndex = 5;
this.solvencyLabel5.Text = "Estimated Risk Mitigation" ;
this.solvencyLabel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel6
//
this.solvencyLabel6.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel6.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel6.Location = new System.Drawing.Point(1662,75);
this.solvencyLabel6.Name = "solvencyLabel6";
this.solvencyLabel6.OrdinateID_Label = 0;
this.solvencyLabel6.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel6.TabIndex = 6;
this.solvencyLabel6.Text = "C1520" ;
this.solvencyLabel6.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel7
//
this.solvencyLabel7.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel7.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel7.Location = new System.Drawing.Point(1555,10);
this.solvencyLabel7.Name = "solvencyLabel7";
this.solvencyLabel7.OrdinateID_Label = 8083;
this.solvencyLabel7.Size = new System.Drawing.Size(108, 65);
this.solvencyLabel7.TabIndex = 7;
this.solvencyLabel7.Text = "Catastrophe Risk Charge before risk mitigation" ;
this.solvencyLabel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel7.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel8
//
this.solvencyLabel8.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel8.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel8.Location = new System.Drawing.Point(1555,75);
this.solvencyLabel8.Name = "solvencyLabel8";
this.solvencyLabel8.OrdinateID_Label = 0;
this.solvencyLabel8.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel8.TabIndex = 8;
this.solvencyLabel8.Text = "C1510" ;
this.solvencyLabel8.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel9
//
this.solvencyLabel9.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel9.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel9.Location = new System.Drawing.Point(1448,30);
this.solvencyLabel9.Name = "solvencyLabel9";
this.solvencyLabel9.OrdinateID_Label = 8082;
this.solvencyLabel9.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel9.TabIndex = 9;
this.solvencyLabel9.Text = "Ratio of insured persons using no formal medical care" ;
this.solvencyLabel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel9.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel10
//
this.solvencyLabel10.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel10.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel10.Location = new System.Drawing.Point(1448,75);
this.solvencyLabel10.Name = "solvencyLabel10";
this.solvencyLabel10.OrdinateID_Label = 0;
this.solvencyLabel10.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel10.TabIndex = 10;
this.solvencyLabel10.Text = "C1500" ;
this.solvencyLabel10.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel11
//
this.solvencyLabel11.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel11.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel11.Location = new System.Drawing.Point(1341,30);
this.solvencyLabel11.Name = "solvencyLabel11";
this.solvencyLabel11.OrdinateID_Label = 8081;
this.solvencyLabel11.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel11.TabIndex = 11;
this.solvencyLabel11.Text = "Unit claim cost no formal medical care" ;
this.solvencyLabel11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel11.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel12
//
this.solvencyLabel12.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel12.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel12.Location = new System.Drawing.Point(1341,75);
this.solvencyLabel12.Name = "solvencyLabel12";
this.solvencyLabel12.OrdinateID_Label = 0;
this.solvencyLabel12.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel12.TabIndex = 12;
this.solvencyLabel12.Text = "C1490" ;
this.solvencyLabel12.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel13
//
this.solvencyLabel13.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel13.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel13.Location = new System.Drawing.Point(1234,30);
this.solvencyLabel13.Name = "solvencyLabel13";
this.solvencyLabel13.OrdinateID_Label = 8080;
this.solvencyLabel13.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel13.TabIndex = 13;
this.solvencyLabel13.Text = "Ratio of insured persons using medical practitioner" ;
this.solvencyLabel13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel13.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel14
//
this.solvencyLabel14.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel14.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel14.Location = new System.Drawing.Point(1234,75);
this.solvencyLabel14.Name = "solvencyLabel14";
this.solvencyLabel14.OrdinateID_Label = 0;
this.solvencyLabel14.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel14.TabIndex = 14;
this.solvencyLabel14.Text = "C1480" ;
this.solvencyLabel14.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel15
//
this.solvencyLabel15.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel15.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel15.Location = new System.Drawing.Point(1127,30);
this.solvencyLabel15.Name = "solvencyLabel15";
this.solvencyLabel15.OrdinateID_Label = 8079;
this.solvencyLabel15.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel15.TabIndex = 15;
this.solvencyLabel15.Text = "Unit claim cost medical practitioner" ;
this.solvencyLabel15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel15.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel16
//
this.solvencyLabel16.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel16.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel16.Location = new System.Drawing.Point(1127,75);
this.solvencyLabel16.Name = "solvencyLabel16";
this.solvencyLabel16.OrdinateID_Label = 0;
this.solvencyLabel16.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel16.TabIndex = 16;
this.solvencyLabel16.Text = "C1470" ;
this.solvencyLabel16.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel17
//
this.solvencyLabel17.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel17.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel17.Location = new System.Drawing.Point(1020,30);
this.solvencyLabel17.Name = "solvencyLabel17";
this.solvencyLabel17.OrdinateID_Label = 8078;
this.solvencyLabel17.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel17.TabIndex = 17;
this.solvencyLabel17.Text = "Ratio of insured persons using hospitalisation" ;
this.solvencyLabel17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel17.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel18
//
this.solvencyLabel18.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel18.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel18.Location = new System.Drawing.Point(1020,75);
this.solvencyLabel18.Name = "solvencyLabel18";
this.solvencyLabel18.OrdinateID_Label = 0;
this.solvencyLabel18.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel18.TabIndex = 18;
this.solvencyLabel18.Text = "C1460" ;
this.solvencyLabel18.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel19
//
this.solvencyLabel19.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel19.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel19.Location = new System.Drawing.Point(913,30);
this.solvencyLabel19.Name = "solvencyLabel19";
this.solvencyLabel19.OrdinateID_Label = 8077;
this.solvencyLabel19.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel19.TabIndex = 19;
this.solvencyLabel19.Text = "Unit claim cost hospitalisation" ;
this.solvencyLabel19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel19.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel20
//
this.solvencyLabel20.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel20.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel20.Location = new System.Drawing.Point(913,75);
this.solvencyLabel20.Name = "solvencyLabel20";
this.solvencyLabel20.OrdinateID_Label = 0;
this.solvencyLabel20.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel20.TabIndex = 20;
this.solvencyLabel20.Text = "C1450" ;
this.solvencyLabel20.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel21
//
this.solvencyLabel21.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel21.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel21.Location = new System.Drawing.Point(806,30);
this.solvencyLabel21.Name = "solvencyLabel21";
this.solvencyLabel21.OrdinateID_Label = 8076;
this.solvencyLabel21.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel21.TabIndex = 21;
this.solvencyLabel21.Text = "Number of insured people" ;
this.solvencyLabel21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel21.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel22
//
this.solvencyLabel22.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel22.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel22.Location = new System.Drawing.Point(806,75);
this.solvencyLabel22.Name = "solvencyLabel22";
this.solvencyLabel22.OrdinateID_Label = 0;
this.solvencyLabel22.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel22.TabIndex = 22;
this.solvencyLabel22.Text = "C1440" ;
this.solvencyLabel22.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel23
//
this.solvencyLabel23.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel23.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel23.Location = new System.Drawing.Point(806,10);
this.solvencyLabel23.Name = "solvencyLabel23";
this.solvencyLabel23.OrdinateID_Label = 8075;
this.solvencyLabel23.Size = new System.Drawing.Size(750, 65);
this.solvencyLabel23.TabIndex = 23;
this.solvencyLabel23.Text = "Medical expense" ;
this.solvencyLabel23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel23.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel24
//
this.solvencyLabel24.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel24.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel24.Location = new System.Drawing.Point(699,30);
this.solvencyLabel24.Name = "solvencyLabel24";
this.solvencyLabel24.OrdinateID_Label = 8074;
this.solvencyLabel24.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel24.TabIndex = 24;
this.solvencyLabel24.Text = "Total pandemic exposure" ;
this.solvencyLabel24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel24.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel25
//
this.solvencyLabel25.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel25.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel25.Location = new System.Drawing.Point(699,75);
this.solvencyLabel25.Name = "solvencyLabel25";
this.solvencyLabel25.OrdinateID_Label = 0;
this.solvencyLabel25.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel25.TabIndex = 25;
this.solvencyLabel25.Text = "C1430" ;
this.solvencyLabel25.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel26
//
this.solvencyLabel26.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel26.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel26.Location = new System.Drawing.Point(592,30);
this.solvencyLabel26.Name = "solvencyLabel26";
this.solvencyLabel26.OrdinateID_Label = 8073;
this.solvencyLabel26.Size = new System.Drawing.Size(108, 45);
this.solvencyLabel26.TabIndex = 26;
this.solvencyLabel26.Text = "Number of insured people" ;
this.solvencyLabel26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel26.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel27
//
this.solvencyLabel27.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel27.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel27.Location = new System.Drawing.Point(592,75);
this.solvencyLabel27.Name = "solvencyLabel27";
this.solvencyLabel27.OrdinateID_Label = 0;
this.solvencyLabel27.Size = new System.Drawing.Size(108, 13);
this.solvencyLabel27.TabIndex = 27;
this.solvencyLabel27.Text = "C1420" ;
this.solvencyLabel27.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel28
//
this.solvencyLabel28.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel28.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel28.Location = new System.Drawing.Point(592,10);
this.solvencyLabel28.Name = "solvencyLabel28";
this.solvencyLabel28.OrdinateID_Label = 8072;
this.solvencyLabel28.Size = new System.Drawing.Size(215, 65);
this.solvencyLabel28.TabIndex = 28;
this.solvencyLabel28.Text = "Income protection" ;
this.solvencyLabel28.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
this.solvencyLabel28.TextAlign = System.Drawing.ContentAlignment.TopCenter;
//
// solvencyLabel29
//
this.solvencyLabel29.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel29.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel29.Location = new System.Drawing.Point(274,75);
this.solvencyLabel29.Name = "solvencyLabel29";
this.solvencyLabel29.OrdinateID_Label = 8087;
this.solvencyLabel29.Size = new System.Drawing.Size(254, 15);
this.solvencyLabel29.TabIndex = 29;
this.solvencyLabel29.Text = "Health Catastrophe risk - Pandemic" ;
this.solvencyLabel29.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel30
//
this.solvencyLabel30.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel30.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel30.Location = new System.Drawing.Point(542,75);
this.solvencyLabel30.Name = "solvencyLabel30";
this.solvencyLabel30.OrdinateID_Label = 0;
this.solvencyLabel30.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel30.TabIndex = 30;
this.solvencyLabel30.Text = "" ;
this.solvencyLabel30.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel31
//
this.solvencyLabel31.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel31.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel31.Location = new System.Drawing.Point(281,95);
this.solvencyLabel31.Name = "solvencyLabel31";
this.solvencyLabel31.OrdinateID_Label = 8088;
this.solvencyLabel31.Size = new System.Drawing.Size(247, 15);
this.solvencyLabel31.TabIndex = 31;
this.solvencyLabel31.Text = "Other countries to be considered in the Pandemic" ;
this.solvencyLabel31.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyLabel32
//
this.solvencyLabel32.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel32.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel32.Location = new System.Drawing.Point(542,95);
this.solvencyLabel32.Name = "solvencyLabel32";
this.solvencyLabel32.OrdinateID_Label = 0;
this.solvencyLabel32.Size = new System.Drawing.Size(50, 13);
this.solvencyLabel32.TabIndex = 32;
this.solvencyLabel32.Text = "R4410" ;
this.solvencyLabel32.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// solvencyCurrencyTextBox33
//
this.solvencyCurrencyTextBox33.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox33.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox33.Location = new System.Drawing.Point(592,115);
this.solvencyCurrencyTextBox33.Name = "solvencyCurrencyTextBox33";
this.solvencyCurrencyTextBox33.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox33.TabIndex = 33;
this.solvencyCurrencyTextBox33.ColName = "R4410C1420";
this.solvencyCurrencyTextBox33.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox33.Enabled = false;
this.solvencyCurrencyTextBox33.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox34
//
this.solvencyCurrencyTextBox34.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox34.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox34.Location = new System.Drawing.Point(699,115);
this.solvencyCurrencyTextBox34.Name = "solvencyCurrencyTextBox34";
this.solvencyCurrencyTextBox34.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox34.TabIndex = 34;
this.solvencyCurrencyTextBox34.ColName = "R4410C1430";
this.solvencyCurrencyTextBox34.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox34.Enabled = false;
this.solvencyCurrencyTextBox34.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox35
//
this.solvencyCurrencyTextBox35.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox35.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Integer;
this.solvencyCurrencyTextBox35.Location = new System.Drawing.Point(806,115);
this.solvencyCurrencyTextBox35.Name = "solvencyCurrencyTextBox35";
this.solvencyCurrencyTextBox35.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox35.TabIndex = 35;
this.solvencyCurrencyTextBox35.ColName = "R4410C1440";
this.solvencyCurrencyTextBox35.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox36
//
this.solvencyCurrencyTextBox36.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox36.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox36.Location = new System.Drawing.Point(913,115);
this.solvencyCurrencyTextBox36.Name = "solvencyCurrencyTextBox36";
this.solvencyCurrencyTextBox36.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox36.TabIndex = 36;
this.solvencyCurrencyTextBox36.ColName = "R4410C1450";
this.solvencyCurrencyTextBox36.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox37
//
this.solvencyCurrencyTextBox37.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox37.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox37.Location = new System.Drawing.Point(1020,115);
this.solvencyCurrencyTextBox37.Name = "solvencyCurrencyTextBox37";
this.solvencyCurrencyTextBox37.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox37.TabIndex = 37;
this.solvencyCurrencyTextBox37.ColName = "R4410C1460";
this.solvencyCurrencyTextBox37.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox38
//
this.solvencyCurrencyTextBox38.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox38.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox38.Location = new System.Drawing.Point(1127,115);
this.solvencyCurrencyTextBox38.Name = "solvencyCurrencyTextBox38";
this.solvencyCurrencyTextBox38.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox38.TabIndex = 38;
this.solvencyCurrencyTextBox38.ColName = "R4410C1470";
this.solvencyCurrencyTextBox38.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox39
//
this.solvencyCurrencyTextBox39.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox39.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox39.Location = new System.Drawing.Point(1234,115);
this.solvencyCurrencyTextBox39.Name = "solvencyCurrencyTextBox39";
this.solvencyCurrencyTextBox39.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox39.TabIndex = 39;
this.solvencyCurrencyTextBox39.ColName = "R4410C1480";
this.solvencyCurrencyTextBox39.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox40
//
this.solvencyCurrencyTextBox40.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox40.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox40.Location = new System.Drawing.Point(1341,115);
this.solvencyCurrencyTextBox40.Name = "solvencyCurrencyTextBox40";
this.solvencyCurrencyTextBox40.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox40.TabIndex = 40;
this.solvencyCurrencyTextBox40.ColName = "R4410C1490";
this.solvencyCurrencyTextBox40.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox41
//
this.solvencyCurrencyTextBox41.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox41.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox41.Location = new System.Drawing.Point(1448,115);
this.solvencyCurrencyTextBox41.Name = "solvencyCurrencyTextBox41";
this.solvencyCurrencyTextBox41.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox41.TabIndex = 41;
this.solvencyCurrencyTextBox41.ColName = "R4410C1500";
this.solvencyCurrencyTextBox41.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox42
//
this.solvencyCurrencyTextBox42.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox42.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox42.Location = new System.Drawing.Point(1555,115);
this.solvencyCurrencyTextBox42.Name = "solvencyCurrencyTextBox42";
this.solvencyCurrencyTextBox42.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox42.TabIndex = 42;
this.solvencyCurrencyTextBox42.ColName = "R4410C1510";
this.solvencyCurrencyTextBox42.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//
// solvencyCurrencyTextBox43
//
this.solvencyCurrencyTextBox43.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox43.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox43.Location = new System.Drawing.Point(1662,115);
this.solvencyCurrencyTextBox43.Name = "solvencyCurrencyTextBox43";
this.solvencyCurrencyTextBox43.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox43.TabIndex = 43;
this.solvencyCurrencyTextBox43.ColName = "R4410C1520";
this.solvencyCurrencyTextBox43.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox43.Enabled = false;
this.solvencyCurrencyTextBox43.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox44
//
this.solvencyCurrencyTextBox44.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox44.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox44.Location = new System.Drawing.Point(1769,115);
this.solvencyCurrencyTextBox44.Name = "solvencyCurrencyTextBox44";
this.solvencyCurrencyTextBox44.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox44.TabIndex = 44;
this.solvencyCurrencyTextBox44.ColName = "R4410C1530";
this.solvencyCurrencyTextBox44.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox44.Enabled = false;
this.solvencyCurrencyTextBox44.BackColor = System.Drawing.Color.Gray;
//
// solvencyCurrencyTextBox45
//
this.solvencyCurrencyTextBox45.BorderStyle = System.Windows.Forms.BorderStyle.None;
this.solvencyCurrencyTextBox45.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Monetry;
this.solvencyCurrencyTextBox45.Location = new System.Drawing.Point(1876,115);
this.solvencyCurrencyTextBox45.Name = "solvencyCurrencyTextBox45";
this.solvencyCurrencyTextBox45.Size = new System.Drawing.Size(100, 13);
this.solvencyCurrencyTextBox45.TabIndex = 45;
this.solvencyCurrencyTextBox45.ColName = "R4410C1540";
this.solvencyCurrencyTextBox45.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
this.solvencyCurrencyTextBox45.Enabled = false;
this.solvencyCurrencyTextBox45.BackColor = System.Drawing.Color.Gray;
//
// solvencyButton46
//
this.solvencyButton46.ColName = "";
this.solvencyButton46.TableNames = "";
this.solvencyButton46.Location = new System.Drawing.Point(7,112);
this.solvencyButton46.Name = "solvencyButton46";
this.solvencyButton46.Size = new System.Drawing.Size(50, 20);
this.solvencyButton46.TabIndex = 46;
this.solvencyButton46.Text = "Delete";
this.solvencyButton46.UseVisualStyleBackColor = true;
this.solvencyButton46.Click += new System.EventHandler(this.btnDel_Click);
//
// solvencyLabel47
//
this.solvencyLabel47.BackColor = System.Drawing.Color.Transparent;
this.solvencyLabel47.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.String;
this.solvencyLabel47.Location = new System.Drawing.Point(64,92);
this.solvencyLabel47.Name = "solvencyLabel47";
this.solvencyLabel47.OrdinateID_Label = 8089;
this.solvencyLabel47.Size = new System.Drawing.Size(200, 13);
this.solvencyLabel47.TabIndex = 47;
this.solvencyLabel47.Text = "Issuer country/country of residence" ;
this.solvencyLabel47.TextAlign = System.Drawing.ContentAlignment.TopLeft;
//
// SolvencyDataComboBox48
//
this.SolvencyDataComboBox48.ColumnType = SolvencyII.Domain.ENumerators.SolvencyDataType.Code;
this.SolvencyDataComboBox48.Location = new System.Drawing.Point(64,112);
this.SolvencyDataComboBox48.Name = "SolvencyDataComboBox48";
this.SolvencyDataComboBox48.Size = new System.Drawing.Size(200, 13);
this.SolvencyDataComboBox48.TabIndex = 48;
this.SolvencyDataComboBox48.ColName = "PAGES2C_LX";
this.SolvencyDataComboBox48.AxisID = 1530;
this.SolvencyDataComboBox48.OrdinateID = 8089;
this.SolvencyDataComboBox48.StartOrder = 1;
this.SolvencyDataComboBox48.NextOrder = 100000;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F); 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font; 
            this.AutoScroll = true;
this.Controls.Add(this.solvencyButton0);
this.Controls.Add(this.solvencyLabel1);
this.Controls.Add(this.solvencyLabel2);
this.Controls.Add(this.solvencyLabel3);
this.Controls.Add(this.solvencyLabel4);
this.Controls.Add(this.solvencyLabel5);
this.Controls.Add(this.solvencyLabel6);
this.Controls.Add(this.solvencyLabel7);
this.Controls.Add(this.solvencyLabel8);
this.Controls.Add(this.solvencyLabel9);
this.Controls.Add(this.solvencyLabel10);
this.Controls.Add(this.solvencyLabel11);
this.Controls.Add(this.solvencyLabel12);
this.Controls.Add(this.solvencyLabel13);
this.Controls.Add(this.solvencyLabel14);
this.Controls.Add(this.solvencyLabel15);
this.Controls.Add(this.solvencyLabel16);
this.Controls.Add(this.solvencyLabel17);
this.Controls.Add(this.solvencyLabel18);
this.Controls.Add(this.solvencyLabel19);
this.Controls.Add(this.solvencyLabel20);
this.Controls.Add(this.solvencyLabel21);
this.Controls.Add(this.solvencyLabel22);
this.Controls.Add(this.solvencyLabel23);
this.Controls.Add(this.solvencyLabel24);
this.Controls.Add(this.solvencyLabel25);
this.Controls.Add(this.solvencyLabel26);
this.Controls.Add(this.solvencyLabel27);
this.Controls.Add(this.solvencyLabel28);
this.Controls.Add(this.solvencyLabel29);
this.Controls.Add(this.solvencyLabel30);
this.Controls.Add(this.solvencyLabel31);
this.Controls.Add(this.solvencyLabel32);
this.Controls.Add(this.solvencyCurrencyTextBox33);
this.Controls.Add(this.solvencyCurrencyTextBox34);
this.Controls.Add(this.solvencyCurrencyTextBox35);
this.Controls.Add(this.solvencyCurrencyTextBox36);
this.Controls.Add(this.solvencyCurrencyTextBox37);
this.Controls.Add(this.solvencyCurrencyTextBox38);
this.Controls.Add(this.solvencyCurrencyTextBox39);
this.Controls.Add(this.solvencyCurrencyTextBox40);
this.Controls.Add(this.solvencyCurrencyTextBox41);
this.Controls.Add(this.solvencyCurrencyTextBox42);
this.Controls.Add(this.solvencyCurrencyTextBox43);
this.Controls.Add(this.solvencyCurrencyTextBox44);
this.Controls.Add(this.solvencyCurrencyTextBox45);
this.Controls.Add(this.solvencyButton46);
this.Controls.Add(this.solvencyLabel47);
this.Controls.Add(this.SolvencyDataComboBox48);
            this.Name = "SR_27_01_01_24__sol2__2_0_1_ctrl"; 
            this.Size = new System.Drawing.Size(2033, 138); 
            this.Load += new System.EventHandler(this.BoundControl_Load);
            this.ResumeLayout(false); 
            this.PerformLayout(); 

      } 
private SolvencyButton solvencyButton0;
private SolvencyLabel solvencyLabel1;
private SolvencyLabel solvencyLabel2;
private SolvencyLabel solvencyLabel3;
private SolvencyLabel solvencyLabel4;
private SolvencyLabel solvencyLabel5;
private SolvencyLabel solvencyLabel6;
private SolvencyLabel solvencyLabel7;
private SolvencyLabel solvencyLabel8;
private SolvencyLabel solvencyLabel9;
private SolvencyLabel solvencyLabel10;
private SolvencyLabel solvencyLabel11;
private SolvencyLabel solvencyLabel12;
private SolvencyLabel solvencyLabel13;
private SolvencyLabel solvencyLabel14;
private SolvencyLabel solvencyLabel15;
private SolvencyLabel solvencyLabel16;
private SolvencyLabel solvencyLabel17;
private SolvencyLabel solvencyLabel18;
private SolvencyLabel solvencyLabel19;
private SolvencyLabel solvencyLabel20;
private SolvencyLabel solvencyLabel21;
private SolvencyLabel solvencyLabel22;
private SolvencyLabel solvencyLabel23;
private SolvencyLabel solvencyLabel24;
private SolvencyLabel solvencyLabel25;
private SolvencyLabel solvencyLabel26;
private SolvencyLabel solvencyLabel27;
private SolvencyLabel solvencyLabel28;
private SolvencyLabel solvencyLabel29;
private SolvencyLabel solvencyLabel30;
private SolvencyLabel solvencyLabel31;
private SolvencyLabel solvencyLabel32;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox33;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox34;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox35;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox36;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox37;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox38;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox39;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox40;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox41;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox42;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox43;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox44;
private SolvencyCurrencyTextBox solvencyCurrencyTextBox45;
private SolvencyButton solvencyButton46;
private SolvencyLabel solvencyLabel47;
private SolvencyDataComboBox SolvencyDataComboBox48;

   }
}

